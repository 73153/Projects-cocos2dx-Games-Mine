Author: Mohammad Azam Website: www.highoncoding.com

Ghetto Birds is a clone of Angry Birds iPhone game. Ghetto Birds uses Cocos2d, Kobold2d, LevelHelper, SpriteHelper and Box2d. This game is specially created to be presented at the 360iDev conference on September 9 at Denver. You can register for the conference using http://360idev.com/ link. 

<img src="http://www.highoncoding.com/articleimages/ghetto_birds_github.png">

All the screencasts related to implementing Ghetto Birds will be hosted on YouTube. 

http://www.youtube.com/user/azamsharp?feature=mhee

All the articles related to implementing Ghetto Birds will be hosted on www.highoncoding.com. 

Special thanks to Chris for providing awesome artwork for Ghetto Birds. 