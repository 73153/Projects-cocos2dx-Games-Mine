//
//  PXSimpleTableSection+Private.h
//  PXSimpleTableAdapter
//
//  Created by Alex Rozanski on 25/03/2011.
//  Copyright 2011 Alex Rozanski. All rights reserved.
//

#import "PXSimpleTableSection.h"

@interface PXSimpleTableSection ()

@property (nonatomic, readwrite, assign) PXSimpleTableAdapter *adapter;

@end