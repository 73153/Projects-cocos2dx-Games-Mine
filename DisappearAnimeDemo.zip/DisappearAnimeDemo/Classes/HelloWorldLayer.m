//
//  HelloWorldLayer.m
//  DisappearAnimeDemo
//
//  Created by SuperSu on 11-9-12.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super init])) {
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"DisappearAnime Demo" fontName:@"Marker Felt" fontSize:32];
		label.position =  ccp( 240, 300);
		[self addChild: label];
		
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"DisappearAnime.plist"];
		NSMutableArray *animFrames = [NSMutableArray array];
		for(int i = 1; i < 5; i++) {
			
			CCSpriteFrame *frame = [[CCSpriteFrameCache sharedSpriteFrameCache] 
									spriteFrameByName:[NSString stringWithFormat:@"%d.png",i]];
			[animFrames addObject:frame];
		}
		CCAnimation *animation = [CCAnimation animationWithFrames:animFrames delay:0.05f];
		[[CCAnimationCache sharedAnimationCache] addAnimation:animation name:@"DisappearAnime"];
		
		self.isTouchEnabled = YES;
	}
	return self;
}

-(void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

-(BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent *)event
{
	return YES;
}

-(void) ccTouchEnded:(UITouch*)touch withEvent:(UIEvent *)event
{
	CGPoint touchLocation = [[CCDirector sharedDirector] convertToGL:[touch locationInView: [touch view]]];

	CCSprite *grossini = [CCSprite node];
	grossini.position = touchLocation;
	grossini.color = ccc3(CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255);
	grossini.scale = 1.0f + CCRANDOM_0_1() * 1.0f;
	[self addChild:grossini z:1];
	
	CCAnimationCache *animCache = [CCAnimationCache sharedAnimationCache];
	
	CCAnimation *normal = [animCache animationByName:@"DisappearAnime"];
	normal.delay = 0.05f + CCRANDOM_0_1() * 0.1f;
	[grossini runAction:[CCSequence actions:[CCAnimate actionWithAnimation:normal], 
						 [CCCallFuncN actionWithTarget:self selector:@selector(removeSprite:)],
						 nil]];
}


-(void)removeSprite:(CCNode *)n
{
	[self removeChild:n cleanup:YES];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
