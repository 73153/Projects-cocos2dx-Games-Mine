//
//  BBDatamanager.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#ifndef __BaccizBooks__BBDatamanager__
#define __BaccizBooks__BBDatamanager__

#include "cocos2d.h"
#include "CCBReader.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

class BBMainDataManager: public cocos2d::CCObject  {
    
private:
    
    BBMainDataManager(void);
    virtual ~BBMainDataManager(void);
    
public:
    
    CCBReader *cocosBuilderReader;
    CCNodeLoader *cocosBuilderLoader;
    
    //Default
    bool init(void);
    static BBMainDataManager* sharedManager(void);
    
    //Variables
    int type;
    const char *mazeName;
    int currentLevel;
};

#endif /* defined(__BaccizBooks__BBDatamanager__) */

