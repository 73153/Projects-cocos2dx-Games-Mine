//
//  BBMazeGameScene.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 13/02/13.
//
//

#ifndef __BaccizBooks__BBMazeGameScene__
#define __BaccizBooks__BBMazeGameScene__

#include "cocos2d.h"
#include "cocos-ext.h"
#include "BBAStarNode.h"
#include "BBAStarPathNode.h"

USING_NS_CC;
USING_NS_CC_EXT;

class BBMazeGameScene:public CCLayer
{
private:
    virtual void onEnter();
    virtual void onExit();

    BBMazeGameScene();
    ~BBMazeGameScene();
    
public:
     static cocos2d::CCScene* scene();
    CCNode *gridNode; //Where we draw everything
    
    BBAStarNode *touchedNode;//
        
    CCArray *gridArray;
    CCPointArray *touchArray;
    
    CCPointArray *testArray;
    
    CCArray *startCordArray;
    CCArray *endCordArray;
    
    CCPoint gridSize;
    CCPoint touchPointNode;
    
    CCPoint previousFarmerPosition;
    CCPoint currentFarmerPosition;
    
    //start point
    CCPoint sPoint;
    
    CCSprite *farmerSprite;
    CCSprite *aCow;
    
    float nodeSpace;//The space between each node
         
    bool isTouchedNodeIsNew;//Where we touched
    bool isPathFound;
    bool isPixelReading;
    
    //temp
    float redValue;

    GLubyte pixelColors[4];
      
    //render texture
    CCSprite *blackBackgroundSprite;
    CCSprite *renderSprite;
    CCRenderTexture *renderTarget;
    
    //Particles
    CCParticleSystem *addParticleEffectToTexture;
    CCSprite *particalSprite;
    
    //Initialize variables
    void initializeVariables();
    
    //UI
    void addBgWithObstacles();
    
    //functionality
    void addWall();
    void addNeighbourNodeToGridNode(BBAStarNode *node,int x,int y);
    void flipNodeWithTouchedNode();
    void findPath();
    bool scanForObstacles(CCPoint point);
    void stopFarmerAnimation();
    void callCowAnimation();
    void stopCowAnimation();
    void removeLoadLabel();
    
    //Menu
    CCMenuItemSprite *prevLvlMenuItem;
    CCMenuItemSprite *nextLvlMenuItem;
    
    void replaceScene();
    void gotoMenuScene();
    void goToNextScene(CCMenuItemSprite *sender); //temp NextScene
    void goToPreviousScene(CCMenuItemSprite *sender); // temp PreviouScene
    
    //catMullPoints
    //-(NSMutableArray *)genCatmullRomSplinesWithPoints:(NSMutableArray *)arrOriginalPoints withNum:(int)num withSegments:(int)segments
       
   static CCPointArray* genCatmullRomSplinesWithPoints(CCPointArray *arrOriginalPoints,int num,int segments);
        
    //update;
    void update(CCTime dt);
    void checkPath(CCTime dt);
    
    //draw
    void draw();
       
    //touches
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(CCSet *pTouches, CCEvent *pEvent);
};

#endif /* defined(__BaccizBooks__BBMazeGameScene__) */
