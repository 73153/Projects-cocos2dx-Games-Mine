//
//  BBMazeGameScene.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 13/02/13.
//
//

#include "BBMazeGameScene.h"
#include "BBMainDataManager.h"
#include "BBMenuScene.h"
#include "BBUtility.h"

#pragma mark - Scene
CCScene* BBMazeGameScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBMazeGameScene();
    scene->addChild(layer);
    layer->release();
    return scene;
}

#pragma mark - Init
BBMazeGameScene::BBMazeGameScene()
{
    this->isPixelReading = true;
    
    //call to initialize Variables
    this->initializeVariables();
    
    //call to UI methods
    this->addBgWithObstacles();

    //getting winsize
    CCSize s = CCDirector::sharedDirector()->getWinSize();
    
    //render Texture
    renderTarget = CCRenderTexture::create(s.width, s.height, kCCTexture2DPixelFormat_RGBA8888);
    
    renderTarget->retain();
    renderTarget->setPosition(ccp(s.width/2, s.height/2));
    this->addChild(renderTarget,-1);

    renderSprite = CCSprite::create("fire.png");
    renderSprite->retain();

    //Reset MenuItem
    CCMenuItemFont *resetBtn = CCMenuItemFont::create("Reset", this, menu_selector(BBMazeGameScene::replaceScene));
    resetBtn->setPosition(ccp(945,700));
    
    //BackBtn MenuItem
    CCMenuItemFont *backBtn = CCMenuItemFont::create("Back", this, menu_selector(BBMazeGameScene::gotoMenuScene));
    backBtn->setPosition(ccp(50,700));
    
    CCMenu* menu1 = CCMenu::create(resetBtn, backBtn, NULL);
    menu1->setPosition(CCPointZero);
    addChild(menu1,17);

    //call to update method
    this->schedule(schedule_selector(BBMazeGameScene::update));
    
    //call to checkPath method
    this->schedule(schedule_selector(BBMazeGameScene::checkPath),1); 
}

void BBMazeGameScene::onEnter()
{
    CCLayer::onEnter();
    
    //FarmerAnimation spriteSheet
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("FarmerAnimation.plist");
    //CowAnimation spritesheet
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("CowAnimation.plist");
    BBUtility::addGameAnimationsToAnimationCache("AnimationData.plist");
}

void BBMazeGameScene::onExit()
{
    CCLayer::onExit();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("FarmerAnimation.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("CowAnimation.plist");
}

void BBMazeGameScene::initializeVariables()
{
    this->setTouchEnabled(true);
    this->isPathFound = false;
    
    //initialize variables
    this->redValue = 0;
    
    this->gridSize = ccp(128,98);
    this->nodeSpace = 8.0f;
    this->touchPointNode = ccp(0, 0);

    this->isTouchedNodeIsNew = false;
    
    //touchArray
    this->touchArray = CCPointArray::create(100);
    this->touchArray->retain();

    //startArray
    this->startCordArray = CCArray::create();
    this->startCordArray->retain();
     
    //endArray
    this->endCordArray = CCArray::create();
    this->endCordArray->retain();

    //gridArray
    this->gridArray = CCArray::createWithCapacity((int)gridSize.x);
    this->gridArray->retain();

    //separate grid node
    this->gridNode = new CCNode();
    gridNode->setPosition(ccp(0, 0));
    this->addChild(gridNode,3);

    for(int x = 0; x<gridSize.x; x++) {
        
        this->gridArray->addObject(this->gridArray->createWithCapacity((int)gridSize.y));
    }
    
    //Create AStar nodes and place them in the grid
    for(int x = 0; x<gridSize.x; x++)
    {
        for(int y = 0;y<gridSize.y;y++)
        {
            BBAStarNode* node = new BBAStarNode();
            
            CCPoint pos = ccp(x*nodeSpace+nodeSpace/2, y*nodeSpace+nodeSpace/2);
            node->position = pos;
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
            tempArray->insertObject(node, y);
        }
    }
    //Add neighbour nodes
    for(int x=0; x<gridSize.x; x++)
    {
        for(int y=0; y<gridSize.y; y++)
        {
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
            BBAStarNode *node = (BBAStarNode*)tempArray->objectAtIndex(y);
            node->active = false;
            
            //Add self as neighbor to neighboring nodes
            this->addNeighbourNodeToGridNode(node, x-1, y-1);
            this->addNeighbourNodeToGridNode(node, x-1, y);
            this->addNeighbourNodeToGridNode(node, x-1, y+1);
            this->addNeighbourNodeToGridNode(node, x, y-1);

            this->addNeighbourNodeToGridNode(node, x, y+1);
            this->addNeighbourNodeToGridNode(node, x+1, y-1);
            this->addNeighbourNodeToGridNode(node, x+1, y);
            this->addNeighbourNodeToGridNode(node, x+1, y+1);
        }
    }
}

#pragma mark - UI
void BBMazeGameScene::addBgWithObstacles()
{   
    //loading plist
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BBMazeGamePlayDetails.plist");
    
    CCDictionary *allMazesInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    CCDictionary *aMazeDict = (CCDictionary*)allMazesInfoDict->valueForKey(BBMainDataManager::sharedManager()->mazeName);
    
    this->startCordArray = (CCArray*)aMazeDict->valueForKey("startPointArray");
    this->endCordArray = (CCArray*)aMazeDict->valueForKey("endPointArray");
    
    //Green Bg
    CCSprite *backGround = CCSprite::create("Bg green.png");
    this->addChild(backGround,0);
    backGround->setPosition(ccp(512, 384));
    
    //Yellow Bg
    CCSprite *yellowSprite = CCSprite::create("Bg yellow.png");
    this->addChild(yellowSprite,-2);
    yellowSprite->setPosition(ccp(512, 384));
    
    //getting winsize
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    
    //temp PreviousLevel button
    CCSprite *normalSprPrev = CCSprite::create("prev.png");
    CCSprite *selectedSprPrev = CCSprite::create("prev.png");
    
    prevLvlMenuItem = CCMenuItemSprite::create(normalSprPrev, selectedSprPrev, this, menu_selector(BBMazeGameScene::goToPreviousScene));
    prevLvlMenuItem->setPosition(CCPoint(size.width/2 - 450, size.height/2 + 230));
    
    if(BBMainDataManager::sharedManager()->currentLevel == 1){
        prevLvlMenuItem->setVisible(false);
    }
    
    //temp NextLevel button
    CCSprite *normalSprNext = CCSprite::create("next.png");
    CCSprite *selectedSprNext = CCSprite::create("next.png");
    
    nextLvlMenuItem = CCMenuItemSprite::create(normalSprNext, selectedSprNext, this, menu_selector(BBMazeGameScene::goToNextScene));
    nextLvlMenuItem->setPosition(CCPoint(size.width/2 + 450, size.height/2 + 230));
    
    if(BBMainDataManager::sharedManager()->currentLevel == 13){
        nextLvlMenuItem->setVisible(false);
    }
    
    CCMenu *tempMenu = CCMenu::create(prevLvlMenuItem, nextLvlMenuItem,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
    //Add BG
    const char *backGroundImageName = (const char *)aMazeDict->valueForKey("BackgroundSpriteName")->getCString();
    this->blackBackgroundSprite = CCSprite::create(backGroundImageName);
    this->blackBackgroundSprite->setPosition(ccp(512, 384));
    this->addChild(this->blackBackgroundSprite,-1);
    
/*
    //startPoint
    for(int i = 0; i<this->startCordArray->count(); i++)
    {
        CCString *aPointStr  =  (CCString *)this->startCordArray->objectAtIndex(i);
        CCPoint point  =  CCPointFromString(aPointStr->getCString());
        CCSprite *startSprite = CCSprite::create("start_button.png");
        startSprite->setScale(2);
        startSprite->setPosition(ccp(point.x*nodeSpace+nodeSpace/2, point.y*nodeSpace+nodeSpace/2));
        this->gridNode->addChild(startSprite,2);
    }
    
    //endPoint
    for(int i = 0; i<this->endCordArray->count(); i++)
    {
        CCString *aPointStr  =  (CCString *)this->endCordArray->objectAtIndex(i);
        CCPoint point  =  CCPointFromString(aPointStr->getCString());
        CCSprite *endSprite = CCSprite::create("end_button.png");
        endSprite->setPosition(ccp(point.x*nodeSpace+nodeSpace/2, point.y*nodeSpace+nodeSpace/2));
        this->gridNode->addChild(endSprite,2);
    }
*/
    
    //startPoint
    //add Farmer sprite
    this->farmerSprite = CCSprite::create("Farmer001.png");
    this->addChild(this->farmerSprite,30);
    this->farmerSprite->setPosition(ccp(110, 400));
    this->farmerSprite->setScale(0.5);
    this->farmerSprite->setAnchorPoint(ccp(0.5, 0));
    
    this->previousFarmerPosition = this->farmerSprite->getPosition();
    this->currentFarmerPosition = this->farmerSprite->getPosition();
    
    //endPoint
    //add Cow sprite
    this->aCow = CCSprite::create("Vaca001.png");
    this->aCow->setScale(0.5);
    this->addChild(this->aCow,5);
    this->aCow->setPosition(ccp(940, 375));
    
    //load Objects for MazeGame from plist
    CCArray *objectsArr = (CCArray*)aMazeDict->valueForKey("objects");
    
    CCObject *aObj = NULL;
    CCARRAY_FOREACH(objectsArr, aObj)
    {
        CCDictionary *objectDetailsDict = (CCDictionary*)aObj;
        
        //load and set Image Name
        const char *imageName = (const char *)objectDetailsDict->valueForKey("imageName")->getCString();
        CCSprite *aSpr = CCSprite::create(imageName);
        
        //load and set Image Position
        CCString *aPointStr = (CCString *)objectDetailsDict->valueForKey("imagePos");
        CCPoint point = CCPointFromString(aPointStr->getCString());
        aSpr->setPosition(point);
        
        //load and set Image Scale factor
        float scaleX = (float)objectDetailsDict->valueForKey("scaleXfactor")->floatValue();
        float scaleY = (float)objectDetailsDict->valueForKey("scaleYfactor")->floatValue();
        aSpr->setScaleX(scaleX);
        aSpr->setScaleY(scaleY);
        
        //load and set Image Rotation
        float rotation = (float)objectDetailsDict->valueForKey("rotation")->floatValue();
        aSpr->setRotation(rotation);
        
        //load and set Image flip movement
        bool flipXfactor = (bool)objectDetailsDict->valueForKey("flipXfactor")->boolValue();
        bool flipYfactor = (bool)objectDetailsDict->valueForKey("flipYfactor")->boolValue();
        aSpr->setFlipX(flipXfactor);
        aSpr->setFlipY(flipYfactor);
        
        this->addChild(aSpr,3);
    }
}

#pragma mark - Restart
void BBMazeGameScene::replaceScene()
{
    //Inorder to replace with the cuurent scene we need to take the currentLevel
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMainDataManager::sharedManager()->currentLevel);
    
    BBMainDataManager::sharedManager()->mazeName = mazeName;
    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
}

void BBMazeGameScene::gotoMenuScene()
{
    CCDirector::sharedDirector()->replaceScene(BBMenuScene::scene());
}

void BBMazeGameScene::goToNextScene(CCMenuItemSprite *sender)
{
    //decrementing levelCount
    BBMainDataManager::sharedManager()->currentLevel++;
    
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMainDataManager::sharedManager()->currentLevel);
    BBMainDataManager::sharedManager()->mazeName = mazeName;
    
    if (BBMainDataManager::sharedManager()->currentLevel > 13) {
        return;
    }
    else {
        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
    }
}

void BBMazeGameScene::goToPreviousScene(CCMenuItemSprite *sender) {
    
    //decrementing levelCount
    BBMainDataManager::sharedManager()->currentLevel--;
    
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMainDataManager::sharedManager()->currentLevel);
    BBMainDataManager::sharedManager()->mazeName = mazeName;
    
    if (BBMainDataManager::sharedManager()->currentLevel < 1) {
        return;
    }
    else {
        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
    }
}

#pragma mark - Update
void BBMazeGameScene::checkPath(CCTime dt)
{
    //If path found then return
    if(this->isPathFound)
        return;
    
    //start Co-ordinate Array
    CCObject *aStartCordObj = NULL;
    CCARRAY_FOREACH(this->startCordArray, aStartCordObj)
    {
        CCString *aPointStr = (CCString *)aStartCordObj;
        CCPoint point = CCPointFromString(aPointStr->getCString());
        CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex((int)point.x);
        BBAStarNode *startNode = (BBAStarNode*)tempArray->objectAtIndex((int)point.y);
        
        //end Co-ordinate Array
        CCObject *aEndCordObj = NULL;
        CCARRAY_FOREACH(this->endCordArray, aEndCordObj)
        {
            //If path found then return
            if(this->isPathFound)
                return;
            
            CCString *aPointStr = (CCString *)aEndCordObj;
            CCPoint point = CCPointFromString(aPointStr->getCString());
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex((int)point.x);
            BBAStarNode *endNode = (BBAStarNode*)tempArray->objectAtIndex((int)point.y);
            
            //checking path
            CCPointArray *tempPathArray = BBAStarPathNode::findPathFromStartToEnd(startNode, endNode);

            if(tempPathArray->count()!=0)
            {
                this->isPathFound = true;
                CCLabelTTF *pathFoundlabel = CCLabelTTF::create("Path Found", "arial", 40);
                pathFoundlabel->setPosition(ccp(512, 700));
                this->addChild(pathFoundlabel,15);
                
                CCPointArray *tempPurePathPoints = BBMazeGameScene::genCatmullRomSplinesWithPoints(tempPathArray, tempPathArray->count(), 2);
                
                CCPointArray *curveArray = CCPointArray::create(1000);
                curveArray->retain();
                curveArray->addControlPoint(ccp(130, 400));
                
                for(int i=tempPurePathPoints->count(); i>=0; i=i-6)
                {
                    CCPoint point = tempPurePathPoints->getControlPointAtIndex(i);
                    int x = point.x;
                    int y = point.y-15;
                    
                    CCPoint tp = ccp(x, y);
                    curveArray->addControlPoint(tp);
                }
                curveArray->addControlPoint(ccp(866, 310));
                
                //Farmer Animation
                CCAnimationCache *animCacheFarmer = CCAnimationCache::sharedAnimationCache();
                CCAnimation *animationFarmer = animCacheFarmer->animationByName("Farmer");
                animationFarmer->setRestoreOriginalFrame(1);
                CCAnimate *animNFarmer = CCAnimate::create(animationFarmer);
                
                this->farmerSprite->runAction(CCRepeatForever::create(animNFarmer));
                
                int speed = 5;
                float dur = curveArray->count()/speed;
                
                CCCatmullRomTo *action = CCCatmullRomTo::create(dur, curveArray);
                CCFiniteTimeAction *seq = CCSequence::create(action,
                                                             CCCallFuncN::create(this, callfuncN_selector(BBMazeGameScene::stopFarmerAnimation)),
                                                             CCCallFunc::create(this,callfunc_selector(BBMazeGameScene::callCowAnimation)),
                                                             CCDelayTime::create(4),
                                                             CCCallFuncN::create(this, callfuncN_selector(BBMazeGameScene::stopCowAnimation)),NULL);
                
                this->farmerSprite->runAction(seq);
                
                testArray = curveArray;
                tempPurePathPoints->retain();
            }
            CC_SAFE_RELEASE(tempPathArray);
            continue;
        }
    }
}
void BBMazeGameScene::callCowAnimation() {
    
    //Cow Animation
    CCAnimationCache *animCacheVaca = CCAnimationCache::sharedAnimationCache();
    CCAnimation *animationForVaca = animCacheVaca->animationByName("Vaca");
    animationForVaca->setRestoreOriginalFrame(1);
    CCAnimate *animNVaca  =  CCAnimate::create(animationForVaca);
    this->aCow->runAction(animNVaca);
}

void BBMazeGameScene::stopFarmerAnimation(){
    
    //stop actions for Farmer and set the default Image
    this->farmerSprite->stopAllActions();
    this->farmerSprite->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Farmer001.png"));
}

void BBMazeGameScene::stopCowAnimation(){
    
    //stop actions for Cow and set the default Image
    this->aCow->stopAllActions();
    this->aCow->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Vaca001.png"));
}

CCPointArray* BBMazeGameScene::genCatmullRomSplinesWithPoints(cocos2d::CCPointArray *arrOriginalPoints, int num, int segments) {
    
    //Create Point Array
    CCPointArray *arrPathConverted = CCPointArray::create(1000);
    arrOriginalPoints->retain();
    
    float b[segments][4];
    {
        //Precompute interpolation parameters
        float t = 0.0f;
        float dt = 1.0f/(float)segments;
        
        for (int i=0; i<segments; i++, t+=dt) {
            float tt  = t*t;
            float ttt  = tt * t;
            b[i][0] = 0.5f * (-ttt + 2.0f*tt - t);
            b[i][1] = 0.5f * (3.0f*ttt -5.0f*tt +2.0f);
            b[i][2] = 0.5f * (-3.0f*ttt + 4.0f*tt + t);
            b[i][3] = 0.5f * (ttt - tt);
        }
    }
    
    {   //first control point
        int i=0;
        
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        arrOriginalPoints->addControlPoint(point);
        
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i+1);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+2);
            
            float px = (b[j][0]+b[j][1])*point.x + b[j][2]*pointPlusOne.x + b[j][3]*pointPlusTwo.x;
            float py = (b[j][0]+b[j][1])*point.y + b[j][2]*pointPlusOne.y + b[j][3]*pointPlusTwo.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }
    
    for (int i=1; i<num-2; i++) {
        
        //the first interpolated point is always the original control point
        CCPoint p;
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        p.x = point.x;
        p.y = point.y;
        
        arrPathConverted->addControlPoint(p);
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i-1);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+1);
            CCPoint pointPlusThree = arrOriginalPoints->getControlPointAtIndex(i+2);

            float px  =  b[j][0]*point.x + b[j][1]*pointPlusOne.x + b[j][2]*pointPlusTwo.x + b[j][3]*pointPlusThree.x;
            float py  =  b[j][0]*point.y + b[j][1]*pointPlusOne.y + b[j][2]*pointPlusTwo.y + b[j][3]*pointPlusThree.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }

    {   //second to last control point
        int i = num-2; 
        CCPoint p;
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        
        p.x = point.x;
        p.y = point.y;
        
        arrPathConverted->addControlPoint(p);
        
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i-1);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+1);
            
            float px  =  b[j][0]*point.x + b[j][1]*pointPlusOne.x + (b[j][2]+b[j][3])*pointPlusTwo.x;
            float py  =  b[j][0]*point.y + b[j][1]*pointPlusOne.y + (b[j][2]+b[j][3])*pointPlusTwo.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }
    
    //the very last interpolated point is the last control point
    CCPoint point = arrOriginalPoints->getControlPointAtIndex(num-1);
    arrPathConverted->addControlPoint(point);
    arrPathConverted->autorelease();
    return arrPathConverted;
}

void BBMazeGameScene::update(CCTime dt) {
    
    if(this->isPathFound) {
        
        previousFarmerPosition = currentFarmerPosition;
        currentFarmerPosition = this->farmerSprite->getPosition();
        
        //flip
        if(currentFarmerPosition.x > previousFarmerPosition.x)
            this->farmerSprite->setFlipX(false);
        
        //don't flip
        else if(currentFarmerPosition.x < previousFarmerPosition.x)
            this->farmerSprite->setFlipX(true);
        
    return;
    }
    
    if(this->isTouchedNodeIsNew) {
        
        this->flipNodeWithTouchedNode();
        this->isTouchedNodeIsNew  =  false;
    }
}

#pragma mark - OtherFunctions
void BBMazeGameScene::addNeighbourNodeToGridNode(BBAStarNode *node, int x, int y)
{
    if(x >= 0 && y>= 0 && x<gridSize.x && y<gridSize.y)
    {
        CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
        BBAStarNode *neighbour = (BBAStarNode*)tempArray->objectAtIndex(y);
        node->neighbourNodesArray->addObject(neighbour);
    }
}

void BBMazeGameScene::addWall()
{
    CCLabelTTF *loading = CCLabelTTF::create("Loading.....", "arial", 40);
    loading->setColor(ccc3(255, 0, 0));
    loading->setPosition(ccp(512, 384));
    loading->setTag(777);
    this->addChild(loading,25);
    
    bool isShouldAddWall;
    CCSize s = CCDirector::sharedDirector()->getWinSize();
    
    for(int p=0; p<s.width; p=p+6)
    {
        for(int q=0; q<s.height; q=q+6)
        {
            isShouldAddWall = this->scanForObstacles(ccp(p,q));
            if(isShouldAddWall)
            {
                int m = ((p-gridNode->getPositionX())/nodeSpace);
                int n = ((q-gridNode->getPositionY())/nodeSpace);
                CCPoint tp = ccp(m, n);
                int x = tp.x;
                int y = tp.y;
                                
                CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
                BBAStarNode *node = (BBAStarNode*)tempArray->objectAtIndex(y);
                node->isWall = true;
                node->active = false;
            }
        }
    }
    this->blackBackgroundSprite->setOpacity(0);
    CCDelayTime *delayAction = CCDelayTime::create(0.2);
    CCSequence *seq = CCSequence::createWithTwoActions(delayAction,CCCallFuncN::create(this, callfuncN_selector(BBMazeGameScene::removeLoadLabel)));
    this->runAction(seq);
    
   
    this->isPixelReading = false;
}
void BBMazeGameScene::removeLoadLabel()
{
    this->removeChildByTag(777, true);
}

bool BBMazeGameScene::scanForObstacles(CCPoint point)
{
    glReadPixels(point.x, point.y, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, &pixelColors[0]);
    
    if(pixelColors[0] == 0 && pixelColors[1] == 0 && pixelColors[0] == 0) {
        return true;
    }
    return false;
}

void BBMazeGameScene::draw()
{
   if(this->isPixelReading)
   {
       this->addWall();
   }
}


#pragma mark - Touches
void BBMazeGameScene::ccTouchesBegan(CCSet *pTouches,CCEvent *pEvent)
{
    //If path found return
    if(this->isPathFound)
        return;
    
    CCSetIterator it;
    CCTouch* touch;
    
    for( it=pTouches->begin(); it !=pTouches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        sPoint = location;
        
        //Create Particle Effect
        addParticleEffectToTexture = CCParticleSystemQuad::create("stars.plist");
        addParticleEffectToTexture->setPosition(location);
        this->addChild(addParticleEffectToTexture, -1);
        
        int x = ((location.x-gridNode->getPositionX())/nodeSpace);
        int y = ((location.y-gridNode->getPositionY())/nodeSpace);
        
        CCPoint tp = ccp(x, y);
        this->isTouchedNodeIsNew = true;
        this->touchPointNode = tp;
        this->touchArray->addControlPoint(this->touchPointNode);
    }
}

void BBMazeGameScene::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent)
{
    //If path found return
    if(this->isPathFound)
        return;
    
    //Grid Scan
    CCTouch *touch1 = (CCTouch*)pTouches->anyObject();
    CCPoint start = touch1->getLocation();
    CCPoint end = touch1->getPreviousLocation();
    
    renderTarget->begin();
    float dist = ccpDistance(start, end);
    
        if(dist>1)
        {
            int d = (int)dist;
            for(int i = 0; i<d; i++)
            {
                float difx = end.x - start.x;
                float dify = end.y - start.y;
                float delta = (float)i/dist;
                
                CCPoint t1 = ccp(start.x + (difx * delta), start.y + (dify * delta));
                int x = ((t1.x-gridNode->getPositionX())/nodeSpace);
                int y = ((t1.y-gridNode->getPositionY())/nodeSpace);
                
                CCPoint tp = ccp(x, y);
                if(tp.x!=this->touchPointNode.x || tp.y!=this->touchPointNode.y)
                    this->isTouchedNodeIsNew = true;
                
                this->touchPointNode = tp;
                this->touchArray->addControlPoint(this->touchPointNode);
                
                renderSprite->setPosition(t1);
                renderSprite->setRotation(rand() % 360);
                float r = (float)(rand()%40 / 50.f) + 0.25f;
                renderSprite->setScale(r);
                renderSprite->setColor(ccc3(25,180,200));
                
                //set position for particles
                addParticleEffectToTexture->setPosition(t1);
                
                renderSprite->visit();
            }
        }
    renderTarget->end();
}
                    
void BBMazeGameScene::ccTouchesEnded(CCSet *pTouches, CCEvent *pEvent) {
    //stop particle effect when touch stops & start in touchesbegin
    addParticleEffectToTexture->stopSystem();
}

void BBMazeGameScene::flipNodeWithTouchedNode()
{
    for(int i=0; i<touchArray->count(); i++)
    {
        CCPoint point1 = this->touchArray->getControlPointAtIndex(i);
        
        int x = point1.x;
        int y = point1.y;
        
        if(x == 0 && y == 0)
            return;
        
        if(x == gridSize.x-1 && y == gridSize.y-1)
            return;
        
        if(x<0 || y<0 || x>gridSize.x-1 || y>gridSize.y-1)
            return;
        
        CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
        touchedNode = (BBAStarNode*)tempArray->objectAtIndex(y);
        
        if(!touchedNode->isWall)
            touchedNode->active = true;
    }
    
    //Clean the Point Array
    while (touchArray->count() != 0)
        touchArray->removeControlPointAtIndex(0);
}


#pragma mark - Dealloc
BBMazeGameScene::~BBMazeGameScene()
{
//    CCLog("destructor called");
    renderSprite->release();
    renderTarget->release();
    CC_SAFE_RELEASE(this->gridArray);
    CC_SAFE_RELEASE(this->touchArray);
}

