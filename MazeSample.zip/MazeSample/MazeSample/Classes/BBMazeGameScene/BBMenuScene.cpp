//
//  BBMenuScene.cpp
//  MazeSample
//
//  Created by Manjunatha Reddy on 28/02/13.
//
//

#include "BBMenuScene.h"
#include "BBMainDataManager.h"
#include "BBMazeGameScene.h"

using namespace cocos2d;

#pragma mark - Default
CCScene* BBMenuScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBMenuScene();
    scene->addChild(layer);
    layer->release();
    return scene;
}


BBMenuScene::BBMenuScene()
{
    CCMenuItemFont *item1 = CCMenuItemFont::create("Maze1", this, menu_selector(BBMenuScene::action));
    item1->setPosition(ccp(200,484));
    item1->setTag(1);
    
    CCMenuItemFont *item2 = CCMenuItemFont::create("Maze2", this, menu_selector(BBMenuScene::action));
    item2->setPosition(ccp(350,484));
    item2->setTag(2);
    
    CCMenuItemFont *item3 = CCMenuItemFont::create("Maze3", this, menu_selector(BBMenuScene::action));
    item3->setPosition(ccp(500,484));
    item3->setTag(3);
    
    CCMenuItemFont *item4 = CCMenuItemFont::create("Maze4", this, menu_selector(BBMenuScene::action));
    item4->setPosition(ccp(650,484));
    item4->setTag(4);
    
    CCMenuItemFont *item5 = CCMenuItemFont::create("Maze5", this, menu_selector(BBMenuScene::action));
    item5->setPosition(ccp(800,484));
    item5->setTag(5);
    
    CCMenuItemFont *item6 = CCMenuItemFont::create("Maze6", this, menu_selector(BBMenuScene::action));
    item6->setPosition(ccp(200,384));
    item6->setTag(6);
    
    CCMenuItemFont *item7 = CCMenuItemFont::create("Maze7", this, menu_selector(BBMenuScene::action));
    item7->setPosition(ccp(350,384));
    item7->setTag(7);
    
    CCMenuItemFont *item8 = CCMenuItemFont::create("Maze8", this, menu_selector(BBMenuScene::action));
    item8->setPosition(ccp(500,384));
    item8->setTag(8);
    
    CCMenuItemFont *item9 = CCMenuItemFont::create("Maze9", this, menu_selector(BBMenuScene::action));
    item9->setPosition(ccp(650,384));
    item9->setTag(9);
    
    CCMenuItemFont *item10 = CCMenuItemFont::create("Maze10", this, menu_selector(BBMenuScene::action));
    item10->setPosition(ccp(800,384));
    item10->setTag(10);
    
    CCMenuItemFont *item11 = CCMenuItemFont::create("Maze11", this, menu_selector(BBMenuScene::action));
    item11->setPosition(ccp(200,284));
    item11->setTag(11);
    
    CCMenuItemFont *item12 = CCMenuItemFont::create("Maze12", this, menu_selector(BBMenuScene::action));
    item12->setPosition(ccp(350,284));
    item12->setTag(12);
    
    CCMenuItemFont *item13 = CCMenuItemFont::create("Maze13", this, menu_selector(BBMenuScene::action));
    item13->setPosition(ccp(500,284));
    item13->setTag(13);
    
    CCMenu* menu1 = CCMenu::create(item1, item2, item3, item4, item5, item6, item7, item8, item9,  item10, item11, item12, item13, NULL);
    menu1->setPosition(CCPointZero);
    this->addChild(menu1,17);
}


BBMenuScene::~BBMenuScene()
{
    //CCLog("Destructor of menuScene");
}


void BBMenuScene::action(CCMenuItemFont *sender)
{
    int tag = sender->getTag();
    BBMainDataManager::sharedManager()->currentLevel = tag;
    
    char mazeName[20];
    sprintf(mazeName, "Maze%d",tag);
    BBMainDataManager::sharedManager()->mazeName = mazeName;
    
    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
/*
switch (tag)
    {
        case 1: //goToMazeLevel-1
                BBMainDataManager::sharedManager()->mazeName = "Maze1";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 2: //goToMazeLevel-2
                BBMainDataManager::sharedManager()->mazeName = "Maze2";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 3: //goToMazeLevel-3
                BBMainDataManager::sharedManager()->mazeName = "Maze3";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 4: //goToMazeLevel-4
                BBMainDataManager::sharedManager()->mazeName = "Maze4";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 5: //goToMazeLevel-5
                BBMainDataManager::sharedManager()->mazeName = "Maze5";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 6: //goToMazeLevel-6
                BBMainDataManager::sharedManager()->mazeName = "Maze6";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 7: //goToMazeLevel-7
                BBMainDataManager::sharedManager()->mazeName = "Maze7";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 8: //goToMazeLevel-8
                BBMainDataManager::sharedManager()->mazeName = "Maze8";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 9: //goToMazeLevel-9
                BBMainDataManager::sharedManager()->mazeName = "Maze9";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 10: //goToMazeLevel-10
                BBMainDataManager::sharedManager()->mazeName = "Maze10";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 11: //goToMazeLevel-11
                BBMainDataManager::sharedManager()->mazeName = "Maze11";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 12: //goToMazeLevel-12
                BBMainDataManager::sharedManager()->mazeName = "Maze12";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        case 13: //goToMazeLevel-13
                BBMainDataManager::sharedManager()->mazeName = "Maze13";
                CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                break;
            
        default:
            break;
}*/
}

