//
//  BBAStarPathNode.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 12/02/13.
//
//

#include "BBAStarPathNode.h"

#pragma mark - Init
BBAStarPathNode::BBAStarPathNode()
{
    this->cost = 0.0f;
    this->previousNode = NULL;
}

#pragma mark - Dealloc
BBAStarPathNode::~BBAStarPathNode()
{
    //CCLog("Destructor");
}

#pragma mark - Create Node
BBAStarPathNode* BBAStarPathNode::createWithAstarNode(BBAStarNode *node)
{
    if(!node)
    {
        //CCLog("return NULL");
        return NULL;
    }
    
    BBAStarPathNode *pathNode = new BBAStarPathNode();
    pathNode->node=node;
    pathNode->autorelease();
    return pathNode;
}

#pragma mark - Find Path
CCPointArray* BBAStarPathNode::findPathFromStartToEnd(BBAStarNode *fromNode, BBAStarNode *toNode)
{
    bool isPathFound = false;
    
    CCPointArray *foundPathArray = CCPointArray::create(1000);
    foundPathArray->retain();
    
    if(fromNode->position.x == toNode->position.x && fromNode->position.y == toNode->position.y)
    {
        return NULL;
    }
    
    CCArray *openList = CCArray::create();
    openList->retain();
    
    CCArray *closedList = CCArray::create();
    closedList->retain();
    
    BBAStarPathNode *currentNode = NULL;
    BBAStarPathNode *aNode = NULL;
    
    BBAStarPathNode *startNode = BBAStarPathNode::createWithAstarNode(fromNode);
	BBAStarPathNode *endNode = BBAStarPathNode::createWithAstarNode(toNode);
    openList->addObject(startNode);
    
    while(openList->count() > 0)
    {
        currentNode = BBAStarPathNode::lowestCostInArray(openList);
        if(currentNode->node->position.x == endNode->node->position.x && currentNode->node->position.y == endNode->node->position.y)
        {
            //Path Found!
            aNode = currentNode;
            
            //CCLog("foundPathArray count is %d",foundPathArray->count());
            
             while(aNode->previousNode!=NULL)
             {
                 foundPathArray->addControlPoint(CCPointMake(aNode->node->position.x, aNode->node->position.y));
                 aNode = aNode->previousNode;
             }
             
            foundPathArray->addControlPoint(CCPointMake(aNode->node->position.x, aNode->node->position.y));
            
            isPathFound = true;
            CC_SAFE_RELEASE(openList);
            CC_SAFE_RELEASE(closedList);
            
            return foundPathArray;
        }
        else
        {
            //still searching
            closedList->addObject(currentNode);
            openList->removeObject(currentNode);
            
            CCObject *aNodeObj = NULL;
            CCARRAY_FOREACH(currentNode->node->neighbourNodesArray, aNodeObj)
            {
                BBAStarNode *sampleNode = (BBAStarNode *)aNodeObj;
                BBAStarPathNode *aNode = (BBAStarPathNode::createWithAstarNode(sampleNode));
                
                float a = currentNode->node->costToNode(aNode->node);
                float b = aNode->node->costToNode(endNode->node);
                
                aNode->cost = currentNode->cost + a + b;
                
                aNode->previousNode = currentNode;
                
                if(aNode->node->active && !(BBAStarPathNode::isPathNodeIsInList(aNode, openList))&& !(BBAStarPathNode::isPathNodeIsInList(aNode, closedList)) )
                {
                    openList->addObject(aNode);
                }
            }
        }
    }
    
    CC_SAFE_RELEASE(openList);
    CC_SAFE_RELEASE(closedList);
    
    //NO path Found
    return foundPathArray;
}


BBAStarPathNode* BBAStarPathNode::lowestCostInArray(CCArray *inArray)
{
    BBAStarPathNode *lowest = NULL;
    
    CCObject *aNodeObj = NULL;
    CCARRAY_FOREACH(inArray, aNodeObj)
    {
        BBAStarPathNode *aNode = (BBAStarPathNode *)aNodeObj;
        if(!lowest||aNode->cost<lowest->cost)
        {
            lowest = aNode;
        }
    }
    return lowest;
}

bool BBAStarPathNode::isPathNodeIsInList(BBAStarPathNode *aNode,CCArray *list)
{
    CCObject *aNodeObj = NULL;
    CCARRAY_FOREACH(list, aNodeObj)
    {
        BBAStarPathNode *bNode = (BBAStarPathNode *)aNodeObj;
        if(aNode->node->position.x==bNode->node->position.x && aNode->node->position.y==bNode->node->position.y)
        {
            return true;
        }
    }
    return false;
}

