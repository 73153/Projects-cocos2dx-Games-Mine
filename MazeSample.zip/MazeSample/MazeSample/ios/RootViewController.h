//
//  MazeSampleAppController.h
//  MazeSample
//
//  Created by Manjunatha Reddy on 14/02/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
