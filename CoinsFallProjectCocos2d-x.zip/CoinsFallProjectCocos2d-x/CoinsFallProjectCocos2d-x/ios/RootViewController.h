//
//  CoinsFallProjectCocos2d_xAppController.h
//  CoinsFallProjectCocos2d-x
//
//  Created by Vivek Sharma on 10/10/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
