//
//  RootViewController.h
//  FastTapRedux
//
//  Created by William Chaney on 10/4/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
