//
//  common_function.h
//  PracCococs2dX
//
//  Created by shin on 13-7-10.
//
//

#ifndef PracCococs2dX_common_function_h
#define PracCococs2dX_common_function_h

#include "cocoa/CCGeometry.h"

typedef struct {
    int x;
    int y;
}Index;


Index convertPointToIndex(const CCPoint pt)
{
    
}

#endif
