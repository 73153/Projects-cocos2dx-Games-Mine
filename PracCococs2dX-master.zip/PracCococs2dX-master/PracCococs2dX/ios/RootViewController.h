//
//  PracCococs2dXAppController.h
//  PracCococs2dX
//
//  Created by shin on 13-6-7.
//  Copyright __MyCompanyName__ 2013年. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
