//
//  CustomCell1.h
//  Animated Table
//
//  Created by Philip Yu on 4/18/13.
//  Copyright (c) 2013 Philip Yu. All rights reserved.
//

#import "AnimatedTableCell.h"

@interface CustomCell1 : AnimatedTableCell

@end
