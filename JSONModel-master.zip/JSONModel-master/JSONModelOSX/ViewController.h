//
//  ViewController.h
//  JSONModelOSX
//
//  Created by Marin Todorov on 25/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end
