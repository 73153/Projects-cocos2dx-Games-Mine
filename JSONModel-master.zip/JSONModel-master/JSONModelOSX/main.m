//
//  main.m
//  JSONModelOSX
//
//  Created by Marin Todorov on 25/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
