//
//  StorageViewController.h
//  JSONModelDemo
//
//  Created by Marin Todorov on 02/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StorageViewController : UIViewController

@end
