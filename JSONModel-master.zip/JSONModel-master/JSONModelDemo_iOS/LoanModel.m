//
//  LoanModel.m
//  JSONModel_Demo
//
//  Created by Marin Todorov on 26/11/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import "LoanModel.h"

@implementation LoanModel

@end
