//
//  RpcRequestModel.m
//  JSONModelDemo_iOS
//
//  Created by Marin Todorov on 4/2/13.
//  Copyright (c) 2013 Underplot ltd. All rights reserved.
//

#import "RpcRequestModel.h"

@implementation RpcRequestModel

@end
