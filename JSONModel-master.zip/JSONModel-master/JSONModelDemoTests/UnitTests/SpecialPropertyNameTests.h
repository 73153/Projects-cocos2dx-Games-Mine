//
//  SpeicalPropertyNameTest.h
//  JSONModelDemo_OSX
//
//  Created by BB9z on 13-4-26.
//  Copyright (c) 2013年 Underplot ltd. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SpecialPropertyNameTests : SenTestCase

@end
