//
//  VBBMultiPlayerUI.h
//  volleyballBash
//
//  Created by Anshul on 10/05/13.
//
//

#ifndef volleyballBash_VBBMultiPlayerUI_h
#define volleyballBash_VBBMultiPlayerUI_h

#include <iostream>
#include "cocos2d.h"
#include "VBBMainScene.h"
#include "VBBMultiPlayerUI.h"
using namespace cocos2d;

class VBBMultiPlayerUI:public CCLayer {
    
public:
    
    //Default
    virtual void onEnter();
    virtual void onExit();
    VBBMultiPlayerUI();
    virtual ~VBBMultiPlayerUI();
    static CCScene* scene();
    
    //-------------------------MULTI-PLAYER
    //Initialize
    void initializeVariables();
    void initializeMultiPlyrUI();
    
    //Variables
    CCSize winsize;
    CCSprite *menuItemsBg;

    //Menu Items & it's methods
    void goToExhibition();
    void goToRankedBtn();
    void goToUsaTournament();
    void goToWorldTour();
    
    void backBtnAction();
    
    //-------------------------TOUCH
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    
    CREATE_FUNC(VBBMultiPlayerUI);
};
#endif
