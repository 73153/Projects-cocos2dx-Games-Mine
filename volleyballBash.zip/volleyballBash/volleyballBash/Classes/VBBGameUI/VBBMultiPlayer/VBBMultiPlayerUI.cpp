//
//  VBBMultiPlayerUI.cpp
//  volleyballBash
//
//  Created by Anshul on 10/05/13.
//
//

#include "VBBMainScene.h"
#include "VBBMultiPlayerUI.h"
#include "VBBExhibitionScene.h"

USING_NS_CC;

#pragma mark - Default
CCScene* VBBMultiPlayerUI::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = new VBBMultiPlayerUI();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    layer->release();
    return scene;
}

VBBMultiPlayerUI::VBBMultiPlayerUI() {
    
    this->setTouchEnabled(true);
}

void VBBMultiPlayerUI::onEnter() {
    
    CCLayer::onEnter();
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //Add plist 
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameUIImages/MultiPlayerScreen/VBBMultiPlyrScene.plist");
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Game UI
    this->initializeMultiPlyrUI();
}

#pragma mark - Initialize
void VBBMultiPlayerUI::initializeVariables() {
    
}


void VBBMultiPlayerUI::initializeMultiPlyrUI() {
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //---------------BG
    CCSprite* homeBg = CCSprite::create("CommonBG/sngl&Multiplyr_bg.png");
    homeBg->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(homeBg, 0);
    
    //-------------GAME SELECTION BUTTONS
    //bg & it's Menu items
    menuItemsBg = CCSprite::createWithSpriteFrameName("btns_bg.png");
    menuItemsBg->setPosition(ccp(475.7, 341.6));
    this->addChild(menuItemsBg, 1);
    
    //----------MenuItems
    CCSprite *normalExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn.png");
    CCSprite *selectedExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn_hvr.png");
    
    CCMenuItemSprite *exhibition = CCMenuItemSprite::create(normalExhibitionBtn, selectedExhibitionBtn, this, menu_selector(VBBMultiPlayerUI::goToExhibition));
    exhibition->setPosition(ccp(294.6, 551.4));
    
    
    CCSprite *normalRankedBtn = CCSprite::createWithSpriteFrameName("rankd_btn.png");
    CCSprite *selectedRankedBtn = CCSprite::createWithSpriteFrameName("rankd_btn_hvr.png");
    
    CCMenuItemSprite *rankedMenuItem = CCMenuItemSprite::create(normalRankedBtn, selectedRankedBtn,this, menu_selector(VBBMultiPlayerUI::goToRankedBtn));
    rankedMenuItem->setPosition(ccp(295.9, 451.9));
    
    
    CCSprite *normalUSAbtn = CCSprite::createWithSpriteFrameName("usa_btn.png");
    CCSprite *selectedUSbBtn = CCSprite::createWithSpriteFrameName("usa_btn_hvr.png");
    
    CCMenuItemSprite *usaBtnMenuItem = CCMenuItemSprite::create(normalUSAbtn, selectedUSbBtn,this, menu_selector(VBBMultiPlayerUI::goToUsaTournament));
    usaBtnMenuItem->setPosition(ccp(299.9, 349));
    
    
    CCSprite *normalWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn.png");
    CCSprite *selectedWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn_hvr.png");
    
    CCMenuItemSprite *worldTourMenuItem = CCMenuItemSprite::create(normalWorldTourBtn, selectedWorldTourBtn,this, menu_selector(VBBMultiPlayerUI::goToWorldTour));
    worldTourMenuItem->setPosition(ccp(300.9, 252.6));
    
    
    //---------Menu
    CCMenu *gameItemsMenu = CCMenu::create(exhibition, rankedMenuItem, usaBtnMenuItem, worldTourMenuItem, NULL);
    gameItemsMenu->setPosition(CCPointZero);
    menuItemsBg->addChild(gameItemsMenu,1);
    
    //Back Button
    CCSprite *normalBackBtn = CCSprite::createWithSpriteFrameName("back_btn1.png");
    CCSprite *selectedBackBtn = CCSprite::createWithSpriteFrameName("back_btn1_hvr.png");
    
    CCMenuItemSprite *backBtn = CCMenuItemSprite::create(normalBackBtn, selectedBackBtn,this, menu_selector(VBBMultiPlayerUI::backBtnAction));
    backBtn->setPosition(ccp(49.5, 41.6));
    
    //---------Menu
    CCMenu *backBtnMenu = CCMenu::create(backBtn, NULL);
    backBtnMenu->setPosition(CCPointZero);
    this->addChild(backBtnMenu,1);
}

#pragma mark - Menu Methods
void VBBMultiPlayerUI::goToExhibition() {
    
    CCTransitionScene *transition = CCTransitionSlideInR::create(0.9, VBBExhibitionScene::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

void VBBMultiPlayerUI::goToRankedBtn() {
    
}

void VBBMultiPlayerUI::goToUsaTournament() {
    
}

void VBBMultiPlayerUI::goToWorldTour() {
    
}

//Back Btn Actions
void VBBMultiPlayerUI::backBtnAction() {
    
    CCTransitionScene *transition = CCTransitionSlideInL::create(0.9, VBBMainScene::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

#pragma mark - Touch
void VBBMultiPlayerUI::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBMultiPlayerUI::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)( pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBMultiPlayerUI::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
}


#pragma mark - Dealloc
void VBBMultiPlayerUI::onExit() {
    
    CCLayer::onExit();
    
    //removing the plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameUIImages/MultiPlayerScreen/VBBMultiPlyrScene.plist");
}

VBBMultiPlayerUI::~VBBMultiPlayerUI() {
    
    //releasing the Array's
//    CC_SAFE_RELEASE_NULL();
}

