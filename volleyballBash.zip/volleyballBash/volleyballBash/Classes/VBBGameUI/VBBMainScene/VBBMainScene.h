#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "VBBMainScene.h"
#include "VBBSinglePlayerUI.h"
#include "VBBMultiPlayerUI.h"
using namespace cocos2d;

class VBBMainScene : public CCLayer
{
public:
    //Default
    static CCScene* scene();
    VBBMainScene();
    ~VBBMainScene();
    void onEnter();
    void onExit();
        
    //Initialize
    void initializeVariables();
    void initializeGameUI();
    void initializeBtnsBg();
    void initializePopUpBg();
    
    //Variables
    CCSprite* popUpBg;
    CCSize winsize;
    bool canTouchNewGameBtn;
    
    CCScene *m_pInScene;

    //-------MENU
    //Methods
    void goToSnglUIScreen();
    void goToMultiUIScreen();
    void goToLoadGame();
    void goToTraining();
    void goToSettings();
    void showPopUpItems();
    void setActionForPopUpBg();
    void menuCallback(CCMenuItemSprite *sender);
    
    //Actions
    void move();
    void skew();
    void rotate();
    
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(VBBMainScene);
};

#endif // __HELLOWORLD_SCENE_H__
