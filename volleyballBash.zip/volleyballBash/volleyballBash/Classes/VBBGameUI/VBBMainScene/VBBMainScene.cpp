#include "VBBMainScene.h"
#include "CCLayer.h"
#include "VBBSinglePlayerUI.h"
#include "VBBMultiPlayerUI.h"
#include "VBBSettingScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

#pragma mark - Default
CCScene* VBBMainScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = VBBMainScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

VBBMainScene::VBBMainScene() {
    
    this->setTouchEnabled(true);
}

void VBBMainScene::onEnter() {
    
    CCLayer::onEnter();
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameUIImages/MainScreen/VBBMainScene.plist");
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Game UI
    this->initializeGameUI();
}

#pragma mark - Initialize
void VBBMainScene::initializeVariables() {
    
    this->canTouchNewGameBtn = true;
}

void VBBMainScene::initializeGameUI()
{
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //---------------BG 
    CCSprite* homeBg = CCSprite::create("CommonBG/home_screen_bg.png");
    homeBg->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(homeBg, 0);
    
    //Title
    CCSprite* title = CCSprite::createWithSpriteFrameName("title.png");
    title->setPosition(ccp(492, 473.8));
    this->addChild(title, 1);
    
    //-------------GAME SELECTION BUTTONS    
    this->initializeBtnsBg();
    
    //-------------POP-UP MENU    
    this->initializePopUpBg();
    
    
    //----------MUSIC MENU
    //Music & Volume Button 
    CCSprite *normalmusicBtn = CCSprite::createWithSpriteFrameName("music_btn.png");
    CCSprite *selectedmusicBtn = CCSprite::createWithSpriteFrameName("music_btn_hvr.png");
    
    CCMenuItemSprite *musicBtnMenuItem = CCMenuItemSprite::create(normalmusicBtn, selectedmusicBtn,this, menu_selector(VBBMainScene::menuCallback));
    
    musicBtnMenuItem->setPosition(ccp(804, 49));
    musicBtnMenuItem->setTag(1);
    
    CCSprite *normalvolumeBtn = CCSprite::createWithSpriteFrameName("volume_btn.png");
    CCSprite *selectedvolumeBtn = CCSprite::createWithSpriteFrameName("volume_btn_hvr.png");
    
    CCMenuItemSprite *volumeBtnMenuItem = CCMenuItemSprite::create(normalvolumeBtn, selectedvolumeBtn,this, menu_selector(VBBMainScene::menuCallback));
    
    volumeBtnMenuItem->setPosition(ccp(897, 49));
    volumeBtnMenuItem->setTag(2);
    
    CCMenu *musicItemsMenu = CCMenu::create(musicBtnMenuItem, volumeBtnMenuItem, NULL);
    musicItemsMenu->setPosition(CCPointZero);
    this->addChild(musicItemsMenu,1);
}


#pragma mark - Buttons
void VBBMainScene::initializeBtnsBg() {
    
    CCSprite* menuItemsBg = CCSprite::createWithSpriteFrameName("btn_bg.png");
    menuItemsBg->setPosition(ccp(185.7, 189));
    this->addChild(menuItemsBg, 1);
    
    //----------MenuItems
    CCSprite *normalGameBtn = CCSprite::createWithSpriteFrameName("new_game_btn.png");
    CCSprite *selectedGameBtn = CCSprite::createWithSpriteFrameName("new_game_btn_hvr.png");
    
    CCMenuItemSprite *newGame = CCMenuItemSprite::create(normalGameBtn, selectedGameBtn, this, menu_selector(VBBMainScene::showPopUpItems));
    newGame->setPosition(ccp(167, 319.8));
    
    CCSprite *normalLoadGame = CCSprite::createWithSpriteFrameName("load_game_btn.png");
    CCSprite *selectedLoadGame = CCSprite::createWithSpriteFrameName("load_game_btn_hvr.png");
    
    CCMenuItemSprite *loadGameMenuItem = CCMenuItemSprite::create(normalLoadGame, selectedLoadGame,this, menu_selector(VBBMainScene::goToLoadGame));
    
    loadGameMenuItem->setPosition(ccp(167.1, 240.8));
    
    CCSprite *normalTrainingBtn = CCSprite::createWithSpriteFrameName("training_btn.png");
    CCSprite *selectedTrainingBtn = CCSprite::createWithSpriteFrameName("training_btn_hvr.png");
    
    CCMenuItemSprite *trainingMenuItem = CCMenuItemSprite::create(normalTrainingBtn, selectedTrainingBtn,this, menu_selector(VBBMainScene::goToTraining));
    
    trainingMenuItem->setPosition(ccp(169, 166));
    
    CCSprite *normalSettingsBtn = CCSprite::createWithSpriteFrameName("settngs_btn.png");
    CCSprite *selectedSettingsBtn = CCSprite::createWithSpriteFrameName("settngs_btn_hvr.png");
    
    CCMenuItemSprite *settingsMenuItem = CCMenuItemSprite::create(normalSettingsBtn, selectedSettingsBtn,this, menu_selector(VBBMainScene::goToSettings));
    
    settingsMenuItem->setPosition(ccp(172, 94));
    
    CCMenu *gameItemsMenu = CCMenu::create(newGame, loadGameMenuItem, trainingMenuItem, settingsMenuItem, NULL);
    gameItemsMenu->setPosition(CCPointZero);
    this->addChild(gameItemsMenu,1);
}

void VBBMainScene::goToSnglUIScreen() {
    
    CCTransitionScene *transition = CCTransitionSlideInR::create(0.9, VBBSinglePlayerUI::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

void VBBMainScene::goToMultiUIScreen() {
    
    CCTransitionScene *transition = CCTransitionSlideInR::create(0.9f, VBBMultiPlayerUI::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

void VBBMainScene::goToLoadGame() {
    
    this->setActionForPopUpBg();
}

void VBBMainScene::goToTraining() {
    
//    CCDirector::sharedDirector()->pushScene();
    this->setActionForPopUpBg();
}

void VBBMainScene::goToSettings() {
    
    //Left Side
    CCTransitionScene *transition = CCTransitionSlideInL::create(0.9, VBBSettingScene::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
    //this->setActionForPopUpBg();
}


#pragma mark - PopUp
void VBBMainScene::initializePopUpBg() {
    
    popUpBg = CCSprite::createWithSpriteFrameName("btn_popup_bg.png");
    popUpBg->setPosition(ccp(416.6, 250.2));
    this->addChild(popUpBg, 1);
    
    //--------------MenuItems
    CCSprite *normalSnglePlyr = CCSprite::createWithSpriteFrameName("sngl_plyr_btn.png");
    CCSprite *selectedSnglePlyr = CCSprite::createWithSpriteFrameName("sngl_plyr_btn_hvr.png");
    
    CCMenuItemSprite *SnglePlyrMenuItem = CCMenuItemSprite::create(normalSnglePlyr, selectedSnglePlyr,this, menu_selector(VBBMainScene::goToSnglUIScreen));
    SnglePlyrMenuItem->setPosition(ccp(147.1, 175.4));
    
    
    CCSprite *normalMultiPlyr = CCSprite::createWithSpriteFrameName("multi_plyr_btn.png");
    CCSprite *selectedMultiPlyr = CCSprite::createWithSpriteFrameName("multi_plyr_btn_hvr.png");
    
    CCMenuItemSprite *MultiPlyrMenuItem = CCMenuItemSprite::create(normalMultiPlyr, selectedMultiPlyr,this, menu_selector(VBBMainScene::goToMultiUIScreen));
    MultiPlyrMenuItem->setPosition(ccp(147.1, 95));
    
    
    CCMenu *popUpItemsMenu = CCMenu::create(SnglePlyrMenuItem, MultiPlyrMenuItem, NULL);
    popUpItemsMenu->setPosition(CCPointZero);
    //add popUp items as a child of popUp bg
    popUpBg->addChild(popUpItemsMenu,1);
    popUpBg->setVisible(false);
}

void VBBMainScene::showPopUpItems() {
    
    popUpBg->setVisible(true);
    popUpBg->stopAllActions();
    
    if (this->canTouchNewGameBtn)
    {
        this->canTouchNewGameBtn = false;
        this->move();
    }
}

void VBBMainScene::setActionForPopUpBg() {
    
    popUpBg->setVisible(false);
    popUpBg->setPosition(ccp(416.6,250.2));
    this->canTouchNewGameBtn = true;
}

#pragma mark - Menu Functions
void VBBMainScene::menuCallback(CCMenuItemSprite *sender) {
    
    int tag = sender->getTag();
    
    switch (tag)
    {
        case 1: //this->showPopUpItems();
                break;
        
        case 2: //this->showPopUpItems();
                break;
        
        default:break;
    }
}


#pragma mark - Actions
void VBBMainScene::move() {
    
    //MOVE
    //    CCMoveTo *moveTo = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x+30, popUpBg->getPosition().y));
    //    CCMoveTo *moveBack = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x-25, popUpBg->getPosition().y));
    CCMoveTo *moveTo1 = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x+22, popUpBg->getPosition().y));
    CCMoveTo *moveBack1 = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x-15, popUpBg->getPosition().y));
    CCMoveTo *moveTo2 = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x+15, popUpBg->getPosition().y));
    CCMoveTo *moveBack2 = CCMoveTo::create(.1, ccp(popUpBg->getPosition().x-5, popUpBg->getPosition().y));
    
    CCSequence *moveSeq = CCSequence::create(moveTo1, moveBack1, moveTo2, moveBack2, NULL);
    popUpBg->runAction(moveSeq);
}

void VBBMainScene::skew() {
    
    //SKEW
    CCSkewBy *skewBy = CCSkewBy::create(0.3f, 10, 0);
    CCSkewBy *skewBy1 = CCSkewBy::create(0.3, -10, 20);
    CCSkewBy *skewBack = CCSkewBy::create(0.3, 0, -20);
    CCTintBy *tintTo = CCTintBy::create(0.4, 255, 0, 0);
    CCSequence *skewSeq = CCSequence::create(skewBy, skewBy1, skewBack, tintTo, NULL);
    popUpBg->runAction(skewSeq);
}

void VBBMainScene::rotate() {
    
    //SKEW
    CCRotateBy *rotate1 = CCRotateBy::create(0.1, 30);
    CCRotateBy *rotate2 = CCRotateBy::create(0.1, -30);
    CCRotateBy *rotate3 = CCRotateBy::create(0.1, 15);
    CCRotateBy *rotate4 = CCRotateBy::create(0.1, -15);
    CCTintBy *tintTo = CCTintBy::create(0.4, 255, 0, 0);
    CCSequence *skewSeq = CCSequence::create(rotate1, rotate2, rotate3, rotate4, tintTo, NULL);
    popUpBg->runAction(skewSeq);
}

#pragma mark - Dealloc
void VBBMainScene::onExit() {
    
    CCLayer::onExit();
    
    //removing the plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameUIImages/MainScreen/VBBMainScene.plist");
}


VBBMainScene::~VBBMainScene() {
    
}
