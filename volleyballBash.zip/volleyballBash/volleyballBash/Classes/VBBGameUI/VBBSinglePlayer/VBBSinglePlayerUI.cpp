//
//  VBBSinglePlayerUI.cpp
//  volleyballBash
//
//  Created by Anshul on 07/05/13.
//
//

#include "VBBSinglePlayerUI.h"
#include "VBBExhibitionScene.h"
#include "cocos2d.h"

#include "SimpleAudioEngine.h"
using namespace CocosDenshion;

USING_NS_CC;

#pragma mark - Default
CCScene* VBBSinglePlayerUI::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = new VBBSinglePlayerUI();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    layer->release();
    return scene;
}

VBBSinglePlayerUI::VBBSinglePlayerUI() {
    
    this->setTouchEnabled(true);
}

void VBBSinglePlayerUI::onEnter() {
    
    CCLayer::onEnter();
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameUIImages/SinglePlayerScreen/VBBSinglePlyrScene.plist");
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Game UI
    this->initializeGameUI();
}

#pragma mark - Initialize
void VBBSinglePlayerUI::initializeVariables() {
    
    this->canTouchNewGameBtn = true;
    this->selectBackBtn = false;
}

void VBBSinglePlayerUI::initializeGameUI() {
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //---------------BG
    CCSprite* homeBg = CCSprite::create("CommonBG/sngl&Multiplyr_bg.png");
    homeBg->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(homeBg, 0);
    
    //GAME SELECTION BUTTONS
    this->initializeSnglPlyrUI();
    
    //POP UP ITEMS
    this->initializePopUpItems();
    
    //Back Button
    CCSprite *normalBackBtn = CCSprite::createWithSpriteFrameName("back_btn1.png");
    CCSprite *selectedBackBtn = CCSprite::createWithSpriteFrameName("back_btn1_hvr.png");
    
    CCMenuItemSprite *backBtn = CCMenuItemSprite::create(normalBackBtn, selectedBackBtn,this, menu_selector(VBBSinglePlayerUI::backToScene));
    backBtn->setPosition(ccp(49.5, 41.6));
    
    //---------Menu
    CCMenu *backBtnMenu = CCMenu::create(backBtn, NULL);
    backBtnMenu->setPosition(CCPointZero);
    
    //add the popUp items as a child of "layer2"
    this->addChild(backBtnMenu,1);
}

void VBBSinglePlayerUI::initializeSnglPlyrUI(){
    
    //-------------GAME SELECTION BUTTONS
    //bg & it's Menu items
    menuItemsBg = CCSprite::createWithSpriteFrameName("btns_bg.png");
    menuItemsBg->setPosition(ccp(475.7, 341.6));
    this->addChild(menuItemsBg, 1);
    
    //Create a transparent layer to place the menu item on it
    this->layer1 = CCLayerColor::create(ccc4(0, 0, 0, 0), 960, 640);
    this->layer1->setPosition(ccp(0, 0));
    menuItemsBg->addChild(this->layer1,3);
    
    
    //----------MenuItems
    CCSprite *normalExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn.png");
    CCSprite *selectedExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn_hvr.png");
    
    CCMenuItemSprite *exhibition = CCMenuItemSprite::create(normalExhibitionBtn, selectedExhibitionBtn, this, menu_selector(VBBSinglePlayerUI::goToExhibition));
    exhibition->setPosition(ccp(294.6, 551.4));
    
    
    CCSprite *normalUSAbtn = CCSprite::createWithSpriteFrameName("usa_btn.png");
    CCSprite *selectedUSbBtn = CCSprite::createWithSpriteFrameName("usa_btn_hvr.png");
    
    CCMenuItemSprite *usaBtnMenuItem = CCMenuItemSprite::create(normalUSAbtn, selectedUSbBtn,this, menu_selector(VBBSinglePlayerUI::goToUsaTournament));
    usaBtnMenuItem->setPosition(ccp(295.9, 451.9));
    
    
    CCSprite *normalWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn.png");
    CCSprite *selectedWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn_hvr.png");
    
    CCMenuItemSprite *worldTourMenuItem = CCMenuItemSprite::create(normalWorldTourBtn, selectedWorldTourBtn,this, menu_selector(VBBSinglePlayerUI::goToWorldTour));
    worldTourMenuItem->setPosition(ccp(299.9, 349));
    
    
    CCSprite *normalChallngeBtn = CCSprite::createWithSpriteFrameName("challnge_btn.png");
    CCSprite *selectedChallngeBtn = CCSprite::createWithSpriteFrameName("challnge_btn_hvr.png");
    
    CCMenuItemSprite *challngeMenuItem = CCMenuItemSprite::create(normalChallngeBtn, selectedChallngeBtn,this, menu_selector(VBBSinglePlayerUI::goToChallengePopUpItems));
    challngeMenuItem->setPosition(ccp(300.9, 252.6));
    
    //---------Menu
    CCMenu *gameItemsMenu = CCMenu::create(exhibition, usaBtnMenuItem, worldTourMenuItem, challngeMenuItem, NULL);
    gameItemsMenu->setPosition(CCPointZero);
    
    //add the popUp items as a child of "layer1"
    this->layer1->addChild(gameItemsMenu,1);
}

void VBBSinglePlayerUI::initializePopUpItems() {
 
    //-------------POPUP ITEMS
    //Create a transparent layer to place the menu item on it
    this->layer2 = CCLayerColor::create(ccc4(0, 0, 0, 0), 960, 640);
    this->layer2->setPosition(ccp(0, -400));
    this->layer2->setVisible(false);
    menuItemsBg->addChild(this->layer2,3);
    
    
    //----------MenuItems
    CCSprite *normalSpikeChllnge = CCSprite::createWithSpriteFrameName("spike_challnge__btn.png");
    CCSprite *selectedSpikeChllnge = CCSprite::createWithSpriteFrameName("spike_challnge__btn_hvr.png");
    
    CCMenuItemSprite *spikeChllnge = CCMenuItemSprite::create(normalSpikeChllnge, selectedSpikeChllnge, this, menu_selector(VBBSinglePlayerUI::goToSpikeChallenge));
    spikeChllnge->setPosition(ccp(294.6, 551.4));
    
    
    CCSprite *normalBlockChllnge = CCSprite::createWithSpriteFrameName("block_challnge__btn.png");
    CCSprite *selectedBlockChllnge = CCSprite::createWithSpriteFrameName("block_challnge__btn_hvr.png");
    
    CCMenuItemSprite *BlockChllnge = CCMenuItemSprite::create(normalBlockChllnge, selectedBlockChllnge,this, menu_selector(VBBSinglePlayerUI::goToBlockChallenge));
    
    BlockChllnge->setPosition(ccp(295.9, 451.9));
    
    CCSprite *normalEndlessChllnge = CCSprite::createWithSpriteFrameName("endls_challnge__btn.png");
    CCSprite *selectedEndlessChllnge = CCSprite::createWithSpriteFrameName("endls_challnge__btn_hvr.png");
    
    CCMenuItemSprite *endlessChllnge = CCMenuItemSprite::create(normalEndlessChllnge, selectedEndlessChllnge,this, menu_selector(VBBSinglePlayerUI::goToEndlessChallenge));
    endlessChllnge->setPosition(ccp(299.9, 349));
    
    
    CCSprite *normalTimeChallnge = CCSprite::createWithSpriteFrameName("time_challnge__btn.png");
    CCSprite *selectedTimeChallnge = CCSprite::createWithSpriteFrameName("time_challnge__btn_hvr.png");
    
    CCMenuItemSprite *timeChallnge = CCMenuItemSprite::create(normalTimeChallnge, selectedTimeChallnge,this, menu_selector(VBBSinglePlayerUI::goToTimeChallenge));
    timeChallnge->setPosition(ccp(300.9, 252.6));
    
    
    //---------Menu
    CCMenu *gamePopUpItemsMenu = CCMenu::create(spikeChllnge, BlockChllnge, endlessChllnge, timeChallnge, NULL);
    gamePopUpItemsMenu->setPosition(CCPointZero);
    
    //add the popUp items as a child of "layer2"
    this->layer2->addChild(gamePopUpItemsMenu,1);
}

#pragma mark - Menu Methods
void VBBSinglePlayerUI::goToChallengePopUpItems() {
    
    CCMoveTo *moveTo = CCMoveTo::create(.4, ccp(this->layer1->getPosition().x, 768));
    CCSequence *seq = CCSequence::create(moveTo, CCCallFunc::create(this, callfunc_selector(VBBSinglePlayerUI::showItemsForPopUpBg)), NULL);
    this->layer1->runAction(seq);
    this->selectBackBtn = true;
}

void VBBSinglePlayerUI::showItemsForPopUpBg() {
    
    this->layer2->setVisible(true);
    
    CCMoveTo *moveTo = CCMoveTo::create(.4, ccp(this->layer2->getPosition().x, 0));
    CCSequence *seq = CCSequence::create(moveTo, CCCallFunc::create(this, callfunc_selector(VBBSinglePlayerUI::setVisibility)), NULL);
    this->layer2->runAction(seq);
}

void VBBSinglePlayerUI::goToExhibition() {
    
//    this->setActionForPopUpBg();
    CCTransitionScene *transition = CCTransitionSlideInR::create(0.9, VBBExhibitionScene::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

void VBBSinglePlayerUI::goToUsaTournament() {
    
    this->setActionForPopUpBg();
}

void VBBSinglePlayerUI::goToWorldTour() {
    
    this->setActionForPopUpBg();
}

void VBBSinglePlayerUI::setActionForPopUpBg() {
    
//    popUpBg->setVisible(false);
//    popUpBg->setPosition(ccp(396.6,250.2));
//    this->canTouchNewGameBtn = true;
}

void VBBSinglePlayerUI::setVisibility() {
    
    this->layer1->setVisible(false);
    this->layer2->setVisible(true);
}

void VBBSinglePlayerUI::setVisibilityBack() {
    
    this->layer1->setVisible(true);
    this->layer2->setVisible(false);
}


//Back Btn Actions
void VBBSinglePlayerUI::backToPreviousMenu() {
    
    CCSequence *seq = CCSequence::create(
                                         CCCallFunc::create(this, callfunc_selector(VBBSinglePlayerUI::backBtnActionForLayer2)), CCCallFunc::create(this, callfunc_selector(VBBSinglePlayerUI::backBtnActionForLayer1)), NULL);
    layer1->runAction(seq);
}

void VBBSinglePlayerUI::backToScene() {
    
    if(this->selectBackBtn) {
        
        this->backToPreviousMenu();
        this->selectBackBtn = false;
    }
    else if(!this->selectBackBtn) {
        
        CCTransitionScene *transition = CCTransitionSlideInL::create(0.9, VBBMainScene::scene());
        CCDirector::sharedDirector()->replaceScene(transition);
    }
}

void VBBSinglePlayerUI::backBtnActionForLayer1() {
    
    CCMoveTo *moveTo = CCMoveTo::create(.6, ccp(this->layer1->getPosition().x, 0));
    this->layer1->runAction(moveTo);
}


void VBBSinglePlayerUI::backBtnActionForLayer2() {
    
    CCMoveTo *moveTo = CCMoveTo::create(.4, ccp(this->layer2->getPosition().x, -400));
    this->layer2->runAction(moveTo);
    CCSequence *seq = CCSequence::create(moveTo, CCCallFunc::create(this, callfunc_selector(VBBSinglePlayerUI::setVisibilityBack)), NULL);
    this->layer2->runAction(seq);
}


#pragma mark - PopUpItems
void VBBSinglePlayerUI::goToSpikeChallenge() {
    
}

void VBBSinglePlayerUI::goToBlockChallenge() {
    
}

void VBBSinglePlayerUI::goToEndlessChallenge() {
    
}

void VBBSinglePlayerUI::goToTimeChallenge() {
    
}


#pragma mark - Touch
void VBBSinglePlayerUI::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBSinglePlayerUI::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)( pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBSinglePlayerUI::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
    
}


#pragma mark - Dealloc
void VBBSinglePlayerUI::onExit() {
    
    CCLayer::onExit();
    
    //removing the puzzle plist from the array
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameUIImages/SinglePlayerScreen/VBBSinglePlyrScene.plist");
}

VBBSinglePlayerUI::~VBBSinglePlayerUI() {
    
    //releasing the Array's
//    CC_SAFE_RELEASE_NULL();
}

