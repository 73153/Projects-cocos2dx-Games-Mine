//
//  VBBSinglePlayerUI.h
//  volleyballBash
//
//  Created by Anshul on 07/05/13.
//
//

#ifndef volleyballBash_VBBSinglePlayerUI_h
#define volleyballBash_VBBSinglePlayerUI_h

#include <iostream>
#include "cocos2d.h"
#include "VBBSinglePlayerUI.h"
#include "VBBMainScene.h"

using namespace cocos2d;

class VBBSinglePlayerUI:public cocos2d::CCLayer {
    
public:
    
    //Default
    virtual void onEnter();
    virtual void onExit();
    VBBSinglePlayerUI();
    virtual ~VBBSinglePlayerUI();
    static CCScene* scene();
    
    //------------------------- VOLLEYBALL
    //Initialize
    void initializeVariables();
    void initializeGameUI();
    void initializeSnglPlyrUI();
    void initializePopUpItems();
    
    //Variables
    CCSize winsize;
    CCSprite *menuItemsBg;
    CCSprite *popUpItemsBg;
    
    CCLayerColor *layer1;
    CCLayerColor *layer2;
    bool canTouchNewGameBtn;
    bool selectBackBtn;
    
    //Menu Items & it's methods
    void goToExhibition();
    void goToUsaTournament();
    void goToWorldTour();
    void goToChallengePopUpItems();
    
    void setActionForPopUpBg();
    void menuCallback(CCMenuItemSprite *sender);
    
    //POP UP ITEMS
    void goToSpikeChallenge();
    void goToBlockChallenge();
    void goToEndlessChallenge();
    void goToTimeChallenge();
    
    //Actions
    void backToScene();
    void backToPreviousMenu();
    
    void backBtnActionForLayer1();
    void backBtnActionForLayer2();
    
    void setVisibility();
    void setVisibilityBack();
    
    void showItemsForPopUpBg();
    void setVisibilityForPopUpBg();
    
    //-------------------------TOUCH
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    
    CREATE_FUNC(VBBSinglePlayerUI);
};

#endif
