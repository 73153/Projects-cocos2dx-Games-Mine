//
//  VBBExhibitionScene.h
//  volleyballBash
//
//  Created by Anshul on 11/05/13.
//
//

#ifndef volleyballBash_VBBExhibitionScene_h
#define volleyballBash_VBBExhibitionScene_h

#include <iostream>
#include "cocos2d.h"
#include "VBBMainScene.h"
#include "VBBExhibitionScene.h"
#include "VBBMultiPlayerUI.h"
using namespace cocos2d;

class VBBExhibitionScene:public CCLayer {
    
public:
    
    //Default
    virtual void onEnter();
    virtual void onExit();
    VBBExhibitionScene();
    virtual ~VBBExhibitionScene();
    static CCScene* scene();
    
    //-------------------------MULTI-PLAYER
    //Initialize
    void initializeVariables();
    void initializeExhibitionUI();
    
    //Variables
    CCSize winsize;
    CCSprite *exhibitionBg;
    
    //Menu Items & it's methods
    void goToExhibition();
    void goToRankedBtn();
    void goToUsaTournament();
    void goToWorldTour();
    
    void backToScene();
    
    //-------------------------TOUCH
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    
    CREATE_FUNC(VBBExhibitionScene);
};

#endif
