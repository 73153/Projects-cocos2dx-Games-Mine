//
//  VBBExhibitionScene.cpp
//  volleyballBash
//
//  Created by Anshul on 11/05/13.
//
//

#include "VBBExhibitionScene.h"
USING_NS_CC;

#pragma mark - Default
CCScene* VBBExhibitionScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = new VBBExhibitionScene();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    layer->release();
    return scene;
}

VBBExhibitionScene::VBBExhibitionScene() {
    
    this->setTouchEnabled(true);
}

void VBBExhibitionScene::onEnter() {
    
    CCLayer::onEnter();
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //Add plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameUIImages/ExhibitionScreen/VBBExhibitionUI.plist");
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Game UI
    this->initializeExhibitionUI();
}

#pragma mark - Initialize
void VBBExhibitionScene::initializeVariables() {
    
}


void VBBExhibitionScene::initializeExhibitionUI() {
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //---------------BG
    CCSprite* homeBg = CCSprite::create("CommonBG/sngl&Multiplyr_bg.png");
    homeBg->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(homeBg, 0);
    
    //-------------GAME SELECTION BUTTONS
    //bg & it's Menu items
    exhibitionBg = CCSprite::createWithSpriteFrameName("exhibition_world_tour_bg.png");
    exhibitionBg->setPosition(ccp(475.6, 317.8));
    this->addChild(exhibitionBg, 1);
    
    //-------------------TITLE
    // "Select Your Team"
    CCSprite* titleYourTeam = CCSprite::createWithSpriteFrameName("titl_selct_ur_team.png");
    titleYourTeam->setPosition(ccp(236.4, 535));
    exhibitionBg->addChild(titleYourTeam, 1);
    
    // "Select Opponent Team"
    CCSprite* titleOppTeam = CCSprite::createWithSpriteFrameName("titl_selct_oponent_team.png");
    titleOppTeam->setPosition(ccp(651.1, 535));
    exhibitionBg->addChild(titleOppTeam, 1);
    
    // "Back" Button
    CCSprite *normalBackBtn = CCSprite::createWithSpriteFrameName("back_btn1.png");
    CCSprite *selectedBackBtn = CCSprite::createWithSpriteFrameName("back_btn1_hvr.png");
    
    CCMenuItemSprite *backBtn = CCMenuItemSprite::create(normalBackBtn, selectedBackBtn,this, menu_selector(VBBExhibitionScene::backToScene));
    backBtn->setPosition(ccp(49.5, 41.6));
    
    //---------Menu
    CCMenu *backBtnMenu = CCMenu::create(backBtn, NULL);
    backBtnMenu->setPosition(CCPointZero);
    this->addChild(backBtnMenu,1);
    
/*
    //----------MenuItems
    CCSprite *normalExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn.png");
    CCSprite *selectedExhibitionBtn = CCSprite::createWithSpriteFrameName("exhibtion_btn_hvr.png");
    
    CCMenuItemSprite *exhibition = CCMenuItemSprite::create(normalExhibitionBtn, selectedExhibitionBtn, this, menu_selector(VBBExhibitionScene::goToExhibition));
    exhibition->setPosition(ccp(294.6, 551.4));
    
    
    CCSprite *normalRankedBtn = CCSprite::createWithSpriteFrameName("rankd_btn.png");
    CCSprite *selectedRankedBtn = CCSprite::createWithSpriteFrameName("rankd_btn_hvr.png");
    
    CCMenuItemSprite *rankedMenuItem = CCMenuItemSprite::create(normalRankedBtn, selectedRankedBtn,this, menu_selector(VBBExhibitionScene::goToRankedBtn));
    rankedMenuItem->setPosition(ccp(295.9, 451.9));
    
    
    CCSprite *normalUSAbtn = CCSprite::createWithSpriteFrameName("usa_btn.png");
    CCSprite *selectedUSbBtn = CCSprite::createWithSpriteFrameName("usa_btn_hvr.png");
    
    CCMenuItemSprite *usaBtnMenuItem = CCMenuItemSprite::create(normalUSAbtn, selectedUSbBtn,this, menu_selector(VBBExhibitionScene::goToUsaTournament));
    usaBtnMenuItem->setPosition(ccp(299.9, 349));
    
    
    CCSprite *normalWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn.png");
    CCSprite *selectedWorldTourBtn = CCSprite::createWithSpriteFrameName("world_tour_btn_hvr.png");
    
    CCMenuItemSprite *worldTourMenuItem = CCMenuItemSprite::create(normalWorldTourBtn, selectedWorldTourBtn,this, menu_selector(VBBExhibitionScene::goToWorldTour));
    worldTourMenuItem->setPosition(ccp(300.9, 252.6));
    
    //---------Menu
    CCMenu *gameItemsMenu = CCMenu::create(exhibition, rankedMenuItem, usaBtnMenuItem, worldTourMenuItem, NULL);
    gameItemsMenu->setPosition(CCPointZero);
    menuItemsBg->addChild(gameItemsMenu,1);
*/
}


//Back Btn Actions
void VBBExhibitionScene::backToScene() {
    
    CCTransitionScene *transition = CCTransitionSlideInL::create(0.9, VBBSinglePlayerUI::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

#pragma mark - Touch
void VBBExhibitionScene::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBExhibitionScene::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)( pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBExhibitionScene::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
}


#pragma mark - Dealloc
void VBBExhibitionScene::onExit() {
    
    CCLayer::onExit();
    
    //removing the plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameUIImages/ExhibitionScreen/VBBExhibitionUI.plist");
}

VBBExhibitionScene::~VBBExhibitionScene() {
    
    //releasing the Array's
//    CC_SAFE_RELEASE_NULL();
}
