//
//  VBBSettingScene.h
//  volleyballBash
//
//  Created by Anshul on 11/05/13.
//
//

#ifndef volleyballBash_VBBSettingScene_h
#define volleyballBash_VBBSettingScene_h


#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include "CCScrollView.h"
#include "CustomTableViewCell.h"
#include "VBBSettingScene.h"
using namespace cocos2d;

USING_NS_CC_EXT;
USING_NS_CC;

class VBBSettingScene:public cocos2d::CCLayer{
    
public:
    
    //Default
    virtual void onEnter();
    virtual void onExit();
    VBBSettingScene();
    virtual ~VBBSettingScene();
    static CCScene* scene();
    
    //-----------------------------SETTINGS-SCENE----------------------------//
    //Initialize
    void initializeVariables();
    void initializeUI();
    void initializeArrowBtns();
    
    //-----------VARIABLES-----------//
    CCSize winsize;
    
    CCArray *allItemsListArr;
    CCDictionary *allCardInfoDict;
    
    
    //--------------------CHARACTER--------------------//
    CCArray *aMenItemsArr;
    CCArray *aWomenItemsArr; //Arrays
    
    CCMenuItemSprite *charactrItem;
    CCMenuItemSprite *menItems;
    CCMenuItemSprite *womenItems; //Menu Items
    
    CCSprite *settngScreenBg;
    CCSprite *characterScrollBg;
    CCSprite *backgrndScrollBg; //Sprites
    
    CCLayer *layerForCharctrBtn; //Layer
    
    void selectCharacter();
    void selectMenCharacter();
    void selectWomenCharacter(); //Methods
    
    bool isCharctrBtnEnabled;
    bool isMenBtnSelected;
    bool isWomenBtnSelected; // bool
    
    
    //------------------BACKGROUND-----------------//
    CCArray *aDayItemsArr;
    CCArray *aNightItemsArr; //Array
    
    CCMenuItemSprite *selectBgItem;
    CCMenuItemSprite *dayBtn;
    CCMenuItemSprite *nightBtn; //Menu Items
    
    CCLayer *layerForBgBtn; //Layer
    
    bool isDaySelected;
    bool isNightSelected; //bool
    
    void selectBg();
    void DayBtnAction();
    void NightBtnAction(); //Methods
    
    
    //-----GENERAL METHODS-------//
    void leftArrowPressed(CCObject *sender);
    void rightArrowPressed(CCObject *sender); // Left & Right Arrows
    
    void backToScene(); //Back to Main Scene
    
    //----Scroll View-----//
    CCScrollView *scrollView;
    CCLayer *scrollLayer;
    
    CCMenuItemSprite *leftArrow;
    CCMenuItemSprite *rightArrow;
    
    CCMenuItemSprite *leftArrow1;
    CCMenuItemSprite *rightArrow1;
    
    int clickArrowCount;
    int characterClickCount;
    int backgroundClickCount;
        
    void Character();
    void menScrollSelection();
    void womenScrollSelection(); //Methods
    
    void Background();
    void dayScrollSelection();
    void nightScrollSelection(); //Methods
    
    //------TOUCH------//
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    
    
    CREATE_FUNC(VBBSettingScene);
};
#endif

