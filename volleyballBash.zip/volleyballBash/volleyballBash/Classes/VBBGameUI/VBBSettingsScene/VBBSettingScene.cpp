//
//  VBBSettingScene.cpp
//  volleyballBash
//
//  Created by Anshul on 11/05/13.
//
//

#include "VBBMainScene.h"
#include "VBBSettingScene.h"
#include "CustomTableViewCell.h"

USING_NS_CC;
#define kCharctrBgGapX 420.0f
#define kScrollCharacterWidth 890.0f//Character
#define kBackgroundBgGapX 520.0f 
#define kScrollBackgroundWidth 520.0f //Background
#define kSettingCardTag 556 //General

using namespace cocos2d;
using namespace cocos2d::extension;


#pragma mark - Default
CCScene* VBBSettingScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = new VBBSettingScene();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    layer->release();
    return scene;
}

VBBSettingScene::VBBSettingScene() {
    
    this->setTouchEnabled(true);
}

void VBBSettingScene::onEnter() {
    
    CCLayer::onEnter();
    
    //ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //Add plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameUIImages/SettingScreen/VBBSettingScene.plist");
    
    
    //-----Loading Data plist-------//
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("VBBSettingsData.plist");
    allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    
    
    //----CHARACTER----//
    CCDictionary *aCharacterDict = (CCDictionary*)allCardInfoDict->valueForKey("Characters");
    aMenItemsArr = (CCArray*)aCharacterDict->valueForKey("Men"); //Men
    aWomenItemsArr = (CCArray*)aCharacterDict->valueForKey("Women"); //Women
    
    CCDictionary *aBackgroundDict = (CCDictionary*)allCardInfoDict->valueForKey("Backgrounds");
    aDayItemsArr = (CCArray*)aBackgroundDict->valueForKey("Day"); //Day
    aNightItemsArr = (CCArray*)aBackgroundDict->valueForKey("Night"); //Night
    
    
    //Back Button
    CCSprite *normalBackBtn = CCSprite::createWithSpriteFrameName("back_btn1.png");
    CCSprite *selectedBackBtn = CCSprite::createWithSpriteFrameName("back_btn1_hvr.png");
    
    CCMenuItemSprite *backBtn = CCMenuItemSprite::create(normalBackBtn, selectedBackBtn,this, menu_selector(VBBSettingScene::backToScene));
    backBtn->setPosition(ccp(40.5, 31.6));
    
    //---------Menu
    CCMenu *backBtnMenu = CCMenu::create(backBtn, NULL);
    backBtnMenu->setPosition(CCPointZero);
    this->addChild(backBtnMenu,1);
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Bg with Arrow for Selecting Character
    this->initializeUI();
    
    //Scroll View
    this->Character();
    
    //initialize Left Scroll & Right Scroll Buttons
    this->initializeArrowBtns();
}

#pragma mark - Initialize
void VBBSettingScene::initializeVariables() {
    
    isCharctrBtnEnabled = true;
    isMenBtnSelected = true;
    
    isDaySelected = true;
    clickArrowCount = 0;
    characterClickCount=0;
    backgroundClickCount=0;
}

void VBBSettingScene::initializeUI() {
    
    //-----Settings_BG------//
    CCSprite* homeBg = CCSprite::create("CommonBG/settng_bg.png");
    homeBg->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(homeBg, 0);
    
    
    //------VOLLEYBALL-NET -------//
    settngScreenBg = CCSprite::createWithSpriteFrameName("setting_screen_bg.png");
    settngScreenBg->setPosition(ccp(456.8, 263.3));
    this->addChild(settngScreenBg, 1);
    
    
    //BUTTONS TO SELECT CHARACTER / BG
    CCSprite *normalCharactrBtn = CCSprite::createWithSpriteFrameName("select_charctr_btn_dsble.png");
    CCSprite *selectedCharactrBtn = CCSprite::createWithSpriteFrameName("select_charctr_btn.png");
    
    charactrItem = CCMenuItemSprite::create(normalCharactrBtn, selectedCharactrBtn, this, menu_selector(VBBSettingScene::selectCharacter));
    charactrItem->setPosition(ccp(287.9, 582.8));
    charactrItem->selected(); //Default
    
    CCSprite *normalSelectBgBtn = CCSprite::createWithSpriteFrameName("select_bg_btn_dsble.png");
    CCSprite *selectedBgBtn = CCSprite::createWithSpriteFrameName("select_bg_btn.png");
    
    selectBgItem = CCMenuItemSprite::create(normalSelectBgBtn, selectedBgBtn,this, menu_selector(VBBSettingScene::selectBg));
    selectBgItem->setPosition(ccp(703, 583));
    selectBgItem->unselected(); //Default
    
    CCMenu *gameItemsMenu = CCMenu::create(charactrItem, selectBgItem, NULL);
    gameItemsMenu->setPosition(CCPointZero);
    this->addChild(gameItemsMenu,1);
    
    
    //---------MEN / WOMEN CHARACTER-----//
    CCSprite *normalMenCharactrBtn = CCSprite::createWithSpriteFrameName("men_btn_dsble.png");
    CCSprite *selectedMenCharactrBtn = CCSprite::createWithSpriteFrameName("men_btn.png");
    
    menItems = CCMenuItemSprite::create(normalMenCharactrBtn, selectedMenCharactrBtn, this, menu_selector(VBBSettingScene::selectMenCharacter));
    menItems->setPosition(ccp(209, 519));
    menItems->selected(); //Default
    
    CCSprite *normalWomenCharactrBtn = CCSprite::createWithSpriteFrameName("women_btn_dsble.png");
    CCSprite *selectedWomenCharactrBtn = CCSprite::createWithSpriteFrameName("women_btn.png");
    
    womenItems = CCMenuItemSprite::create(normalWomenCharactrBtn, selectedWomenCharactrBtn,this, menu_selector(VBBSettingScene::selectWomenCharacter));
    womenItems->setPosition(ccp(371.1, 519));
    womenItems->unselected(); //Default
    
    //MENU
    CCMenu *charctrItemsMenu = CCMenu::create(menItems, womenItems, NULL);
    charctrItemsMenu->setPosition(CCPointZero);
    this->addChild(charctrItemsMenu,1);
    
    
    //-------BUTTONS TO SELECT DAY / NIGHT TIME-------//
    CCSprite *normalDayBtn = CCSprite::createWithSpriteFrameName("day_btn_dsble.png");
    CCSprite *selectedDayBtn = CCSprite::createWithSpriteFrameName("day_btn.png");
    
    dayBtn = CCMenuItemSprite::create(normalDayBtn, selectedDayBtn, this, menu_selector(VBBSettingScene::DayBtnAction));
    dayBtn->setPosition(ccp(630.4, 516.6));
    dayBtn->setVisible(false); //Default
    
    CCSprite *normalNightBtn = CCSprite::createWithSpriteFrameName("night_btn_dsble.png");
    CCSprite *selectedNightBtn = CCSprite::createWithSpriteFrameName("night_btn.png");
    
    nightBtn = CCMenuItemSprite::create(normalNightBtn, selectedNightBtn, this, menu_selector(VBBSettingScene::NightBtnAction));
    nightBtn->setPosition(ccp(782, 517.2));
    nightBtn->setVisible(false); //Default
    
    
    //MENU
    CCMenu *bgItemsMenu = CCMenu::create(dayBtn, nightBtn, NULL);
    bgItemsMenu->setPosition(CCPointZero);
    this->addChild(bgItemsMenu,1);
}


#pragma mark - SCROLL VIEW
void VBBSettingScene::Character() {
    
    //incrementing characterClickCount
    characterClickCount++;
    
    //Add Bg
    characterScrollBg = CCSprite::createWithSpriteFrameName("setting_screen_foregrnd_bg_2.png");
    characterScrollBg->setPosition(ccp(winsize.width/2 - 180, winsize.height/2 - 250));
    characterScrollBg->setAnchorPoint(CCPointZero);
    characterScrollBg->setTag(111);
    this->addChild(characterScrollBg,1);
    
    //------Scroll for Character------//
    scrollLayer = CCLayer::create();
    scrollView = CCScrollView::create(CCSize(410,700));
    scrollView->setDirection(kCCScrollViewDirectionHorizontal);
    scrollView->setBounceable(true);
    scrollView->setContainer(scrollLayer);
    this->addChild(scrollView,3);
    
    scrollView->setPosition(ccp(300, winsize.height/2 - 200));
    
    if (isCharctrBtnEnabled) { //----CHARACTER-------//

        if(isMenBtnSelected) { //Men
            
            CCObject *aMenItemObj = NULL;
            int i=0;
            CCPoint currPos = CCPoint(220, 180);
            
            CCARRAY_FOREACH(aMenItemsArr, aMenItemObj) {
                
                CCString *aMenStr = (CCString *)aMenItemsArr->objectAtIndex(i);
                
                CCSprite *aMenNormalSpr = CCSprite::createWithSpriteFrameName(aMenStr->getCString());
                CCSprite *aMenSelectedSpr = CCSprite::createWithSpriteFrameName(aMenStr->getCString());
                                
                CCMenuItemSprite *menMenuItem = CCMenuItemSprite::create(aMenNormalSpr, aMenSelectedSpr, this, menu_selector(VBBSettingScene::menScrollSelection));
                menMenuItem->setPosition(ccp(currPos.x, currPos.y));
                
                //incrementing xPos for placing characters in the table view
                currPos.x += 400;
                
                scrollLayer->addChild(menMenuItem,3);
                menMenuItem->setTag(kSettingCardTag);
                i++;
            }
        }
        else if (!isMenBtnSelected) {
            
            CCObject *aMenItemObj = NULL;
            int j=0;
            CCPoint currPos = CCPoint(220, 180);
            CCARRAY_FOREACH(aWomenItemsArr, aMenItemObj) {
                
                CCString *aWomenStr = (CCString *)aWomenItemsArr->objectAtIndex(j);
                
                CCSprite *aWomenNormalSpr = CCSprite::createWithSpriteFrameName(aWomenStr->getCString());
                CCSprite *aWomenSelectedSpr = CCSprite::createWithSpriteFrameName(aWomenStr->getCString());
                
                CCMenuItemSprite *womenMenuItem = CCMenuItemSprite::create(aWomenNormalSpr, aWomenSelectedSpr, this, menu_selector(VBBSettingScene::womenScrollSelection));
                womenMenuItem->setPosition(ccp(currPos.x, currPos.y));
                currPos.x += 400;
                scrollLayer->addChild(womenMenuItem,3);
                womenMenuItem->setTag(kSettingCardTag);
                j++;
            }
        }
    }
    
    //setting the length of the scroll
    scrollView->setContentSize(CCSize(2000,210));
    
    //setting the start offset for the image inside scroll
    scrollView->setContentOffset(CCPointMake(0,0), false);
}

void VBBSettingScene::Background(){
    
    //Add Bg
    backgrndScrollBg = CCSprite::createWithSpriteFrameName("setting_screen_foregrnd_bg.png");
    backgrndScrollBg->setPosition(ccp(winsize.width/2 - 260, winsize.height/2 - 230));
    backgrndScrollBg->setAnchorPoint(CCPointZero);
    backgrndScrollBg->setTag(222);
    this->addChild(backgrndScrollBg,1);
    
    //Add Scroll View For Background
    scrollLayer = CCLayer::create();
    scrollView = CCScrollView::create(CCSize(490,710));
    scrollView->setDirection(kCCScrollViewDirectionHorizontal);
    scrollView->setBounceable(true);
    scrollView->setContainer(scrollLayer);
    this->addChild(scrollView, 3);
    
    scrollView->setPosition(ccp(270, winsize.height/2 - 220));
    
    if (!isCharctrBtnEnabled) { //------BACKGROUND-----//
        
        if (isDaySelected) { //Day
            
            CCObject *aDayItemObj = NULL;
            int i=0;
            CCPoint currPos = CCPoint(220, 180);
            CCARRAY_FOREACH(aDayItemsArr, aDayItemObj) {
                
                CCString *aDayStr = (CCString *)aDayItemsArr->objectAtIndex(i);
                
                CCSprite *aDayNormalSpr = CCSprite::createWithSpriteFrameName(aDayStr->getCString());
                CCSprite *aDaySelectedSpr = CCSprite::createWithSpriteFrameName(aDayStr->getCString());
                
                CCMenuItemSprite *dayMenuItem = CCMenuItemSprite::create(aDayNormalSpr, aDaySelectedSpr, this, menu_selector(VBBSettingScene::dayScrollSelection));
                dayMenuItem->setPosition(ccp(currPos.x,currPos.y));
                currPos.x += 530;
                scrollLayer->addChild(dayMenuItem,3);
                dayMenuItem->setTag(kSettingCardTag);
            }
        }
        else if (!isDaySelected) { //Night
            
            CCObject *aDayItemObj = NULL;
            int j=0;
            CCPoint currPos = CCPoint(240, 180);
            CCARRAY_FOREACH(aNightItemsArr, aDayItemObj) {
                
                CCString *aNightStr = (CCString *)aNightItemsArr->objectAtIndex(j);
                
                CCSprite *aNightNormalSpr = CCSprite::createWithSpriteFrameName(aNightStr->getCString());
                CCSprite *aNightSelectedSpr = CCSprite::createWithSpriteFrameName(aNightStr->getCString());
                
                CCMenuItemSprite *nightMenuItem = CCMenuItemSprite::create(aNightNormalSpr, aNightSelectedSpr, this, menu_selector(VBBSettingScene::nightScrollSelection));
                
                nightMenuItem->setPosition(ccp(currPos.x,currPos.y));
                currPos.x += 540;
                scrollLayer->addChild(nightMenuItem,3);
                nightMenuItem->setTag(kSettingCardTag);
            }
        }
    }
    
    //setting the length of the scroll
    scrollView->setContentSize(CCSize(2700,210));
    
    //setting the start offset for the image inside scroll
    scrollView->setContentOffset(CCPointMake(5, 0), false);
}


// Men-Women
void VBBSettingScene::menScrollSelection() {
    
}

void VBBSettingScene::womenScrollSelection() {
    
}

// Day-Night
void VBBSettingScene::dayScrollSelection() {
    
}

void VBBSettingScene::nightScrollSelection() {
    
}

#pragma mark - Menu Methods
void VBBSettingScene::selectCharacter() {
    
    //status for menu items in this menu
    charactrItem->selected();
    selectBgItem->unselected();
    
    backgroundClickCount=0;
    characterClickCount++;
    
    if (characterClickCount >= 2) {
        return;
    }
    
    leftArrow1->removeFromParentAndCleanup(true);
    rightArrow1->removeFromParentAndCleanup(true);
    
    this->removeChildByTag(222);
    this->removeChild(backgrndScrollBg, true);
    this->removeChild(scrollView, true);
    
    //Reset the variables
    isCharctrBtnEnabled = true;
    
    menItems->setVisible(true);
    womenItems->setVisible(true);
    
    dayBtn->setVisible(false);
    nightBtn->setVisible(false);
    
    CCCallFunc *characterFunc = CCCallFunc::create(this, callfunc_selector(VBBSettingScene::Character));
    this->runAction(characterFunc);
    
    this->initializeArrowBtns();
}

void VBBSettingScene::selectBg() {
    
    //status of menu items
    charactrItem->unselected();
    selectBgItem->selected();
    
    characterClickCount=0;
    backgroundClickCount++;
    if (backgroundClickCount >= 2) {
        return;
    }
    
    leftArrow->removeFromParentAndCleanup(true);
    rightArrow->removeFromParentAndCleanup(true);
    
    //remove Scroll View For Character
    this->removeChild(scrollView, true);
    this->removeChildByTag(111);
    this->removeChild(characterScrollBg, true);
    
    isCharctrBtnEnabled = false;
    
    dayBtn->setVisible(true);
    nightBtn->setVisible(true);
    
    menItems->setVisible(false);
    womenItems->setVisible(false);
    
    dayBtn->selected();
    nightBtn->unselected();
    
    CCCallFunc *characterFunc = CCCallFunc::create(this, callfunc_selector(VBBSettingScene::Background));
    this->runAction(characterFunc);
    
    this->initializeArrowBtns();
}

//MEN & WOMEN BUTTON METHODS
void VBBSettingScene::selectMenCharacter() {
    
    //Removing all children
    this->removeChildByTag(111);
    scrollLayer->removeAllChildren();
    
    //status of menu items
    menItems->selected();
    womenItems->unselected();
    isMenBtnSelected = true;
    
    //Scroll View
    this->Character();
}

void VBBSettingScene::selectWomenCharacter() {
    
    //Removing all children
    this->removeChildByTag(111);
    scrollLayer->removeAllChildren();
    
    //status of menu items
    womenItems->selected();
    menItems->unselected();
    
    isMenBtnSelected = false;
    
    //Scroll View
    this->Character();
}

//DAY & NIGHT BUTTON METHODS
void VBBSettingScene::DayBtnAction() {
    
    //Removing all children
    this->removeChildByTag(222);
    scrollLayer->removeAllChildren();
    
    //status of menu items
    dayBtn->selected();
    nightBtn->unselected();
    
    isDaySelected = true;
    
    //Scroll View
    this->Background();
}

void VBBSettingScene::NightBtnAction() {
    
    //Removing all children
    this->removeChildByTag(222);
    scrollLayer->removeAllChildren();
    
    //status of menu items
    nightBtn->selected();
    dayBtn->unselected();
    
    isDaySelected = false;
    
    //Scroll View
    this->Background();
}


//BACK TO MAINSCENE
void VBBSettingScene::backToScene() {
    
    CCTransitionScene *transition = CCTransitionSlideInR::create(0.9, VBBMainScene::scene());
    CCDirector::sharedDirector()->replaceScene(transition);
}

#pragma mark - Touch
void VBBSettingScene::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
}

void VBBSettingScene::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent) {
    
    CCTouch* touch = (CCTouch*)( pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
    
    //disabled the touch for the scroll view
    //make the scroll work only with the arrow buttons
    scrollView->setTouchEnabled(false);
}

void VBBSettingScene::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
}

//ARROW BUTTON
void VBBSettingScene::initializeArrowBtns() {
    
    if (isCharctrBtnEnabled) { //------FOR CHARACTER BUTTON-----//
        
        CCSprite *normalLeftArrow = CCSprite::createWithSpriteFrameName("screen_arrw_lft.png");
        CCSprite *selectedLeftArrow = CCSprite::createWithSpriteFrameName("screen_arrw_lft.png");
        
        leftArrow = CCMenuItemSprite::create(normalLeftArrow, selectedLeftArrow, this, menu_selector(VBBSettingScene::leftArrowPressed));
        leftArrow->setPosition(ccp(328, 280));
        
        
        CCSprite *normalRightArrow = CCSprite::createWithSpriteFrameName("screen_arrw_rght.png");
        CCSprite *selectedRightArrow = CCSprite::createWithSpriteFrameName("screen_arrw_rght.png");
        
        rightArrow = CCMenuItemSprite::create(normalRightArrow, selectedRightArrow,this, menu_selector(VBBSettingScene::rightArrowPressed));
        rightArrow->setPosition(ccp(674, 280));
        
        //---------Menu
        CCMenu *characterChngeMenu = CCMenu::create(leftArrow, rightArrow, NULL);
        characterChngeMenu->setPosition(CCPointZero);
        this->addChild(characterChngeMenu,3);
    }
    else if(!this->isCharctrBtnEnabled) { //------FOR BACKGROUND BUTTON-----//
        
        CCSprite *normalLeftArrow = CCSprite::createWithSpriteFrameName("screen_arrw_lft.png");
        CCSprite *selectedLeftArrow = CCSprite::createWithSpriteFrameName("screen_arrw_lft.png");
        
        leftArrow1 = CCMenuItemSprite::create(normalLeftArrow, selectedLeftArrow, this, menu_selector(VBBSettingScene::leftArrowPressed));
        leftArrow1->setPosition(ccp(250, 270));
        
        
        CCSprite *normalRightArrow = CCSprite::createWithSpriteFrameName("screen_arrw_rght.png");
        CCSprite *selectedRightArrow = CCSprite::createWithSpriteFrameName("screen_arrw_rght.png");
        
        rightArrow1 = CCMenuItemSprite::create(normalRightArrow, selectedRightArrow,this, menu_selector(VBBSettingScene::rightArrowPressed));
        rightArrow1->setPosition(ccp(804, 270));
        
        //---------Menu
        CCMenu *BgChngeMenu = CCMenu::create(leftArrow1, rightArrow1, NULL);
        BgChngeMenu->setPosition(CCPointZero);
        this->addChild(BgChngeMenu,3);
    }
}

//LEFT & RIGHT ARROW BUTTON ACTIONS
void VBBSettingScene::leftArrowPressed(CCObject *sender)
{
    if (clickArrowCount <= 0) {
        return;
    }
    clickArrowCount--;
    
    if (isCharctrBtnEnabled) {
        
        CCPoint currentContentOffset = this->scrollView->getContentOffset();
        
        float newContentOffsetX = currentContentOffset.x + kCharctrBgGapX;
        if(newContentOffsetX>=0){
            newContentOffsetX = 0.0f;
        }
    this->scrollView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
    }
    else if (!isCharctrBtnEnabled) {
        
        CCPoint currentContentOffset = this->scrollView->getContentOffset();
        
        float newContentOffsetX = currentContentOffset.x + kBackgroundBgGapX;
        if(newContentOffsetX>=0){
            newContentOffsetX = 0.0f;
        }
        this->scrollView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
    }
}

void VBBSettingScene::rightArrowPressed(CCObject *sender)
{
    if (clickArrowCount > aMenItemsArr->count()) {
        return;
    }
    clickArrowCount++;
    
    if (isCharctrBtnEnabled) {
        
        CCPoint currentContentOffset = this->scrollView->getContentOffset();
        
        float newContentOffsetX = currentContentOffset.x - kCharctrBgGapX;
        float maxContentOffsetX = -1*(kCharctrBgGapX*5)+kScrollCharacterWidth-3;
        
        if(newContentOffsetX <= maxContentOffsetX){
            newContentOffsetX = maxContentOffsetX;
        }
    this->scrollView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
    }
    else if (!isCharctrBtnEnabled) {
        
        CCPoint currentContentOffset = this->scrollView->getContentOffset();
        
        float newContentOffsetX = currentContentOffset.x - kBackgroundBgGapX;
        float maxContentOffsetX = -1*(kBackgroundBgGapX*5)+kScrollBackgroundWidth-6;
        
        if(newContentOffsetX <= maxContentOffsetX){
            newContentOffsetX = maxContentOffsetX;
        }
        this->scrollView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
    }
}

#pragma mark - Dealloc
void VBBSettingScene::onExit() {
    
    CCLayer::onExit();
    
    //removing the plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameUIImages/SettingScreen/VBBSettingScene.plist");
}

VBBSettingScene::~VBBSettingScene() {
    
    //releasing the Array's
//    CC_SAFE_RELEASE_NULL();
}

