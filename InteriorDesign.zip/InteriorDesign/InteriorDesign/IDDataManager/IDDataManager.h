//
//  BADataManager.h
//  InteriorDesign
//
//  Created by Vivek on 13/05/13.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

////////
// SHARED DATA MANAGER OF PAINT
////////


#import <Foundation/Foundation.h>

@class IDDrawScene;

@interface IDDataManager : NSObject
{
    //Game Layer
    IDDrawScene *drawLayer;
}

+(IDDataManager *)sharedManager;

@property(nonatomic,assign) IDDrawScene *drawLayer;;


@end
