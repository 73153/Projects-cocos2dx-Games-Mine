//
//  IDDataManager.m
//  InteriorDesign
//
//  Created by Vivek on 13/05/13.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "IDDataManager.h"
@class IDMainScene;
@implementation IDDataManager

//Synthesis
@synthesize drawLayer;

static  IDDataManager *sSharedInstance = nil;

#pragma mark - Singleton Default Methods

- (id) init
{
	self = [super init];
	if (self != nil) {
        
             
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
  }

+(IDDataManager *)sharedManager
{
    @synchronized(self) {
        if (sSharedInstance == nil) {
            [[self alloc] init];// assignment not done here
        }
    }
    return sSharedInstance;
}


+ (id)allocWithZone:(NSZone *)zone
{
    @synchronized(self) {
        if (sSharedInstance == nil) {
            sSharedInstance = [super allocWithZone:zone];
            return sSharedInstance;  // assignment and return on first allocation
        }
    }
    return nil; //on subsequent allocation attemIDs return nil
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain
{
    return self;
}

- (unsigned)retainCount
{
    return UINT_MAX;  //denotes an object that cannot be released
}

- (id)autorelease
{
    return self;
}

#pragma mark - IDDataManager Implementation

@end
