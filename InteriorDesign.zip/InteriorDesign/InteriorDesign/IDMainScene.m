//
//  IDMainScene.m
//  InteriorDesign
//
//  Created by Vivek on 13/05/13.
//  Copyright Vivek 2013. All rights reserved.
//


// Import the interfaces
#import "IDMainScene.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#import "SimpleAudioEngine.h"

#pragma mark - IDMainScene

// IDMainScene implementation
@implementation IDMainScene
@class IDDataManager;

// Helper class method that creates a Scene with the IDMainScene as the only child.
+(CCScene *) scene
{
    // 'scene' is an autorelease object.
    CCScene *scene = [CCScene node];
    
    // 'layer' is an autorelease object.
    IDMainScene *layer = [IDMainScene node];
    
    // add layer as a child to scene
    [scene addChild: layer];
    
    // return the scene
    return scene;
}

-(void)onEnter
{
    [super onEnter];
    [self setTouchEnabled:YES];
    
    //ask director the window size
    winsize= [[CCDirector sharedDirector]winSize];
    
    [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"UIImages/MainScreen/IDMainScene.plist"];
    
    NSString *basePath = [[NSBundle mainBundle] pathForResource:@"IDData" ofType:@"plist"];
    self.gameDict=[NSDictionary dictionaryWithContentsOfFile:basePath];
    
    self.BedRoomDict =[self.gameDict objectForKey:@"BedRoom"];
    self.BathRoomDict =[self.gameDict objectForKey:@"BathRoom"];
    self.DesignsDict =[self.gameDict objectForKey:@"Designs"];
    self.LivingRoomDict =[self.gameDict objectForKey:@"LivingRoom"];
    self.DinningRoomDict =[self.gameDict objectForKey:@"DinningRoom"];
    
    //call to initialize variables
    [self initializeVariables];
    
    //Add Game UI
    [self initializeGameUI];
    
}

#pragma mark - Initialize
-(void)initializeVariables
{
    topBarItemsArr = [[CCArray alloc]init];
    canSelectDesignBtn=true;
    isTopBarPopUpItemSelected=true;
}

-(void)initializeGameUI {
    
    //---------------BG
    NSString *ImageSprName = [self.BedRoomDict objectForKey:@"Background"];
    CCSprite *homeBg =[CCSprite spriteWithFile:ImageSprName];
    homeBg.position=ccp(winsize.width/2, winsize.height/2);
    [self addChild:homeBg z:0];
    
    //Initialize
    //TOP BAR BUTTONS
    [self initializeTopBarItems];
    //
    //POP UP ITEMS
    //Top Bar
    [self initializePopUpItems];
    //
    //Bottom Bar
    [self initializeBottomPopUpItems];
}


#pragma mark -------------------MENU ACTIONS
#pragma mark - TopBar
-(void)initializeTopBarItems
{
    
    //----------MENU ITEMS
    CCSprite *normalBedRoomBtn = [CCSprite spriteWithSpriteFrameName:@"b_room_btn.png"];
    CCSprite *selectedBedRoomBtn = [CCSprite spriteWithSpriteFrameName:@"b_room_btn_hvr.png"];
    
    CCMenuItemSprite *BedRoomMenuItem = [CCMenuItemSprite  itemWithNormalSprite:normalBedRoomBtn selectedSprite:selectedBedRoomBtn target:self selector:@selector(topBarMenuItems:)];
    [BedRoomMenuItem setTag:11];
    BedRoomMenuItem.Position=(ccp(250, 736.9));
    
    CCSprite *normalBathRoomBtn = [CCSprite spriteWithSpriteFrameName:@"bath_room_btn.png"];
    CCSprite *selectedBathRoomBtn = [CCSprite spriteWithSpriteFrameName:@"bath_room_btn_hvr.png"];
    
    CCMenuItemSprite *bathRoomMenuItem = [CCMenuItemSprite  itemWithNormalSprite:normalBathRoomBtn selectedSprite:selectedBathRoomBtn target:self selector:@selector(topBarMenuItems:)];
    [bathRoomMenuItem setTag:12];
    
    bathRoomMenuItem.Position=(ccp(447.9, 736.9));
    
    CCSprite *normalDiningRoomBtn = [CCSprite spriteWithSpriteFrameName:@"d_room_btn.png"];
    CCSprite *selectedDiningRoomBtn = [CCSprite spriteWithSpriteFrameName:@"d_room_btn_hvr.png"];
    
    CCMenuItemSprite *diningRoomMenuItem = [CCMenuItemSprite  itemWithNormalSprite:normalDiningRoomBtn selectedSprite:selectedDiningRoomBtn target:self selector:@selector(topBarMenuItems:)];
    [diningRoomMenuItem setTag:13];
    
    diningRoomMenuItem.Position=(ccp(675, 736.9));
    
    CCSprite *normalLivingRoomBtn = [CCSprite spriteWithSpriteFrameName:@"l_room_btn.png"];
    CCSprite *selectedLivingRoomBtn = [CCSprite spriteWithSpriteFrameName:@"l_room_btn_hvr.png"];
    
    CCMenuItemSprite *livingRoomMenuItem = [CCMenuItemSprite  itemWithNormalSprite:normalLivingRoomBtn selectedSprite:selectedLivingRoomBtn target:self selector:@selector(topBarMenuItems:)];
    [livingRoomMenuItem setTag:14];
    
    livingRoomMenuItem.Position=(ccp(910.6, 736.9));
    
    CCMenu *menuItemsForPaperSlide =[ CCMenu menuWithItems:BedRoomMenuItem,bathRoomMenuItem,diningRoomMenuItem,livingRoomMenuItem,NULL];
    menuItemsForPaperSlide.position=ccp(0,0);
    [self addChild:menuItemsForPaperSlide z:1];
    
}

-(void)initializePopUpItems {
    
    //Initial Position for Top Bar
    topBarBg = [CCSprite spriteWithSpriteFrameName:@"top_bar.png"];
    topBarBg.Position=(ccp(512, 745));
    [topBarBg setVisible:false];
    [self addChild:topBarBg];
    
}


-(NSArray*)getArray:(int)selectedItem{
    
    if(self.selectedMenuIndex==11){
        NSArray *BedRoomArr=[self.BedRoomDict objectForKey:@"BedRoomArr"];
        //        NSInteger tag = [BedRoomArr objectForKey:@"setTag"];
        return BedRoomArr;
        
    }
    else if(self.selectedMenuIndex==12){
        NSArray *BathRoomArr=[self.BathRoomDict objectForKey:@"BathRoomArr"];
        return BathRoomArr;
        
    }
    else if(self.selectedMenuIndex==13){
        NSArray *DinningRoomArr=[self.DinningRoomDict objectForKey:@"DinningRoomArr"];
        return DinningRoomArr;
        
    }
    else if(self.selectedMenuIndex==14){
        NSArray *LivingRoomArr=[self.LivingRoomDict objectForKey:@"LivingRoomArr"];
        return LivingRoomArr;
    }
}

-(void)ImageSprNamePosition:(NSArray*)ArrForAll
{
    int xVal=68.5;
    int yVal=40;
    int indexVal=1;
    
    for(int i=0;i<[ArrForAll count];i++){
        
        NSDictionary *DictForAll=[ArrForAll objectAtIndex:i];
        NSString *ImageSprName = [DictForAll objectForKey:@"ImageName"];
        
        NSNumber *num = [DictForAll valueForKey:@"setTag"];
        int tag = [num intValue];
        
        CCSprite *NormalSpr =[CCSprite spriteWithSpriteFrameName:ImageSprName];
        CCSprite *SelectedSpr =[CCSprite spriteWithSpriteFrameName:ImageSprName];
        
        
        CCMenuItemSprite *MenuItem = [CCMenuItemSprite  itemWithNormalSprite:NormalSpr selectedSprite:SelectedSpr target:self selector:@selector(menuCallback:)];
        
        MenuItem.position=ccp(xVal,yVal);
        
        [MenuItem setTag:tag];
        
        xVal= xVal+128;
        indexVal++;
        
        CCMenu *roomItemsMenu = [ CCMenu menuWithItems:MenuItem, NULL];
        roomItemsMenu.Position=ccp(0,0);
        [topBarBg addChild:roomItemsMenu z:1];        
    }
}

-(void)moveTopBarDown:(id)sender {
    
    [self ImageSprNamePosition:[self getArray:self.selectedMenuIndex]];
    
    //Final Moved Position
    [topBarBg setVisible:true];
    CCMoveTo *moveTo = [CCMoveTo actionWithDuration:0.12 position:ccp([topBarBg position].x, 665)];
    [topBarBg runAction:moveTo];

}

-(void)moveTopBarUp:(id)sender {

    CCMoveTo *moveTo = [CCMoveTo actionWithDuration:0.12 position:ccp([topBarBg position].x, 745)];
    
    CCSequence *seq =[CCSequence actions:moveTo,[CCCallFunc actionWithTarget:self selector:@selector(setVisibility:)],NULL];
    [topBarBg runAction:seq];
    
}

-(void)setVisibility:(id)sender
{
    [topBarBg setVisible:false];
}


-(void)topBarMenuItems:(id)sender {
    self.topBarSelectedCount=self.selectedMenuIndex;
    self.selectedMenuIndex = [sender tag];
    [topBarBg removeAllChildrenWithCleanup:true];
    
    
    if(self.selectedMenuIndex==self.topBarSelectedCount)
    {
        
        if(topBarBg.position.y>=745){
           
            [self moveTopBarDown:sender];
        }
        else
        {
            [self moveTopBarUp:sender];
        }
    
    }
    
    else
    {
        [self moveTopBarDown:sender];

    }
}


#pragma mark - Pillows
-(void)createPillow1
{
    
    //Sprites to be added on topBar
    CCSprite *pillow1 = [CCSprite spriteWithSpriteFrameName:@"deco_pillw_big.png"];
    pillow1.Position=(ccp(68.6, 657.3));
    [self addChild:pillow1];
    [topBarItemsArr addObject:pillow1];
    
    CCMoveTo *moveTo = [CCMoveTo actionWithDuration:1.5 position:ccp(winsize.width/2 + 130, winsize.height/2 + 20)];
    [pillow1 runAction:moveTo];
    
    //to get position of moved Sprite from topBar when we press bottom Bar Menu Item
    selectedItem = pillow1;
}

-(void)createPillow2
{
    
    CCSprite *pillow2 = [CCSprite spriteWithSpriteFrameName:@"sleepng_pillws.png"];
    pillow2.Position=(ccp(198, 658.1));
    [self addChild:pillow2];
    
    [topBarItemsArr addObject:pillow2];
    
    CCMoveTo *moveTo = [CCMoveTo actionWithDuration:1.5 position: ccp(winsize.width/2 + 50, winsize.height/2 + 20)];
    [pillow2 runAction:moveTo];
    
    //to get position of moved Sprite from topBar when we press bottom Bar Menu Item
    selectedItem = pillow2;
}


#pragma mark - Menu Functions
-(void)menuCallback:(id)sender {
    
    CCMenuItemSprite *item=(CCMenuItemSprite*)sender;
    
    int tag = item.tag;
    
    switch (tag)
    {
        case 1: [self createPillow1];
            break;
            
        case 2: [self createPillow2];
            break;
            
        case 3: [self designsBtnMethod];
            break;
            
        case 4: [self closeBtnMethod];
            break;
            
        default:break;
    }
}


#pragma mark - BottomBar
-(void)initializeBottomPopUpItems {
    
    //Initial Position for Bottom Bar
    bottomBarBg = [CCSprite spriteWithSpriteFrameName:@"bottom_bar.png"];
    bottomBarBg.Position=(ccp(512, 0));
    [bottomBarBg setVisible:false];
    [self addChild:bottomBarBg];
    
    
    CCSprite *bottomBarItem1 = [CCSprite spriteWithSpriteFrameName:@"desgn_1_btn.png"];
    bottomBarItem1.Position=(ccp(71.4, 57));
    [bottomBarBg addChild:bottomBarItem1];
    
    //Sprites to be added on bottomBar
    NSArray *DesignArr=[self.DesignsDict objectForKey:@"DesignsArr"];
    //    NSLog(@"bedRoomDict count=%lu",(unsigned long)[BedRoomArr count]);
    
    int indexVal=3;
    int xVal=98.7;
    int yVal=133.5;
    for(int i=0;i<[DesignArr count];i++){
        
        NSDictionary *DesignDict=[DesignArr objectAtIndex:i];
        
        NSString *ImageSprName = [DesignDict objectForKey:@"Design"];
        
        CCSprite *NormalSpr =[CCSprite spriteWithSpriteFrameName:ImageSprName];
        CCSprite *SelectedSpr =[CCSprite spriteWithSpriteFrameName:ImageSprName];
        
        bottomBarMenuItem = [CCMenuItemSprite  itemWithNormalSprite:NormalSpr selectedSprite:SelectedSpr target:self selector:@selector(menuCallback:)];
        
        bottomBarMenuItem.Position=(ccp(xVal, yVal));
        
        xVal = xVal+908;
        
        [bottomBarMenuItem setTag:indexVal];
        
        closeBtnMenuItem.Position=(ccp(1006, 133.5));
        [closeBtnMenuItem setTag:4];
        
        CCMenu *bottomItemsMenu = [ CCMenu menuWithItems:bottomBarMenuItem, closeBtnMenuItem, NULL];
        bottomItemsMenu.Position=ccp(0,0);
        [self addChild:bottomItemsMenu z:1];
        
        indexVal++;
    }
    
}

-(void)designsBtnMethod
{
    if (canSelectDesignBtn)
    {
        bottomBarBg.Position=(ccp(512, 0));
        canSelectDesignBtn=false;
        [bottomBarBg setVisible:true];
        CCMoveTo *moveTo = [CCMoveTo actionWithDuration:0.2 position:ccp([bottomBarBg position].x ,[bottomBarBg position].y+58.2)];
        CCSequence *Seq = [CCSequence actions:moveTo,[CCCallFunc actionWithTarget:self selector:@selector(resetBottomBgPosition)], NULL];
        [bottomBarBg runAction:Seq];
    }
}

-(void)closeBtnMethod
{
    CCMoveTo *moveTo = [CCMoveTo actionWithDuration:0.2 position:ccp([bottomBarBg position].x ,-58.2)];
    [bottomBarBg runAction:moveTo];
    canSelectDesignBtn = true;
}

-(void)resetBottomBgPosition
{
    
    bottomBarBg.Position=(ccp(512, 58.2));
}

#pragma mark - Touch
- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
    
    
    NSObject *topBarItemsObj = NULL;
    CCARRAY_FOREACH(topBarItemsArr, topBarItemsObj)
    {
        CCSprite *topBarItemSpr = (CCSprite*)topBarItemsObj;
        
        CGRect targetRect = topBarItemSpr.boundingBox;
        if (CGRectContainsPoint(targetRect, location)){
            
            isTopBarPopUpItemSelected = true;
            selectedItem = topBarItemSpr;
            [selectedItem setZOrder:3];
            //to get the position of the movedSprite assign sprite to movedSprite
            break;
        }
    }
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
//    CGRect spriteRect = selectedItem.boundingBox;

    if (isTopBarPopUpItemSelected) {
        
        selectedItem.Position=(location);
//        movedSprite.Position= movedSprite.position;
    }
}

-(void) ccTouchEnded:(NSSet *)touch withEvent:(UIEvent *)event
{
    
    isTopBarPopUpItemSelected = false;
}


#pragma mark - onExit
-(void)onExit
{
    [super onExit];
    
    [[CCSpriteFrameCache sharedSpriteFrameCache] removeSpriteFramesFromFile:@"IDMainScene.plist"];
    
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
    // in case you have something to dealloc, do it in this method
    // in this particular example nothing needs to be released.
    // cocos2d will automatically release all the children (Label)
    
    // don't forget to call "super dealloc"
    [super dealloc];
}

#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
    AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
    [[app navController] dismissModalViewControllerAnimated:YES];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
    AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
    [[app navController] dismissModalViewControllerAnimated:YES];
}
@end

