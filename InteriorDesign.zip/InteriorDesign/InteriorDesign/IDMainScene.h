//
//  IDMainScene.h
//  InteriorDesign
//
//  Created by Vivek on 13/05/13.
//  Copyright Vivek 2013. All rights reserved.
//


#import <GameKit/GameKit.h>

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// IDMainScene
@interface IDMainScene : CCLayer 
{

    //---------VARIABLES
    CGSize winsize;
    CCSprite *topBarBg;
    CCSprite *bottomBarBg;
    CCSprite *selectedItem;
    
    CCArray *topBarItemsArr;
        
    bool canSelectDesignBtn;
    bool isTopBarPopUpItemSelected;
    int selectedMenuIndex;
    
    //-----------Menu
    //Variables
    CCMenuItemSprite *bottomBarMenuItem;
    CCMenuItemSprite *closeBtnMenuItem;

    
}
@property (nonatomic,assign)   int selectedMenuIndex;
@property (nonatomic,assign)    int topBarSelectedCount;


@property (nonatomic,retain)      NSDictionary  *gameDict;
@property (nonatomic,retain)      NSDictionary *BathRoomDict;
@property (nonatomic,retain)      NSDictionary *BedRoomDict;
@property (nonatomic,retain)      NSDictionary *DesignsDict;
@property (nonatomic,retain)      NSDictionary *DinningRoomDict;
@property (nonatomic,retain)      NSDictionary *LivingRoomDict;

@property (nonatomic,retain)      NSMutableArray *DesignArr;


// returns a CCScene that contains the IDMainScene as the only child
+(CCScene *) scene;

-(NSArray*)getArray:(int)selectedItem;

@end
