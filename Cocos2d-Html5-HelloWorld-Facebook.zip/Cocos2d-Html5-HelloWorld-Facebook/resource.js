var s_HelloWorld = "HelloWorld.png";
var g_ressources = [
    {src:s_HelloWorld}
];
