ParticleEmitterStudio
=====================

Particle Emitter Studio allows you to test various particle settings for use in cocos2d/cocos2d-x and to export them.