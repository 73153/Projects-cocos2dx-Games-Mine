//
//  Item.h
//  ChemRef
//
//  Created by Created by Lemonadestand.com.au on 3/2/09.
//  Copyright 2009 zxZX. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Fav : NSObject {
	int _id;
	NSString* score_name;
	NSString* score_points;
	
}

@property    int _id;
@property(nonatomic,retain)    NSString* score_name;
@property(nonatomic,retain)    NSString* score_points;

@end
