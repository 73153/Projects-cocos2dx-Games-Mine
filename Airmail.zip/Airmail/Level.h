//
//  Item.h
//  ChemRef
//
//  Created by Created by Lemonadestand.com.au on 3/2/09.
//  Copyright 2009 zxZX. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Level : NSObject {
	int _id;
	int goal;
	int bombs;
	int packages;
	NSString* locked;
	NSString* score;
	int _time;
	NSString* _background;
	float _speed;
	int _wind;
}

@property(nonatomic, assign)   int _id;
@property(nonatomic, assign)   int goal;
@property(nonatomic, assign)  int bombs;
@property(nonatomic, assign)   int packages;
@property(nonatomic,retain)    NSString* locked;
@property(nonatomic,retain)    NSString* score;
@property(nonatomic, assign)	int _time;
@property(nonatomic,retain)    NSString* _background;
@property(nonatomic, assign)  float _speed;
@property(nonatomic, assign)	int _wind;



@end
