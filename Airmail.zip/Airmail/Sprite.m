//
//  Item.m
//  ChemRef
//
//  Created by Created by Lemonadestand.com.au on 3/2/09.
//  Copyright 2009 zxZX. All rights reserved.
//

#import "Sprite.h"


@implementation Sprite


@synthesize _id;
@synthesize height;
@synthesize width;
@synthesize x;
@synthesize y;
@synthesize level_id;
@synthesize type;
@synthesize imagefile;

- (void)dealloc {
	[type release];
	[imagefile release];
	[super dealloc];
}



@end
