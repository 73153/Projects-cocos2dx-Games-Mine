#import "cocos2d.h"

@interface CCSuck : CCGrid3DAction {
    CGPoint toPoint;
	float amplitudeRate;
}

@property (nonatomic,readwrite) CGPoint toPoint;

+(id)actionWithGrid:(ccGridSize)gridSize duration:(ccTime)d toPoint:(CGPoint)p;
-(id)initWithGrid:(ccGridSize)gridSize duration:(ccTime)d toPoint:(CGPoint)p;

@end
