#import "CCSuck.h"


@implementation CCSuck

@synthesize toPoint;

+(id)actionWithGrid:(ccGridSize)gridSize duration:(ccTime)d toPoint:(CGPoint)p
{
	return [[[self alloc] initWithGrid:gridSize duration:d toPoint:p] autorelease];
}

-(id)initWithGrid:(ccGridSize)gridSize duration:(ccTime)d toPoint:(CGPoint)p
{
	if ( (self = [super initWithSize:gridSize duration:d]) )
	{
		amplitudeRate = 1.0f;
        toPoint = p;
	}
	return self;
}

-(void)update:(ccTime)time
{
	int i, j;
    CGPoint target = toPoint;
	
	for( i = 0; i < (gridSize_.x+1); i++ )
	{
		for( j = 0; j < (gridSize_.y+1); j++ )
		{
			ccVertex3F	v = [self vertex:ccg(i,j)];
			
            CGFloat s = ccpDistance(ccp(v.x, v.y), target);
            float distx = abs(v.x - target.x);
            float disty = abs(v.y - target.y);
			
            if (s > 0) {
                s = s / (10/duration_);
				
                float valx = distx*time/s;
                if (valx > distx) valx = distx;
                if (valx < 0) valx = 0;
                float valy = disty*time/s;
                if (valy > disty) valy = disty;
                if (valy < 0) valy = 0;
				
                if (v.x < target.x)
                    v.x += valx;
                if (v.x >= target.x)
                    v.x -= valx;
				
                if (v.y < target.y)
                    v.y += valy;
                if (v.y >= target.y)
                    v.y -= valy;
            }
			
			[self setVertex:ccg(i,j) vertex:v];
		}
	}
}

-(id) copyWithZone: (NSZone*) zone
{
	CCGridAction *copy = [[[self class] allocWithZone:zone] initWithGrid:gridSize_ duration:duration_ toPoint:toPoint];
	return copy;
}

@end
