#import "HelloWorldLayer.h"
#import "CCSuck.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
		//Add bg
		CCSprite *bgSprite = [CCSprite spriteWithFile:@"bg.png"];
		bgSprite.anchorPoint = ccp(0, 0);
		bgSprite.position = ccp(0, 0);
		[self addChild:bgSprite z:-1];
		
		//Add a raccoon
		CCSprite *raccoonSprite = [CCSprite spriteWithFile:@"raccoon.png"];
		raccoonSprite.position = ccp(240, 160);
		[self addChild:raccoonSprite z:1];
		
		[raccoonSprite runAction:[CCSequence actions:
								  [CCDelayTime actionWithDuration:10.0f],
								  [CCSuck actionWithGrid:ccg(10, 10)
												duration:3.0f
												 toPoint:ccp(240, 100)],
								  nil]];
		
		//Add a label
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"CCSuck Action Demo"
											  fontName:@"Verdana-BoldItalic"
											  fontSize:30];
		label.position = ccp(240, 300);
		label.color = ccBLUE;
		[self addChild:label z:1];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
