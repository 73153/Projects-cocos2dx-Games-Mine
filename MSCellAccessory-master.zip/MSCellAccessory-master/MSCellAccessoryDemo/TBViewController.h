//
//  TBViewController.h
//  MSCellAccessoryDemo
//
//  Created by SHIM MIN SEOK on 13. 6. 19..
//  Copyright (c) 2013 SHIM MIN SEOK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBViewController : UITableViewController

@end
