asteroid-rain
=============

A simple game written in C++ and using the cocos2d-x engine.
