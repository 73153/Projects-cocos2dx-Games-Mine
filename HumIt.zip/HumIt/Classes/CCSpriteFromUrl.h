//
//  CCSpriteFromUrl.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//
//

#ifndef __HumIt__CCSpriteFromUrl__
#define __HumIt__CCSpriteFromUrl__



#include "sprite_nodes/CCSprite.h"
//given a url it loads asyncrnously
class CCSpriteFromUrl:public cocos2d::CCSprite
{
    
    const char * mUrl;
    
    std::string name;
    
public:
    
    virtual bool init(const char * url);
    static CCSpriteFromUrl * create(const char * url);
    void setURL(const char * url);
    
    
    void onEnter()
    {
        cocos2d::CCSprite::onEnter();
        setURL(mUrl);
    }


};


//given a facebook is it fetches his profileimagw
class CCSpriteFaceBook:public CCSpriteFromUrl
{
    
    void fetchFaceBookProfile();
    
    std::string facebookuuid;

    
public:
    
    virtual bool init(const char * fuserid);
    static CCSpriteFaceBook * create(const char * fuserid);
    
    void onEnter()
    {
        cocos2d::CCSprite::onEnter();
        fetchFaceBookProfile();
    }

    
};



#endif /* defined(__HumIt__CCSpriteFromUrl__) */
