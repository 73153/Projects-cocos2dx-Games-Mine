#include "RecordAndPlay.h"
#include "SimpleAudioEngine.h"
#include "RecJNICommunicator.h"
#include "GUI/CCControlExtension/CCControlSlider.h"
#include "cocos-ext.h"

using namespace cocos2d;
using namespace CocosDenshion;
USING_NS_CC_EXT;

CCScene* RecordAndPlay::scene()
{
	CCLog(" -------------- entering RecordAndPlay::scene ---------------- ");
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    RecordAndPlay *layer = RecordAndPlay::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool RecordAndPlay::init()
{
	CCLog(" -------------- entering RecordAndPlay::init ---------------- ");
	isRecording = false;
	count = 0;
	loopCount = 0;
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

    // ask director the window size
	CCSize size = CCDirector::sharedDirector()->getWinSize();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(RecordAndPlay::menuCloseCallback) );
    pCloseItem->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );



    record = CCMenuItemImage::create(
                                            "record_bt.png",
                                            "record_bthvr.png",
                                            this,
                                            menu_selector(RecordAndPlay::startRecording) );
    record->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width/2, CCDirector::sharedDirector()->getWinSize().height/2 - 30) );



    stop = CCMenuItemImage::create(
                                                "stop_bt.png",
                                                "stop_bthvr.png",
                                                this,
                                                menu_selector(RecordAndPlay::startRecording) );
    stop->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width/2, CCDirector::sharedDirector()->getWinSize().height/2 - 30) );
    stop->setEnabled(false);
    stop->setVisible(false);

    CCMenuItemImage *loop = CCMenuItemImage::create(
                                                "loop_bt.png",
                                                "loop_bthvr.png",
                                                this,
                                                menu_selector(RecordAndPlay::startPlaying) );
    loop->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width/2, record->getPosition().y-(loop->getContentSize().height*1.5)) );

    pLoopings = CCMenuItemImage::create(
                                                "qest_bt.png",
                                                "qest_bthvr.png",
                                                this,
                                                menu_selector(RecordAndPlay::setLooping) );
    pLoopings->setPosition( ccp(loop->getPosition().x+loop->getContentSize().width/2+pLoopings->getContentSize().width/2, loop->getPosition().y) );
    //this->addChild(pLoopings, 1);

	// create menu, it's an autorelease object
	CCMenu* pMenu = CCMenu::create(pCloseItem,record,stop, loop, pLoopings, NULL);
	pMenu->setPosition( CCPointZero );
	this->addChild(pMenu, 1);

	// Add the slider

	CCControlSlider *slider = CCControlSlider::create("progressbg.png","progress_loading.png","prgress_bt_red.png");
	slider->setAnchorPoint(ccp(0.5f, 1.0f));
	slider->setMinimumValue(0.0f); // Sets the min value of range
	slider->setMaximumValue(10.0f); // Sets the max value of range
	slider->setPosition(ccp(size.width/2, (record->getPosition().y - record->getContentSize().height/2) - 10));
	slider->setTag(1100);
	this->addChild(slider,1);

	mLeftLabel = CCLabelTTF::create("00:10", "Thonburi", 34);
	// position the label on the center of the screen
	mLeftLabel->setColor(ccc3(0, 0, 0));
	mLeftLabel->setPosition( ccp(slider->getPosition().x-slider->getContentSize().width * 0.6, slider->getPosition().y) );
	mLeftLabel->setAnchorPoint(ccp(0.5f, 1.0f));
	// add the label as a child to this layer
	this->addChild(mLeftLabel, 1);

	mRightLabel = CCLabelTTF::create("00:00", "Thonburi", 34);
	mRightLabel->setColor(ccc3(0, 0, 0));
	// position the label on the center of the screen
	mRightLabel->setPosition( ccp(slider->getPosition().x+slider->getContentSize().width * 0.6, slider->getPosition().y) );
	mRightLabel->setAnchorPoint(ccp(0.5f, 1.0f));
	// add the label as a child to this layer
	this->addChild(mRightLabel, 1);

    // add "RecordAndPlay" splash screen"
    CCSprite* pSprite = CCSprite::create("bg.png");
    pSprite->setPosition( ccp(size.width/2, size.height/2) );
    // add the sprite as a child to this layer
    this->addChild(pSprite, 0);

    CCSprite* pBottomSprite = CCSprite::create("add.png");
    pBottomSprite->setPosition( ccp(size.width/2, pBottomSprite->getContentSize().height/2) );
    // position the sprite on the center of the screen
    this->addChild(pBottomSprite, 0);


    CCSprite* pRecordingBg = CCSprite::create("record_bg.png");
    pRecordingBg->setPosition( ccp(size.width/2, size.height/2) );
	// position the sprite on the center of the screen
	this->addChild(pRecordingBg, 0);

    return true;
}

void RecordAndPlay::menuCloseCallback(CCObject* pSender)
{
    CCDirector::sharedDirector()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void RecordAndPlay::startRecording(CCObject* pSender)
{
//	CCMenuItemImage *recordBtn = (CCMenuItemImage *)pSender;
	CCLOG(" ---------- inside startRecording ------ ");
	if(!isRecording) {

		count = 0;
		RecJNICommunicator::startRecordings();
		this->schedule(schedule_selector(RecordAndPlay::updateSecondTimer), 1);
		stop->setEnabled(true);
		stop->setVisible(true);

		record->setVisible(false);
		record->setEnabled(false);
	}
	else {
		RecJNICommunicator::stopRecording();
		this->unschedule(schedule_selector(RecordAndPlay::updateSecondTimer));
		//count = 1;
		record->setVisible(true);
		record->setEnabled(true);

		stop->setEnabled(false);
		stop->setVisible(false);
	}

	isRecording = !isRecording;
}

void RecordAndPlay::setLooping(CCObject* pSender)
{
//	CCMenuItemImage *recordBtn = (CCMenuItemImage *)pSender;

}

void RecordAndPlay::startPlaying(CCObject* pSender)
{
	isRecording = false;

	loopCount = 0;
//	this->schedule(schedule_selector(RecordAndPlay::updateSecondTimer), 1);

	CCMenuItemImage *playBtn = (CCMenuItemImage *)pSender;
	record->setVisible(true);
	record->setEnabled(true);

	stop->setEnabled(false);
	stop->setVisible(false);
	RecJNICommunicator::startPlaying(0);
	startRecording(pSender);
	CCControlSlider *slider = (CCControlSlider *)this->getChildByTag(1100);
	slider->setValue(0);

}

//get
const char* RecordAndPlay::getTime(void)
{
	int miniut = count / 60;
	int second = count % 60;
	char newTime[20];
	sprintf(newTime,"%02d:%02d",miniut,second);

	return newTime;
}


//This timer calls once every second
void RecordAndPlay::updateSecondTimer(float dt)
{
//	pLabel->setString(this->getTime());

	if(isRecording) {

//		mRightLabel->setString(this->getTime());
		count += 1;

		char time[20];
		sprintf(time,"00:%02d", count);
		mRightLabel->setString(time);

		CCControlSlider *slider = (CCControlSlider *)this->getChildByTag(1100);
		slider->setValue(count);

		if(count == 10) {
			RecJNICommunicator::stopRecording();
			this->unschedule(schedule_selector(RecordAndPlay::updateSecondTimer));
			//count = 0;
			record->setVisible(true);
			record->setEnabled(true);

			stop->setEnabled(false);
			stop->setVisible(false);
		}
	}
	else {

		loopCount++;
		char time[20];
		sprintf(time,"00:%02d", loopCount);
		mRightLabel->setString(time);
		CCControlSlider *slider = (CCControlSlider *)this->getChildByTag(1100);
		slider->setValue(loopCount);

		if(loopCount == count+1) {

			loopCount = 1;
			slider->setValue(1);
		}
	}
}
