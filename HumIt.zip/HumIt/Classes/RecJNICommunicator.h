//
//  DNJNICommunicator.h
//  Dominoes
//
//  Created by ICRG LABS on 07/09/12.
//
//

#ifndef Dominoes_DNJNICommunicator_h
#define Dominoes_DNJNICommunicator_h

#include "cocos2d.h"
#include <jni.h>

USING_NS_CC;

class RecJNICommunicator  {
    
public:
    
	RecJNICommunicator(void);
    virtual ~RecJNICommunicator(void);

    // facebook login and logout

    static void connectToFB();

    static void logoutFromFB();

    static void fetchFriendsList();

    // alert dialogs

    static void showDialog();

    static void dismissDialog();

    static void showAlert();

    // recording stuff
    static void startRecordings();

    static void stopRecording();

    static void startPlaying(int);

//    //World
    static bool isWorldLocked(const char *worldName);
//    static void unlockAllWorlds();
//
//
};


#endif
