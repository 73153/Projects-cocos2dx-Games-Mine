//
//  RandomPlayerScreen.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#ifndef __RandomPlayerScreen__SCENE_H__
#define __RandomPlayerScreen__SCENE_H__

#include "cocos2d.h"

class RandomPlayerScreen : public cocos2d::CCLayer
{
public:
    RandomPlayerScreen();
    
    ~RandomPlayerScreen();
    
    static cocos2d::CCScene* scene();
    
	virtual bool init();  
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
	
	CREATE_FUNC(RandomPlayerScreen);
    
private:
    
    void SelectGender(CCObject* sender);
    cocos2d::CCLabelTTF * status;
    
    void onHttpRequestCompleted(CCNode *sender, void *data);
    void requestForRandomUser(const char * gender);



    
};

#endif // __RandomPlayerScreen__SCENE_H__