//
//  LoginScreen.cpp
//  Hum
//
//  Created by Shakthi Prasad G S on 10/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "LoginScreen.h"
#include "CommonUtils.h"

#import "GamesProgresScreen.h"
#import "GameManager.h"
#import "network/HttpRequest.h"
#import "network/HttpClient.h"
#import "json.h"
#include "assert.h"
#include <android/log.h>
#include "RecJNICommunicator.h"
#include "cocos2d.h"
#define CCAssert(cond, msg)���������CC_ASSERT(cond)
USING_NS_CC_EXT;
#define  LOG_TAG    "LoginScreen"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

using namespace cocos2d;
using namespace cocos2d::extension;


class Dialog:public CCLayer
{
    CCLabelTTF * text;
    
public:
    
    
    virtual bool init(const char * message,const char * button, CCObject* target, SEL_MenuHandler selector)
    {
        if(!CCLayer::init())
            return false;

      //  m_bIgnoreAnchorPointForPosition=false;
        
        CCLayerColor * bg = CCLayerColor::create(ccc4(0, 0, 0, 200), 280, 230);
        bg->ignoreAnchorPointForPosition(false);
        this->addChild(bg);
        CCLOG("bg added");
        CCNodePlaceAtCenter(bg);
        
        CCLabelTTF * messageLabel = CCLabelTTF::create(message, "Helvetica", 20, CCSize(200, 100), kCCTextAlignmentCenter);
        bg->addChild(messageLabel);

        CCNodePlaceAtCenter(messageLabel);
        CCLOG("messagelbl");
        
        CCMenuItemImage * menuitem = CCMenuItemImage::create("CommonButton.png", "CommonButtonPressed.png","CommonButtonDisabled.png",target, selector);
        
        CCLabelTTF * label = CCLabelTTF::create(button, "Helvetica", 17);
        menuitem->addChild(label);
        CCNodePlaceAtCenter(label);
        
        CCMenu * menu =CCMenu::create(menuitem,NULL);
        menu->setPosition(ccp(0, 0));
        menu->setContentSize(bg->getContentSize());
        bg->addChild(menu);
        
        CCNodePlaceAtBottom(menuitem,ccp(0, 20));
        CCLOG("menu item");
        
        return true;
    
    }
    
    
    static Dialog * create(const char * message,const char * button, CCObject* target, SEL_MenuHandler selector)
    {
        Dialog * dilog = new Dialog;
        dilog->init(message, button, target, selector);
         dilog->autorelease();
        return dilog;
    
    }
    
    
    void draw()
    {
        CCNode::draw();
    }
    
    
};

CCScene* LoginScreen::scene()
{
	CCScene *scene = CCScene::create();
	
	LoginScreen *layer = LoginScreen::create();
    
	scene->addChild(layer);
    
	return scene;
}

LoginScreen::LoginScreen()
:facebookDataRetrievedCount(0)
{
	CCLog(" ------- CCCCCCCCCC ------- entering LoginScreen constructor -------- CCCCCCCCCC -------- ");
}

LoginScreen::~LoginScreen()
{
	CCLog(" ------- DDDDDDDD ------- entering LoginScreen destructor -------- DDDDDDDD -------- ");
}



bool LoginScreen::init()
{
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	CCLog(" ----------------- LoginScreen::init ------------------------- ");
 	if ( !CCLayer::init() )
	{
		return false;
	}
    
    CCSprite * sprite = CCSprite::create("bg.png");
    this->addChild(sprite);
    CCNodePlaceAtCenter(sprite);
    CCLOG("bg added");
    
    CCSprite* pBottomSprite = CCSprite::create("add.png");
	pBottomSprite->setPosition( ccp(size.width/2, pBottomSprite->getContentSize().height/2) );
	// position the sprite on the center of the screen
	this->addChild(pBottomSprite);
	CCNodePlaceAtBottom(pBottomSprite);

    CCSprite * lognPanel = CCSprite::create("startnewgame_box.png");
    this->addChild(lognPanel);
    CCNodePlaceAtTop(lognPanel,ccp(0, -113));

    CCLOG("start new ");

    
    CCMenu * menu = CCMenu::create();
    lognPanel->addChild(menu);
    
    CCNodePlaceAtBottom(menu);
    
    loginButton  = CCMenuItemImage::create("facebook.png", "facebook_hvr.png","facebook_hvr.png",
    										this, menu_selector(LoginScreen::facebookLoginStart));
    loginButton->setPosition(CCPoint(0, 10));
    
    
    
    loginLabel = CCLabelTTF::create("", "Helvetica", 25);
    this->addChild(loginLabel);
    CCNodePlaceAtCenter(loginLabel);
    
    menu->addChild(loginButton);
    CCNodePlaceAtBottom(loginButton,ccp(0, 20));
    CCLOG("login btn");
    
    CCSprite * topbar = CCSprite::create("Logobackground.png");
    this->addChild(topbar);
    CCNodePlaceAtTop(topbar);
    CCLOG("log background");
	return true;
}


void LoginScreen::next()
{
	LOGD(" ----------------- LoginScreen::next ------------------------- ");
	RecJNICommunicator::dismissDialog();
    cocos2d::CCDirector::sharedDirector()->replaceScene(GamesProgresScreen::scene());
}


void LoginScreen::checkForNetWork()
{
	LOGD(" ----------------- checkForNetWork ------------------------- ");
    CCHttpRequest* request = new CCHttpRequest();
    
    std::string url="http://humserver.appsonfire.co.uk/";
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LoginScreen::onnetworkRequestCompleted));
    // optional fields
    request->setTag("Network test");
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    
}


void LoginScreen::loginHumServer()
{
	LOGD(" ----------------- loginHumServer ------------------------- ");
    facebookDataRetrievedCount++;
    
    if(facebookDataRetrievedCount<2)
        return;
    
    
    CCHttpRequest* request = new CCHttpRequest();
    LOGD(" ----------------- constructing url ------------------------- ");
    std::string url="http://humserver.appsonfire.co.uk/user/sign_in?";
    url=url+"name"+"="+facebookNoSpaceUserName+"&";
    url=url+"facebook_thumbnail"+"="+facebookUserPictureUrl+"&";
    url=url+"facebook_id"+"="+facebookUserId+"&";
    url=url+"gender"+"="+facebookUserGender+"&";
    url=url+"ios_push_id"+"="+"12346";

    CCLog("UUUUUUUUUUUUUUUUUUU %s ",url.c_str());
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LoginScreen::onHttpRequestCompleted));
    // optional fields
    request->setTag("GET test2");
    LOGD(" ----------------- loginHumServer getInstance ------------------------- ");
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    LOGD(" ----------------- loginHumServer request->release ------------------------- ");
    loginLabel->setString("Loging to hum server..");
}

void LoginScreen::facebookLoginStart(CCObject* sender)
{
	LOGD(" ----------------- facebookLoginStart ------------------------- ");
	RecJNICommunicator::showDialog();
    checkForNetWork();
    loginButton->setEnabled(false);
//    loginLabel->setString("Signing in with Facebook..");
}


void LoginScreen::onnetworkRequestCompleted(cocos2d::CCNode *sender, void *data)
{
	LOGD(" ----------------- onnetworkRequestCompleted ------------------------- ");
    CCHttpResponse *response = (CCHttpResponse*)data;
    if(!response->isSucceed())
    {
    	LOGD(" ----------------- No Internet Connection ------------------------- ");
        
//        CCMessageBox("Failed to login to facebook", "Network error");
    	RecJNICommunicator::dismissDialog();
    	RecJNICommunicator::showAlert();
    	loginButton->setEnabled(true);
    	loginLabel->setString("Sign in with Facebook");

    } else {
    	// call java method for Android
//        LoginScreen::facebookLogin(sender);
    	LOGD(" ----------------- Connecting To FB ------------------------- ");
//    	RecJNICommunicator::dismissDialog();
        RecJNICommunicator::connectToFB();
        this->facebookProfileInfoFetch("fi", "gh", "df");
    }
}

void LoginScreen::facebookLoginFailedOK(CCObject* sender)
{
    this->removeChildByTag(CCTAG(dialog),true);
    loginLabel->setString("Sign in with Facebook");
    loginButton->setEnabled(true);
}


void LoginScreen::facebookLoginDone(bool isSuccessFull)
{
    if(isSuccessFull)
    {
        CCLOG("Login successful");
        
        loginLabel->setString("Fetching facebook data..");
        
//        this->facebookProfileInfoFetch(8);
    } else {
        Dialog * dialog= Dialog::create("Failed to connect facebook", "OK",
        		this, menu_selector(LoginScreen::facebookLoginFailedOK));
        
        dialog->setTag(CCTAG(dialog));
        
        this->addChild(dialog);
    }
    
}

void LoginScreen::facebookProfileInfoFetch(const char * value1, const char * value2, const char * value3) {
	LOGD(" ----------------- facebookProfileInfoFetch ------------- %s ------------ ", value1);
	LOGD(" ----------------- facebookProfileInfoFetch ------------- %s ------------ ", value2);
	LOGD(" ----------------- facebookProfileInfoFetch ------------- %s ------------ ", value3);
	facebookDataRetrievedCount=0;
//	RecJNICommunicator::dismissDialog();
//	if(facebookUserName.empty()) {
//		facebookUserName = value;
//		CCLog(" ---------- facebookUserName ------ %s ------- ", facebookUserName.c_str());
//	} else if(facebookUserId.empty()) {
//		facebookUserId = value;
//		CCLog(" ---------- facebookUserId ------- %s ------ ", facebookUserId.c_str());
//	} else if(facebookUserGender.empty()) {
//		facebookUserGender = value;
//		CCLog(" ---------- facebookUserGender ------ %s ------- ", facebookUserGender.c_str());
//	} else if(facebookUserPictureUrl.empty()) {
//		facebookUserPictureUrl = value;
//		CCLog(" ---------- afacebookUserPictureUrl ----- %s -------- ", facebookUserPictureUrl.c_str());
//	} else {
//		CCLog(" ---------- all fields got values ------------- ");
//	}
//	facebookUserName = value1;
//	facebookUserId = value2;
//	facebookUserGender = value3;
//	    if (FBSession.activeSession.isOpen)
//	    {
	            //fetch user detail

//	            [[FBRequest requestForMe] startWithCompletionHandler:
//	             ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
//
//
//	                 if (!error) {


	                     facebookUserName = "basavaraj.sarwad";
	                     facebookUserId = "100001397956564";
	                     facebookUserGender = "male";



//	                     NSString *unescaped = "Daya Shankar";
//	                     NSString *escapedString = (NSString *)CFURLCreateStringByAddingPercentEscapes(
//	                                                                                                   NULL,
//	                                                                                                   (CFStringRef)unescaped,
//	                                                                                                   NULL,
//	                                                                                                   (CFStringRef)@"!*'();:@&=+$,/?%#[]",
//	                                                                                                   kCFStringEncodingUTF8);



	                     facebookNoSpaceUserName = facebookUserName;
//	                     [escapedString release];

	                     this->loginHumServer();
//	                 }
//	             }];

	        //fetch user profileimage url

//	            [[FBRequest requestWithGraphPath:@"me/picture" parameters:[NSDictionary dictionaryWithObjectsAndKeys:@"false" ,@"redirect",@"square",@"type",Nil] HTTPMethod:@"GET"] startWithCompletionHandler:
//	             ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
//	                 if (!error) {
//
//	                     NSLog(@"%@",[user valueForKeyPath:@"data.url"]);
//
//
//
//	                     NSString * fburl = [[ user valueForKeyPath:@"data.url"] substringFromIndex:8];//https://
	                     facebookUserPictureUrl = "http://graph.facebook.com/"+facebookUserId+"/picture?type=small";

	                     this->loginHumServer();
//	                 }
//	             }];
//	    }
}



void LoginScreen::onHttpRequestCompleted(CCNode *sender, void *data)
{
	LOGD(" ----------------- LoginScreen onHttpRequestCompleted ------------------------- ");
    CCLOG("request completed");
    
    CCHttpResponse *response = (CCHttpResponse*)data;
    
    if (!response)
    {
    	LOGD(" ----------------- LoginScreen onHttpRequestCompleted return ------------------------- ");
        return;
    }
    
    // You can get original request type from: response->request->reqType
    if (0 != strlen(response->getHttpRequest()->getTag()))
    {
        CCLog("%s completed", response->getHttpRequest()->getTag());
    }
    
    int statusCode = response->getResponseCode();
    char statusString[64] = {};
    sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode, response->getHttpRequest()->getTag());
    //m_labelStatusCode->setString(statusString);
    CCLog("response code: %d", statusCode);
    
    if (!response->isSucceed())
    {
        CCLog(" %s response failed", response->getResponseData());
        CCLog("error buffer: %s", response->getErrorBuffer());
        LOGD(" ----------------- LoginScreen onHttpRequestCompleted response failed ------------------------- ");
        return;
    }
    
     //dump data
    std::vector<char> *buffer = response->getResponseData();

    char * charbuffer =new char[buffer->size()];

    printf("Http Test, dump data: ");

    unsigned int size=0;
    for (unsigned int i = 0; i < buffer->size(); i++)
    {
        charbuffer[i]=(*buffer)[i];
        size=i+1;
    }

    charbuffer[size]=0;

    char *errorPos = 0;
    char *errorDesc = 0;
    int errorLine = 0;
    block_allocator allocator(1 << 10); // 1 KB per block

    json_value *root = json_parse(charbuffer, &errorPos, &errorDesc, &errorLine, &allocator);

    root = root->first_child;

    assert(root->type ==JSON_STRING );

    assert(std::string(root->name) =="user_id" );
    
    
    loginLabel->setString("Loading active games..");
    GameManager::create(root->json_value::string_value);
//  GameManager::create("b37e329c-37ac-11e2-abf1-1231381a9805");

    this->next();
    
}


void LoginScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
}

void LoginScreen::onExit()
{
    CCLayer::onExit();
}
