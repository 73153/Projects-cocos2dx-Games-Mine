//
//  GameManager.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 21/11/12.
//
//

#include "GameManager.h"
#include "GamesProgresScreen.h"
#import "network/HttpRequest.h"
#import "network/HttpClient.h"
#include "vjson/json.h"
USING_NS_CC_EXT;

using namespace cocos2d;
using namespace cocos2d::extension;




static GameManager * gGameManager = NULL;


GameManager::GameManager()
:activeGameCount(0),fetchedActivegames(0)
{




}


int GameManager::getActiveGameCount()
{
    return activeGameCount;
}


bool GameManager::init(const char * uid)
{
    if(gGameManager != NULL)
        return false;
    gGameManager=this;
    useruid = (char*)uid;

    return true;
}

GameManager * GameManager::sharedGameManager()
{
    if(gGameManager==NULL)
    {
        CCLOG("No gamemanager");
        GameManager::create("12334");
    }

    return gGameManager;
}



void GameManager::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    
    CCLOG("request completed");
    
    CCHttpResponse *response = (CCHttpResponse*)data;
    
    if (!response)
    {
        return;
    }
    
    // You can get original request type from: response->request->reqType
    if (0 != strlen(response->getHttpRequest()->getTag()))
    {
        CCLog("%s completed", response->getHttpRequest()->getTag());
    }
    
    int statusCode = response->getResponseCode();
    char statusString[64] = {};
    sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode, response->getHttpRequest()->getTag());
    //m_labelStatusCode->setString(statusString);
    CCLog("response code: %d", statusCode);

    if (!response->isSucceed())
    {
        CCLog("response failed");
        CCLog("error buffer: %s", response->getErrorBuffer());
        return;
    }
    
    // dump data
    std::vector<char> *buffer = response->getResponseData();

    char * charbuffer =new char[buffer->size()];

    printf("Http Test, dump data: ");

    unsigned int size=0;
    for (unsigned int i = 0; i < buffer->size(); i++)
    {
        charbuffer[i]=(*buffer)[i];
        size=i+1;
    }
    
    charbuffer[size]=0;


    char *errorPos = 0;
    char *errorDesc = 0;
    int errorLine = 0;
    block_allocator allocator(1 << 10); // 1 KB per block

    json_value *root = json_parse(charbuffer, &errorPos, &errorDesc, &errorLine, &allocator);
    
    
//    root = root->first_child;
//
//    assert(root->type ==JSON_STRING );
//
//    assert(std::string(root->name) =="user_id" );
    
    
//    loginLabel->setString("Loading active games..");
//    GameManager::create(root->json_value::string_value);
//
//
//    this->next();
    fetchedActivegames=true;
    
    if(gameprogressScreen)
        gameprogressScreen->LoadActiveGames();




    
}




void GameManager::requestForActiveGame(GamesProgresScreen * gamescreen)
{

    CCHttpRequest* request = new CCHttpRequest();

    std::string url="http://humserver.appsonfire.co.uk/game/list?";
    
    url=url+"user_id"+"="+getUserUUid()+"&";
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(GameManager::onHttpRequestCompleted));
    // optional fields
    request->setTag("Network test");
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    
    gameprogressScreen = gamescreen;

}


void GameManager::logout()
{
    gGameManager->release();

    gGameManager = NULL;

}

GameManager::~GameManager()
{

}
