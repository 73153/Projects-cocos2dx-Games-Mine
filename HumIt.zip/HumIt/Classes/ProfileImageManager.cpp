//
//  ProfileImageManager.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 19/11/12.
//
//

#include "ProfileImageManager.h"
#include "cocos2d.h"
#include "network/HttpClient.h"
#include "network/HttpRequest.h"
#include "network/HttpResponse.h"
#include "CommonUtils.h"
#include "stdio.h"
#include <fstream>
USING_NS_CC_EXT;

using namespace cocos2d;
using namespace cocos2d::extension;
// TextureCache - Alloc, Init & Dealloc
static ProfileImageManager *g_sharedProfileImageManager = NULL;
static double g_CacheSeconds=3600;

ProfileImageManager * ProfileImageManager::sharedProfileImageManager()
{
    if (!g_sharedProfileImageManager)
    {
        g_sharedProfileImageManager = new ProfileImageManager();
        g_sharedProfileImageManager->init();
    }
    return g_sharedProfileImageManager;
}


ProfileImageManager::~ProfileImageManager()
{
    imageRequests->release();
    facebookUrlDict->release();

}



void ProfileImageManager::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    
    
    CCHttpResponse *response = (CCHttpResponse*)data;
    
    if (!response)
    {
        return;
    }
    
    // You can get original request type from: response->request->reqType
    if (0 != strlen(response->getHttpRequest()->getTag()))
    {
        CCLog("%s completed", response->getHttpRequest()->getTag());
    }
    
    
    int statusCode = response->getResponseCode();
    CCLog("response code: %d", statusCode);
    
    if (statusCode == -1||!response->isSucceed())
    {
        CCLog("response failed");
        CCLog("error buffer: %s", response->getErrorBuffer());
    }else
    {
    
    // dump data
        std::vector<char> *buffer = response->getResponseData();
        std::string name = nameFromUrl(response->getHttpRequest()->getUrl());
        std::string cachepath =CCFileUtils::sharedFileUtils()->getWriteablePath();
        cachepath+=name;
        std::string url= response->getHttpRequest()->getUrl();
        
        std::ofstream outfile(cachepath.c_str());
        for (unsigned int i = 0; i < buffer->size(); i++)
            outfile<<(*buffer)[i];
        outfile.close();
        
        
        CCArray * array = (CCArray *)imageRequests->objectForKey(url);
        
        for (int i=0; i<array->count(); i++)
        {
            this->setTextureFromFilePath((CCSprite*)array->objectAtIndex(i),nameFromUrl(url));
        }
        
        
                                     ;
    }
    imageRequests->removeObjectForKey(response->getHttpRequest()->getUrl());
    
    
}



bool ProfileImageManager::init()
{
    
    imageRequests= new CCDictionary;
    
    facebookUrlDict = new CCDictionary;
    
    
    return true;

}


std::string ProfileImageManager::nameFromUrl(std::string url)
{
    
    std::string name = url;
//    name.erase( std::remove( name.begin(), name.end(), '/' ), name.end() );
//    name.erase( std::remove( name.begin(), name.end(), ':' ), name.end() );
    
    return name;
    

}

bool ProfileImageManager::setTextureFromFilePath(CCSprite * sprite,std::string path)
{
    
    std::string cachepath =CCFileUtils::sharedFileUtils()->getWriteablePath();
    cachepath+=path;
    
   
    
    
    if(CCFileUtils_FileExistAtPath(cachepath.c_str()))
    {
        
        CCTexture2D * texture = CCTextureCache::sharedTextureCache()->addImage(cachepath.c_str());
        if (texture)
        {
            
            sprite->setTexture(texture);
            
            if(CCFileUtils_FileAge(cachepath.c_str()) > g_CacheSeconds)
                return false;
            return true;

        }
    }

    return false;
}




void ProfileImageManager::setFacebookProfileUrl(CCSpriteFaceBook * sprite,const char* url,const char* facebookid)
{
    sprite->setURL(url );
    facebookUrlDict->setObject(CCString::create(url), facebookid);

}


void ProfileImageManager::requestForFaceBookProfileImage(const char* facebookid,CCSpriteFaceBook * sprite)
{

    if(facebookUrlDict->objectForKey(facebookid))
    {
        const CCString * url=facebookUrlDict->valueForKey(facebookid);
        setFacebookProfileUrl(sprite, url->getCString(), facebookid);
    } else {
    	this->requestForFaceBookProfileImageImplmentation(facebookid, sprite);
    }

}

void ProfileImageManager::requestForFaceBookProfileImageImplmentation(const char* facebookid,CCSpriteFaceBook * sprite) {

}


void ProfileImageManager::requestForImage(const char* url,cocos2d::CCSprite * sprite)
{
    
    
    
    
    if(setTextureFromFilePath(sprite, nameFromUrl(url)))
        return;
        
    CCArray * spriteArray = (CCArray*)imageRequests->objectForKey(url);
    bool newlycreated =false;
    if(spriteArray == NULL)
    {
        spriteArray = CCArray::create();
        newlycreated = true;
    }
    
    
    spriteArray->addObject(sprite);
    
    
    
    
    
    imageRequests->setObject(spriteArray, url);

    
    if(!newlycreated)
        return;
    
    CCHttpRequest* request = new CCHttpRequest();
    request->setUrl(url);
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(ProfileImageManager::onHttpRequestCompleted));
    // optional fields
    request->setTag(url);
    
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    
    
    
    

    
    



}
