//
//  LoginScreen.h
//  Hum
//
//  Created by Shakthi Prasad G S on 10/11/12.
//  Copyright 2012 Erawppa Co., Ltd.. All rights reserved.
//

#ifndef __LoginScreen__SCENE_H__
#define __LoginScreen__SCENE_H__

#include "cocos2d.h"


class LoginScreen : public cocos2d::CCLayer
{
public:
    LoginScreen();
    
    ~LoginScreen();
    
    static cocos2d::CCScene* scene();
    
	virtual bool init();  
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
	
	CREATE_FUNC(LoginScreen);
    
    void facebookLoginStart(CCObject* sender);
    void facebookLogin(CCObject* sender);
    void facebookLoginFailedOK(CCObject* sender);
    
    
    void facebookLoginDone(bool isSuccessFull);
    void facebookProfileInfoFetch(const char * value1, const char * value2, const char * value3);
    void onHttpRequestCompleted(CCNode *sender, void *data);
    void onnetworkRequestCompleted(CCNode *sender, void *data);
    
    
    void next();
    void loginHumServer();

    void checkForNetWork();
    
    std::string facebookUserName,facebookUserId,facebookUserGender,facebookUserPictureUrl,facebookNoSpaceUserName;

    int facebookDataRetrievedCount;


private:
    
    cocos2d::CCMenuItemImage * loginButton;
    cocos2d::CCLabelTTF * loginLabel;
    
};

#endif // __LoginScreen__SCENE_H__
