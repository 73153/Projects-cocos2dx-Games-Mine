//
//  SelectGenreScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "SelectGenreScreen.h"
#include "SelectSongScreen.h"
#include "GamesProgresScreen.h"
#include "GameManager.h"
#include "CommonUtils.h"
#include "platform/CCFileUtils.h"
#include "json.h"
#include "RecordAndPlay.h"
#include "cocos-ext.h"

using namespace cocos2d;
using namespace cocos2d::extension;

CCScene* SelectGenreScreen::scene()
{
	CCLog(" -------------- entering SelectGenreScreen::scene ---------------- ");

	CCScene *scene = CCScene::create();
	CCLog(" -------------- entering CCScene::create ---------------- ");
	SelectGenreScreen *layer = SelectGenreScreen::create();
	CCLog(" -------------- entering SelectGenreScreen::create ---------------- ");
	scene->addChild(layer);
	CCLog(" -------------- entering addChild ---------------- ");
	return scene;
}


CCScene* SelectGenreScreen::scene(bool val)
{
	CCLog(" -------------- entering SelectGenreScreen::scene(bool val) ---------------- ");
	CCScene *scene = CCScene::create();

	SelectGenreScreen *layer = SelectGenreScreen::create(val);

	scene->addChild(layer);

	return scene;
}


SelectGenreScreen::SelectGenreScreen()
:isexapanded(false)
{
	CCLog(" ------- CCCCCCCCCC ------- entering SelectGenreScreen constructor -------- CCCCCCCCCC -------- ");
}

SelectGenreScreen::~SelectGenreScreen()
{
	CCLog(" ------- DDDDDDDDD ------- entering SelectGenreScreen destructor -------- DDDDDDDDD -------- ");
}


void SelectGenreScreen::SelectGenre(CCObject* sender)
{
	CCLog(" ----------------------- SelectGenreScreen::SelectGenre ------------------------- ");
    CCNode * node = (CCNode *)sender;

    if(node->getTag()==1000)
    {
    	CCLog(" ----------------------- SelectGenreScreen::SelectGenre if ------------------------- ");
        CCScene * next = SelectGenreScreen::scene(true);

        cocos2d::CCDirector::sharedDirector()->replaceScene(next);

    } else {
    	CCLog(" ----------------------- SelectGenreScreen::SelectGenre else ------------------------- ");
        GameManager::sharedGameManager()->setActiveGenre(node->getTag());
        CCScene * next = SelectSongScreen::scene();
//        CCScene * next = RecordAndPlay::scene();
		cocos2d::CCDirector::sharedDirector()->replaceScene(next);

//		std::string str = "hi,hello";
//		    std::string word;
//		    std::stringstream stream(str);
//		    while( getline(stream, word, ',') ) {
//		    	CCLog(" ---- %s ---- ", word);
//		    }

    }

}

void SelectGenreScreen::loadgenre()
{
	CCLog(" ----------------------- SelectGenreScreen::loadgenreeeeeeeeee ------------------------- ");
    const char * genrefile = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("genres.json");
    CCLog( " %s ---------- genrefile ---------", genrefile);
    
    size_t size;
    unsigned long bufferSize = 0;
    unsigned char * charbuffer = CCFileUtils::sharedFileUtils()->getFileData(genrefile, "rb", &bufferSize);
    CCLog( " %s ---------- charbuffer ---------", charbuffer);
    CCLog(" ----------------------- SelectGenreScreen::loadgenre charbuffer ------------------------- ");
    char *errorPos = 0;
    char *errorDesc = 0;
    int errorLine = 0;
    block_allocator allocator(1 << 10); // 1 KB per block

    CCLog(" ----------------------- SelectGenreScreen::loadgenre allocator ------------------------- ");
    char * newcharbuffer = strndup((char*)charbuffer, bufferSize);
//    char * newcharbuffer = strndupunsigned(charbuffer, bufferSize);
//    char * newcharbuffer = (char*)charbuffer;
    CCLog(" ----------------------- newcharbuffer ----------- %s -------------- ", newcharbuffer);
    delete charbuffer;

    json_value *root = json_parse(newcharbuffer, &errorPos, &errorDesc, &errorLine, &allocator);
    CCLog(" ----------------------- before free ------------------------- ");
    free(newcharbuffer);
    CCLog(" ----------------------- SelectGenreScreen::loadgenre free(newcharbuffer) ------------------------- ");
//    std::string genrename;
    
    CCLog(" ----------------------- SelectGenreScreen::loadgenre before for ------------------------- ");
    for (json_value *itgenre = root->first_child; itgenre; itgenre = itgenre->next_sibling)
    {
    	CCLog(" ----------------------- SelectGenreScreen::loadgenre 1st for ------------------------- ");
        json_value * agenre = itgenre;

        GenreEntry entry;

        for (json_value * itproperty = agenre->first_child; itproperty; itproperty = itproperty->next_sibling)
        {
        	CCLog(" ----------------------- SelectGenreScreen::loadgenre 2nd for ------------------------- ");
            if (std::string("name") == itproperty->name )
            {
                entry.name = itproperty->string_value;
            }

            if (std::string("id") == itproperty->name )
            {
                entry.genreid= itproperty->int_value;
                continue;
            }
        }
        genrelist.push_back(entry);

    }
    CCLog(" ----------------------- SelectGenreScreen::loadgenre after for ------------------------- ");
}


//char * SelectGenreScreen::strndupunsigned(unsigned char * charbuffer , size_t size)
//{
//	CCLog(" ----------------------- strndupunsigned -------- %f --------- %s -------- ",size, charbuffer);
//	char * buffer = (char *)malloc(size+1 * sizeof(char));
//	for (int i = 0; i < size; i++)
//	{
//		buffer[i]=charbuffer[i];
//	}
//
//	buffer[size]='\0';
//	return buffer;
//
//}


bool SelectGenreScreen::init()
{
//	isexapanded = false;
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	CCLog(" -------------- entering SelectGenreScreen::init ---------------- ");
	if ( !CCLayer::init() )
	{
		return false;
	}
	CCLog(" -------------- entering SelectGenreScreen before loadgenre ---------------- ");

    this->loadgenre();

	CCLog(" -------------- entering SelectGenreScreen after loadgenre -------- %d -------- ", genrelist.size());
    {
        
        CCSprite * bg = CCSprite::create("bg.png");
        this->addChild(bg);
        CCNodePlaceAtCenter(bg);


    }
    CCLog(" -------------- after  CCNodePlaceAtCenter ---------------- ");
    {

        if(!isexapanded)
        {
        	CCLog(" -------------- inside 1st if ---------------- ");
            
             box = CCSprite::create("box.png");
            this->addChild(box);
            CCNodePlaceAtCenter(box);
            
            CCMenu * menu =CCMenu::create();
        
            box->addChild(menu);
            menu->setContentSize(box->getContentSize());
            CCNodePlaceAtCenter(menu);
            
            CCPoint offset = CCPoint(0, -90);
            CCPoint stride = CCPoint(0, 90);


            for (int i = 0; i < 3; i++)
            {
            	CCLog(" %d -------------- inside for ---------------- "+genrelist.size());
                CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                                    "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",
                                                                    this, menu_selector(SelectGenreScreen::SelectGenre));
                menu->addChild(button);
                CCNodePlaceAtTop(button,offset);
                
                
                CCLabelTTF * label = CCLabelTTF::create(genrelist[i].name.c_str(), "Helvetica", 25);
                
                button->addChild(label);
                CCNodePlaceAtCenter(label,ccp(0,10));
                
                button->setTag(genrelist[i].genreid);
                
                
                offset = ccpSub(offset, stride);

            }
            CCLog(" -------------- after for ---------------- ");
            
            {
                
                CCMenuItemImage * button  = CCMenuItemImage::create("Get_more_genres.png",
                                                                    "Get_more_genres_hvr.png","Get_more_genres_hvr.png",
                                                                    this, menu_selector(SelectGenreScreen::SelectGenre));
                menu->addChild(button);
                CCNodePlaceAtTop(button,offset);
                
                
                CCLabelTTF * label = CCLabelTTF::create("Get more", "Helvetica", 25);
                
                button->addChild(label);
                CCNodePlaceAtCenter(label,ccp(0,10));
                
                button->setTag(1000);
                
                
                offset = ccpSub(offset, stride);
            
            }
        }
        
        if (isexapanded)
        {
        	CCLog(" -------------- inside 2nd if ---------------- ");
            
             box = CCSprite::create("box.png");
            this->addChild(box);
            CCNodePlaceAtCenter(box);
            
            
            CCTableView * tableview = CCTableView::create(this, CCSize(box->getContentSize().width, box->getContentSize().height-80));
            tableview->setDelegate(this);

            box->addChild(tableview);
            
            tableview->setPosition(ccp(0,10));
            
        }
        
    }
    
    {
    	CCLog(" -------------- creating  OpponentUserTopBar ---------------- ");
        CCSprite * topbar = OpponentUserTopBar::create();
        this->addChild(topbar);
        CCNodePlaceAtTop(topbar);

        ScorePanel * scorepanel = ScorePanel::create();
        topbar->addChild(scorepanel);

        CCNodePlaceAtLeft(scorepanel,ccp(0, 0));

    }
    
    {
    	CCLog(" -------------- adding bottom sprite ---------------- ");
        CCSprite * add = CCSprite::create("add.png");
        this->addChild(add);
        CCNodePlaceAtBottom(add);
    }
    CCLog(" -------------- FINISHED ---------------- ");
	return true;
}

void SelectGenreScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
}

void SelectGenreScreen::onExit()
{
    CCLayer::onExit();
}


CCSize SelectGenreScreen::cellSizeForTable(CCTableView *table)
{
    return CCSizeMake(box->getContentSize().width, 100);
}

CCTableViewCell* SelectGenreScreen::tableCellAtIndex(CCTableView *table, unsigned int idx)
{
    CCTableViewCell  * cell = new CCTableViewCell;
    cell->setContentSize(this->cellSizeForTable(table));

    cell->autorelease();
//    
//    CCSprite * sprite= CCSprite::create("RandomPlayerScreen/RandomHumIt_Button.png");
//    cell->addChild(sprite);
//    
//    CCNodePlaceAtLeft(sprite);
    
//    return cell;
    
    CCMenuScrollable * menu =CCMenuScrollable::create();
    menu->scrollView = table;
    
    cell->addChild(menu);
    menu->setContentSize(cell->getContentSize());
    CCNodePlaceAtCenter(menu);
    
     
    {
        CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                            "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",this, menu_selector(SelectGenreScreen::SelectGenre));
        menu->addChild(button);
        CCNodePlaceAtCenter(button);
        
        
        CCLabelTTF * label = CCLabelTTF::create(genrelist[idx].name.c_str(), "Helvetica", 25);
        
        button->addChild(label);
        CCNodePlaceAtCenter(label,ccp(0,10));
        
        button->setTag(genrelist[idx].genreid);
        
    }
    
    return cell;
}

unsigned int SelectGenreScreen::numberOfCellsInTableView(CCTableView *table)
{
    return genrelist.size();
}

