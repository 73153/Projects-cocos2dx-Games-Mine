//
//  GamesProgresScreen.h
//  Hum
//
//  Created by Shakthi Prasad G S on 12/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#ifndef __GamesProgresScreen__SCENE_H__
#define __GamesProgresScreen__SCENE_H__

#include "cocos2d.h"
#include "cocos-ext.h"



class GamesProgresScreen : public cocos2d::CCLayer,public cocos2d::extension::CCTableViewDataSource
,public cocos2d::extension::CCTableViewDelegate
{
public:
    GamesProgresScreen();
    
    ~GamesProgresScreen();
    
    static cocos2d::CCScene* scene();
    
	virtual bool init();  
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
	
	CREATE_FUNC(GamesProgresScreen);
    void dummySelector(CCObject* sender);
    void LoginOut(CCObject* sender);
    void FacebookLoginOut(CCObject* sender);
    void LoginOutDone(CCObject* sender,void * data);
    
    void LoadActiveGames();
    
private:
    
    cocos2d::CCLabelTTF * status;
    cocos2d::CCLayer * gamelayer;
    
    
    virtual cocos2d::CCSize cellSizeForTable(cocos2d::extension::CCTableView *table);
    virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(cocos2d::extension::CCTableView *table);

    void tableCellTouched(cocos2d::extension::CCTableView* table, cocos2d::extension::CCTableViewCell* cell)
    {}

    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view) {};
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view) {}
    
    
    int gameMatchwidth,tablecellheight;
};




class ScorePanel:public cocos2d::CCLayer
{
    cocos2d::CCLabelTTF * lable1,*lable2;
    
    
public:
    
    
    void updateScore();
    bool init();
    
    CREATE_FUNC(ScorePanel);
    
};





class OpponentUserTopBar:public cocos2d::CCSprite {

public:
    CREATE_FUNC(OpponentUserTopBar);

    bool init();

};




class CCMenuScrollable :public cocos2d::CCMenu
{

    cocos2d::CCPoint initialLocation;
        bool exitTracking;


    cocos2d::CCTouch* savedtouch;

    public:
        CCMenuScrollable()
        :scrollView(0),savedtouch(0)
        {
        }

        ~CCMenuScrollable();
        cocos2d::extension::CCScrollView * scrollView;

        CREATE_FUNC(CCMenuScrollable);


        bool ccTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);

        void ccTouchMoved(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
        void ccTouchEnded(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
        void ccTouchCancelled(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);

        void onExit();


};










#endif // __GamesProgresScreen__SCENE_H__
