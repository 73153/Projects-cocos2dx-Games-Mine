//
//  DNJNICommunicator.cpp
//  Dominoes
//
//  Created by ICRG LABS on 07/09/12.
//
//

#include "RecJNICommunicator.h"
#include "platform/android/jni/JniHelper.h"
#include <android/log.h>
#include <jni.h>

#include "LoginScreen.h"

#define  LOG_TAG    "RecJNICommunicator"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  CLASS_NAME "com.humit.android/RecorderAndPlay"

RecJNICommunicator::RecJNICommunicator(void)
{
	CCLog(" ------- CCCCCCC ------- entering RecJNICommunicator constructor -------- CCCCCCC -------- ");
}

RecJNICommunicator::~RecJNICommunicator(void)
{
	CCLog(" ------- DDDDDDDD ------- entering RecJNICommunicator destructor -------- DDDDDDDD -------- ");
}

extern "C" {
    JNIEXPORT void JNICALL Java_com_humit_android_HumIt_javaCallJNI(JNIEnv * env, jobject obj,
    		jstring javaString, jstring javaString2, jstring javaString3);
};

JNIEXPORT void JNICALL Java_com_humit_android_HumIt_javaCallJNI(JNIEnv* env, jobject obj,
										jstring javaString1, jstring javaString2, jstring javaString3)
{
	//Get the native string from javaString
	 const char *nativeString1 = env->GetStringUTFChars(javaString1, 0);
	 const char *nativeString2 = env->GetStringUTFChars(javaString2, 0);
	 const char *nativeString3 = env->GetStringUTFChars(javaString3, 0);
//	 CCLog(" ---------- nativeString ------ %s ------- ", nativeString);

//	 loginScreen.facebookUserName = nativeString;
//	 loginScreen.facebookUserId = nativeString;
//	 loginScreen.facebookUserName = nativeString;
//	 if(loginScreen.facebookUserName.empty()) {
//		 	loginScreen.facebookUserName = nativeString;
//	 		CCLog(" ---------- facebookUserName ------ %s ------- ", loginScreen.facebookUserName.c_str());
//	} else if(loginScreen.facebookUserId.empty()) {
//		loginScreen.facebookUserId = nativeString;
//		CCLog(" ---------- facebookUserId ------- %s ------ ", loginScreen.facebookUserId.c_str());
//	} else if(loginScreen.facebookUserGender.empty()) {
//		loginScreen.facebookUserGender = nativeString;
//		CCLog(" ---------- facebookUserGender ------ %s ------- ", loginScreen.facebookUserGender.c_str());
//	} else {
//		CCLog(" ---------- all fields got values ------------- ");
//		loginScreen.facebookProfileInfoFetch(nativeString);
//	}
//	 LoginScreen loginScreen;
//	 if(loginScreen.facebookUserName.empty() && loginScreen.facebookUserId.empty() && loginScreen.facebookUserGender.empty())
//	 loginScreen.facebookProfileInfoFetch(nativeString1, nativeString2, nativeString3);

//	 env->CallVoidMethod(obj, facebookProfileInfoFetch);

//	 facebookProfileInfoFetch(nativeString1, nativeString2, nativeString3);
	 //Do something with the nativeString

     CCLog(" ---- JJJJJJJJJJJJJJJ --- %s ---------- JNI worked ! --------- JJJJJJJJJ %s JJJJJJJ ---------- ", nativeString1);
     CCLog(" ---- JJJJJJJJJJJJJJJ --- %s ---------- JNI worked ! --------- JJJJJJJJJ %s JJJJJJJ ---------- ", nativeString2);
     CCLog(" ---- JJJJJJJJJJJJJJJ --- %s ---------- JNI worked ! --------- JJJJJJJJJ %s JJJJJJJ ---------- ", nativeString3);

    //DON'T FORGET THIS LINE!!!
	 env->ReleaseStringUTFChars(javaString1, nativeString1);
	 env->ReleaseStringUTFChars(javaString2, nativeString2);
	 env->ReleaseStringUTFChars(javaString3, nativeString3);

//    jsize len = env->GetArrayLength(env,arr);
//    for(int i=0; i<len; i++) {
//    	CCLog(" --- %s --- ", arr[i]);
//    }

//    jclass clazz = env->FindClass("com.humit.android/HumIt");
//    if (clazz == 0) {
//    	CCLog(" --- FindClass error --- ");
//        return;
//    }
//
//    jmethodID javamethod = env->GetMethodID(clazz, "callFromCPP", "()V");
//    if (javamethod == 0) {
//    	CCLog(" --- GetMethodID error --- ");
//        return;
//    }
//
//    env->CallVoidMethod(obj, javamethod);
//    env->DeleteLocalRef(loginScreen);
}

extern "C" {
    JNIEXPORT void JNICALL Java_com_humit_android_HumIt_addFriends(JNIEnv * env, jobject obj,
    		jint size, jobjectArray nodes);
};

JNIEXPORT void JNICALL Java_com_humit_android_HumIt_addFriends(JNIEnv* env, jobject obj,
		jint size, jobjectArray nodes)
{
	//Get the native string from javaString
//	 const char *nativeString1 = env->GetStringUTFChars(userName, 0);
//	 const char *nativeString2 = env->GetStringUTFChars(userId, 0);

	for(int i=0; i<size; i++) {
		CCLog(" ----- value ----- ");
	}

     CCLog(" ---- JJJJJJJ addFriends JJJJJJJJ --- %s ---------- JNI worked ! --------- JJJJJJJJJ %s JJJJJJJ ---------- ", nativeString1);
//     CCLog(" ---- JJJJJJJ addFriends JJJJJJJJ --- %s ---------- JNI worked ! --------- JJJJJJJJJ %s JJJJJJJ ---------- ", nativeString2);

    //DON'T FORGET THIS LINE!!!
//	 env->ReleaseStringUTFChars(userName, nativeString1);
//	 env->ReleaseStringUTFChars(userId, nativeString2);

}


// get env and cache it
static JNIEnv* getJNIEnv(void)
{
	JavaVM* jvm = cocos2d::JniHelper::getJavaVM();
	if (NULL == jvm) {
		LOGD("Failed to get JNIEnv. JniHelper::getJavaVM() is NULL");
		return NULL;
	}

	JNIEnv *env = NULL;
	// get jni environment
	jint ret = jvm->GetEnv((void**)&env, JNI_VERSION_1_4);

	switch (ret) {
		case JNI_OK :
			// Success!
			return env;

		case JNI_EDETACHED :
			// Thread not attached

			// TODO : If calling AttachCurrentThread() on a native thread
			// must call DetachCurrentThread() in future.
			// see: http://developer.android.com/guide/practices/design/jni.html

			if (jvm->AttachCurrentThread(&env, NULL) < 0)
			{
				LOGD("Failed to get the environment using AttachCurrentThread()");
				return NULL;
			} else {
				// Success : Attached and obtained JNIEnv!
				return env;
			}

		case JNI_EVERSION :
			// Cannot recover from this error
			LOGD("JNI interface version 1.4 not supported");
		default :
			LOGD("Failed to get the environment using GetEnv()");
			return NULL;
	}
}

// get class and make it a global reference, release it at endJni().
//static jclass getClassID(JNIEnv *pEnv)
//{
//	jclass ret = pEnv->FindClass(CLASS_NAME);
//	if (! ret)
//	{
//		LOGD("Failed to find class of %s", CLASS_NAME);
//	}
//
//	return ret;
//}


#pragma mark - Record And play functions

void RecJNICommunicator::startRecordings()
{
	LOGD("startRecording inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/RecorderAndPlay");
	methodID = pEnv->GetStaticMethodID(ret, "startRecording", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "startRecording");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::stopRecording()
{
	LOGD("startRecording inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/RecorderAndPlay");
	methodID = pEnv->GetStaticMethodID(ret, "stopRecording", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "stopRecording");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::startPlaying(int loopCount)
{
	LOGD("startRecording inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/RecorderAndPlay");
	methodID = pEnv->GetStaticMethodID(ret, "playSong", "(I)V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "playSong");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID, loopCount);
	pEnv->DeleteLocalRef(ret);

}

#pragma mark - Facebook connect And Logout

void RecJNICommunicator::connectToFB()
{
	LOGD("connectToFB inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "connectToFB", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "connectToFB");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::logoutFromFB()
{
	LOGD("logoutFromFB inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "logoutOfFB", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "logoutFromFB");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::fetchFriendsList()
{
	LOGD("fetchFriendsList inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "fetchFriendsList", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "fetchFriendsList");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

#pragma mark - Alert dialogs

void RecJNICommunicator::showDialog()
{
	LOGD("showDialog inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "showDialog", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "showDialog");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::dismissDialog()
{
	LOGD("dismissDialog inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "dismissDialog", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "dismissDialog");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}

void RecJNICommunicator::showAlert()
{
	LOGD("showAlert inside RecJNICommunicator");

	jmethodID methodID = 0;
	JNIEnv *pEnv = 0;
	pEnv = getJNIEnv();
	jclass ret = pEnv->FindClass("com.humit.android/FBConnect");
	methodID = pEnv->GetStaticMethodID(ret, "showAlert", "()V");

	if (! methodID)
	{
		 LOGD("Failed to find static method id of %s", "showAlert");
		 return;
	}

	pEnv->CallStaticVoidMethod(ret,methodID);
	pEnv->DeleteLocalRef(ret);

}
