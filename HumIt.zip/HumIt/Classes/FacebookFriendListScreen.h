//
//  FacebookFriendListScreen.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#ifndef __FacebookFriendListScreen__LAYER_H__
#define __FacebookFriendListScreen__LAYER_H__

#include "cocos2d.h"
#include "cocos-ext.h"

class FacebookFriendListScreen : public cocos2d::CCLayer,public cocos2d::extension::CCTableViewDataSource
,public cocos2d::extension::CCTableViewDelegate
{
public:
    FacebookFriendListScreen();
    
    ~FacebookFriendListScreen();
    
    void FetchFriendList();
    
    
    
	virtual bool init();  
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
    
	CREATE_FUNC(FacebookFriendListScreen);
    
    
    
    
    static cocos2d::CCScene* scene();

    void loadFriendList();
    void reinitlist()
    {
        tableView->setContentOffset(tableView->minContainerOffset());
    }
    
    
    
    static void sendInvitation(const char * facebookid ,const char * username);
    
private:
    
    cocos2d::extension::CCTableView * tableView;
    cocos2d::CCArray * friendsList;
    
    virtual cocos2d::CCSize cellSizeForTable(cocos2d::extension::CCTableView *table);
    virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(cocos2d::extension::CCTableView *table);

    void tableCellTouched(cocos2d::extension::CCTableView* table, cocos2d::extension::CCTableViewCell* cell)
    {}
    
    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view) {};
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view) {}

    cocos2d::CCLabelTTF * status;

};

#endif // __FacebookFriendListScreen__LAYER_H__