//
//  SelectGenreScreen.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#ifndef __SelectGenreScreen__SCENE_H__
#define __SelectGenreScreen__SCENE_H__

#include "cocos2d.h"
#include <vector>
#include <string>
#include "cocos-ext.h"

struct GenreEntry {
    std::string name;
    int genreid;
};

class SelectGenreScreen : public cocos2d::CCLayer, public cocos2d::extension::CCTableViewDataSource
,public cocos2d::extension::CCTableViewDelegate
{
public:
    SelectGenreScreen();
    
    ~SelectGenreScreen();
    
    static cocos2d::CCScene* scene();
    static cocos2d::CCScene* scene(bool val);
    
    unsigned char * getFileData(const char* pszFileName, const char* pszMode, unsigned long * pSize);

    char * strndupunsigned(unsigned char * charbuffer , size_t size);

	virtual bool init();
    virtual bool init(bool expandedstatus)
    {
        isexapanded = expandedstatus;
        return init();
    }
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
	
	CREATE_FUNC(SelectGenreScreen);
    
    void SelectGenre(CCObject* sender);
    void loadgenre();

    
    static SelectGenreScreen * create(bool exapand)
    {
        SelectGenreScreen * scene = new SelectGenreScreen;
        scene->autorelease();
        scene->init(exapand);

        return scene;
    }
private:
    
    bool isexapanded;
    cocos2d::CCSprite *box;
    
    std::vector<GenreEntry> genrelist;
    
    virtual cocos2d::CCSize cellSizeForTable(cocos2d::extension::CCTableView *table);
    virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(cocos2d::extension::CCTableView *table);
    
    void tableCellTouched(cocos2d::extension::CCTableView* table, cocos2d::extension::CCTableViewCell* cell)
    {}
    
    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view) {};
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view) {}
    
};

#endif // __SelectGenreScreen__SCENE_H__
