//
//  GameManager.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 21/11/12.
//
//

#ifndef __HumIt__GameManager__
#define __HumIt__GameManager__

#include "cocos2d.h"
#include <string>
#include <vector>


enum EPlayerStatus {
    ePlayerStatusPoke ,
    ePlayerStatusAccept,
    ePlayerStatusPlay
    };

class Player : public cocos2d::CCObject
{

    public:
    std::string facebookuseruid,userid,profileurl,name;
    EPlayerStatus status;


    bool init(std::string infacebookuseruid, std::string inuserid, std::string inprofileurl,std::string inname)
    {
        facebookuseruid=infacebookuseruid;
        userid=inuserid;
        profileurl=inprofileurl;
        name=inname;
        return true;
    }

    static Player * create(std::string infacebookuseruid, std::string inuserid, std::string inprofileurl="",std::string inname="")
    {
        Player * player = new Player;
        player->autorelease();
        player->init(infacebookuseruid, inuserid, inprofileurl, inname);
        return player;
    }

    std::string getComment()const
    {
        return std::string("Sample active game");

    }

};




class GamesProgresScreen;
class GameManager:public cocos2d::CCObject{
    
    int coins;
    int activeGameCount;
    int stars;
    int activegenre;
    std::string useruid;
    bool fetchedActivegames;
    
    GamesProgresScreen * gameprogressScreen;
    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);

    Player * activePlayer;


    std::vector<Player>  activegamelist;


public:
    
    
    bool init(const char * uid);
    

    static GameManager * sharedGameManager();
    GameManager();
    ~GameManager();
    
    static GameManager * create(const char * uid)
    {
        GameManager * gameManager =  new GameManager;
        gameManager->init(uid);
        return gameManager;//note: no auto release
    }
    
    int getActiveGameCount();
    
    bool hasFetchedActivegames()
    {
        return fetchedActivegames;
    }
    
    std::string getUserUUid()
    {
        return useruid;
    }
    
    int getCoins()
    {
        return coins;
    }
    
    int getStars()
    {
        return stars;
    }

    void setActiveGenre(int a)
    {
        activegenre = a;
    }

    int getActiveGenre()
    {
        return activegenre ;
    }



    void setActivePlayer(Player * inactivePlayer)
    {

        inactivePlayer->retain();
        if(activePlayer != NULL)
            activePlayer->release();
        activePlayer = inactivePlayer;
    }

    Player * getActivePlayer()
    {
        return activePlayer;
    }



    const  std::vector<Player> & getActivePlayerList()
    {
        return activegamelist;
    }


    void loadSampleGames();

    

    void logout();
    
    

    void requestForActiveGame(GamesProgresScreen * gamescreen);
    
};







#endif /* defined(__HumIt__GameManager__) */
