//
//  GamesProgresScreen.cpp
//  Hum
//
//  Created by Shakthi Prasad G S on 12/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
#include "CommonUtils.h"
#include "GamesProgresScreen.h"
#include "GameManager.h"
#include "LoginScreen.h"
#include "CCScrollView.h"
#import "network/HttpRequest.h"
#import "network/HttpClient.h"
#import "CCSpriteFromUrl.h"

#import "FacebookFriendListScreen.h"
#import "RandomPlayerScreen.h"
#include "RecJNICommunicator.h"

using namespace cocos2d;
using namespace cocos2d::extension;

bool CCMenuScrollable::ccTouchBegan(CCTouch* touch, CCEvent* event)
{
    CCPoint touchLocation = touch->getLocation();
    CCPoint local = this->convertToNodeSpace(touchLocation);
    initialLocation = local;
    exitTracking=false;
    return CCMenu::ccTouchBegan(touch, event);
}

void CCMenuScrollable::ccTouchMoved(CCTouch* touch, CCEvent* event)
{
    CCPoint touchLocation = touch->getLocation();
    CCPoint local = this->convertToNodeSpace(touchLocation);
    
    if(ccpDistance(local, initialLocation)>10)
    {
        exitTracking =true;
    }
    
    if(exitTracking)
    {
        if(m_eState == kCCMenuStateTrackingTouch)
        {
            CCMenu::ccTouchCancelled(touch, event);
            if(scrollView)
                scrollView->ccTouchBegan(touch, event);
        } else {
            if(scrollView)
                scrollView->ccTouchMoved(touch, event);
        }
        touch->retain();
        if(savedtouch)
            savedtouch->release();
        savedtouch = touch;
    
    }else
    {
        CCMenu::ccTouchMoved(touch, event);

    }
    
}


void CCMenuScrollable::ccTouchEnded(CCTouch* touch, CCEvent* event)
{
    if(exitTracking)
    {
        if(scrollView)
            scrollView->ccTouchEnded(touch, event);
        
        if(savedtouch)
            savedtouch->release();
        savedtouch=NULL;

    } else

    
    CCMenu::ccTouchEnded(touch, event);

}


CCMenuScrollable::~CCMenuScrollable()
{

}


void CCMenuScrollable::onExit()
{
    if(exitTracking)
        if(scrollView)
            scrollView->ccTouchCancelled(savedtouch, NULL);

    
    
    if(savedtouch)
        savedtouch->release();
    savedtouch=NULL;

    CCMenu::onExit();

}



void CCMenuScrollable::ccTouchCancelled(CCTouch* touch, CCEvent* event)
{
    if(exitTracking)
    {
        if(scrollView)
            scrollView->ccTouchCancelled(touch, event);

        
        if(savedtouch)
            savedtouch->release();
        
        savedtouch=NULL;


    }else

    
    CCMenu::ccTouchCancelled(touch, event);


}



void ScorePanel::updateScore()
{
    char score[200];
    sprintf(score, "%d",GameManager::sharedGameManager()->getCoins());
    lable1->setString(score);
    
    sprintf(score, "%d",GameManager::sharedGameManager()->getStars());
    lable2->setString(score);
    
}

bool ScorePanel::init()
{
    if(!CCLayer::init())
        return false;
    
    CCSprite * sprite = CCSprite::create("Header-scorebar1.png");
    this->addChild(sprite);
    
    CCSprite * sprite2 = CCSprite::create("Header-scorebar2.png");
    this->addChild(sprite2);
    
    CCNodePlaceAtRight(sprite,ccp(0, 13));
    CCNodePlaceAtRight(sprite2,ccp(0, 13));
    
    lable1 = CCLabelTTF::create("123", "Helvetica", 25);
    lable1->setHorizontalAlignment(kCCTextAlignmentLeft);
    
    sprite->addChild(lable1);
    lable2 = CCLabelTTF::create("123", "Helvetica", 25);
    sprite2->addChild(lable2);;
    
    lable2->setHorizontalAlignment(kCCTextAlignmentLeft);
    
    CCNodePlaceAtLeft(lable1,ccp(70,0));
    CCNodePlaceAtLeft(lable2,ccp(70,0));
    
    lable1->setColor(ccBLACK);
    lable2->setColor(ccBLACK);
    
    updateScore();
    
    return true;
}


class ActiveGamePanel:public CCSprite {
    
    
public:
    
    void Play(CCObject* sender)
    {

    }


    static ActiveGamePanel * create(const char * name,const char * comment, const char * facebookurl, int status)
    {
        ActiveGamePanel * panel = new ActiveGamePanel;
        panel->autorelease();

        panel->init(name, comment, facebookurl, status);

        return panel;
        
    }
    
    
    
    bool init(const char * name,const char * comment, const char * facebookurl, int status)
    {
        if ( !CCSprite::initWithFile("Match.png"))
        {
            return false;
        }
        
        
        CCLabelTTF * labelttf = CCLabelTTF::create(name, "Helvetica", 25);
        this->addChild(labelttf);
        labelttf->setColor(ccBLACK);
        CCNodePlaceAtLeft(labelttf,ccp(100,20));
        
        
        labelttf = CCLabelTTF::create(comment, "Helvetica", 20);
        this->addChild(labelttf);
        labelttf->setColor(ccBLACK);
        CCNodePlaceAtLeft(labelttf,ccp(100,-14));
        
        
        {
            CCMenuScrollable * menu =CCMenuScrollable::create();
            CCMenuItemImage * button;

            switch (status) {
                case ePlayerStatusPlay:
                     button = CCMenuItemImage::create("HumIt_Button_play.png",
													 "HumIt_Button_play_hvr.png","HumIt_Button_play_hvr.png",
													 this, menu_selector(ActiveGamePanel::Play));
                    break;


                case ePlayerStatusPoke:
                    button = CCMenuItemImage::create("HumIt_Button_poke.png",
                                                     "HumIt_Button_poke_hvr.png","HumIt_Button_poke_hvr.png",
                                                     this, menu_selector(ActiveGamePanel::Play));
                    break;

                case ePlayerStatusAccept:
                    button = CCMenuItemImage::create("HumIt_Button_poke.png",
                                                     "HumIt_Button_poke_hvr.png","HumIt_Button_poke_hvr.png",
                                                     this, menu_selector(ActiveGamePanel::Play));
                    break;



                default:
                    break;
            }

            
            
            menu->addChild(button);
            
            this->addChild(menu);
            
            CCNodePlaceAtRight(menu);
            CCNodePlaceAtRight(button,ccp(-5,0));
            

            CCSpriteFromUrl * profileimage=
            CCSpriteFromUrl::create(facebookurl);
        
            this->addChild(profileimage);
            CCNodePlaceAtLeft(profileimage,ccp(10,0));
        
        }
        
        
        return true;
    }
    
    
};



class GameInvitation:public CCSprite {
    
    
public:
    CREATE_FUNC(GameInvitation);
    
    void facebookplay(CCObject* sender)
    {
        cocos2d::CCDirector::sharedDirector()->replaceScene(FacebookFriendListScreen::scene());

    }
    
    
    void randomplay(CCObject* sender)
    {
        cocos2d::CCDirector::sharedDirector()->replaceScene(RandomPlayerScreen::scene());
    }
    

    bool init()
    {
        if ( !CCSprite::initWithFile("startnewgame_box.png"))
        {
            return false;
        }
        
        {
            CCMenuScrollable * menu =CCMenuScrollable::create();
            this->addChild(menu);
            
            CCNodePlaceAtCenter(menu,ccp(0,-22));

            
            {
            
                CCMenuItemImage * button  = CCMenuItemImage::create("facebook_bt.png", "facebook_bt_hvr.png","facebook_bt_hvr.png",this,
                											 menu_selector(GameInvitation::facebookplay));
                
                menu->addChild(button);
                
                CCNodePlaceAtLeft(button,ccp(30,0));
            }
            
            
            
            {
                
                CCMenuItemImage * button  = CCMenuItemImage::create("random_bt.png", "random_bt_hvr.png","random_bt_hvr.png",this,
                											menu_selector(GameInvitation::randomplay));
                
                menu->addChild(button);
                
                CCNodePlaceAtRight(button,ccp(-30,0));
            }
            

            
        }
        
        
        return true;
    }
    
    
};


CCScene* GamesProgresScreen::scene()
{
	CCScene *scene = CCScene::create();
	
	GamesProgresScreen *layer = GamesProgresScreen::create();
    
	scene->addChild(layer);
    
	return scene;
}

GamesProgresScreen::GamesProgresScreen()
{
}

void GamesProgresScreen::dummySelector(CCObject* sender)
{

}


GamesProgresScreen::~GamesProgresScreen()
{
}

void GamesProgresScreen::LoginOutDone(CCObject* sender,void * data)
{


}



void GamesProgresScreen::LoginOut(CCObject* sender)
{
    CCHttpRequest* request = new CCHttpRequest();
    std::string url="http://humserver.appsonfire.co.uk/user/sign_out?";
    url=url+"user_id"+"="+GameManager::sharedGameManager()->getUserUUid();
    CCLOG(url.c_str());
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(GamesProgresScreen::LoginOutDone));
    // optional fields
    request->setTag("GET test2");
    
    CCHttpClient::getInstance()->send(request);
    request->release();
    
    
    cocos2d::CCDirector::sharedDirector()->replaceScene(LoginScreen::scene());
    
    // need to implement Android logout method
//    GamesProgresScreen::FacebookLoginOut(sender);
    RecJNICommunicator::logoutFromFB();
    
    GameManager::sharedGameManager()->logout();
}


bool GamesProgresScreen::init()
{
	CCSize size = CCDirector::sharedDirector()->getWinSize();
	if ( !CCLayer::init() )
	{
		return false;
	}
    
    CCSprite * bg = CCSprite::create("bg.png");
    this->addChild(bg);
    CCNodePlaceAtCenter(bg);
    

    status = CCLabelTTF::create("Loading your games...", "Helvetica", 30);
    this->addChild(status);
    CCNodePlaceAtCenter(status,ccp(0, 0));



    
    {
        CCSprite * topbar = CCSprite::create("add.png");
        this->addChild(topbar);
        CCNodePlaceAtBottom(topbar);

        CCMenuScrollable * menu =CCMenuScrollable::create();
  
        {
            CCMenuItemImage * button  = CCMenuItemImage::create("buystuff_bt.png", "buystuff_bt_hvr.png","buystuff_bt_hvr.png",
            													 this, menu_selector(GamesProgresScreen::LoginOut));
            menu->addChild(button);
            CCNodePlaceAtBottom(button,ccp(-160,0));

        }
        
        
        
        {
            CCMenuItemImage * button  = CCMenuItemImage::create("signout.png", "signout_hvr.png","signout_hvr.png",
            													 this, menu_selector(GamesProgresScreen::LoginOut));
            menu->addChild(button);
            CCNodePlaceAtBottom(button,ccp(160,0));
            
        }

        
        topbar->addChild(menu);
        
        CCNodePlaceAtBottom(menu,ccp(0,150));
        
    }
    
    
    {
        CCSprite * topbar = CCSprite::create("Logobackground.png");
        this->addChild(topbar);
        CCNodePlaceAtTop(topbar);
        
        ScorePanel * scorepanel = ScorePanel::create();
        topbar->addChild(scorepanel);
        
        CCNodePlaceAtLeft(scorepanel,ccp(0, 0));

    }
    
//    this->LoadActiveGames();

	return true;
}

void GamesProgresScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
    
    GameManager::sharedGameManager()->requestForActiveGame(this);

}


void GamesProgresScreen::LoadActiveGames()
{
    status->setString("");


    CCPoint gameProgressBGOffset =  CCPoint(0, -180);
    CCPoint gameProgressBGStride =  CCPoint(0, 94.2);
    tablecellheight=gameProgressBGStride.y;

    int activegamecount = GameManager::sharedGameManager()->getActiveGameCount();
    int showablegamecount = (this->getContentSize().height - 650)/gameProgressBGStride.y;

    if(showablegamecount>activegamecount)
        showablegamecount = activegamecount;

    if(showablegamecount )

    {
        CCSprite * bg = CCSprite::create("Games-in-progressboxtop.png");
        this->addChild(bg);
        CCNodePlaceAtTop(bg,ccp(0, -130));

    }
    


    
    for (int i = 0; i < showablegamecount;i++)
    {
        CCSprite * bg = CCSprite::create("Games-in-progressboxCentre.png");
        this->addChild(bg);
        CCNodePlaceAtTop(bg,gameProgressBGOffset);

        gameProgressBGOffset = ccpSub(gameProgressBGOffset, gameProgressBGStride);
        
    }
    

    

    if(showablegamecount)
    {
        CCSprite * bottombg = CCSprite::create("Games-in-progressboxBottom.png");
        this->addChild(bottombg);

        gameProgressBGOffset = ccpSub(gameProgressBGOffset, ccp(0,-30));

        CCNodePlaceAtTop(bottombg,gameProgressBGOffset);

        gameProgressBGOffset = ccpSub(gameProgressBGOffset, ccp(0,70));

        gameMatchwidth = bottombg->getContentSize().width;



        {


            CCTableView * tableview = CCTableView::create(this, CCSize(bottombg->getContentSize().width, gameProgressBGStride.y * showablegamecount));
            tableview->setDelegate(this);
            tableview->setDataSource(this);

            bottombg->addChild(tableview);

            tableview->setPosition(ccp(6,20));



        }

    }
    
    {


        GameInvitation * panel = GameInvitation::create();
        this->addChild(panel);
        CCNodePlaceAtTop(panel,gameProgressBGOffset);
        
    }


}



void GamesProgresScreen::onExit()
{
    CCLayer::onExit();
}



bool OpponentUserTopBar::init()
{
    if(!CCSprite::initWithFile("topbar.png"))
        return false;


    CCLabelTTF * labelttf = CCLabelTTF::create(GameManager::sharedGameManager()->getActivePlayer()->name.c_str(), "Helvetica", 25);
    this->addChild(labelttf);
    labelttf->setColor(ccBLACK);
    CCNodePlaceAtLeft(labelttf,ccp(100,20));


    labelttf = CCLabelTTF::create("3 plays to next Bonus", "Helvetica", 20);
    this->addChild(labelttf);
    labelttf->setColor(ccBLACK);
    CCNodePlaceAtLeft(labelttf,ccp(100,-14));


    {
        CCSpriteFromUrl * profileimage=
        CCSpriteFromUrl::create(GameManager::sharedGameManager()->getActivePlayer()->profileurl.c_str());

        this->addChild(profileimage);
        CCNodePlaceAtLeft(profileimage,ccp(10,0));

    }

    return true;
}






CCSize GamesProgresScreen::cellSizeForTable(CCTableView *table)
{
    return CCSizeMake(gameMatchwidth, tablecellheight);

}

CCTableViewCell* GamesProgresScreen::tableCellAtIndex(CCTableView *table, unsigned int idx)
{
    CCTableViewCell  * cell = new CCTableViewCell;
    cell->setContentSize(this->cellSizeForTable(table));

    cell->autorelease();

    CCSprite * sprite= CCSprite::create("Match.png");


    const  std::vector<Player> & gamelist = GameManager::sharedGameManager()->getActivePlayerList();

    const Player & player = gamelist[idx];

    ActiveGamePanel * panel = ActiveGamePanel::create(player.name.c_str(), player.getComment().c_str(), player.profileurl.c_str(), player.status);

    cell->setContentSize(sprite->getContentSize());

    cell->addChild(panel);
    CCNodePlaceAtCenter(panel);


    return cell;
}

unsigned int GamesProgresScreen::numberOfCellsInTableView(CCTableView *table)
{

    int activegamecount = GameManager::sharedGameManager()->getActiveGameCount();
    return activegamecount;

}
