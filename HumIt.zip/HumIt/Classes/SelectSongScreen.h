//
//  SelectSongScreen.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#ifndef __SelectSongScreen__SCENE_H__
#define __SelectSongScreen__SCENE_H__

#include "cocos2d.h"

struct TrackEntry {
    std::string name;
    std::string artist;
    int trackid;
    
};

class SelectSongScreen : public cocos2d::CCLayer
{
    cocos2d::CCSprite *box;

public:
    SelectSongScreen();
    
    ~SelectSongScreen();
    
    char * strndupunsigned(unsigned char * charbuffer , size_t size);

    static cocos2d::CCScene* scene();
    
	virtual bool init();  
    
    virtual void onExit();
    
    virtual void onEnterTransitionDidFinish();
    void SelectSong(CCObject* sender);

	CREATE_FUNC(SelectSongScreen);
    
private:
    
    void loadtrack();
    void updatetrackitem();
    void removePurchased();
    std::vector<TrackEntry> tracklist;
    
    std::vector<int> purchasedtrack;

    cocos2d::CCLabelTTF * status;
    
    void onHttpRequestCompleted(CCNode *sender, void *data);
    void SendSong(int songid);

};

#endif // __SelectSongScreen__SCENE_H__
