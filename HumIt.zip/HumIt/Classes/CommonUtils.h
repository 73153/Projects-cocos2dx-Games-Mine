//
//  Header.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 15/11/12.
//
//

#ifndef HumIt_Header_h
#define HumIt_Header_h
#include "base_nodes/CCNode.h"

namespace  cocos2d {
    void CCNodePlaceAtCenter(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtBottom(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtTop(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtRight(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtLeft(CCNode * node,CCPoint offset=CCPointZero);

    
    int CCTag(const  char *str);
    
    //to be ported to android
    bool CCFileUtils_FileExistAtPath(const char * path);
    
    double CCFileUtils_FileAge(const char * path);
}

#define CCTAG(x) CCTag(#x)
#endif
