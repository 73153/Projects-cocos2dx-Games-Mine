//
//  RandomPlayerScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "RandomPlayerScreen.h"
#include "GamesProgresScreen.h"
#include "GameManager.h"
#include "CommonUtils.h"
#include "cocos-ext.h"
#include "json.h"

#include "RecordAndPlay.h"
#include "SelectGenreScreen.h"
#include "RecJNICommunicator.h"


using namespace cocos2d;
using namespace cocos2d::extension;

CCScene* RandomPlayerScreen::scene()
{
	CCScene *scene = CCScene::create();
	
	RandomPlayerScreen *layer = RandomPlayerScreen::create();
    
	scene->addChild(layer);
    
	return scene;
}

RandomPlayerScreen::RandomPlayerScreen() {
	CCLog(" ------- CCCCCCC ------- entering RandomPlayerScreen constructor -------- CCCCCCC -------- ");
}

RandomPlayerScreen::~RandomPlayerScreen() {
	CCLog(" ------- DDDDDDDD ------- entering RandomPlayerScreen destructor -------- DDDDDDDD -------- ");
}

bool RandomPlayerScreen::init()
{
	if (!CCLayer::init())
        return false;
    
	{
        CCSprite * bg = CCSprite::create("bg.png");
        this->addChild(bg);
        CCNodePlaceAtCenter(bg);

        CCSprite * topbar = CCSprite::create("add.png");
		this->addChild(topbar);
		CCNodePlaceAtBottom(topbar);

        
        CCSprite * box = CCSprite::create("bonus_box.png");
        this->addChild(box);
        CCNodePlaceAtCenter(box);
        
        {
            CCMenu * menu =CCMenu::create();
            
            {
                box->addChild(menu);
                menu->setContentSize(box->getContentSize());
                CCNodePlaceAtCenter(menu);
                
                {

                    CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                                        "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",
                                                                        this, menu_selector(RandomPlayerScreen::SelectGender));
                    

                    menu->addChild(button);
                    CCNodePlaceAtCenter(button,ccp(0,100));
                    
                    
                    CCLabelTTF * label = CCLabelTTF::create("Male", "Bold", 25);
                    
                    button->addChild(label);
                    CCNodePlaceAtCenter(label);
                    
                    button->setTag(CCTag("male"));

                }
                
                
                {
                    
                    
                    CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                                        "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",
                                                                        this, menu_selector(RandomPlayerScreen::SelectGender));
                    menu->addChild(button);
                    CCNodePlaceAtCenter(button,ccp(0,0));
                    
                    
                    CCLabelTTF * label = CCLabelTTF::create("Female", "Bold", 25);
                    
                    button->addChild(label);
                    CCNodePlaceAtCenter(label);
                    button->setTag(CCTag("female"));

                }
                
                {
                    
                    CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                                        "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",
                                                                        this, menu_selector(RandomPlayerScreen::SelectGender));
                    
                    
                    menu->addChild(button);
                    CCNodePlaceAtCenter(button,ccp(0,-100));
                    
                    
                    CCLabelTTF * label = CCLabelTTF::create("I don't mind", "Bold", 25);
                    
                    button->addChild(label);
                    CCNodePlaceAtCenter(label);
                    button->setTag(CCTag("any"));

                }

            }
            
        }
        
        {
            CCSprite * topbar = CCSprite::create("Logobackground.png");
            this->addChild(topbar);
            CCNodePlaceAtTop(topbar);
            
            ScorePanel * scorepanel = ScorePanel::create();
            topbar->addChild(scorepanel);
            
            CCNodePlaceAtLeft(scorepanel,ccp(0, 0));
            
        }
        

        {
            
            status = CCLabelTTF::create("", "Helvetica", 30);
            this->addChild(status);
            CCNodePlaceAtBottom(status,ccp(0, 150));
        }

        
	}
    
	return true;
}



void RandomPlayerScreen::requestForRandomUser(const char * gender)
{
	CCLog(" ------------------ RandomPlayerScreen requestForRandomUser ------------------- ");
    CCHttpRequest* request = new CCHttpRequest();
    
    std::string url="http://humserver.appsonfire.co.uk/user/random?";
    url=url+"gender"+"="+gender;
    CCLog(" %s UUUUUUUUUUU url UUUUUUUUUUU ",url.c_str());
    CCLOG(url.c_str());
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(RandomPlayerScreen::onHttpRequestCompleted));
    // optional fields
    request->setTag("randomplayer");
    
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    status->setString("Choosing a random player for you!...");
    
}

void RandomPlayerScreen::onHttpRequestCompleted(CCNode *sender, void *data)
{
	CCLog(" ------------------ RandomPlayerScreen onHttpRequestCompleted ------------------- ");
    CCLOG("request completed");

    CCHttpResponse *response = (CCHttpResponse*)data;

    if (!response)
    {
        return;
        CCLog(" ----------------- RandomPlayerScreen onHttpRequestCompleted return ------------------- ");
    }

    if (!response->isSucceed())
    {
        CCLog("response failed");
        CCLog("error buffer: %s", response->getErrorBuffer());
        CCLog(" ----------------- RandomPlayerScreen onHttpRequestCompleted response failed ------------------- ");
        RecJNICommunicator::showAlert();
        return;
    }

    // dump data
    std::vector<char> *buffer = response->getResponseData();

    char * charbuffer = new char[buffer->size()];

    printf("Http Test, dump data: ");

    unsigned int size=0;
    for (unsigned int i = 0; i < buffer->size(); i++)
    {
        charbuffer[i] = (*buffer)[i];
        size = i+1;
    }
    CCLog(" ------------------ aftttttttttttwer for loop -------- %s ----------- ", charbuffer);
    charbuffer[size]=0;

    printf("%s",charbuffer);

    char *errorPos = 0;
    char *errorDesc = 0;
    int errorLine = 0;
    block_allocator allocator(1 << 10); // 1 KB per block

    json_value *root = json_parse(charbuffer, &errorPos, &errorDesc, &errorLine, &allocator);


    root = root->first_child;
    assert(root->type ==JSON_OBJECT );
    assert(std::string(root->name) =="user" );

    std::string user_id,facebook_id,gender,name,facebook_thumbnail;


    for (json_value *it = root->first_child; it; it = it->next_sibling)
    {
        if (std::string("user_id") == it->name )
        {  if(it->string_value)
            user_id = it->string_value;
            continue;
        }

        if (std::string("facebook_id") == it->name )
        {
            if(it->type == JSON_STRING && it->string_value)
            facebook_id = it->string_value;
                        continue;
        }

        if (std::string("gender") == it->name )
        {
            if(it->string_value)
            gender = it->string_value;
                        continue;
        }

        if (std::string("name") == it->name )
        {
            if(it->string_value)
            name = it->string_value;
                        continue;
        }


        if (std::string("facebook_thumbnail") == it->name )
        {
            if(it->string_value)
            facebook_thumbnail = it->string_value;
                        continue;
        }
    }

    CCLog(" ------------------ after 2nd for loop ------------------- ");

    facebook_thumbnail = std::string("http://")+facebook_thumbnail;


    GameManager::sharedGameManager()->setActivePlayer(Player::create(facebook_id, user_id,facebook_thumbnail,name));
    CCLog(" ------------------ aftttttttttttwer setActivePlayer ------------------- ");
    cocos2d::CCDirector::sharedDirector()->replaceScene(SelectGenreScreen::scene());

}

void RandomPlayerScreen::SelectGender(CCObject* sender)
{
	CCLog(" ------------------ RandomPlayerScreen SelectGender ------------------- ");
    CCMenuItemImage * menuitem = (CCMenuItemImage *) sender;
    
    if(menuitem->getTag()==CCTag("any"))
        requestForRandomUser("any");
    else if(menuitem->getTag()==CCTag("male"))
        requestForRandomUser("male");
    else if(menuitem->getTag()==CCTag("female"))
        requestForRandomUser("female");
    else assert(0);
    
}

void RandomPlayerScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
}

void RandomPlayerScreen::onExit()
{
    CCLayer::onExit();
}
