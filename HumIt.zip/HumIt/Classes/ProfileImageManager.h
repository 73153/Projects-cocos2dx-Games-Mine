//
//  ProfileImageManager.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 19/11/12.
//
//

#ifndef __HumIt__ProfileImageManager__
#define __HumIt__ProfileImageManager__
#include "cocoa/CCObject.h"
#include "sprite_nodes/CCSprite.h"
#include "CCSpriteFromUrl.h"
#include "string.h"
class ProfileImageManager:public cocos2d::CCObject {
    
    cocos2d::CCDictionary * imageRequests;
    bool setTextureFromFilePath(cocos2d::CCSprite * sprite,std::string path);
    
    void setFacebookProfileUrl(CCSpriteFaceBook * sprite,const char* url,const char* facebookid);
    
    
   cocos2d::CCDictionary * facebookUrlDict ;//Dictionary containing url for each facebookid
    
    void requestForFaceBookProfileImageImplmentation(const char* facebookid,CCSpriteFaceBook * sprite);

    
    

public:
    
    static ProfileImageManager * sharedProfileImageManager();

    void requestForImage(const char* url,cocos2d::CCSprite * sprite);
    void requestForFaceBookProfileImage(const char* facebookid,CCSpriteFaceBook * sprite);
    

    

    virtual bool init();
    ~ProfileImageManager();

    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);
    
    std::string nameFromUrl(std::string url);

    
};




#endif /* defined(__HumIt__ProfileImageManager__) */
