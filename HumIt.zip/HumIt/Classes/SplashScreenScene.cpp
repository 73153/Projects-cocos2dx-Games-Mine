/*
 * SplashScreenScene.cpp
 *
 *  Created on: Nov 20, 2012
 *      Author: icrg
 */

#include "SplashScreenScene.h"
#include "RecordAndPlay.h"
#include "LoginScreen.h"

using namespace cocos2d;

CCScene* SplashScreenScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();

    // 'layer' is an autorelease object
    SplashScreenScene *layer = SplashScreenScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

SplashScreenScene::SplashScreenScene() {

	CCLog(" ------- CCCCCCCCCC ------- entering SplashScreenScene constructor -------- CCCCCCCCCC -------- ");
	// add "RecordAndPlay" splash screen"
	CCSize size = CCDirector::sharedDirector()->getWinSize();

	CCSprite* pSprite = CCSprite::create("splash_screen.png");
	pSprite->setPosition( ccp(size.width/2, size.height/2) );
	this->addChild(pSprite, 0);

    CCFiniteTimeAction *delayAction = CCDelayTime::create(3.0f);
    CCFiniteTimeAction *callBackN = CCCallFuncN::create(this, callfuncN_selector(SplashScreenScene::gotoApp));
    CCFiniteTimeAction *seqAction = CCSequence::create(delayAction,callBackN,NULL);
    this->runAction(seqAction);
}

SplashScreenScene::~SplashScreenScene() {
	// TODO Auto-generated destructor stub
	CCLog(" ------- DDDDDDDD ------- entering SplashScreenScene destructor -------- DDDDDDDD -------- ");
}

void SplashScreenScene::gotoApp() {

    CCDirector::sharedDirector()->replaceScene(LoginScreen::scene());
}
