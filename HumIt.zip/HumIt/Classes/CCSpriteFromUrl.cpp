//
//  CCSpriteFromUrl.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//
//

#include "CCSpriteFromUrl.h"
#include "CommonUtils.h"

#include "ProfileImageManager.h"

using namespace cocos2d;

void CCSpriteFromUrl::setURL(const char * url)
{
    if(url==NULL)
        return;
    
    if(std::string("") == url)
        return;
    
    
    ProfileImageManager::sharedProfileImageManager()->requestForImage(url, this);

}

bool CCSpriteFromUrl::init(const char * url)
{
    if(CCSprite::initWithFile("SampleProfile.png"))
    {
        mUrl=url;
        return true;
    }
    
    
    return false;
}
 CCSpriteFromUrl * CCSpriteFromUrl::create(const char * url)
{
    CCSpriteFromUrl * sprite =new CCSpriteFromUrl;
    sprite->init(url);
    sprite->autorelease();
    return sprite;
}

CCSpriteFaceBook * CCSpriteFaceBook::create(const char * uid)
{
    CCSpriteFaceBook * sprite =new CCSpriteFaceBook;
    sprite->init(uid);
    sprite->autorelease();
    return sprite;
}

bool CCSpriteFaceBook::init(const char * uuid)
{
    if(CCSpriteFromUrl::init(0))
    {
        
        facebookuuid = uuid;
        
        return true;
        
        
    }
    return false;
}



void CCSpriteFaceBook::fetchFaceBookProfile()
{
    ProfileImageManager::sharedProfileImageManager()->requestForFaceBookProfileImage(facebookuuid.c_str(), this);

}

