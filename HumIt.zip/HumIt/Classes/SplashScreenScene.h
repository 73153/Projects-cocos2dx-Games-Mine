/*
 * SplashScreenScene.h
 *
 *  Created on: Nov 20, 2012
 *      Author: icrg
 */

#ifndef SPLASHSCREENSCENE_H_
#define SPLASHSCREENSCENE_H_

#include "cocos2d.h"

class SplashScreenScene : public cocos2d::CCLayer {

public:

	SplashScreenScene();
	virtual ~SplashScreenScene();

	static cocos2d::CCScene* scene();
	void gotoApp();

	// implement the "static node()" method manually
	CREATE_FUNC(SplashScreenScene);
};

#endif /* SPLASHSCREENSCENE_H_ */
