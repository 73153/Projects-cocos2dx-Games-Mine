//
//  FacebookFriendListScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
#include "CommonUtils.h"
#include "GamesProgresScreen.h"
#include "FacebookFriendListScreen.h"
#include "cocos-ext.h"
#include "CCSpriteFromUrl.h"

#include "RecJNICommunicator.h"

using namespace cocos2d;
using namespace cocos2d::extension;




class FacebookFriendCell:public CCTableViewCell {
    
    std::string name,facebookid;
    
    
public:
    static FacebookFriendCell * create(std::string inname,std::string infinacebookid)
    {
        FacebookFriendCell * facebookfriend = new FacebookFriendCell;
        facebookfriend->init(inname, infinacebookid);
        
        facebookfriend->autorelease();
        return facebookfriend;
    }
    

    void facebookInvite(CCObject* sender)
    {
//        FacebookFriendListScreen::sendInvitation(facebookid.c_str(),name.c_str());
    }


        
    bool init(std::string inname,std::string infacebookid)
    {
        name=inname;
        facebookid=infacebookid;
        CCSprite * sprite = CCSprite::create("Match.png");
        
        this->addChild(sprite);
        this->setContentSize(sprite->getContentSize());
        CCNodePlaceAtCenter(sprite);
        
        
        CCLabelTTF * labelttf = CCLabelTTF::create("", "Helvetica", 25);
        this->addChild(labelttf);
        labelttf->setColor(ccBLACK);
        CCNodePlaceAtLeft(labelttf,ccp(100,0));
        
        labelttf->setString(inname.c_str());
        
        {
            CCMenu * menu =CCMenu::create();
            
            CCMenuItemImage * button  = CCMenuItemImage::create("HumIt_Button_play.png",
                                                                "HumIt_Button_play.png","HumIt_Button_play.png",
                                                                this, menu_selector(FacebookFriendCell::facebookInvite));
            
            
            menu->addChild(button);
            
            this->addChild(menu);
            menu->setContentSize(sprite->getContentSize());

            
            CCNodePlaceAtRight(menu);
            CCNodePlaceAtRight(button,ccp(-5,0));
            
            
            CCSpriteFaceBook * profileimage=
            CCSpriteFaceBook::create(facebookid.c_str());
            
            this->addChild(profileimage);
            CCNodePlaceAtLeft(profileimage,ccp(10,0));
            
            
        }
        
        
        return true;
    }
    
    
};




FacebookFriendListScreen::FacebookFriendListScreen()
{
}

FacebookFriendListScreen::~FacebookFriendListScreen()
{
}

CCScene* FacebookFriendListScreen::scene()
{
	CCScene *scene = CCScene::create();
	
	FacebookFriendListScreen *layer = FacebookFriendListScreen::create();
    
	scene->addChild(layer);
    
	return scene;
}


void FacebookFriendListScreen::loadFriendList()
{
    tableView->reloadData();
    status->setString("");
}

bool FacebookFriendListScreen::init()
{
	if ( !CCLayer::init() )
	{
		return false;
	}
    
    friendsList = new CCArray;
    
    CCSprite * bg = CCSprite::create("bg.png");
    this->addChild(bg);
    CCNodePlaceAtCenter(bg);
    
    
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    
    tableView = CCTableView::create(this, CCSizeMake(getContentSize().width, getContentSize().height-300));
    tableView->setDirection(kCCScrollViewDirectionVertical);
    tableView->setPosition(ccp(20,130));
    tableView->setDataSource(this);
    tableView->setVerticalFillOrder(kCCTableViewFillTopDown);
    tableView->setDelegate(this);

    this->addChild(tableView);
    
    status = CCLabelTTF::create("Loading...", "Helvetica", 30);
    this->addChild(status);
    CCNodePlaceAtCenter(status,ccp(0, 0));

    
    {
        CCSprite * topbar = CCSprite::create("Logobackground.png");
        this->addChild(topbar);
        CCNodePlaceAtTop(topbar);
        
        ScorePanel * scorepanel = ScorePanel::create();
        topbar->addChild(scorepanel);
        
        CCNodePlaceAtLeft(scorepanel,ccp(0, 0));

    }

    
    {
    
    CCSprite * topbar = CCSprite::create("add.png");
    this->addChild(topbar);
    CCNodePlaceAtBottom(topbar);
    
    }
    
    

	return true;
}



CCSize FacebookFriendListScreen::cellSizeForTable(CCTableView *table)
{
    return CCSizeMake(getContentSize().width, 100);
}

CCTableViewCell* FacebookFriendListScreen::tableCellAtIndex(CCTableView *table, unsigned int idx)
{
    CCDictionary * dict = (CCDictionary *)friendsList->objectAtIndex(idx);
    const CCString * name =dict->valueForKey("name");
    const CCString * facebookid =dict->valueForKey("id");
    
    
    
    FacebookFriendCell *cell  = FacebookFriendCell::create(name->getCString(),facebookid->getCString());
        cell->autorelease();
    
    return cell;
}

unsigned int FacebookFriendListScreen::numberOfCellsInTableView(CCTableView *table)
{
    return friendsList->count();
}

void FacebookFriendListScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
    // call java version
//    FetchFriendList();
    RecJNICommunicator::fetchFriendsList();
    
}

void FacebookFriendListScreen::onExit()
{
    CCLayer::onExit();
}

