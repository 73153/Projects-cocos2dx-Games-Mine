//
//  SelectSongScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 22/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "SelectSongScreen.h"
#include "GamesProgresScreen.h"
#include "CommonUtils.h"
#include "json.h"
#include "GameManager.h"
#include"cocos-ext.h"

#include "RecordAndPlay.h"


using namespace cocos2d;
using namespace cocos2d::extension;

CCScene* SelectSongScreen::scene()
{
	CCScene *scene = CCScene::create();
	
	SelectSongScreen *layer = SelectSongScreen::create();
    
	scene->addChild(layer);
    
	return scene;
}

SelectSongScreen::SelectSongScreen()
{
}

SelectSongScreen::~SelectSongScreen()
{
}

void SelectSongScreen::removePurchased()
{
    std::vector<TrackEntry> newtracklist;
    
    for (int i = 0;  i< tracklist.size(); i++)
    {
        bool ispurchased=false;
        
        for (int k = 0; k < purchasedtrack.size(); k++)
        {
            if(tracklist[i].trackid == purchasedtrack[k])
            {
                ispurchased = true;
                break;
            }
        }
            
        if(!ispurchased)
        {
            newtracklist.push_back(tracklist[i]);
        
        }
    }
    
    
    tracklist.swap(newtracklist);

}

void SelectSongScreen::SelectSong(CCObject* sender)
{
    CCNode * node = (CCNode *)sender;
    
    if(node->getTag()==1000)
    {
        for (int i = 0; i < 3 && i< tracklist.size(); i++)
        {
            purchasedtrack.push_back(tracklist[i].trackid);
        }    

        removePurchased();
        updatetrackitem();
        
    } else {
        
//        SendSong(node->getTag());
    	  cocos2d::CCDirector::sharedDirector()->replaceScene(RecordAndPlay::scene());
    }
    
}


void SelectSongScreen::loadtrack()
{
    CCLog(" -------- SelectSongScreen::loadtrack ------- ");
    const char * genrefile =   CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("tracks.json");
    
    size_t size;
    unsigned long bufferSize = 0;
    //////////// attention
//    unsigned char * charbuffer = CCFileUtils::sharedFileUtils()->getFileData(genrefile, "rb", &size);
    unsigned char * charbuffer = CCFileUtils::sharedFileUtils()->getFileData(genrefile, "rb", &bufferSize);
    
    char *errorPos = 0;
    char *errorDesc = 0;
    int errorLine = 0;
    block_allocator allocator(1 << 10); // 1 KB per block
    
    //////////// attention
    char * newcharbuffer = strndup((char*)charbuffer, bufferSize);
//    char * newcharbuffer = strndupunsigned(charbuffer, bufferSize);
    
    delete charbuffer;
    
    json_value *root = json_parse(newcharbuffer, &errorPos, &errorDesc, &errorLine, &allocator);
    
    free(newcharbuffer);
    
    std::string genrename;
    
    CCLog(" -------- SelectSongScreen::loadtrack entering for loop ------- ");
    for (json_value *itgenre = root->first_child; itgenre; itgenre = itgenre->next_sibling)
    {
//    	CCLog(" -------- SelectSongScreen::loadtrack 1st for ------- ");
        json_value * agenre = itgenre;
        
        TrackEntry entry;
        
        
        int genreid;
        
        for (json_value * itproperty = agenre->first_child; itproperty; itproperty = itproperty->next_sibling)
        {
//        	CCLog(" -------- SelectSongScreen::loadtrack 2nd for ------- ");
            if (std::string("title") == itproperty->name )
            {
                entry.name = itproperty->string_value;
                
                continue;
                
            }
            
            if (std::string("id") == itproperty->name )
            {
                entry.trackid= itproperty->int_value;
                continue;
                
                
            }
            
            if (std::string("genre_id") == itproperty->name )
            {
                genreid= itproperty->int_value;
                continue;
                
            }
            
        }
        
        
        if( genreid == GameManager::sharedGameManager()->getActiveGenre())
            tracklist.push_back(entry);
        
    }
    
    CCLog(" -------- SelectSongScreen::loadtrack exiting for loop ------- ");

}

//char * SelectSongScreen::strndupunsigned(unsigned char * charbuffer , size_t size)
//{
//	CCLog(" ----------------------- strndupunsigned -------- %f --------- %s -------- ",size, charbuffer);
//	char * buffer = (char *)malloc(size+1 * sizeof(char));
//	for (int i = 0; i < size; i++)
//	{
//		buffer[i]=charbuffer[i];
//	}
//
//	buffer[size]='\0';
//	return buffer;
//
//}


void SelectSongScreen::SendSong(int songid)
{
    
    CCHttpRequest* request = new CCHttpRequest();
    
    char songidstr[250];
    sprintf(songidstr, "%d",songid);
    
    std::string url="http://humserver.appsonfire.co.uk/game/submit_audio?";
    url=url+"user_id"+"="+GameManager::sharedGameManager()->getUserUUid()+"&";
    url=url+"opponent_user_id"+"="+GameManager::sharedGameManager()->getActivePlayer()->userid+"&";
    url=url+"audio_url"+"="+"https://s3.amazonaws.com/videocreator/voices/audio1614798204084236623.mp3"+"&";
    url=url+"track_id"+"="+songidstr+"&";

    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(SelectSongScreen::onHttpRequestCompleted));
    // optional fields
    request->setTag("randomplayer");
    
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
  //  status->setString("Choosing a random player for you!...");
    
}



void SelectSongScreen::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    
    CCLOG("request completed");
    
    CCHttpResponse *response = (CCHttpResponse*)data;
    
  
    
       
  //  cocos2d::CCDirector::sharedDirector()->popScene();//song
   // cocos2d::CCDirector::sharedDirector()->popScene();//genre
//    cocos2d::CCDirector::sharedDirector()->popScene();//random

    
    cocos2d::CCDirector::sharedDirector()->replaceScene(GamesProgresScreen::scene());
    
  
    if (!response || !response->isSucceed() || response->getResponseCode() !=200)
    {
        CCMessageBox("Failed to send song", "Failure");
    }else
    {
        CCMessageBox("Suceeded to send song", "Success");
    }
    
}


void SelectSongScreen::updatetrackitem()
{
	CCLog(" ------- SelectSongScreen::updatetrackitem ----- %d ----- ", tracklist.size());
    box->removeAllChildrenWithCleanup(true);
    
    
    CCMenu * menu = CCMenu::create();
    
    box->addChild(menu);
    menu->setContentSize(box->getContentSize());
    CCNodePlaceAtCenter(menu);
    
    CCPoint offset = CCPoint(0, -90);
    CCPoint stride = CCPoint(0, 90);
    
    
    for (int i = 0; i < 3; i++)
    {
    	CCLog(" ------- SelectSongScreen::updatetrackitem for loop ---------- ");
        CCMenuItemImage * button  = CCMenuItemImage::create("RandomHumIt_Button.png",
                                                            "RandomHumIt_Button_hvr.png","RandomHumIt_Button_hvr.png",
                                                            this, menu_selector(SelectSongScreen::SelectSong));
        menu->addChild(button);
        CCNodePlaceAtTop(button,offset);
        
        
        CCLabelTTF * label = CCLabelTTF::create(tracklist[i].name.c_str(), "Helvetica", 25);
        
        button->addChild(label);
        CCNodePlaceAtCenter(label,ccp(0,10));
        
        button->setTag(tracklist[i].trackid);
        
        
        offset = ccpSub(offset, stride);
        
    }
    
    
    {
        
        CCMenuItemImage * button  = CCMenuItemImage::create("Get_more_genres.png",
                                                            "Get_more_genres_hvr.png","Get_more_genres_hvr.png",
                                                            this, menu_selector(SelectSongScreen::SelectSong));
        menu->addChild(button);
        CCNodePlaceAtTop(button,offset);
        
        
        CCLabelTTF * label = CCLabelTTF::create("Refresh", "Helvetica", 25);
        
        button->addChild(label);
        CCNodePlaceAtCenter(label,ccp(0,10));
        
        button->setTag(1000);
        
        
        offset = ccpSub(offset, stride);
        
    }

}


bool SelectSongScreen::init()
{
	if ( !CCLayer::init() )
	{
		return false;
	}
    
    loadtrack();
    
    {
        
        CCSprite * bg = CCSprite::create("bg.png");
        this->addChild(bg);
        CCNodePlaceAtCenter(bg);
        
    }
    
    {
        
        box = CCSprite::create("box.png");
        this->addChild(box);
        CCNodePlaceAtCenter(box);
        
        this->updatetrackitem();
        
    }
    
    {
        CCSprite * topbar = OpponentUserTopBar::create();
        this->addChild(topbar);
        CCNodePlaceAtTop(topbar);
        
        ScorePanel * scorepanel = ScorePanel::create();
        topbar->addChild(scorepanel);
        
        CCNodePlaceAtLeft(scorepanel,ccp(0, 0));
        
    }
    
    
    {
        
        CCSprite * topbar = CCSprite::create("add.png");
        this->addChild(topbar);
        CCNodePlaceAtBottom(topbar);
        
    }
    
	return true;
}

void SelectSongScreen::onEnterTransitionDidFinish()
{
    CCLayer::onEnterTransitionDidFinish();
}

void SelectSongScreen::onExit()
{
    CCLayer::onExit();
}
