//
//  Header.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 15/11/12.
//
//
#include"CommonUtils.h"
#include"base_nodes/CCNode.h"
#include"support/CCPointExtension.h"

namespace  cocos2d {

//shakthi
 void CCNodePlaceAtCenter(CCNode * node,CCPoint offset)
{
    node->setAnchorPoint(ccp(0.5, 0.5));
    node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, node->getParent()->getContentSize().height /2+offset.y) );
    node->ignoreAnchorPointForPosition(false);

}

    
    
void CCNodePlaceAtBottom(CCNode * node,CCPoint offset)
{
    node->setAnchorPoint(ccp(0.5, 0));
    node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, offset.y) );
    node->ignoreAnchorPointForPosition(false);

}

void CCNodePlaceAtTop(CCNode * node,CCPoint offset)
{
    node->setAnchorPoint(ccp(0.5, 1));
    node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, node->getParent()->getContentSize().height+offset.y) );
    node->ignoreAnchorPointForPosition(false);

}
    
    
    
    
    
    void CCNodePlaceAtRight(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(1, 0.5));
        node->setPosition( ccp(node->getParent()->getContentSize().width +offset.x,node->getParent()->getContentSize().height/ 2+ offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    


    void CCNodePlaceAtLeft(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(0, 0.5));
        node->setPosition( ccp(offset.x,node->getParent()->getContentSize().height/ 2+ offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }

    bool CCFileUtils_FileExistAtPath(const char * path) {
    	return false;
    }

    double CCFileUtils_FileAge(const char * path) {
    	double value = 2.4444444;
    	return value;
    }


    
    
    
namespace {
    unsigned long
    hash(unsigned char *str)
    {
        unsigned long hash = 5381;
        int c;
        
        while ((c = *str++))
            hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
        
        return hash;
    }
}
    
int CCTag(const  char *str)
    {
    
        return hash((unsigned char *)str);
    
    
    }
    

}
