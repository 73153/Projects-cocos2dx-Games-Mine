/****************************************************************************
Copyright (c) 2010-2012 cocos2d-x.org

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
package com.humit.android;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.json.JSONException;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.facebook.FacebookActivity;
import com.facebook.GraphUser;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.SessionState;
import com.facebook.Request.GraphUserListCallback;
import com.humit.R;

public class HumIt extends Cocos2dxActivity{
	
	private ArrayList<User> mFBFriendList = null;

	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		System.out.println("-------------- onCreate called!! in HumIt -------------");
//		javaCallJNI("hi");
		
		mFBFriendList = new ArrayList<User>();
	}
	
	public native void javaCallJNI(String userName, String userId, String gender);
	
	public native void addFriends(int size, ArrayList<User> userList);
	
    static {
         System.loadLibrary("game");
    }
    
    @Override
	protected void onSessionStateChange(SessionState state, Exception exception) {
		// user has either logged in or not ...
    	System.out.println("--------------onSessionStateChange called!! in HumIt -------------"); 
      if (state.isOpened()) {
    	  System.out.println("--------------onSessionStateChange isOpened called!! in HumIt -------------"); 
    	  
    	// fetch friends list
          Request.newMyFriendsRequest(getSession(), new GraphUserListCallback() {
				@Override
				public void onCompleted(List<GraphUser> users, Response response) {
					// TODO Auto-generated method stub
					System.out.println(" ---- response ---- "+response);
					System.out.println(" ---- users ---- "+users);
					for(GraphUser graphUser : users) {
						String userName = graphUser.getName();
						String userId = graphUser.getId();
						System.out.println(" - name - "+userName+" - id - "+userId);
						mFBFriendList.add(new User(userName, userId));
					}
					addFriends(mFBFriendList.size(), mFBFriendList);
				}
			}).executeAsync();
          
        // make request to the /me API
        Request request = Request.newMeRequest(
          this.getSession(),
          new Request.GraphUserCallback() {
            // callback after Graph API response with user object
            public void onCompleted(GraphUser user, Response response) {
            	System.out.println("onCompleted called!! in HumIt ");
            	
              if (user != null) {
//            	  FBConnect.dismissDialog();
            	  String[] items = new String[3];
            	  items[0] = "1";
            	  items[1] = "2";
            	  items[2] = "3";
//            	  javaCallJNI("hi");
            	  System.out.println("onCompleted called & user not null!! in HumIt ");
                TextView welcome = (TextView) findViewById(R.id.textview_user_name);
//                welcome.setText("Hello " + user.getName() + "!");
                System.out.println(" ---- username ---- "+user.getUsername());
                System.out.println(" ---- id ---- "+user.getId());
                System.out.println(" ---- link ---- "+user.getLink());
                try {
					System.out.println(" ---- gender ---- "+user.getInnerJSONObject().getString("gender").toString());
					
//					String[] userFbData = new String[3];
					String userName = user.getUsername();
					String userId = user.getId();
					String gender = user.getInnerJSONObject().getString("gender").toString();
	                
					javaCallJNI(userName, userId, gender);
	                
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                
                Map<String, Object> userMap = user.asMap();
                FBConnect.userDetails(userMap);
                TextView uId = (TextView) findViewById(R.id.textView_ID);
//                uId.setText("User ID is"+user.getId());
            
              }
            }
          }
        );
        Request.executeBatchAsync(request);
      } else {
    	  System.out.println("--------------onSessionStateChange isOpened not called!!-------------"); 
      }
	}
    
    
    @Override
    protected void onStop() {
    	super.onStop();
    	System.out.println(" ------------------- onStop --------------------- ");
    }
    
    void callFromCPP() {
        Log.i("callFromCPP", "JNI can call JAVA !");
    }
}
