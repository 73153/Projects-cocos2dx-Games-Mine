package com.humit.android;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnSeekCompleteListener;
import android.media.MediaRecorder;
import android.os.Environment;
import android.util.Log;

import com.humit.R;

public class RecorderAndPlay {
	private static MediaPlayer mediaPlayer;
	private static String file1 = null;
	private static final String AUDIO_RECORDER_FOLDER = "AudioRecorder";
	private static final String AUDIO_RECORDER_FILE_EXT_3GP = ".3gp";
	private static final String AUDIO_RECORDER_FILE_EXT_MP4 = ".mp4";
	private static MediaRecorder recorder = null;
	private static int currentFormat = 0;
	private static String defaultName;
	private static boolean isRecorded = false;
	private static int output_formats[] = { MediaRecorder.OutputFormat.MPEG_4, MediaRecorder.OutputFormat.THREE_GPP };
	private static String file_exts[] = { AUDIO_RECORDER_FILE_EXT_MP4, AUDIO_RECORDER_FILE_EXT_3GP };
	private static String oldFileName = null;

	private static String getFilename() {
		String filepath = Environment.getExternalStorageDirectory().getPath();
		File file = new File(filepath, AUDIO_RECORDER_FOLDER);
		
		if ( !file.exists()) {
			file.mkdirs();
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		defaultName = formatter.format(new Date());
		String newFileName = file.getAbsolutePath() + "/" + "AUDIO" + defaultName + file_exts[currentFormat];
		oldFileName = newFileName;
		return newFileName;
	}

	public static void startRecording() {
		System.out.println(" ----- inside startRecording in RecorderActivity -------- ");
		
		isRecorded = false;
		if(recorder == null)
			recorder = new MediaRecorder();

		recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		recorder.setOutputFormat(output_formats[currentFormat]);
		recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
		file1 = getFilename();
		recorder.setOutputFile(file1);

		recorder.setOnErrorListener(errorListener);
		recorder.setOnInfoListener(infoListener);
		
		try {
			recorder.prepare();
			recorder.start();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void stopRecording() {
		System.out.println(" ------- inside stopRecording in RecorderActivity -------- ");
		if (null != recorder) {
//			Toast.makeText(MyApplication.getAppContext(), "Recording Stopped", Toast.LENGTH_SHORT).show();
//			showToast("Recording Stopped!");
			isRecorded = true;
			recorder.stop();
//			timer.stop();
			recorder.reset();
			recorder.release();
			recorder = null;
//			timer.reset();
		} else {
			System.out.println(" --- record first --- ");
		}
	}
	
	public static void stopPlaying() {
		if (mediaPlayer != null) {
//			Toast.makeText(RecorderActivity.this, "Playing Stopped", Toast.LENGTH_SHORT).show();
//			showToast("Playing Stopped!");
			if(mediaPlayer.isPlaying())
				mediaPlayer.stop();
			mediaPlayer.reset();
			mediaPlayer.release();
			mediaPlayer = null;
		} else {
			System.out.println(" --- record first --- ");
		}
	}

	private static MediaRecorder.OnErrorListener errorListener = new MediaRecorder.OnErrorListener() {
		@Override
		public void onError(MediaRecorder mr, int what, int extra) {
			AppLog.logString("Error: " + what + ", " + extra);
		}
	};

	private static MediaRecorder.OnInfoListener infoListener = new MediaRecorder.OnInfoListener() {
		@Override
		public void onInfo(MediaRecorder mr, int what, int extra) {
			AppLog.logString("Warning: " + what + ", " + extra);
		}
	};

	public static void playSong(final int count) {
		  stopRecording();
		  System.out.println(" ----------- songPath in playSong ------------- "+file1);
		  if(file1 != null && isRecorded) {
	        try {
	        	 if(mediaPlayer != null) {
	        		 if(mediaPlayer.isPlaying()) 
	        			 mediaPlayer.stop();
	        		 mediaPlayer.reset();
	        		 mediaPlayer.release();
	        		 mediaPlayer = null;
	        	 }
        		 mediaPlayer = new MediaPlayer();
                 mediaPlayer.setDataSource(file1);
                 mediaPlayer.prepare();
              
                 mediaPlayer.start();
                 
                 mediaPlayer.setOnSeekCompleteListener(new OnSeekCompleteListener() {
					
					@Override
					public void onSeekComplete(MediaPlayer mp) {
						System.out.println(" ...onSeekComplete... ");
					}
				});
                 
                 mediaPlayer.setLooping(false);
                 
                 mediaPlayer.setOnBufferingUpdateListener(new OnBufferingUpdateListener() {
					
					@Override
					public void onBufferingUpdate(MediaPlayer mp, int percent) {
						System.out.println(" ...onBufferingUpdate... ");
					}
				});
                 
                 mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
					
					@Override
					public void onCompletion(MediaPlayer mp) {
						// TODO Auto-generated method stub
						System.out.println(" ...onCompletion... ");
//						File file = new File(oldFileName);
//						if(file != null && file.exists())
//							file.delete();
					}
				});
                 
                 mediaPlayer.setOnPreparedListener(new OnPreparedListener() {
					
					@Override
					public void onPrepared(MediaPlayer mp) {
						System.out.println(" !!!...onPrepared...!!! ");
					}
				});
                 
                 System.out.println("Playing song...");
	       
            } catch (IOException eIoException) {   
                Log.v(MyApplication.getAppContext().getString(R.string.app_name), eIoException.getMessage());   
        }
	 } else {
		 System.out.println(" ---- not completed recording ---- ");
	 }
	} 
}