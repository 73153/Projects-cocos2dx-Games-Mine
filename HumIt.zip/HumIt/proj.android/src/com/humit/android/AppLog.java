package com.humit.android;

import android.util.Log;

public class AppLog {private static final String APP_TAG = "AudioRecorder";

public static int logString(String message) {
	// TODO Auto-generated method stub
	return Log.i(APP_TAG,message);
}

}
