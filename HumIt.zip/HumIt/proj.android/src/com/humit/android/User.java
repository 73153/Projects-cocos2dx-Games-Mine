package com.humit.android;

public class User {
	
	public User(String name, String id) {
		
	}

}
