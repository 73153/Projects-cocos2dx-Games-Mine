package com.humit.android;

import java.util.List;
import java.util.Map;

import org.cocos2dx.lib.Cocos2dxActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.location.Address;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.facebook.FacebookActivity;
import com.facebook.GraphUser;
import com.facebook.Request;
import com.facebook.Request.GraphUserListCallback;
import com.facebook.Response;

public class FBConnect {
	
	private static ProgressDialog sProgressDialog = null;
	
	// check for Internet connection
	private static boolean isConnectedToNetwork() {
		ConnectivityManager connectivityManager = (ConnectivityManager)Cocos2dxActivity.getInstance().getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
		if(networkInfo != null && networkInfo.isConnected())
			return true;
		else
			return false;
	}
	
	// start a connection to FaceBook
	public static void connectToFB() {
		
		System.out.println(" ----------------- inside java connectToFB ------------------ ");
		if(isConnectedToNetwork()) {
			Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Cocos2dxActivity.getInstance().openSession();
				}
			});
			System.out.println(" ----------------- opening FB session ------------------ ");
			
		} else {
			showAlert();
		}
	}
	
	// logout of FaceBook
	public static void logoutOfFB() {
		
		System.out.println(" ----------------- inside java logoutOfFB ------------------ ");
		if(isConnectedToNetwork()) {
			Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Cocos2dxActivity.getInstance().closeSessionAndClearTokenInformation();
					System.out.println(" ----------------- closing FB session ------------------ ");
				}
			});
			
		} else {
			showAlert();
		}
	}
	
	// show an alert to user when there is no Internet connection
	private static void showAlert() {
		Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder aBuilder = new AlertDialog.Builder(Cocos2dxActivity.getInstance());
				aBuilder.setTitle("Network Error");
				aBuilder.setMessage("Check your Internet connection and try again.");
				aBuilder.show();
			}
		});
	}
	
	public static void userDetails(Map<String, Object> userMap) {
		System.out.println(" ---- user map ---- "+userMap);
		
	}
	
	// show progress dialog while a operation is going on
	public static void showDialog() {
		Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if(sProgressDialog == null)
					sProgressDialog = ProgressDialog.show(Cocos2dxActivity.getInstance(), "Loading", "");
			}
		});
	}
	
	// dismiss progress dialog when operation is completed
	public static void dismissDialog() {
		System.out.println(" ------- inside dismissDialog -------- ");
		Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				System.out.println(" ------- inside dismissDialog dismissing -------- ");
				if(sProgressDialog != null && sProgressDialog.isShowing()) {
					sProgressDialog.dismiss();
					sProgressDialog = null;
				}
			}
		});
	}
	
	// dismiss progress dialog when operation is completed
	public static void fetchFriendsList() {
		System.out.println(" ------- inside dismissDialog -------- ");
		Cocos2dxActivity.getInstance().runOnUiThread(new Runnable() {
			@Override
			public void run() {
				System.out.println(" ------- inside dismissDialog dismissing -------- ");
				Request request = Request.newMyFriendsRequest(FacebookActivity.sSession, new GraphUserListCallback() {
					@Override
					public void onCompleted(List<GraphUser> users, Response response) {
						// TODO Auto-generated method stub
						System.out.println(" ---- response ---- "+response);
						System.out.println(" ---- users ---- "+users);
						for(GraphUser graphUser : users) {
							String userName = graphUser.getName();
							String userId = graphUser.getId();
							System.out.println(" - name - "+userName+" - id - "+userId);
							
						}
					}
				});
				
				System.out.println(" ---- friends list ---- "+request.executeAsync());
			}
		});
	}
	
}
