package com.facebook;

import java.util.ArrayList;
import java.util.Collection;

import android.database.CursorIndexOutOfBoundsException;

class SimpleGraphObjectCursor<T extends GraphObject> implements GraphObjectCursor<T> {
    private int pos = -1;
    private boolean closed = false;
    private ArrayList<T> graphObjects = new ArrayList<T>();
    private boolean moreObjectsAvailable = false;
    private boolean fromCache = false;

    SimpleGraphObjectCursor() {
    }

    SimpleGraphObjectCursor(SimpleGraphObjectCursor<T> other) {
        pos = other.pos;
        closed = other.closed;
        graphObjects = new ArrayList<T>();
        graphObjects.addAll(other.graphObjects);
        fromCache = other.fromCache;

        // We do not copy observers.
    }

    public void addGraphObjects(Collection<T> graphObjects, boolean fromCache) {
        this.graphObjects.addAll(graphObjects);
        // We consider this cached if ANY results were from the cache.
        this.fromCache |= fromCache;
    }

    public boolean isFromCache() {
        return fromCache;
    }

    public void setFromCache(boolean fromCache) {
        this.fromCache = fromCache;
    }

    public boolean areMoreObjectsAvailable() {
        return moreObjectsAvailable;
    }

    public void setMoreObjectsAvailable(boolean moreObjectsAvailable) {
        this.moreObjectsAvailable = moreObjectsAvailable;
    }

    @Override
    public int getCount() {
        return graphObjects.size();
    }

    @Override
    public int getPosition() {
        return pos;
    }

    @Override
    public boolean move(int offset) {
        return moveToPosition(pos + offset);
    }

    @Override
    public boolean moveToPosition(int position) {
        final int count = getCount();
        if (position >= count) {
            pos = count;
            return false;
        }

        if (position < 0) {
            pos = -1;
            return false;
        }

        pos = position;
        return true;
    }

    @Override
    public boolean moveToFirst() {
        return moveToPosition(0);
    }

    @Override
    public boolean moveToLast() {
        return moveToPosition(getCount() - 1);
    }

    @Override
    public boolean moveToNext() {
        return moveToPosition(pos + 1);
    }

    @Override
    public boolean moveToPrevious() {
        return moveToPosition(pos - 1);
    }

    @Override
    public boolean isFirst() {
        return (pos == 0) && (getCount() != 0);
    }

    @Override
    public boolean isLast() {
        final int count = getCount();
        return (pos == (count - 1)) && (count != 0);
    }

    @Override
    public boolean isBeforeFirst() {
        return (getCount() == 0) || (pos == -1);
    }

    @Override
    public boolean isAfterLast() {
        final int count = getCount();
        return (count == 0) || (pos == count);
    }

    @Override
    public T getGraphObject() {
        if (pos < 0) {
            throw new CursorIndexOutOfBoundsException("Before first object.");
        }
        if (pos >= graphObjects.size()) {
            throw new CursorIndexOutOfBoundsException("After last object.");
        }
        return graphObjects.get(pos);
    }

    @Override
    public void close() {
        closed = true;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

}
