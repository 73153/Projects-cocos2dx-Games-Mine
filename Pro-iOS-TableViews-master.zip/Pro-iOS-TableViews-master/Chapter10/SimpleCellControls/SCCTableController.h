//
//  SCCTableController.h
//  SimpleCellControls
//
//  Created by Tim Duckett on 03/01/2012.
//  Copyright (c) 2012 Charismatic Megafauna Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCCTableController : UITableViewController

@property (nonatomic, strong) NSArray *tableData;

@end
