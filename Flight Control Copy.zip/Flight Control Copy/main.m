//
//  main.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Debug.h"

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"Flight_Control_CopyAppDelegate");
	[pool release];
	return retVal;
}
