//
//  RemindIconsArray.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RemindIconSprite;

@interface RemindIconsArray : NSObject {
	NSMutableArray *idleIcons_;
	NSMutableArray *busyIcons_;
}

+ (RemindIconsArray *) sharedIcons;
- (RemindIconSprite *) getIdleRemindIcon;
- (void) setRemindIconToIdle: (RemindIconSprite *)icon;

@end
