//
//  MenuLayer.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MenuLayer.h"
#import "LevelScene.h"
#import "Debug.h"


@implementation MenuLayer

// on "init" you need to initialize your instance
- (id) init
{
	self = [super init];
	if (self) {
		debug_NSLog(@"MenuLayer init");
		
		// 设定菜单文字
		[CCMenuItemFont setFontName:@"Helvetica"];
		[CCMenuItemFont setFontSize:30];
		CCMenuItem *start = [CCMenuItemFont itemFromString:@"Start Game"
													target:self
												  selector:@selector(startGame:)];
		CCMenuItem *scores = [CCMenuItemFont itemFromString:@"Scores"
													 target:self
												   selector:@selector(scores:)];
		CCMenu *menu = [CCMenu menuWithItems:start, scores, nil];
		[menu alignItemsVertically];
		[self addChild:menu];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	debug_NSLog(@"MenuLayer dealloc");
	[super dealloc];
}

- (void) startGame: (id)sender {
	[[CCDirector sharedDirector] replaceScene:[LevelScene node]];
}

- (void) scores: (id)sender {
	debug_NSLog(@"scores");
}

@end
