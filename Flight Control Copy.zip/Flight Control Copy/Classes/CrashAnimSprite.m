//
//  CrashAnimSprite.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CrashAnimSprite.h"
#import "Config.h"
#import "SpriteSheetSprite.h"


@implementation CrashAnimSprite

+ (CrashAnimSprite *) newCrashAnim {
	return [SpriteSheetSprite newAnimSprite:@"CrashAnim" 
							   withCapacity:WARNING_SPRITE_SHEET_CAPACITY 
								  withDelay:1.0f / MAX_FPS 
							withSpriteClass:[CrashAnimSprite class]];
}

@end
