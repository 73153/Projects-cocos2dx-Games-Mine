/*
 *  Config.h
 *  Flight Control Copy
 *
 *  Created by dualface on 10-5-29.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#define MAX_FPS 60

#define WARNING_SPRITE_SHEET_CAPACITY 11
#define CARSH_SPRITE_SHEET_CAPACITY 24
#define REMINDICON_SPRITE_SHEET_CAPACITY 14

#define MIN_NEXT_CREATE_PLANE_DELAY 3
#define MAX_NEXT_CREATE_PLANE_DELAY 7
#define MAX_NUM_PLANES 10

#define PLANE_WIDTH 32
#define PLANE_HEIGHT 32
#define PLANE_DEFAULT_SPEED 0.3f

// 飞机靠近到特定距离时显示警告信息
#define PLANE_WARNING_DISTANCE 60

// 飞机靠近到特定距离时产生碰撞
#define PLANE_CRASH_DISTANCE 30

#define REMINDICON_DISPLAY_DELAY 3
#define REMINDICON_WIDTH 11
#define REMINDICON_HEIGHT 11
