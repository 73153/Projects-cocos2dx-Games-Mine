//
//  AirPlaneLayer.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AirplanesLayer.h"
#import "PlaneSprite.h"
#import "RemindIconSprite.h"
#import "RemindIconsArray.h"
#import "Config.h"
#import "Debug.h"


@implementation AirplanesLayer

// on "init" you need to initialize your instance
-(id) init
{
	self = [super init];
	if (self) {
		debug_NSLog(@"AirplanesLayer init");
		
		// 创建数组
		allPlanes_ = [[NSMutableArray arrayWithCapacity:MAX_NUM_PLANES] retain];

		// 设定下一架飞机出现的等待时间
		nextCreatePlaneDelay_ = 0;

		// 计划更新
		[self schedule:@selector(nextFrame:)];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	debug_NSLog(@"AirplanesLayer dealloc");

	[super dealloc];
}

// 更新
- (void) nextFrame: (ccTime)dt {
	int i;
	int count = allPlanes_.count;
	PlaneSprite *plane;

	// 遍历所有飞机，更新飞机
	for (i = 0; i < count; i++) {
		plane = [allPlanes_ objectAtIndex:i];
		[plane enterFrame];
	}
	
	// 进行碰撞检测
	int j;
	for (i = 0; i < count; i++) {
		plane = [allPlanes_ objectAtIndex:i];
		for (j = i + 1; j < count; j++) {
			[plane collisionDetection:[allPlanes_ objectAtIndex:j]];
		}
	}

	if ([allPlanes_ count] >= MAX_NUM_PLANES) {
		// 如果飞机总数已经足够，则不再产生新飞机
		return;
	}

	if (nextCreatePlaneDelay_ <= 0) {
		// 创建一个新飞机
		PlaneSprite *plane = [PlaneSprite node];
		[allPlanes_ addObject:plane];
		
		// 显示一个提醒图标
		RemindIconSprite *remindIcon = [[RemindIconsArray sharedIcons] getIdleRemindIcon];
		remindIcon.position = plane.remindIconPosition;
		[remindIcon beginDisplay];

		[self addChild:plane];
		[self addChild:remindIcon];

		// 确定下一次产生新飞机的间隔时间
		int l = MAX_NEXT_CREATE_PLANE_DELAY - MIN_NEXT_CREATE_PLANE_DELAY;
		nextCreatePlaneDelay_ = MIN_NEXT_CREATE_PLANE_DELAY + random() % l;
		debug_NSLog(@"nextCreatePlaneDelay_: %0.1f seconds", nextCreatePlaneDelay_);
	} else {
		nextCreatePlaneDelay_ -= dt;
	}
}

@end
