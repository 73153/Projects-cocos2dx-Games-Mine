//
//  WarningAnimSprite.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@class PlaneSprite;

@interface WarningAnimSprite : CCSprite {
}

+ (WarningAnimSprite *) newWarningAnim;

@end
