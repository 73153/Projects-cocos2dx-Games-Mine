//
//  MenuScene.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MenuScene.h"
#import "MenuLayer.h"
#import "Debug.h"


@implementation MenuScene


// on "init" you need to initialize your instance
- (id) init
{
	self = [super init];
	if (self) {
		debug_NSLog(@"MenuScene init");

		// 设定菜单背景
		CGSize winSize = [[CCDirector sharedDirector] winSize]; 
		CCSprite *bg = [CCSprite spriteWithFile:@"MenuBackground.png"];
		bg.position = ccp(winSize.width / 2, winSize.height / 2);
		[self addChild:bg];

		// 添加菜单层
		[self addChild:[MenuLayer node]];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	debug_NSLog(@"MenuScene dealloc");
	[super dealloc];
}

@end
