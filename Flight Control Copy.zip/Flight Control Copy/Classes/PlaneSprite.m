//
//  PlaneSprite.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PlaneSprite.h"
#import "Config.h"
#import "WarningAnimSprite.h"
#import "CrashAnimSprite.h"
#import "Debug.h"


@implementation PlaneSprite

@synthesize planeId;
@synthesize isWarning;
@synthesize remindIconPosition;

static int maxPlaneId_ = 0;

// 设定新飞机进入屏幕时的初始位置、角度、速度
- (id) init {
	self = [super init];
	if (self) {
		debug_NSLog(@"PlaneSprite init");
		
		// 整个关卡运行时，飞机的ID是递增的，确保不重复
		maxPlaneId_++;
		NSString *planeId_ = [NSString stringWithFormat:@"Plane%04d", maxPlaneId_];
		self.planeId = planeId_;
		debug_NSLog(@"planeId: %@", self.planeId);

		// 添加警告动画
		warningSprite_ = [[WarningAnimSprite newWarningAnim] retain];
		[warningSprite_ setOpacity:0.0f];
		warningSprite_.visible = NO;
		[self addChild:warningSprite_];

		// 添加飞机机体图像
		CCSprite *plane = [CCSprite spriteWithFile:@"Plane.png"];
		[self addChild:plane];
		
#ifdef DEBUG
		// 添加飞机标识
		CCLabel *planeLabel = [CCLabel labelWithString:[NSString stringWithFormat:@"%d", maxPlaneId_]
											  fontName:@"Helvetica"
											  fontSize:14];
		planeLabel.color = ccc3(0xff,0,0);
		[self addChild:planeLabel];
#endif

		// 设定进入位置和速度
		[self setEnterPoint];
		speed_ = PLANE_DEFAULT_SPEED;

		// isTurnBack_ 用于跟踪飞机是否正在返回屏幕中央
		// 当飞机初始进入和从边缘弹回时，isTurnBack_ = YES
		isTurnBack_ = YES;
		// isWarning 用于指示飞机当前的状态
		self.isWarning = NO;
		// closerPlanes_ 用于跟踪与当前飞机靠近的飞机
		closerPlanes_ = [[NSMutableDictionary dictionaryWithCapacity:MAX_NUM_PLANES] retain];
	}
	return self;
}

// 设定飞机进入屏幕的初始位置
- (void) setEnterPoint {
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	
	int w = PLANE_WIDTH;
	int h = PLANE_HEIGHT;
	minX_ = w;
	maxX_ = winSize.width - w;
	minY_ = h;
	maxY_ = winSize.height - h;
	
	// 确定飞机的起始位置
	int border = random() % 4;
	float nx = 0, ny = 0;
	
	switch (border) {
		case 0: // right
			nx = winSize.width + w * 2;
			ny = (random() % (int)(maxY_ - minY_)) + minY_;
			break;
		case 1: // bottom
			nx = (random() % (int)(maxX_ - minX_)) + minX_;
			ny = -h * 2;
			break;
		case 2: // left
			nx = -w * 2;
			ny = (random() % (int)(maxY_ - minY_)) + minY_;
			break;
		case 3: // top
			nx = (random() % (int)(maxX_ - minX_)) + minX_;
			ny = winSize.height + h * 2;
	}
	self.position = ccp(nx, ny);
	
	// 确定飞行目的和方向，以及提醒图标的位置
	CGPoint pos = [self newDestinationPosition];
	self.rotation = [self newEnterRotationWithDestination:pos];
	[self setRemindIconPositionWithBorder:border andDestination:pos];
}

// 在飞机进入屏幕时，设定提醒图标出现的位置
- (void) setRemindIconPositionWithBorder: (int)border andDestination: (CGPoint)pos {
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	int w = REMINDICON_WIDTH;
	int h = REMINDICON_HEIGHT;
	CGPoint p1, p2;
	switch (border) {
		case 0: // right'
			p1 = ccp(winSize.width - w, winSize.height - h);
			p2 = ccp(winSize.width - w, h);
			break;
		case 1: // bottom
			p1 = ccp(w, h);
			p2 = ccp(winSize.width - w, h);
			break;
		case 2: // left
			p1 = ccp(w, winSize.height - h);
			p2 = ccp(w, h);
			break;
		case 3: // top
			p1 = ccp(w, winSize.height - h);
			p2 = ccp(winSize.width - w, winSize.height - h);
	}
	
	CGPoint q1 = pos;
	CGPoint q2 = self.position;
	CGPoint crossPoint;
	
	long tempLeft, tempRight;
	tempLeft = (q2.x - q1.x) * (p1.y - p2.y) - (p2.x - p1.x) * (q1.y - q2.y);
	tempRight = (p1.y - q1.y) * (p2.x - p1.x) * (q2.x - q1.x) 
				+ q1.x * (q2.y - q1.y) * (p2.x - p1.x) - p1.x * (p2.y - p1.y) * (q2.x - q1.x);
	crossPoint.x = (int)((double)tempRight / (double)tempLeft);

	tempLeft = (p1.x - p2.x) * (q2.y - q1.y) - (p2.y - p1.y) * (q1.x - q2.x);
	tempRight = p2.y * (p1.x - p2.x) * (q2.y - q1.y) 
				+ (q2.x- p2.x) * (q2.y - q1.y) * (p1.y - p2.y) 
				- q2.y * (q1.x - q2.x) * (p2.y - p1.y);
	crossPoint.y =(int)((double)tempRight / (double)tempLeft);
	
	self.remindIconPosition = crossPoint;
}

// 确定一个新的目的地
- (CGPoint) newDestinationPosition {
	CGPoint pos;
	pos.x = (random() % (int)((maxX_ - minX_) / 3)) + minX_ * 3;
	pos.y = (random() % (int)((maxY_ - minY_) / 3)) + minY_ * 3;
	return pos;
}

// 根据目的地，返回飞机的飞行方向
- (float) newEnterRotationWithDestination: (CGPoint)pos {
	float angle = atan2(-(pos.y - self.position.y), pos.x - self.position.x);
	return CC_RADIANS_TO_DEGREES(angle);
}

// 更新飞机的位置和状态
- (void) enterFrame {
	// 根据当前角度和速度计算出新的位置	
	float rot = self.rotation;
	float angle = CC_DEGREES_TO_RADIANS(rot);
	float vx = cos(angle) * speed_;
	float vy = -sin(angle) * speed_;
	float nx = self.position.x + vx;
	float ny = self.position.y + vy;
	self.position = ccp(nx, ny);

	// 判断飞机当前是否在屏幕有效区域中
	if (nx <= minX_ || nx >= maxX_ || ny <= minY_ || ny >= maxY_) {
		if (!isTurnBack_) {
			// 当飞机飞出有效区域时，设定一个新的飞行方向
			CGPoint pos = [self newDestinationPosition];
			float newRotation = [self newEnterRotationWithDestination:pos];
			[self runAction:[CCRotateTo actionWithDuration:1.2 angle:newRotation]];
			isTurnBack_ = YES;
		}
	} else if (isTurnBack_) {
		isTurnBack_ = NO;
	}
}

// 碰撞检测
- (void) collisionDetection: (PlaneSprite *)otherPlane {
	float tmp = pow(self.position.x - otherPlane.position.x, 2) 
				+ pow(self.position.y - otherPlane.position.y, 2);
	float distance = sqrt(tmp);

	if (distance > PLANE_WARNING_DISTANCE) {
		[self hideWarning:otherPlane.planeId];
		[otherPlane hideWarning:self.planeId];
	} else {
		[self displayWarning:otherPlane.planeId];
		[otherPlane displayWarning:self.planeId];
		if (distance <= PLANE_CRASH_DISTANCE) {
			// 碰撞
			
		}
	}
}

// 显示警告信息
- (void) displayWarning: (id)otherPlaneId {
	if ([closerPlanes_ objectForKey:otherPlaneId] == nil) {
		[closerPlanes_ setObject:otherPlaneId forKey:otherPlaneId];
		debug_NSLog(@"warning: %@ > < %@, %d", self.planeId, otherPlaneId, closerPlanes_.count);

		self.isWarning = YES;
		[warningSprite_ stopActionByTag:WARNING_ANIM_ACTION_FADEOUT];
		[warningSprite_ stopActionByTag:WARNING_ANIM_ACTION_HIDE];
		warningSprite_.visible = YES;
		id fadein = [CCFadeTo actionWithDuration:0.5 opacity:255];
		[fadein setTag:WARNING_ANIM_ACTION_FADEIN];
		[warningSprite_ runAction:fadein ];
	}
}

// 取消警告
- (void) hideWarning: (id)otherPlaneId {
	if ([closerPlanes_ objectForKey:otherPlaneId] != nil) {
		[closerPlanes_ removeObjectForKey:otherPlaneId];
		debug_NSLog(@"clear: %@ < > %@, %d", self.planeId, otherPlaneId, closerPlanes_.count);

		if (closerPlanes_.count == 0) {
			debug_NSLog(@"removeWarning: %@", self.planeId);
			self.isWarning = NO;
			[warningSprite_ stopActionByTag:WARNING_ANIM_ACTION_FADEIN];
			id fadeout = [CCFadeTo actionWithDuration:1.0f opacity:0];
			[fadeout setTag:WARNING_ANIM_ACTION_FADEOUT];
			id hide = [CCHide action];
			[hide setTag:WARNING_ANIM_ACTION_HIDE];
			[warningSprite_ runAction:[CCSequence actions:fadeout, nil]];
		}
	}
}

@end
