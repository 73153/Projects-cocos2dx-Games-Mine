//
//  Flight_Control_CopyAppDelegate.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Flight_Control_CopyAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
