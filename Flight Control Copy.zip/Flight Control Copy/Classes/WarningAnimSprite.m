//
//  WarningAnimSprite.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WarningAnimSprite.h"
#import "SpriteSheetSprite.h"
#import "PlaneSprite.h"
#import "Config.h"
#import "Debug.h"


@implementation WarningAnimSprite


// 创建新的警告动画
+ (WarningAnimSprite *) newWarningAnim {
	return [SpriteSheetSprite newAnimSprite:@"WarningAnim" 
							   withCapacity:WARNING_SPRITE_SHEET_CAPACITY 
								  withDelay:1.0f / MAX_FPS 
							withSpriteClass:[WarningAnimSprite class]];
}

@end
