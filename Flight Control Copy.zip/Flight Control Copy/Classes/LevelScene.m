//
//  LevelScene.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LevelScene.h"
#import "AirfieldsLayer.h"
#import "AirplanesLayer.h"
#import "Config.h"
#import "Debug.h"


@implementation LevelScene

// on "init" you need to initialize your instance
- (id) init
{
	self = [super init];
	if (self) {
		debug_NSLog(@"LevelScene init");

		// 初始化 SpriteSheet
		CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
		CCSpriteSheet *sheet;
		
		[cache addSpriteFramesWithFile:@"WarningAnim.plist"];
		sheet = [CCSpriteSheet spriteSheetWithFile:@"WarningAnim.png"
										  capacity:WARNING_SPRITE_SHEET_CAPACITY];
		[self addChild:sheet];

		[cache addSpriteFramesWithFile:@"CrashAnim.plist"];
		sheet = [CCSpriteSheet spriteSheetWithFile:@"CrashAnim.png"
										  capacity:CARSH_SPRITE_SHEET_CAPACITY];
		[self addChild:sheet];
		
		[cache addSpriteFramesWithFile:@"RemindIcon.plist"];
		sheet = [CCSpriteSheet spriteSheetWithFile:@"RemindIcon.png"
										  capacity:REMINDICON_SPRITE_SHEET_CAPACITY];

		// 添加层
		[self addChild:[AirfieldsLayer node]];
		[self addChild:[AirplanesLayer node]];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	debug_NSLog(@"LevelScene dealloc");

	[[CCSpriteFrameCache sharedSpriteFrameCache] removeUnusedSpriteFrames];
	[super dealloc];
}

@end
