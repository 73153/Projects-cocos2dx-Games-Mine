//
//  MenuLayer.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface MenuLayer : CCLayer {

}

- (void) startGame: (id)sender;
- (void) scores: (id)sender;

@end
