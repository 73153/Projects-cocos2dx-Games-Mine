//
//  SpriteSheetSprite.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface SpriteSheetSprite : CCSprite {

}

+ (NSMutableArray *) loadFrames: (NSString *)sheetName
				   withCapacity: (int)capacity;
+ (id) newAnimSprite: (NSString *)sheetName 
		withCapacity: (int)capacity 
		   withDelay: (float)delay
	 withSpriteClass: (id)spriteClass;

@end
