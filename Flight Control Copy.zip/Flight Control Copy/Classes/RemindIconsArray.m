//
//  RemindIconsArray.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RemindIconsArray.h"
#import "RemindIconSprite.h"
#import "Config.h"


@implementation RemindIconsArray

static RemindIconsArray *sharedIcons_;

+ (RemindIconsArray *) sharedIcons {
	if (!sharedIcons_) {
		sharedIcons_ = [[RemindIconsArray alloc] retain];
	}
	return sharedIcons_;
}

- (RemindIconsArray *) init {
	self = [super init];
	if (self) {
		idleIcons_ = [[NSMutableArray arrayWithCapacity:MAX_NUM_PLANES] retain];
		busyIcons_ = [[NSMutableArray arrayWithCapacity:MAX_NUM_PLANES] retain];
	}
	return self;
}

- (RemindIconSprite *) getIdleRemindIcon {
	RemindIconSprite *icon;
	if (idleIcons_.count > 0) {
		icon = [[idleIcons_ objectAtIndex:0] retain];
		[idleIcons_ removeObjectAtIndex:0];
		[busyIcons_ addObject:icon];
		[icon release];
		return icon;
	} else {
		// 创建一个新图标
		icon = [RemindIconSprite newRemindIconAnim];
		[busyIcons_ addObject:icon];
		return icon;
	}
}

- (void) setRemindIconToIdle: (RemindIconSprite *)icon {
	[busyIcons_ removeObject:icon];
	[idleIcons_ addObject:icon];
}

@end
