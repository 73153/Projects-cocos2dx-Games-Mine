//
//  SpriteSheetSprite.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SpriteSheetSprite.h"


@implementation SpriteSheetSprite

static NSMutableDictionary *allFrames_;

+ (NSMutableArray *) loadFrames: (NSString *)sheetName 
				   withCapacity: (int)capacity {
	if (!allFrames_) {
		allFrames_ = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
	}
	
	NSMutableArray *frames;
	if ((frames = [allFrames_ objectForKey:sheetName]) == nil) {
		CCSpriteFrameCache *cache = [CCSpriteFrameCache sharedSpriteFrameCache];
		NSString *frameNameFormat = [NSString stringWithFormat:@"%@%%04d.png", sheetName];
		frames = [[NSMutableArray array] autorelease];
		for (int i = 1; i <= capacity; i++) {
			NSString *frameName = [NSString stringWithFormat:frameNameFormat, i];
			CCSpriteFrame *frame = [cache spriteFrameByName:frameName];
			[frames addObject:frame];
		}
		[allFrames_ setObject:frames forKey:sheetName];
	}
	[frames retain];
	return frames;
}

+ (id) newAnimSprite: (NSString *)sheetName 
		withCapacity: (int)capacity 
		   withDelay: (float)delay
	 withSpriteClass: (id)spriteClass {
	NSString *spriteFrameName = [NSString stringWithFormat:@"%@%04d.png", sheetName, 1];
	id sprite = [[spriteClass spriteWithSpriteFrameName:spriteFrameName] retain];
	NSMutableArray *frames = [self loadFrames:sheetName withCapacity:capacity];
	CCAnimation *animation = [CCAnimation animationWithName:sheetName
													  delay:delay
													 frames:frames];
	[sprite runAction:[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:animation
																  restoreOriginalFrame:NO]]];
	return sprite;
}

@end
