//
//  RemindIconSprite.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RemindIconSprite.h"
#import "SpriteSheetSprite.h"
#import "RemindIconsArray.h"
#import "Config.h"


@implementation RemindIconSprite

+ (RemindIconSprite *) newRemindIconAnim {
	return [SpriteSheetSprite newAnimSprite:@"RemindIcon" 
							   withCapacity:REMINDICON_SPRITE_SHEET_CAPACITY 
								  withDelay:1.0f / 15
							withSpriteClass:[RemindIconSprite class]];
}

- (void) beginDisplay {
	[self schedule:@selector(endDisplay) interval:REMINDICON_DISPLAY_DELAY];
}

- (void) endDisplay {
	id fadeout = [CCFadeOut actionWithDuration:1.0f];
	id remove  = [CCCallFuncN actionWithTarget:self selector:@selector(setToIdle:)];
	[self runAction:[CCSequence actions:fadeout, remove, nil]];
}

- (void) setToIdle: (id)sender {
	[self removeFromParentAndCleanup:YES];
	[[RemindIconsArray sharedIcons] setRemindIconToIdle:self];
}

@end
