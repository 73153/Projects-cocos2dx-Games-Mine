//
//  RemindIconSprite.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface RemindIconSprite : CCSprite {

}

+ (RemindIconSprite *) newRemindIconAnim;
- (void) beginDisplay;
- (void) endDisplay;
- (void) setToIdle: (id)sender;

@end
