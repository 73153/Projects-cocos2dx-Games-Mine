//
//  AirfieldsLayer.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface AirfieldsLayer : CCLayer {

}

- (void) ccTouchesEnded: (NSSet *)touches withEvent: (UIEvent *)event;

@end
