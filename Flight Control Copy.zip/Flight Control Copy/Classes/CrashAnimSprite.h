//
//  CrashAnimSprite.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface CrashAnimSprite : CCSprite {

}

+ (CrashAnimSprite *) newCrashAnim;

@end
