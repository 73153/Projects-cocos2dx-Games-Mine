//
//  AirfieldsLayer.m
//  Flight Control Copy
//
//  Created by dualface on 10-5-28.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AirfieldsLayer.h"
#import "Debug.h"


@implementation AirfieldsLayer

// on "init" you need to initialize your instance
-(id) init
{
	self = [super init];
	if (self) {
		debug_NSLog(@"AirfieldsLayer init");

		// 设定关卡背景
		CGSize winSize = [[CCDirector sharedDirector] winSize];
		CCSprite *bg = [CCSprite spriteWithFile:@"Level1Background.png"];
		bg.position = ccp(winSize.width / 2, winSize.height / 2);		
		[self addChild:bg];

//		airfield1 = [CCSprite spriteWithFile:@"Level1Airfield1.png"];
//		airfield2 = [CCSprite spriteWithFile:@"Level1Airfield2.png"];
//		airfield2.position = ccp(155, 105);
//		airfield3 = [CCSprite spriteWithFile:@"Level1Airfield3.png"];
		isTouchEnabled = YES;
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	debug_NSLog(@"AirfieldsLayer dealloc");

	[super dealloc];
}

- (void) ccTouchesEnded: (NSSet *)touches withEvent: (UIEvent *)event {
	debug_NSLog(@"touch");
	
	// Choose one of the touches to work with
//    UITouch *touch = [touches anyObject];
//    CGPoint location = [touch locationInView:[touch view]];
//    location = [[CCDirector sharedDirector] convertToGL:location];
}

@end
