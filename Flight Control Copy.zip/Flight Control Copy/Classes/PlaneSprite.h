//
//  PlaneF22Sprite.h
//  Flight Control Copy
//
//  Created by dualface on 10-5-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@class WarningAnimSprite;

#define WARNING_ANIM_ACTION_FADEIN	0x1001
#define WARNING_ANIM_ACTION_FADEOUT	0x1002
#define WARNING_ANIM_ACTION_HIDE	0x1003

@interface PlaneSprite : CCSprite {
	NSString *planeId;
	BOOL isWarning;
	CGPoint remindIconPosition;

	float minX_;
	float minY_;
	float maxX_;
	float maxY_;
	float speed_;
	BOOL isTurnBack_;
	WarningAnimSprite *warningSprite_;
	NSMutableDictionary *closerPlanes_;
}

@property (nonatomic, retain) NSString *planeId;
@property (nonatomic) BOOL isWarning;
@property (nonatomic) CGPoint remindIconPosition;

- (id) init;
- (void) setEnterPoint;
- (void) setRemindIconPositionWithBorder: (int)border andDestination: (CGPoint)pos;
- (CGPoint) newDestinationPosition;
- (float) newEnterRotationWithDestination: (CGPoint)pos;

- (void) enterFrame;
- (void) collisionDetection: (PlaneSprite *)otherPlane;
- (void) displayWarning: (id)otherPlaneId;
- (void) hideWarning: (id)otherPlaneId;

@end
