/*
 *  Debug.h
 *  Flight Control Copy
 *
 *  Created by dualface on 10-5-30.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifdef DEBUG
#define debug_NSLog(format, ...) NSLog(format, ## __VA_ARGS__)
#else
#define debug_NSLog(format, ...)
#endif
