#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;
USING_NS_CC;

enum {
	kTagTileMap =1,	
};
CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.
    
    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                                          "CloseNormal.png",
                                                          "CloseSelected.png",
                                                          this,
                                                          menu_selector(HelloWorld::menuCloseCallback) );
    pCloseItem->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );
    
    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(pCloseItem, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    // ask director the window size
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    
    //Setup Map
    collisionMap = CCTMXTiledMap::create("TileMapTest.tmx");
    collisionMap->setAnchorPoint(CCPoint(0,0));
    // Set all layers to AntiAlias
    //    for( CCTMXLayer* child;;collisionMap->getChildren()) {
    //        child->getTexture()->setAntiAliasTexParameters();
    //       };
    // Set up all the map layers
    colLayer = collisionMap->layerNamed("Tiles");
    flowerLayer = collisionMap->layerNamed("Flowers");
    mapMoving = true;
    
    // Setup player
    ball = CCSprite::create("ball.png");
    ball->setPosition(ccp(240,50));
    ball->setAnchorPoint(ccp(0,0));
    ball->setScaleX(1);
    ball->setScaleY(1);
    ballWidth = 32;
    ballHeight = 32;
    tblX = 0;
    tblX = 0;
    
    // Setup a label for display of score
    scoreLabel = CCLabelTTF::create("Flowers 0", "Marker Felt", 20, CCSize(130, 25), kCCTextAlignmentCenter, kCCVerticalTextAlignmentCenter);
    scoreLabel->setPosition(ccp(size.width-(scoreLabel->getContentSize().width), size.height-(scoreLabel->getContentSize().height/2)));
    
    //Add everything to self
    this-> addChild(scoreLabel,10);
    this->addChild(collisionMap ,-1 ,kTagTileMap);
    this->addChild(ball);
    //this->schedule(schedule_selector(update(1/60)),1);
    this->scheduleUpdate();
    
    
    
    return true;
}
void HelloWorld::update(float adelta)
{
	// Move the TileMap
    
	CCPoint diff = ccp(-tblX*adelta, -tblY*adelta);
	CCNode * node = this->getChildByTag(kTagTileMap);
	CCPoint currentPos = node->getPosition();
	CCPoint newPos = ccpAdd(currentPos, diff);
	if (newPos.x > 0 || newPos.x < -160) {
		newPos.x = currentPos.x;
		mapMoving = false;
	} else {
		mapMoving = true;
	}
	if (newPos.y > 0 || newPos.y < -160) {
		newPos.y = currentPos.y;
		mapMoving = false;
	} else {
		mapMoving = true;
	}
	node->setPosition(newPos);
	
	// Move the Player
	if (mapMoving) {
		ball->setPosition(ccp(ball->getPositionX() + ((tblX*adelta)*0.75),ball->getPositionY()+ ((tblY*adelta)*0.75)));
	} else {
		ball->setPosition(ccp (ball->getPositionX() + ((tblX*adelta)),ball->getPositionY()+ ((tblY*adelta))));
	}
    
	// Determine the four corners of my player
	int tlXright = ball->getPositionX()+ballWidth;
	int tlXleft = ball->getPositionX();
	int tlYup = ball->getPositionY()+ballHeight;
	int tlYdown = ball->getPositionY();
	
	//Convert our Map points due to us scrolling the map
	CCPoint nodeSpace1 = collisionMap->convertToNodeSpace(ccp(tlXright,tlYdown));
	pos1X = nodeSpace1.x / collisionMap->getTileSize().width;
	pos1Y = collisionMap->getMapSize().height - (nodeSpace1.y / collisionMap->getTileSize().height);
    
	CCPoint nodeSpace2 = collisionMap->convertToNodeSpace(ccp(tlXright,tlYup));
	pos2X = nodeSpace2.x / collisionMap->getTileSize().width;
	pos2Y = collisionMap->getMapSize().height - (nodeSpace2.y / collisionMap->getTileSize().height);
	
	CCPoint nodeSpace3 = collisionMap->convertToNodeSpace(ccp(tlXleft,tlYdown));
	pos3X = nodeSpace3.x / collisionMap->getTileSize().width;
	pos3Y = collisionMap->getMapSize().height - (nodeSpace3.y / collisionMap->getTileSize().height);
	
	CCPoint nodeSpace4 = collisionMap->convertToNodeSpace(ccp(tlXleft,tlYup));
	pos4X = nodeSpace4.x / collisionMap->getTileSize().width;
	pos4Y = collisionMap->getMapSize().height - (nodeSpace4.y / collisionMap->getTileSize().height);
	
	if (pos1X <=19 && pos1Y <=15 && pos2X <= 19 && pos2Y >=0 && pos3X >=0 && pos3Y <=15 && pos4X >=0 && pos4Y >=0) {
		
		//Check if tile is blocked (collision)
		if (tblX !=0 && tblY !=0) {
			unsigned int gid1 = colLayer->tileGIDAt(ccp(pos1X,pos1Y));
			unsigned int gid2 = colLayer-> tileGIDAt(ccp(pos2X,pos2Y));
			unsigned int gid3 = colLayer-> tileGIDAt(ccp(pos3X,pos3Y));
			unsigned int gid4 = colLayer ->tileGIDAt(ccp(pos4X,pos4Y));
            
			if (gid1 == 3 || gid1 == 5 || gid2 == 3 || gid2 == 5 || gid3 == 3 || gid3 == 5 || gid4 == 3 || gid4 == 5) {
				tblX = 0;
				tblY = 0;
			}
			CCString *score;
			unsigned int gid5 = flowerLayer->tileGIDAt(ccp(pos1X,pos1Y));
			if (gid5 == 31) {
				flowerLayer ->removeTileAt(ccp(pos1X,pos1Y));
				flowerCount++;
                score= CCString::createWithFormat("Flowers: %d",flowerCount);
				scoreLabel->setString(score->getCString());
			}
			unsigned int gid6 = flowerLayer->tileGIDAt(ccp(pos2X,pos2Y));
			if (gid6 == 31) {
				flowerLayer->removeTileAt(ccp(pos2X,pos2Y));
				flowerCount++;
				score= CCString::createWithFormat("Flowers: %d",flowerCount);
				scoreLabel->setString(score->getCString());
                
			}
			unsigned int gid7 = flowerLayer->tileGIDAt(ccp(pos3X,pos3Y));
			if (gid7 == 31) {
				flowerLayer->removeTileAt(ccp(pos3X,pos3Y));
				flowerCount++;
				score= CCString::createWithFormat("Flowers: %d",flowerCount);
				scoreLabel->setString(score->getCString());
                
			}
			unsigned int gid8 = flowerLayer->tileGIDAt(ccp(pos4X,pos4Y));
			if (gid8 == 31) {
				flowerLayer->removeTileAt(ccp(pos4X,pos4Y));
				flowerCount++;
				score= CCString::createWithFormat("Flowers: %d",flowerCount);
				scoreLabel->setString(score->getCString());
			}
		}
	} else {
		tblX = 0;
		tblY = 0;
	}
}
void HelloWorld::registerWithTouchDispatcher()
{
    CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, 0, true);
}

bool HelloWorld::ccTouchBegan(CCTouch *touch ,CCEvent *event)
{
	if (touch) {
		CCPoint location = touch->getLocationInView();   
		
		location = CCDirector::sharedDirector()->convertToGL(location);
		
		//NSLog(@"Touched");
		
		if (location.x > ball->getPositionX()) {
			tblX = 32;
		}
		if (location.x < ball->getPositionX()) {
			tblX = -32;
		}
		if (location.y > ball->getPositionY()) {
			tblY = 32;
		}
		if (location.y < ball->getPositionY()) {
			tblY = -32;
		}
		return true;
	}
	return false;
}


void HelloWorld::menuCloseCallback(CCObject* pSender)
{
    CCDirector::sharedDirector()->end();
    
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
