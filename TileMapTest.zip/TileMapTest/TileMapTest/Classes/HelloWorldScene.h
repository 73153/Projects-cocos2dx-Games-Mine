#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
USING_NS_CC;

class HelloWorld : public cocos2d::CCLayer
{
public:
    // Method 'init' in cocos2d-x returns bool, instead of 'id' in cocos2d-iphone (an object pointer)
    virtual bool init();

    // there's no 'id' in cpp, so we recommend to return the class instance pointer
    static cocos2d::CCScene* scene();
    
    // a selector callback
    void menuCloseCallback(CCObject* pSender);
    
    CCTMXTiledMap *collisionMap;
	CCTMXLayer *colLayer;
	CCTMXLayer *flowerLayer;
	bool mapMoving;
	CCSprite *ball;
	int ballWidth;
	int ballHeight;
	float tblX, tblY;
	int flowerCount, c;
	int pos1X,pos1Y,pos2X,pos2Y,pos3X,pos3Y,pos4X,pos4Y;
	CCLabelTTF *scoreLabel;
    void  update(float adelta);
    bool ccTouchBegan(CCTouch *touch ,CCEvent *event);
    
    void registerWithTouchDispatcher();
    

    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(HelloWorld);
};

#endif // __HELLOWORLD_SCENE_H__
