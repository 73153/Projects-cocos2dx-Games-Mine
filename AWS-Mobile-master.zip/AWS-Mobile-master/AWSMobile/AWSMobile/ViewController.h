//
//  ViewController.h
//  AWSMobile
//
//  Created by Oleg Bogatenko on 19.12.12.
//  Copyright (c) 2012 DoZator Home. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashSegue : UIStoryboardSegue
@end

@interface ViewController : UIViewController

@property IBOutlet UIImageView *logoImageView;

@end
