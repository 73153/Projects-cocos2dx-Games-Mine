//
//  main.m
//  UITableViewTest
//
//  Created by wangbaoxiang on 13-4-23.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BMAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BMAppDelegate class]));
    }
}
