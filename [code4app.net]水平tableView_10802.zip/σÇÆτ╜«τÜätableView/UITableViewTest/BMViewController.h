//
//  BMViewController.h
//  UITableViewTest
//
//  Created by wangbaoxiang on 13-4-23.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
@interface BMViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@end
