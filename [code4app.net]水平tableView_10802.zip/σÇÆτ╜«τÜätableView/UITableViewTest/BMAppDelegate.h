//
//  BMAppDelegate.h
//  UITableViewTest
//
//  Created by wangbaoxiang on 13-4-23.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BMViewController;

@interface BMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BMViewController *viewController;

@end
