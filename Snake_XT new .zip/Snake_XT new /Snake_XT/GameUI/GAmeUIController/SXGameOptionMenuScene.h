//
//  GameOptionMenuScene.h
//  Snake-XT
//
//  Created by i-CRG dinesh on 6/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "cocos2d.h"
@interface SXGameOptionMenuScene : CCLayer
{
    CCSprite *gameOptionmodeBG;
}
+(id)scene;

@end
