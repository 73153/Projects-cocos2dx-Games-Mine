//
//  OtherAppScene.h
//  Snake-XT
//
//  Created by i-CRG dinesh on 5/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SXDataManager.h"
//#import "SXGameScene.h"
@interface SXOtherAppScene : CCLayer
{
    CCSprite *otherAppBG;
}

+(id)scene;

@end
