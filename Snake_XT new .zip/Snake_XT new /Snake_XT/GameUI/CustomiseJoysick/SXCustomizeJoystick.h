//
//  SXCustomizeJoystick.h
//  Snake_XT
//
//  Created by Pavitra on 29/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SXCustomizeJoystick : CCLayer
{
    CCSprite *joystickBase;
}

+(id)scene;

@end
