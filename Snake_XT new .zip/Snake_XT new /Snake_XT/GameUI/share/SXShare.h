//
//  SXShare.h
//  Snake_XT
//
//  Created by Pavitra on 01/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SXShare : CCLayer
{
    
}

+(id)scene;
@end
