//
//  SXCustomSprite.m
//  Snake_XT
//
//  Created by i-CRG Labs Virupaksh on 6/6/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "SXCustomSprite.h"
#import "SXMainController.h"

@implementation SXCustomSprite
@synthesize gameLayer;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here
    }
    
    return self;
}

-(void)dealloc {
    
    [super dealloc];
}


@end
