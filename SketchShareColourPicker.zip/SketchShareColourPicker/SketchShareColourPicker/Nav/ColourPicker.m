/*

SketchShareColourPicker

Copyright (c) 2012 Stewart Hamilton-Arrandale
http://www.creativewax.co.uk
@creativewax

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:
   This product includes software developed by Stewart Hamilton-Arrandale (@creativewax).
4. Neither the name of the <organization> nor the
   names of its contributors may be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY Stewart Hamilton-Arrandale (@creativewax) ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//
//  ColourPicker.m
//  SketchShareMenu
//
//  Created by stewart hamilton-arrandale on 02/12/2011.
//  Copyright (c) 2011 creative wax limited. All rights reserved.
//

#import "ColourPicker.h"
#import "Utils.h"
#import "ColourUtils.h"

@implementation ColourPicker

@synthesize saturation, brightness;

- (id)initWithTarget:(id)target withPos:(CGPoint)pos
{
	if ((self = [super init]))
	{
		// add image
		bkgd			= [Utils addSprite:@"colourPickerBkgd.png" toTarget:self withPos:pos andAnchor:ccp(0, 0)];
		overlay			= [Utils addSprite:@"colourPickerOverlay.png" toTarget:self withPos:pos andAnchor:ccp(0, 0)];
		shadow			= [Utils addSprite:@"colourPickerShadow.png" toTarget:self withPos:pos andAnchor:ccp(0, 0)];
		slider			= [Utils addSprite:@"colourPicker.png" toTarget:self withPos:pos andAnchor:ccp(.5, .5)];
        
        startPos		= pos;	// starting position of the colour picker
        boxPos			= 35;	// starting position of the virtual box area for picking a colour
        boxSize			= 150;	// the size (width and height) of the virtual box for picking a colour from
	}
	return self;
}

- (void)dealloc
{
    [self removeAllChildrenWithCleanup:YES];
    
    bkgd	= nil;
    overlay	= nil;
    shadow	= nil;
    slider	= nil;
    
	[super dealloc];
}




#pragma mark - Update Methods

- (void)updateToGlobalColour
{
    HSV hsv		= [[ColourUtils sharedInstance] hsv];
    
    // set the bkgd colour to the panel
    hsv.s		= 1;
    hsv.v		= 1;
    RGBA rgb	= [[ColourUtils sharedInstance] RGBfromHSV:hsv];
    
    [bkgd setColor:ccc3(rgb.r*255.0f, rgb.g*255.0f, rgb.b*255.0f)];
}

-(void)updateDraggerToGlobalColour
{
    HSV hsv		= [[ColourUtils sharedInstance] hsv];
    
    // set the position of the slider to the correct saturation and brightness
    CGPoint pos	= CGPointMake(
                              startPos.x + boxPos + (boxSize*(1 - hsv.s)),
                              startPos.y + boxPos + (boxSize*hsv.v));
    
    // update
    [self updateSliderPosition:pos];
}

-(void)updateSliderPosition:(CGPoint)sliderPosition
{
    // clamp the position of the icon within the circle
    
    // get the center point of the bkgd image
    float centerX		= startPos.x + bkgd.boundingBox.size.width*.5;
    float centerY		= startPos.y + bkgd.boundingBox.size.height*.5;
    
    // work out the distance difference between the location and center
    float dx			= sliderPosition.x - centerX;
    float dy			= sliderPosition.y - centerY;
    float dist			= sqrtf(dx*dx+dy*dy);
    
    // update angle by using the direction of the location
    float angle			= atan2f(dy, dx);
    
    // set the limit to the slider movement within the colour picker
    float limit			= bkgd.boundingBox.size.width*.5;
    
    // check distance doesn't exceed the bounds of the circle
    if (dist > limit)
    {
        sliderPosition.x	= centerX + limit * cosf(angle);
        sliderPosition.y	= centerY + limit * sinf(angle);
    }
    
    // set the position of the dragger
    slider.position		= sliderPosition;
    
    
    // clamp the position within the virtual box for colour selection
    if (sliderPosition.x < startPos.x + boxPos)						sliderPosition.x = startPos.x + boxPos;
    else if (sliderPosition.x > startPos.x + boxPos + boxSize - 1)	sliderPosition.x = startPos.x + boxPos + boxSize - 1;
    if (sliderPosition.y < startPos.y + boxPos)						sliderPosition.y = startPos.y + boxPos;
    else if (sliderPosition.y > startPos.y + boxPos + boxSize)		sliderPosition.y = startPos.y + boxPos + boxSize;
    
    // use the position / slider width to determin the percentage the dragger is at
    self.saturation		= 1 - ABS((startPos.x + boxPos - sliderPosition.x)/boxSize);
    self.brightness		= ABS((startPos.y + boxPos - sliderPosition.y)/boxSize);
}

-(BOOL)checkSliderPosition:(CGPoint)location
{
    // clamp the position of the icon within the circle
    
    // get the center point of the bkgd image
    float centerX		= startPos.x + bkgd.boundingBox.size.width*.5;
    float centerY		= startPos.y + bkgd.boundingBox.size.height*.5;
    
    // work out the distance difference between the location and center
    float dx			= location.x - centerX;
    float dy			= location.y - centerY;
    float dist			= sqrtf(dx*dx+dy*dy);
    
    // check that the touch location is within the bounding rectangle before sending updates
	if (dist <= bkgd.boundingBox.size.width*.5)
    {
        [self updateSliderPosition:location];
        
        // send CCControl callback
        [self sendActionsForControlEvents:CCControlEventValueChanged];
        
        return TRUE;
    }
    return FALSE;
}




#pragma mark - Touch Methods

-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location	= [touch locationInView:[touch view]];					// get the touch position
	location			= [[CCDirector sharedDirector] convertToGL:location];	// convert the position to GL space
	location			= [self convertToNodeSpace:location];					// convert to the node space of this class
	
    // check the touch position on the slider
	return [self checkSliderPosition:location];
}

-(void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location	= [touch locationInView:[touch view]];					// get the touch position
	location			= [[CCDirector sharedDirector] convertToGL:location];	// convert the position to GL space
	location			= [self convertToNodeSpace:location];					// convert to the node space of this class
	
    // check the touch position on the slider
	[self checkSliderPosition:location];
}

-(void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    
}

@end
