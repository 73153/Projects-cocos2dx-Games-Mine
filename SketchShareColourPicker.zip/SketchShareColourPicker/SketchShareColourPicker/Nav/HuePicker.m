/*

SketchShareColourPicker

Copyright (c) 2012 Stewart Hamilton-Arrandale
http://www.creativewax.co.uk
@creativewax

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:
   This product includes software developed by Stewart Hamilton-Arrandale (@creativewax).
4. Neither the name of the <organization> nor the
   names of its contributors may be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY Stewart Hamilton-Arrandale (@creativewax) ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//
//  HuePicker.m
//  SketchShareMenu
//
//  Created by stewart hamilton-arrandale on 02/12/2011.
//  Copyright (c) 2011 creative wax limited. All rights reserved.
//

#import "HuePicker.h"
#import "Utils.h"

@implementation HuePicker

@synthesize percentage;

- (id)initWithTarget:(id)target withPos:(CGPoint)pos
{
	if ((self = [super init]))
	{
		// add image
		bkgd			= [Utils addSprite:@"huePickerBkgd.png" toTarget:self withPos:pos andAnchor:ccp(0, 0)];
		slider			= [Utils addSprite:@"colourPicker.png" toTarget:self withPos:pos andAnchor:ccp(.5, .5)];
        
        slider.position	= ccp(pos.x, pos.y + bkgd.boundingBox.size.height*.5);
        
        startPos		= pos;
	}
	return self;
}

- (void)dealloc
{
    [self removeAllChildrenWithCleanup:YES];
    
    bkgd	= nil;
    slider	= nil;
    
	[super dealloc];
}




#pragma mark - Update Methods

- (void)updateToGlobalColour
{
    HSV hsv		= [[ColourUtils sharedInstance] hsv];
    
    // set the position of the slider to the correct hue
    // we need to divide it by 360 as its taken as an angle in degrees
    float huePercentage	= hsv.h/360.0f;
    
    // update
    [self updateWithPercentage:huePercentage];
}

-(void) updateWithPercentage:(CGFloat)newPercentage
{
    // clamp the position of the icon within the circle
    
    // get the center point of the bkgd image
    float centerX		= startPos.x + bkgd.boundingBox.size.width*.5;
    float centerY		= startPos.y + bkgd.boundingBox.size.height*.5;
    
    // work out the limit to the distance of the picker when moving around the hue bar
    float limit			= bkgd.boundingBox.size.width*.5 - 15;
    
    // update angle
    float angleDeg		= newPercentage * 360.0f - 180.0f;
    float angle			= CC_DEGREES_TO_RADIANS(angleDeg);
    
    // set new position of the slider
    float x				= centerX + limit * cosf(angle);
    float y				= centerY + limit * sinf(angle);
    slider.position		= ccp(x, y);
    
    // update percentage reference
    percentage			= newPercentage;
}

-(void) updateSliderPosition:(CGPoint)location
{
    // clamp the position of the icon within the circle
    
    // get the center point of the bkgd image
    float centerX		= startPos.x + bkgd.boundingBox.size.width*.5;
    float centerY		= startPos.y + bkgd.boundingBox.size.height*.5;
    
    // work out the distance difference between the location and center
    float dx			= location.x - centerX;
    float dy			= location.y - centerY;
    
    // update angle by using the direction of the location
    float angle			= atan2f(dy, dx);
    float angleDeg		= CC_RADIANS_TO_DEGREES(angle)+180;
    
    // use the position / slider width to determin the percentage the dragger is at
    self.percentage		= angleDeg/360.0f;
    
	// send CCControl callback
	[self sendActionsForControlEvents:CCControlEventValueChanged];
}

-(BOOL) checkSliderPosition:(CGPoint)location
{
    // check that the touch location is within the bounding rectangle before sending updates
	if (CGRectContainsPoint(bkgd.boundingBox, location))
    {
        [self updateSliderPosition:location];
        return TRUE;
    }
    return FALSE;
}




#pragma mark - Touch Methods

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location	= [touch locationInView:[touch view]];					// get the touch position
	location			= [[CCDirector sharedDirector] convertToGL:location];	// convert the position to GL space
	location			= [self convertToNodeSpace:location];					// convert to the node space of this class
	
    // check the touch position on the slider
	return [self checkSliderPosition:location];
}

-(void) ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location	= [touch locationInView:[touch view]];					// get the touch position
	location			= [[CCDirector sharedDirector] convertToGL:location];	// convert the position to GL space
	location			= [self convertToNodeSpace:location];					// convert to the node space of this class
	
    // check the touch position on the slider
	[self checkSliderPosition:location];
}

-(void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    
}

@end
