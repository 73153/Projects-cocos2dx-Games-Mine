/*

SketchShareColourPicker

Copyright (c) 2012 Stewart Hamilton-Arrandale
http://www.creativewax.co.uk
@creativewax

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:
   This product includes software developed by Stewart Hamilton-Arrandale (@creativewax).
4. Neither the name of the <organization> nor the
   names of its contributors may be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY Stewart Hamilton-Arrandale (@creativewax) ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//
//  HelloWorldLayer.m
//  SketchShareColourPicker
//
//  Created by stewart hamilton-arrandale on 17/01/2012.
//  Copyright Creativewax 2012. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "Utils.h"
#import "ColourUtils.h"

@interface HelloWorldLayer (Private)
-(void)createColourPicker;
@end

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *)scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id)init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init]))
    {
        CCDirector *director	= [CCDirector sharedDirector];
        CGSize size				= director.winSize;
        
        // add a temp white bkgd to see the assets easier
        bkgd					= [CCLayerColor layerWithColor:ccc4(240, 240, 240, 255) width:size.width height:size.height];
        [self addChild:bkgd];
        
        // cache the sprites
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"colourPicker.plist"];
		
        // create the sprite batch node
        spriteSheet				= [CCSpriteBatchNode batchNodeWithFile:@"colourPicker.png"];
        [self addChild:spriteSheet];
        
        // MIPMAP
        ccTexParams params		= {GL_LINEAR_MIPMAP_LINEAR,GL_LINEAR,GL_REPEAT,GL_REPEAT};
        [spriteSheet.texture setAliasTexParameters];
        [spriteSheet.texture setTexParameters:&params];
        [spriteSheet.texture generateMipmap];
        
        // create colour picker panel
        [self createColourPicker];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
-(void)dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}


-(void)createColourPicker
{
    colourPicker			= [[ColourPickerPanel alloc]initWithTarget:spriteSheet withPos:ccp(345, 225)];
    
    // setup events
    [colourPicker addTarget:self action:@selector(colourValueChanged:) forControlEvents:CCControlEventColourChanged];
    
    [self addChild:colourPicker];
}

-(void)colourValueChanged:(ColourPickerPanel*)sender
{
    RGBA rgb = [ColourUtils sharedInstance].rgb;
    [bkgd setColor:ccc3(rgb.r*255.0f, rgb.g*255.0f, rgb.b*255.0f)];
}


@end
