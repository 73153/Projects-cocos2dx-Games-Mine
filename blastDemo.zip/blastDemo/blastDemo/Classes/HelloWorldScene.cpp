#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

#define keffectSprTag 555

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = new HelloWorld();

    layer->init();
    
    // add layer as a child to scene
    scene->addChild(layer);

    layer->release();
    
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    this->setTouchEnabled(true);
    
    // ask director the window size
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    
    // create and initialize a label
    CCLabelTTF* pLabel = CCLabelTTF::create("DisappearAnime Demo", "Marker Felt", 34);
    pLabel->setPosition( ccp(size.width / 2, size.height - 20) );
    this->addChild(pLabel, 2);
    
    CCSprite *sprite = CCSprite::create("bgGameSelection.png");
    sprite->setPosition(ccp(size.width/2, size.height/2) );
    this->addChild(sprite, 1);
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("DisappearAnime.plist");
    
    CCArray *animFrames = CCArray::create();
    
    for (int i = 1; i <= 5; i++) {
        
        char name[30];
        sprintf(name, "%d.png",i);
        
        CCSpriteFrame *frame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name);
        animFrames->addObject(frame);
    }
    
    CCAnimation *animation = CCAnimation::createWithSpriteFrames(animFrames, 0.05);
    animFrames->release();
    CCAnimationCache::sharedAnimationCache()->addAnimation(animation, "DisappearAnime");
    
    return true;
}

HelloWorld::HelloWorld() {
    
    
}

HelloWorld::~HelloWorld() {
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFrameByName("DisappearAnime.plist");
}

//bool HelloWorld::ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent) {
//    
//    return true;
//}
//
//void HelloWorld::ccTouchEnded(CCTouch *pTouch, CCEvent *pEvent) {
//    
//    CCPoint touchLocation = pTouch->getLocationInView();
//    touchLocation = CCDirector::sharedDirector()->convertToGL(touchLocation);
//    
//    CCSprite *effectSpr = CCSprite::create();
//    effectSpr->setPosition(touchLocation);
//    effectSpr->setColor(ccc3(CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255));
//    effectSpr->setScale(1.0f + CCRANDOM_0_1() * 1.0f);
//    this->addChild(effectSpr,1);
//    
//    CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
//    CCAnimation *normal = animCache->animationByName("DisappearAnime");
//    normal->setDelayPerUnit(0.05f + CCRANDOM_0_1() * 0.1f);
//    
//    CCFiniteTimeAction *action = CCSequence::create(CCAnimate::create(normal), CCCallFuncN::create(this, callfuncN_selector(HelloWorld::removeSprite)), NULL);
//    
//    effectSpr->runAction(action);
//}

#pragma mark - Touches Methods
void HelloWorld::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent)
{
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
    
}

void HelloWorld::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
    
    CCSprite *effectSpr = CCSprite::create();
    effectSpr->setPosition(location);
    effectSpr->setTag(keffectSprTag);
    effectSpr->setColor(ccc3(CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255, CCRANDOM_0_1() * 255));
    effectSpr->setScale(1.0f + CCRANDOM_0_1() * 1.0f);
    this->addChild(effectSpr,1);
    
    CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
    CCAnimation *normal = animCache->animationByName("DisappearAnime");
    normal->setDelayPerUnit(0.05f + CCRANDOM_0_1() * 0.1f);
    
    CCFiniteTimeAction *action = CCSequence::create(CCAnimate::create(normal), CCCallFuncN::create(this, callfuncN_selector(HelloWorld::removeSprite)), NULL);
    
    effectSpr->runAction(action);
}

void HelloWorld::removeSprite() {
    
    this->removeChildByTag(keffectSprTag);
}

