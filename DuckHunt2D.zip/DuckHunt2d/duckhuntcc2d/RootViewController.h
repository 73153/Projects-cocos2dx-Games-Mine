//
//  RootViewController.h
//  duckhuntcc2d
//
//  Created by Matthew on 8/18/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
