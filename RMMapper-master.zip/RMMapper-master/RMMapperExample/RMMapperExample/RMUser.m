//
//  RMUser.m
//  RMMapperExample
//
//  Created by Roomorama on 28/6/13.
//  Copyright (c) 2013 Roomorama. All rights reserved.
//

#import "RMUser.h"

@implementation RMUser


- (NSArray *)rm_excludedProperties
{
    return @[@"display"];
}

@end
