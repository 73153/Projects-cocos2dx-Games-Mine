//
//  PTDataManager.m
//  Paint
//
//  Created by i-CRG Labs Krithik on 12/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PTDataManager.h"
@class EMailSending;
@class PTDogAnimation;

@implementation PTDataManager

//Synthesis
@synthesize drawLayer;

static  PTDataManager *sSharedInstance = nil;

#pragma mark - Singleton Default Methods

- (id) init
{
	self = [super init];
	if (self != nil) {
        
             
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
  }

+(PTDataManager *)sharedManager
{
    @synchronized(self) {
        if (sSharedInstance == nil) {
            [[self alloc] init];// assignment not done here
        }
    }
    return sSharedInstance;
}


+ (id)allocWithZone:(NSZone *)zone
{
    @synchronized(self) {
        if (sSharedInstance == nil) {
            sSharedInstance = [super allocWithZone:zone];
            return sSharedInstance;  // assignment and return on first allocation
        }
    }
    return nil; //on subsequent allocation attempts return nil
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain
{
    return self;
}

- (unsigned)retainCount
{
    return UINT_MAX;  //denotes an object that cannot be released
}

- (id)autorelease
{
    return self;
}

#pragma mark - PTDataManager Implementation

@end
