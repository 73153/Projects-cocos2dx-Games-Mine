//
//  BADataManager.h
//  BlastAngle
//
//  Created by i-CRG Labs Krithik on 12/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

////////
// SHARED DATA MANAGER OF PAINT
////////


#import <Foundation/Foundation.h>

@class PTDrawScene;

@interface PTDataManager : NSObject
{
    //Game Layer
    PTDrawScene *drawLayer;
}

+(PTDataManager *)sharedManager;

@property(nonatomic,assign) PTDrawScene *drawLayer;;


@end
