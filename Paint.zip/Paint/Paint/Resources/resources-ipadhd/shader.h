//
//  shader.h
//  Paint
//
//  Created by Deepthi on 13/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface shader : NSObject

@end
