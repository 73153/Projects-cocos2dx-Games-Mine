//
//  PTDogAnimation.h
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SuperAnimNodeV2.h"
#import "PTGameManager.h"



@interface PTSuperAnimationManager : PTGameManager <SuperAnimNodeListener>
{
        SuperAnimNode *animatedDog;
        
}
@property(nonatomic,assign)SuperAnimNode *animatedDog;

-(void)runDogAnimation;

@end
