//
//  DCRGameManager.h
//  DarkCityRider
//
//  Created by Krithik B on 6/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PTDrawScene;

@interface PTGameManager : NSObject
{
    PTDrawScene *drawLayer;
}

@property (nonatomic, assign)PTDrawScene *drawLayer;

@end
