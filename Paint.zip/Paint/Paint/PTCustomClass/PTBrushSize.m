//
//  PTBrushSize.m
//  Paint
//
//  Created by Deepthi on 25/04/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTBrushSize.h"

@implementation PTBrushSize

@synthesize brushSize,selectedImageSizeVal;

- (void)dealloc
{
        [super dealloc];
}

@end
