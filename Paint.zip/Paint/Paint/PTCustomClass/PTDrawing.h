//
//  PTDrawing.h
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface PTDrawing : CCSprite
{
        int drawingNO;
        NSString *drawingName;
}
@property(nonatomic,assign)int drawingNO;
@property(nonatomic,assign)NSString *drawingName;

@end
