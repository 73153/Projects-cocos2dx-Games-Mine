//
//  PTBrushSize.h
//  Paint
//
//  Created by Deepthi on 25/04/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"



@interface PTBrushSize : CCMenuItemSprite
{
        float brushSize;
        float selectedImageSizeVal;
}

@property(nonatomic,assign)float brushSize;
@property(nonatomic,assign)float selectedImageSizeVal;

@end


