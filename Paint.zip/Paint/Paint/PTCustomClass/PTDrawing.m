//
//  PTDrawing.m
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTDrawing.h"

@implementation PTDrawing
@synthesize  drawingNO,drawingName;
-(id)init
{
        if( (self=[super init]))
        {
            
        }
        return TRUE;
}

- (void)dealloc
{
        self.drawingNO = nil;
        self.drawingName=nil;
        [super dealloc];
}


@end
