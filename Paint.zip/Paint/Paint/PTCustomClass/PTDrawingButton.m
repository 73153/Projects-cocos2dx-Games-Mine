//
//  PTImage.m
//  Paint
//
//  Created by Deepthi on 09/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTDrawingButton.h"

@implementation PTDrawingButton

@synthesize imageName;

- (void)dealloc
{
        self.imageName = nil;
        [super dealloc];
}

@end
