//
//  DCRGameManager.m
//  DarkCityRider
//
//  Created by Krithik B on 6/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "PTGameManager.h"
#import "PTDataManager.h"

@implementation PTGameManager

@synthesize drawLayer;

- (id)init
{
    self = [super init];
    if (self)
    {
            self.drawLayer = [PTDataManager sharedManager].drawLayer;
    }
    return self;
}

- (void)dealloc
{
    
    [super dealloc];
}

@end
