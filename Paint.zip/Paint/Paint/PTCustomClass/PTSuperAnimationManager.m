//
//  PTDogAnimation.m
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTSuperAnimationManager.h"
#import "PTDataManager.h"
#import "PTDrawScene.h"
#import "PTGameConstant.h"
#import "PTGameManager.h"

@implementation PTSuperAnimationManager
@synthesize animatedDog;

- (id)init
{
        self = [super init];
        if (self) {
                [self initialise];
        }
        return self;
}


-(void)initialise
{
        NSString* anAnimFileFullPath = [[CCFileUtils sharedFileUtils] fullPathForFilename:@"SuperAnimation/BaccizTalkingAnimation/talking.sam"];
        NSLog(@"%@",anAnimFileFullPath);
        self.animatedDog=[SuperAnimNode create:anAnimFileFullPath id:0 listener:self];
        self.animatedDog.position=ccp(81, 87);
        [self.drawLayer addChild:self.animatedDog z:20 tag:900];
        [self.animatedDog PlaySection:@"talking" isLoop:NO];
        
        [self.animatedDog Pause];
}


-(void)runDogAnimation
{
        [self.animatedDog PlaySection:@"talking" isLoop:NO];       
}

- (void) OnAnimSectionEnd:(int)theId label:(NSString *)theLabelName
{
      //  [[CCFileUtils sharedFileUtils]removeSuffixFromFile:@"talking.sam"];
       // [animatedDog stopActionByTag:900];
        //    [self.drawLayer.uiManager.dogSpr setVisible:true];
  //    [self.drawLayer removeChild:animatedDog cleanup:true];
}
-(void)OnTimeEvent:(int)theId label:(NSString *)theLabelName eventId:(int)theEventId
{
        
}


-(void)dealloc
{
        [self.animatedDog removeFromParentAndCleanup:TRUE];
        [super dealloc];
}
@end
