//
//  PTImage.h
//  Paint
//
//  Created by Deepthi on 09/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PTDrawingButton : UIButton
{
        NSString *imageName;
}

@property(nonatomic,retain) NSString *imageName;

@end


