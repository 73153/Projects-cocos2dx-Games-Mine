//
//  PTBaccizAnimation.h
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "SuperAnimNodeV2.h"

#import "cocos2d.h"

@interface PTBaccizAnimation :public SuperAnimNodeListener
{
        
}
@end
