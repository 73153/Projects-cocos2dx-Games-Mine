/*
 
 SketchShareColourPicker
 
 Copyright (c) 2012 Stewart Hamilton-Arrandale
 http://www.creativewax.co.uk
 @creativewax
 
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 1. Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 3. All advertising materials mentioning features or use of this software
 must display the following acknowledgement:
 This product includes software developed by Stewart Hamilton-Arrandale (@creativewax).
 4. Neither the name of the <organization> nor the
 names of its contributors may be used to endorse or promote products
 derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY Stewart Hamilton-Arrandale (@creativewax) ''AS IS'' AND ANY
 EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
//  ColourPickerPanel.m
//  SketchShareMenu
//
//  Created by stewart hamilton-arrandale on 30/11/2011.
//  Copyright (c) 2011 creative wax limited. All rights reserved.
//

#import "ColourPickerPanel.h"
#import "Utils.h"

@interface ColourPickerPanel (Private)
@end

@implementation ColourPickerPanel

- (id)initWithTarget:(id)target withPos:(CGPoint)pos;
{
	if ((self = [super init]))
	{
                colourUtils		= [ColourUtils sharedInstance];
                
                // setup panels
                huePicker		= [[HuePicker alloc]initWithTarget:self withPos:ccp(pos.x-61, pos.y-65)];    //-100,-400
              //  [huePicker setScale:1];
                // setup events
                [huePicker addTarget:self action:@selector(hueSliderValueChanged:) forControlEvents:CCControlEventValueChanged];
                
                // set defaults
                [self updateToGlobalColour];
                
                [self addChild:huePicker z:10];
 	}
	return self;
}

- (void)dealloc
{
        [huePicker removeTarget:self action:@selector(hueSliderValueChanged:) forControlEvents:CCControlEventValueChanged];
        
        [bkgd removeFromParentAndCleanup:YES];
        [huePicker removeFromParentAndCleanup:YES];
        
        colourUtils		= nil;
        bkgd			= nil;
        huePicker		= nil;
        [super dealloc];
}


#pragma mark - Update Methods

- (void)updateToColour
{
        [huePicker updateToGlobalColour];
}

- (void)updateToGlobalColour
{
        [huePicker updateToGlobalColour];
}


#pragma mark - Callback Methods

- (void)hueSliderValueChanged:(HuePicker *)sender
{
        HSV hsv;
        hsv.h			= sender.percentage*360.0f;
        
        hsv.s = 1;
        hsv.v = 1;
        
        // update colour in ColourUtils
        [colourUtils updateHSV:hsv];
        
	// send CCControl callback
	[self sendActionsForControlEvents:CCControlEventColourChanged];
        [self updateToColour];
}


#pragma mark - Touch Methods

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
        return FALSE;
}

@end
