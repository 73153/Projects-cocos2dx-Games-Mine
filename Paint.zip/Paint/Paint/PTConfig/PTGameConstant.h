//
//  PTGameConstant.h
//  Paint
//
//  Created by Deepthi on 15/04/13.
//  Copyright (c) 2013 Deepthi. All rights reserved.
//

#import <Foundation/Foundation.h>

#define DrawLayer   [PTDataManager sharedManager].drawLayer

typedef enum
{
        kEraser = 120,
        kBucket = 121,
        kBrush = 122,
        kCranes=123
}PenType;

typedef enum {
        UndoMoveNone, //no move
        UndoMoveBrush,//Drawing move, program will look for a value in the lastTexture variable
        UndoMoveBucket, //Paint move, state of the lastColor will be applied onto the lastAlerteredSprite
}UndoMoveType;


//tag
//paperSlider1Contents
#define thrashButtonTag 101
#define undoButtonTag   102
#define redoButtonTag    103
#define saveButtonTag    104


//paperslider2Contents
#define sizeButtonStartingTag   0

//brushTools
#define eraserButtonTag 120
#define BucketButtonTag  121
#define brushButtonTag  122
#define cranesButtonTag 123

//colors
#define colorButtonStartingTag 200

//socialNetworks
#define faceBookButtonTag 301
#define mailButtonTag         302

