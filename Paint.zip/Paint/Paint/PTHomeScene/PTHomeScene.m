//
//  PTHomeScene.m
//  Paint
//
//  Created by Deepthi on 24/04/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTHomeScene.h"
#import "PTDrawScene.h"

@implementation PTHomeScene
+(CCScene *)scene
{
        CCScene *scene = [CCScene node];
        PTHomeScene *layer = [PTHomeScene node];
        [scene addChild:layer];
        return scene;
}

#pragma mark - constructor

-(id)init
{
        if( (self=[super init]))
        {
                [CCMenuItemFont setFontName:@"Marker Felt"];
                [CCMenuItemFont setFontSize:125];
                CCMenuItemFont *item = [CCMenuItemFont itemWithString:@"PAINT" target:self  selector:@selector(onClickPaint:)];
                [item setPosition:ccp(512, 384)];
                
                CCMenu *menu = [CCMenu menuWithItems:item, nil];
                [self addChild:menu];
                [menu setPosition:CGPointZero];
        }
        return self;
}

-(void)onClickPaint:(id)sender

{
      [ [CCDirector sharedDirector ] replaceScene:[PTDrawScene scene]];
}
-(void)dealloc
{
        [super dealloc];
}
@end
