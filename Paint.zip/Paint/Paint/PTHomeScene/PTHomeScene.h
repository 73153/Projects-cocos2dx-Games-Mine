//
//  PTHomeScene.h
//  Paint
//
//  Created by Deepthi on 24/04/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface PTHomeScene : CCLayer
{
        
}
+(CCScene *) scene;
@end
