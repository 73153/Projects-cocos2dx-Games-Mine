//
//  PenNode.m
//  SimpleDrawing
//
//  Created by stewart hamilton-arrandale on 08/07/2012.
//  Copyright (c) 2012 Creativewax. All rights reserved.
//

#import "PTPenNode.h"
#include "PTDrawScene.h"
#import "Utils.h"
#import "PTUIManager.h"
#import "PTDataManager.h"
#import "PTGameConstant.h"


@implementation PTPenNode

@synthesize drawLayer;
@synthesize brush;
@synthesize penColor,penSize;

#pragma mark - INIT

-(id) init
{
	if( (self=[super init]))
        {
                //Add Brush
                self.brush=[CCSprite spriteWithSpriteFrameName:@"splatter5.png"];
                [self.brush retain];
                
                //Initialise Default Values
                [self initialseDefaultValuesForPen];
        }
	return self;
}

-(void)initialseDefaultValuesForPen
{
        self.penSize = 1.0;
        
        penColor.a = 255;
        penColor.r = 255;
        penColor.g = 0;
        penColor.b = 0;
  
        [self.brush setScale:self.penSize];
        [self setColourForBrushWithRed:penColor.r WithGreen:penColor.g withBlue:penColor.b];
}

#pragma mark - Pen Tools
-(void)changePenToolWithType:(int)penToolType
{
        NSString *splatterName=[NSString stringWithFormat:@"splatter%d.png",penToolType];
        [self createNewPenWithImage:splatterName];
        
        penType = penToolType;
        
        [brush setScale:penSize];
        [brush setColor:ccc3(penColor.r,penColor.g,penColor.b)];
}

-(void)createNewPenWithImage:(NSString*)splatterName
{
        [brush removeFromParentAndCleanup:YES];
        [brush release];
        
        brush=[CCSprite spriteWithSpriteFrameName:splatterName];
        [brush retain];
}

-(void)eraserFunc
{
        [brush setColor:ccc3(255, 255, 255)];
}

#pragma mark - Drawing
// start the update the position of the pen and draw it into the OpenGL context
-(void)drawPenWithPosition:(CGPoint)start toThePosition:(CGPoint)end
{
        [self.drawLayer.canvas begin];
        
        float distance = ccpDistance(start, end);
        if (distance > 0)
        {
                int d = (int)distance;
                for (int i = 0; i < d; i++)
                {
                        float difx = end.x - start.x;
                        float dify = end.y - start.y;
                        float delta = (float)i / distance;
                        
                        brush.position=ccp(start.x + (difx * delta), start.y + (dify * delta));
                        [brush setRotation:rand() % 360];
                        [brush visit];
                }
        }
        [self.drawLayer.canvas end];
}

#pragma mark - Pen Properties

-(void)scaleValueForBrush:(float)scaleValue
{
        penSize = scaleValue;
        [brush setScale:penSize];
}


-(void)setColourForBrushWithRed:(double)rVal WithGreen:(double)gVal withBlue:(double)bVal;
{
        penColor.r = rVal;
        penColor.g = gVal;
        penColor.b = bVal;
             
        [brush setColor:ccc3(penColor.r,penColor.g,penColor.b)];
        [self.drawLayer.uiManager.selectedColorIndicatorSpr setColor:ccc3(penColor.r,penColor.g,penColor.b)];
}

#pragma mark - dealloc

- (void) dealloc
{
        self.drawLayer = nil;
        
        [self.brush release];
        self.brush =nil;
        
             [super dealloc];
}

@end
