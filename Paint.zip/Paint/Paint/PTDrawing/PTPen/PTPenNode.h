//
//  PenNode.h
//  SimpleDrawing
//
//  Created by stewart hamilton-arrandale on 08/07/2012.
//  Copyright (c) 2012 Creativewax. All rights reserved.
//

#import "cocos2d.h"
#import "ColourPickerPanel.h"
#import "PTGameConstant.h"

@class PTDrawScene;
@class PTUIManager;

@interface PTPenNode : CCNode
{
        PTDrawScene *drawLayer;
        
        CCSprite  *brush;
    
        //Pen Properties
        PenType penType;
        RGBA penColor;
        float penSize;
}

@property (nonatomic,assign) PTDrawScene *drawLayer;
@property(nonatomic,assign)  CCSprite  *brush;
@property(nonatomic,assign) RGBA penColor;
@property(nonatomic,assign) float penSize;


//Pen Tools
-(void)eraserFunc;
-(void)changePenToolWithType:(int)penToolType;

//Pen Properties
-(void)setColourForBrushWithRed:(double)rVal WithGreen:(double)gVal withBlue:(double)bVal;
-(void)scaleValueForBrush:(float)scaleValue;

//Drawing
-(void)drawPenWithPosition:(CGPoint)start toThePosition:(CGPoint)end;

@end
