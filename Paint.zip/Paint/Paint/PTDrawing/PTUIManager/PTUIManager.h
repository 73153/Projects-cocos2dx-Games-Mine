//
//  PTUIManager.h
//  Paint
//
//  Created by Deepthi on 06/04/13.
//  Copyright (c) 2013 Deepthi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ColourUtils.h"
#import "PTGameManager.h"
#import "PTHomeScene.h"
#import "PTBrushSize.h"
#import <MessageUI/MFMailComposeViewController.h>
#import <UIKit/UIKit.h>


@interface PTUIManager : PTGameManager
{
        NSMutableArray *colorSArray;
        NSMutableArray *sizeArray;
        NSMutableArray *imageArray;
      
        //paperSlider
        CCSprite *paperSideSpr;
        CCSprite *paperSideSprOne;
        
        //Color Picker
        CCSpriteBatchNode	*  spriteSheet;
        CCSprite *selectedColorIndicatorSpr;
      
        //pen color(pelletes)
        CCSprite *selectedColorIndicator;
        
        //Pen Size
        CCSprite *selectedSizeIndicatorSpr ;

        //drawing Tools
        CCMenuItemSprite *eraserSpr;
        CCMenuItemSprite *brushSpr;
        CCMenuItemSprite *bucketSpr;
        CCMenuItemSprite *crayonSpr;
        
        //tool tips
        CCSprite *crayonTip;
        CCSprite *magicMarkerTip;
        CCSprite *bucketTip;
        
        //scrollView
        UIScrollView *drawingListScrollView;
    
        //other tools
        CCMenuItemSprite *checkSpr ;
        CCMenuItemSprite *closeSprOne;
        CCMenuItemSprite *closeSpr;
             
        //thrash&save bg
        CCSprite *thrashBg;
        CCSprite *savSpr;
                
        //bool 
        bool canPressBackGroundButtons;
        bool isThrashImagePresent;
        bool isSaveImagePresent;
        bool isScrollPresent;
      
}

@property (nonatomic,retain)      NSMutableArray *colorSArray;
@property (nonatomic,retain)      NSMutableArray *sizeArray;
@property (nonatomic,retain)      NSMutableArray *imageArray;

@property (nonatomic,assign)      CCSprite *selectedColorIndicatorSpr;
@property (nonatomic,assign)      CCSprite *paperSideSpr;
@property (nonatomic,assign)      CCSprite *paperSideSprOne;

@property (nonatomic,assign)    bool canPressBackGroundButtons;

@property(nonatomic,assign)     CCSprite *thrashBg;
@property(nonatomic,assign)    CCSprite *savSpr;

@property(nonatomic,assign)     bool isThrashImagePresent;
@property(nonatomic,assign)    bool isSaveImagePresent;

@end

