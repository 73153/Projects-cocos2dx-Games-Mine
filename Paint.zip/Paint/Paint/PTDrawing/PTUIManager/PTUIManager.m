//
//  PTUIManager.m
//  Paint
//
//  Created by Deepthi on 06/04/13.
//  Copyright (c) 2013 Deepthi. All rights reserved.
//

#import "PTUIManager.h"
#import "ColourUtils.h"
#import "PTDataManager.h"
#import "PTDrawScene.h"
#import "PTGameConstant.h"
#import "PTHomeScene.h"
#import "PTBrushSize.h"
#import "PTDrawingButton.h"
#import "CCShaderCache.h"
#import "PTEmail.h"

//#import "AppDelegate.h"

@implementation PTUIManager

@synthesize colorSArray,sizeArray,selectedColorIndicatorSpr,paperSideSpr,paperSideSprOne,imageArray,canPressBackGroundButtons,thrashBg,savSpr,isSaveImagePresent,isThrashImagePresent;



#pragma mark - constructor
-(id)init
{
        self = [super init];
        if (self)
        {
                self.drawLayer = [PTDataManager sharedManager].drawLayer;
                
                           
                NSString *basePath = [[NSBundle mainBundle] pathForResource:@"PTColors" ofType:@"plist"];
                NSDictionary  *gameDict=[NSDictionary dictionaryWithContentsOfFile:basePath];
                self.colorSArray=[gameDict objectForKey:@"Colors"];
                self.sizeArray=[gameDict objectForKey:@"Size"];
                self.imageArray=[gameDict objectForKey:@"Images"];
                          
                canPressBackGroundButtons=true;
                
                [self  initiliseGameUI] ;
                
                [self intialiseColorPicker];
                
                isScrollPresent=false;
                
        }
        return self;
}

#pragma mark - intialiseUI
-(void)initiliseGameUI
{
        [self initialisePaperSliderOneTools];
        [self initialisePaperSliderTwoTools];
        [self initialiseDrawingTools];
        [self initialiseOtherImages];
        
}
#pragma mark - paperSliderOneTools
-(void)initialisePaperSliderOneTools
{
        paperSideSpr =[CCSprite spriteWithSpriteFrameName:@"paperside3.png"];
        paperSideSpr.position=ccp(56,550);
        [self.drawLayer addChild:paperSideSpr z:4 ];
        
        CCSprite *thrashNormalSpr =[CCSprite spriteWithSpriteFrameName:@"trash.png"];
        CCSprite *thrashSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"trash.png"];
        
        CCMenuItemSprite *thrashSpr= [CCMenuItemSprite  itemWithNormalSprite:thrashNormalSpr selectedSprite:thrashSelectedSpr target:self selector:@selector(thrashButtonAction:)];
        [thrashSpr setTag:thrashButtonTag];
        thrashSpr.position=ccp(32,244);
        
        CCSprite *undoNormalSpr =[CCSprite spriteWithSpriteFrameName:@"undo.png"];
        CCSprite *undoSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"undo.png"];
        
        CCMenuItemSprite *undoSpr = [CCMenuItemSprite  itemWithNormalSprite:undoNormalSpr selectedSprite:undoSelectedSpr target:self selector:@selector(undoRedoButtonAction:)];
        [undoSpr setTag:undoButtonTag];
        undoSpr.position=ccp(32,180);
        
        
        CCSprite *redoNormalSpr =[CCSprite spriteWithSpriteFrameName:@"redo.png"];
        CCSprite *redoSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"redo.png"];
        
        CCMenuItemSprite *redoSpr = [CCMenuItemSprite  itemWithNormalSprite:redoNormalSpr selectedSprite:redoSelectedSpr target:self selector:@selector(undoRedoButtonAction:)];
        [redoSpr setTag:redoButtonTag];
        redoSpr.position=ccp(32,116);
        
        
        CCSprite *saveNormalSpr =[CCSprite spriteWithSpriteFrameName:@"save.png"];
        CCSprite *saveSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"save.png"];
        
        CCSprite   *saveSpr = [CCMenuItemSprite  itemWithNormalSprite:saveNormalSpr selectedSprite:saveSelectedSpr target:self selector:@selector(saveButtonAction:)];
        [saveSpr setTag:saveButtonTag];
        saveSpr.position=ccp(32,52);
        
        
        CCSprite *backIcon =[CCSprite spriteWithSpriteFrameName:@"little-arrow_1.png"];
        CCMenuItem *toggleOn = [CCMenuItemSprite itemWithNormalSprite:backIcon selectedSprite:nil];
        
        CCSprite *frontIcon=[CCSprite spriteWithSpriteFrameName:@"little-arrow.png"];
        CCMenuItem *toggleOff = [CCMenuItemSprite itemWithNormalSprite:frontIcon selectedSprite:nil];
        
        CCMenuItemToggle *arrowSpr= [CCMenuItemToggle itemWithTarget:self selector:@selector(paperSliderButtonActionOne:) items:toggleOn, toggleOff, nil ];
        arrowSpr.position=ccp(80,145);
        
        CCMenu *menuItemsForPaperSlide =[ CCMenu menuWithItems:thrashSpr,arrowSpr,undoSpr,redoSpr,saveSpr,nil];
        menuItemsForPaperSlide.position=ccp(0,0);
        [paperSideSpr addChild:menuItemsForPaperSlide z:4];
}
#pragma mark - paperSliderTwoTools
-(void)initialisePaperSliderTwoTools
{
        CCSprite *backArrowNormalSpr =[CCSprite spriteWithSpriteFrameName:@"little-arrow_1.png"];
        CCMenuItem *toggleOnItem = [CCMenuItemSprite itemWithNormalSprite:backArrowNormalSpr selectedSprite:nil];
        
        CCSprite *frontArrowSelectedSpr=[CCSprite spriteWithSpriteFrameName:@"little-arrow.png"];
        CCMenuItem *toggleOffItem = [CCMenuItemSprite itemWithNormalSprite:frontArrowSelectedSpr selectedSprite:nil];
        
        CCMenuItemToggle *arrowSprOne= [CCMenuItemToggle itemWithTarget:self selector:@selector(paperSliderButtonActionTwo:) items:toggleOnItem, toggleOffItem, nil ];
        arrowSprOne.position=ccp(80,145);
        
        paperSideSprOne=[CCSprite spriteWithSpriteFrameName:@"paperside3.png"];
        paperSideSprOne.position=ccp(54,264);
        [self.drawLayer addChild:paperSideSprOne z:4 ];
        
        CCMenu *menuItems =[ CCMenu menuWithItems:arrowSprOne, nil];
        menuItems.position=ccp(0,0);
        [paperSideSprOne addChild:menuItems z:4];
        
        int xVal=30;
        int yVal=251;
        int indexVal = sizeButtonStartingTag;
        for (NSDictionary *sizeDetailsDic in self.sizeArray)
        {
                //NSDictionary *sizeDetailsDic=[self.sizeArray objectAtIndex:(i)];
                NSString *sizeName = [sizeDetailsDic objectForKey:@"imageName"];
                
                CCSprite *sizeNormalSpr =[CCSprite spriteWithSpriteFrameName:sizeName];
                CCSprite *sizeSelectedSpr =[CCSprite spriteWithSpriteFrameName:sizeName];
                
                //CCMenuItemSprite *sizeIndicationSpr= [CCMenuItemSprite  itemWithNormalSprite:sizeNormalSpr selectedSprite:sizeSelectedSpr target:self selector:@selector(setSize:)];
                PTBrushSize *sizeIndicationSpr= [PTBrushSize  itemWithNormalSprite:sizeNormalSpr selectedSprite:sizeSelectedSpr target:self selector:@selector(setSize:)];
                sizeIndicationSpr.position=ccp(xVal,yVal);
                [sizeIndicationSpr setTag:  indexVal];
                
                yVal=yVal-sizeIndicationSpr.contentSize.height-18;
                indexVal++;
                
                [menuItems addChild:sizeIndicationSpr z:5];
        }
}

#pragma mark - initialiseDrawingTools
-(void)initialiseDrawingTools
{
        
        CCSprite *colorPaperSpr=[CCSprite spriteWithSpriteFrameName:@"paper-colors.png"];
        colorPaperSpr.position=ccp(746,82);
        [self.drawLayer addChild:colorPaperSpr ];
        
        //   [colorPaperSpr setShaderProgram:shader];
        
        CCSprite *eraserNormalSpr =[CCSprite spriteWithSpriteFrameName:@"eraser.png"];
        CCSprite *eraserSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"eraser.png"];
        
        eraserSpr = [CCMenuItemSprite  itemWithNormalSprite:eraserNormalSpr selectedSprite:eraserSelectedSpr target:self selector:@selector(drawingToolsButtonAction:)];
        [eraserSpr setTag:eraserButtonTag];
        eraserSpr.position=ccp(425,55);
        
        
        CCSprite *brushNormalSpr =[CCSprite spriteWithSpriteFrameName:@"magic_marker-2.png"];
        CCSprite *brushSelectedSpr=[CCSprite spriteWithSpriteFrameName:@"magic_marker-2.png"];
        
        brushSpr = [CCMenuItemSprite  itemWithNormalSprite:brushNormalSpr selectedSprite:brushSelectedSpr target:self selector:@selector(drawingToolsButtonAction:)];
        [brushSpr setTag:brushButtonTag];
        brushSpr.position=ccp(178,90);
        
        magicMarkerTip = [CCSprite spriteWithSpriteFrameName:@"magic_marker_tip-1.png"];
        [brushSpr addChild:magicMarkerTip];
        magicMarkerTip.position=ccp([brushSpr position].x-26,[brushSpr position].y+38);
        magicMarkerTip.position=[brushSpr convertToNodeSpace:[magicMarkerTip position]];
        
        CCSprite *bucketNormalSpr =[CCSprite spriteWithSpriteFrameName:@"paint_bucket.png"];
        CCSprite *bucketSelectedSpr=[CCSprite spriteWithSpriteFrameName:@"paint_bucket.png"];
        
        bucketSpr = [CCMenuItemSprite  itemWithNormalSprite:bucketNormalSpr selectedSprite:bucketSelectedSpr target:self selector:@selector(drawingToolsButtonAction:)];
        [bucketSpr setTag:BucketButtonTag];
        bucketSpr.position=ccp(344,61);
        
        bucketTip = [CCSprite spriteWithSpriteFrameName:@"paint_bucket_tip.png"];
        [bucketSpr addChild:bucketTip];
        bucketTip.position=ccp([bucketSpr position].x,[bucketSpr position].y+3);
        bucketTip.position=[bucketSpr convertToNodeSpace:[bucketTip position]];
        
        CCSprite *crayonNormalSpr =[CCSprite spriteWithSpriteFrameName:@"crayon_body-1.png"];
        CCSprite *crayonSelectedSpr=[CCSprite spriteWithSpriteFrameName:@"crayon_body-1.png"];
        
        crayonSpr = [CCMenuItemSprite  itemWithNormalSprite:crayonNormalSpr selectedSprite:crayonSelectedSpr target:self selector:@selector(drawingToolsButtonAction:)];
        [crayonSpr setTag:cranesButtonTag];
        crayonSpr.position=ccp(259,53);
        
        crayonTip = [CCSprite spriteWithSpriteFrameName:@"crayon_tip.png"];
        [crayonSpr addChild:crayonTip];
        crayonTip.position=ccp(236,95);
        crayonTip.position=[crayonSpr convertToNodeSpace:[crayonTip position]];
        
        [crayonTip setColor:ccc3(255, 0, 0)];
        [bucketTip setColor:ccc3(255,0,0)];
        [magicMarkerTip setColor:ccc3(255,0,0)];
        
        selectedSizeIndicatorSpr =[CCSprite spriteWithSpriteFrameName:@"color-selected.png"];
        [paperSideSprOne addChild:selectedSizeIndicatorSpr z:6];
        selectedSizeIndicatorSpr.position=CGPointMake(-30,-20);
        
        selectedColorIndicator =[CCSprite spriteWithSpriteFrameName:@"color selected.png"];
        [self.drawLayer addChild:selectedColorIndicator z:6];
        selectedColorIndicator.position=CGPointMake(-30,-20);
        [selectedColorIndicator setScale:1.1];
        
        CCMenu *menu =[CCMenu menuWithItems:eraserSpr,brushSpr,bucketSpr,crayonSpr,nil];
        menu.position=ccp(0,0);
        [self.drawLayer addChild:menu  z:5];
        
        int  posX=500;
        int  posY=86;
        
        int index = colorButtonStartingTag;
        for (NSDictionary *aColorDetailsDic in self.colorSArray) {
                NSString *colorName = [aColorDetailsDic objectForKey:@"colorName"];
                
                CCSprite *colorNormalSpr =[CCSprite spriteWithSpriteFrameName:colorName];
                CCSprite *colorSelectedSpr =[CCSprite spriteWithSpriteFrameName:colorName];
                
                CCMenuItemSprite *paintBtnItem= [CCMenuItemSprite  itemWithNormalSprite:colorNormalSpr selectedSprite:colorSelectedSpr target:self selector:@selector(setPaintColor:)];
                [paintBtnItem setTag:index];
                paintBtnItem.position=ccp(posX,posY);
                
                posX=posX+60;
                
                if(index==206)
                {
                        posY=posY-57;
                        posX=500;
                }
                
                [menu addChild:paintBtnItem z:4];
                index++;
        }
}

#pragma mark - initialiseOtherImages
-(void)initialiseOtherImages
{
        CCSprite *facebookNormalSpr =[CCSprite spriteWithSpriteFrameName:@"facebook.png"];
        CCSprite *facebookSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"facebook.png"];
        //
        CCMenuItemSprite *facebookSpr = [CCMenuItemSprite  itemWithNormalSprite:facebookNormalSpr selectedSprite:facebookSelectedSpr target:self selector:@selector(faceBookButtonAction:)];
        [facebookSpr setTag:faceBookButtonTag];
        facebookSpr.position=ccp(917,730);
        
        CCSprite *drawNormalSpr =[CCSprite spriteWithSpriteFrameName:@"drawings to color icon.png"];
        CCSprite *drawSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"drawings to color icon.png"];
        //
        CCSprite *drawSpr = [CCMenuItemSprite  itemWithNormalSprite:drawNormalSpr selectedSprite:drawSelectedSpr target:self selector:@selector(addDrawingScrollView:)];
        //   [facebookSpr setTag:faceBookButtonTag];
        drawSpr.position=ccp(150,731);
        
        
        CCSprite *mailNormalSpr =[CCSprite spriteWithSpriteFrameName:@"mail.png"];
        CCSprite *mailSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"mail.png"];
        
        CCMenuItemSprite *mailSpr = [CCMenuItemSprite  itemWithNormalSprite:mailNormalSpr selectedSprite:mailSelectedSpr target:self selector:@selector(mailButtonAction:)];
        [mailSpr setTag:mailButtonTag];
        mailSpr.position=ccp(985,730);
        
        CCSprite *closeNormalSpr =[CCSprite spriteWithSpriteFrameName:@"X.png"];
        CCSprite *closeSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"X.png"];
        
        closeSpr = [CCMenuItemSprite  itemWithNormalSprite:closeNormalSpr selectedSprite:closeSelectedSpr target:self selector:@selector(closeScrollAction:)];
        [mailSpr setTag:mailButtonTag];
        closeSpr.position=ccp(850,730);
        [closeSpr setVisible:false];
        
        CCSprite *colorPaperSpr=[CCSprite spriteWithSpriteFrameName:@"paper-colors.png"];
        colorPaperSpr.position=ccp(746,82);
        [self.drawLayer addChild:colorPaperSpr ];
        
        CCSprite *gamerNormalSpr =[CCSprite spriteWithSpriteFrameName:@"gamer.png"];
        CCSprite *gamerSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"gamer.png"];
        
        CCMenuItemSprite *gamerSpr = [CCMenuItemSprite  itemWithNormalSprite:gamerNormalSpr selectedSprite:gamerSelectedSpr target:self selector:@selector(gamerButtonAction:)];
        // [gamerSpr setTag:redoButtonTag];
        gamerSpr.position=ccp(49,731);
        
        CCMenu *menu =[CCMenu menuWithItems:facebookSpr,mailSpr,gamerSpr,drawSpr,closeSpr,nil];
        menu.position=ccp(0,0);
        [self.drawLayer addChild:menu  z:5];
        
        
}
#pragma mark - setPaintColor
-(void)setPaintColor:(id)sender
{
        [selectedColorIndicator setVisible:true];
        CCMenuItemSprite *spr =(CCMenuItemSprite*)sender;
        selectedColorIndicator.position=[self.drawLayer convertToNodeSpace:spr.position];//
        selectedColorIndicator.position=ccp(selectedColorIndicator.position.x-2,selectedColorIndicator.position.y);
        
        int colorIndex = [sender tag]-200;
        
        NSDictionary *colorDetailsDic = [self.colorSArray objectAtIndex:(colorIndex)];
        NSString *rgbVal = [colorDetailsDic objectForKey:@"rgbVal"];
        
        NSArray *rgbColorArray=[[NSArray alloc]initWithArray:[rgbVal componentsSeparatedByString:@","]];
        
        RGBA color;
        color.r=[[rgbColorArray objectAtIndex:0]doubleValue];
        color.g=[[rgbColorArray objectAtIndex:1] doubleValue];
        color.b=[[rgbColorArray objectAtIndex:2] doubleValue];
        
        [drawLayer.pen setColourForBrushWithRed:color.r WithGreen:color.g withBlue:color.b];
        [self setSelectedColorForTools];
}

#pragma mark - setColorForTools
-(void)setSelectedColorForTools
{
        [crayonTip setColor:ccc3(drawLayer.pen.penColor.r, drawLayer.pen.penColor.g, drawLayer.pen.penColor.b)];
        [bucketTip setColor:ccc3(drawLayer.pen.penColor.r, drawLayer.pen.penColor.g, drawLayer.pen.penColor.b)];
        [magicMarkerTip setColor:ccc3(drawLayer.pen.penColor.r, drawLayer.pen.penColor.g, drawLayer.pen.penColor.b)];
        
}

#pragma mark - sliderMoveAction
-(void)paperSliderButtonActionOne:(id)sender
{
        CCMenuItemToggle *item=(CCMenuItemToggle*)sender;
        if([paperSideSpr numberOfRunningActions]==0)
        {
                if([item selectedIndex]==1 )
                {
                        CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(-20, 550)];
                        [paperSideSpr runAction:move];
                }
                
                else
                {
                        CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(56, 550)];
                        [paperSideSpr runAction:move];
                        
                }
        }
        else
        {
                [item setSelectedIndex:![item selectedIndex]];
        }
}

-(void)paperSliderButtonActionTwo:(id)sender
{
        CCMenuItemToggle *item=(CCMenuItemToggle*)sender;
        if([paperSideSprOne numberOfRunningActions]==0)
        {
                if([item selectedIndex]==1)
                {
                        CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(-20, 264)];
                        [paperSideSprOne runAction:move];
                }
                else
                {
                        CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(54, 264)];
                        [paperSideSprOne runAction:move];
                }
                
        }
        else
        {
                [item setSelectedIndex:![item selectedIndex]];
        }
        
}

#pragma mark - setSize
-(void)setSize:(id)sender
{
        if(canPressBackGroundButtons)
        {
                PTBrushSize *item =(PTBrushSize*)sender;
                selectedSizeIndicatorSpr.position=[self.drawLayer convertToNodeSpace:item.position];//
                
                selectedSizeIndicatorSpr.position=ccp(selectedSizeIndicatorSpr.position.x,selectedSizeIndicatorSpr.position.y-1);
                
                int i = [sender tag];
                
                NSDictionary *sizeDetailsDic=[self.sizeArray objectAtIndex:(i)];
                item. brushSize = [[sizeDetailsDic valueForKey:@"scaleVal"]floatValue];
                item.selectedImageSizeVal=[[sizeDetailsDic valueForKey:@"scaleValForSizeIndicator"]floatValue];
                [ drawLayer.pen scaleValueForBrush:item.brushSize ];
                [selectedSizeIndicatorSpr setScale:item.selectedImageSizeVal];
        }
}

#pragma mark - ThrashButtonACtion
-(void)thrashButtonAction:(id)sender
{
        if(canPressBackGroundButtons)
        {
                [self.drawLayer.superAnimationManager runDogAnimation];
            
                isThrashImagePresent=true;
                canPressBackGroundButtons=false;
          
                thrashBg = [CCSprite spriteWithSpriteFrameName:@"thrashBG.png"];
                [self.drawLayer addChild:thrashBg z:11 tag:500];
                thrashBg.position=ccp(500,100);
                
                CCMoveTo *moveTO =[CCMoveTo actionWithDuration:1 position:ccp(500, 450)];
                id easeBackOut= [CCEaseElasticOut actionWithAction:[[moveTO copy] autorelease] ];
                [thrashBg runAction:easeBackOut];
                
                CCSprite *checkNormalSpr =[CCSprite spriteWithSpriteFrameName:@"check.png"];
                CCSprite *checkSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"check.png"];
                
                checkSpr = [CCMenuItemSprite  itemWithNormalSprite:checkNormalSpr selectedSprite:checkSelectedSpr target:self selector:@selector(onClickOfCorrect:)];
                checkSpr.position=ccp(100, 50);
                
                
                CCSprite *closeNormalSpr =[CCSprite spriteWithSpriteFrameName:@"X.png"];
                CCSprite *closeSelectedSpr =[CCSprite spriteWithSpriteFrameName:@"X.png"];
                
                closeSprOne = [CCMenuItemSprite  itemWithNormalSprite:closeNormalSpr selectedSprite:closeSelectedSpr target:self selector:@selector(onClickWrong:)];
                closeSprOne.position=ccp(250, 50);
                
                CCMenu *menu = [CCMenu menuWithItems:checkSpr,closeSprOne, nil];
                [thrashBg addChild:menu];
                menu.position=ccp(0,0);
                
        }
        
}

-(void)onClickOfCorrect:(id)sender
{
        CCMoveTo *moveTO =[CCMoveTo actionWithDuration:1 position:ccp(500, 100)];
        id easeBackOut= [CCEaseElasticOut actionWithAction:[[moveTO copy] autorelease] ];
        CCFadeOut *fadeOutAction = [CCFadeOut actionWithDuration:1];
        
        CCFadeOut *fadeOutActionONE = [CCFadeOut actionWithDuration:1];
        [checkSpr runAction:fadeOutActionONE];
        
        CCFadeOut *fadeOutActiontWO= [CCFadeOut actionWithDuration:1];
        [closeSprOne runAction:fadeOutActiontWO];
        
        CCFiniteTimeAction *sp =[CCSpawn actions:fadeOutAction,easeBackOut, nil];
        CCFiniteTimeAction *sp1 =[CCSequence actions:sp,[CCCallFunc actionWithTarget:self selector:@selector(removeThrahBG)],nil];
        [thrashBg runAction:sp1];
        [self callClearFunc];
        
        if(self.drawLayer.isImagePresentAfterScroll)
        {
                [self.drawLayer removeChild:(CCNode*)self.drawLayer.currentSprite];
                self.drawLayer.isImagePresentAfterScroll=FALSE;
        }
        
        [self.drawLayer  addIntialCanvastoTheUndoArray];
        
}
-(void)onClickWrong:(id)sender
{
        CCMoveTo *moveTO =[CCMoveTo actionWithDuration:1 position:ccp(500, 250)];
        id easeBackOut= [CCEaseElasticOut actionWithAction:[[moveTO copy] autorelease] ];
        CCFadeOut *fadeOutAction = [CCFadeOut actionWithDuration:1];
        
        CCFadeOut *fadeOutActionONE = [CCFadeOut actionWithDuration:1];
        [closeSprOne runAction:fadeOutActionONE];
        
        CCFadeOut *fadeOutActiontWO= [CCFadeOut actionWithDuration:1];
        [checkSpr runAction:fadeOutActiontWO];
        
        CCFiniteTimeAction *sp =[CCSpawn actions:fadeOutAction,easeBackOut, nil];
        CCFiniteTimeAction *sp1 =[CCSequence actions:sp,[CCCallFunc actionWithTarget:self selector:@selector(removeThrahBG)],nil];
        [thrashBg runAction:sp1];
        
}

-(void)removeThrahBG
{
        CCSprite *spr = (CCSprite*)[self.drawLayer getChildByTag:500];
        [self.drawLayer removeChild:spr];
        canPressBackGroundButtons=true;
        isThrashImagePresent=false;
        
}

#pragma mark - Undo/Redo
-(void)undoRedoButtonAction:(id)sender
{
        if(canPressBackGroundButtons)
        {
                [self.drawLayer.superAnimationManager runDogAnimation];
                if([sender tag]==undoButtonTag)
                {
                        [self.drawLayer undoFunc];
                        
                }
                else
                        [self.drawLayer redoFunc];
        }
        
}

#pragma mark - gamerButtonAction
-(void)gamerButtonAction:(id)sender
{
        if(isScrollPresent )
        {
                [drawingListScrollView removeFromSuperview ];
        }

        [[CCDirector sharedDirector]replaceScene:[PTHomeScene scene]];
}

#pragma mark - saveButtonAction
-(void)saveButtonAction:(id)sender
{
        if( canPressBackGroundButtons)
        {
                [self.drawLayer.superAnimationManager runDogAnimation];
                isSaveImagePresent=true;
                canPressBackGroundButtons=false;
                savSpr = [CCSprite spriteWithFile:@"popUpSave.png"];
                [self.drawLayer addChild:savSpr z:15];
                savSpr.position=ccp(500, 440);
                
                CCScaleTo *scaleTo =[CCScaleTo actionWithDuration:.8 scale:1.5];
                id easeBackOut= [CCEaseElasticOut actionWithAction:[[scaleTo copy] autorelease] ];
                           
                CCFadeOut *fadeOutAction = [CCFadeOut actionWithDuration:1];
                CCFiniteTimeAction *seq =[CCSequence actions:easeBackOut,[CCDelayTime actionWithDuration:0.3], fadeOutAction,[CCCallFunc actionWithTarget:self selector:@selector(callFuncAfterDelay)],NULL];
                [savSpr runAction:seq];
                
                [self.drawLayer addDrawingTocanvas];
                UIImage *image = [drawLayer.canvas getUIImage];
                UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
        }
}

-(void)callFuncAfterDelay
{
        [self.drawLayer addDrawingBackToDrawScene];
        canPressBackGroundButtons=true;
        isSaveImagePresent=false;
 }

#pragma mark - Drawings
-(void)addDrawingScrollView:(id)sender
{
        if(canPressBackGroundButtons)
        {
                canPressBackGroundButtons=false;
              
                drawingListScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(100, 80, 897, 550)];
                
                [drawingListScrollView setBackgroundColor:[UIColor whiteColor]];
                [[CCDirector sharedDirector].view addSubview:drawingListScrollView];
                [drawingListScrollView release];
                [drawingListScrollView setScrollEnabled:YES];
                drawingListScrollView.showsVerticalScrollIndicator=YES;
                
                isScrollPresent=true;
                [closeSpr setVisible:true];
                
               //Custom type button
                float xPos=100;
                float yPos=80;
        
                for (NSDictionary *imageDetailsDic in self.imageArray)
                {
                        NSString *imgName = [imageDetailsDic objectForKey:@"imageName"];
                        
                        PTDrawingButton *button= [PTDrawingButton buttonWithType:UIButtonTypeCustom];
                        button.imageName = imgName;
                        
                        UIImage *image= [UIImage imageNamed:imgName];
                        
                        button.frame = CGRectMake(xPos, yPos, [image size].width-200, [image size].height-200);
                        xPos= xPos+[image size].width;
                        [button setBackgroundImage:image forState:UIControlStateNormal];
                        [button addTarget:self action:@selector(aDrawingImageSelected:) forControlEvents:UIControlEventTouchUpInside];
                        [drawingListScrollView addSubview:button];
                        
                }
                [drawingListScrollView setContentSize:CGSizeMake(xPos, 500)];
        }
}

-(void)aDrawingImageSelected:(id)sender
{
        PTDrawingButton *button = (PTDrawingButton*)sender;
        
        //remove scrollView
        [drawingListScrollView removeFromSuperview ];
        isScrollPresent=FALSE;
        
        [closeSpr setVisible:false];
        
        [self callClearFunc];
        [self.drawLayer addDrawingWithName:button.imageName];
}
-(void)closeScrollAction:(id)sender
{
        
        if(isScrollPresent)
        {
                [closeSpr setVisible:false];
                [drawingListScrollView removeFromSuperview];
                canPressBackGroundButtons=true;
        }
}



#pragma mark - ClearFunc
-(void)callClearFunc
{
        [self.drawLayer.canvas clear:1 g:1 b:1 a:1];
        [self.drawLayer.undoArray removeAllObjects];
        [self.drawLayer.redoArray removeAllObjects];
}

#pragma mark - Share
-(void)faceBookButtonAction:(id)sender
{
        
        //        UIImage *originalImage = [drawLayer.canvas getUIImage]; // this image we get from UIImagePickerController
        //
        //        CGColorSpaceRef colorSapce = CGColorSpaceCreateDeviceGray();
        //        CGContextRef context = CGBitmapContextCreate(nil, originalImage.size.width, originalImage.size.height, 8, originalImage.size.width, colorSapce, kCGImageAlphaNone);
        //        CGContextSetInterpolationQuality(context, kCGInterpolationHigh);
        //        CGContextSetShouldAntialias(context, NO);
        //        CGContextDrawImage(context, CGRectMake(0, 0, originalImage.size.width, originalImage.size.height), [originalImage CGImage]);
        //
        //        CGImageRef bwImage = CGBitmapContextCreateImage(context);
        //        CGContextRelease(context);
        //        CGColorSpaceRelease(colorSapce);
        //
        //        UIImage *resultImage = [UIImage imageWithCGImage:bwImage]; // This is result B/W image.
        //        CGImageRelease(bwImage);
        //        UIButton *button= [UIButton buttonWithType:UIButtonTypeCustom];
        //        button.frame = CGRectMake(100, 100, 100,100);
        //        [button setBackgroundImage:resultImage forState:UIControlStateNormal];
        //        [button addTarget:self action:@selector(onClickOfUIButton:) forControlEvents:UIControlEventTouchUpInside];
        
        //Set image of button
        
        /*
         UIImageView    *textImageview=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"thrashBG.png"]] ;
         
         [textImageview setFrame:CGRectMake(10, 8, 390,924)];
         
         textImageview.autoresizesSubviews = YES;
         
         [stickerListScrollView  addSubview:textImageview];
         
         [textImageview release];
         */
        
        
        /*
         AppController *appDelegate = [[UIApplication sharedApplication]delegate];
         
         NSLog(@"appDelegate.session.state is %d",appDelegate.session.state);
         if (appDelegate.session.state != FBSessionStateCreated)
         {
         // Create a new, logged out session.
         appDelegate.session = [[FBSession alloc] init];
         
         
         }
         
         //        NSLog(@"appDelegate.session is %@",appDelegate.session.accessTokenData.accessToken);
         //        // if the session isn't open, let's open it now and present the login UX to the user
         //        [appDelegate.session openWithCompletionHandler:^(FBSession *session,
         //                                                         FBSessionState status,
         //                                                         NSError *error) {
         //
         //
         //
         //                UIImage *image = [drawLayer.canvas getUIImage];
         //
         //                FBRequestConnection *requestConnection = [[FBRequestConnection alloc] init];
         //                FBRequest *stagingRequest = [FBRequest requestForUploadStagingResourceWithImage:image];
         //                [requestConnection addRequest:stagingRequest
         //                            completionHandler:^(FBRequestConnection *connection, id result, NSError *error)
         //                 {
         //                         NSLog(@"Done %d",error.fberrorCategory);
         //                 }
         //                               batchEntryName:@"stagedphoto"];
         //
         //                [requestConnection start];
         
         //     }];
         
         */
        
}

-(void)mailButtonAction:(id)sender
{
        [self.drawLayer addDrawingTocanvas];
        
        PTEmail *mail = [[PTEmail alloc]init];
        [self.drawLayer addChild:mail z:10];
         [mail release];
        [mail emailCallback];
        
}


#pragma mark - drawingToolsActions
-(void)drawingToolsButtonAction:(id)sender
{
        CCMenuItemSprite *item=(CCMenuItemSprite*)sender;
        if([item numberOfRunningActions]==0)
        {
                
                CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(item.position.x,90)];
                id move_ease_bio = [CCEaseBackInOut actionWithAction:[[move copy] autorelease] ];
                
                [item runAction:move_ease_bio];
                
                if([sender tag]==kBucket)
                {
                        
                        [self.drawLayer.pen changePenToolWithType:5];
                        
                }
                else if([sender tag]==kBrush)
                {
                        [self.drawLayer.pen changePenToolWithType:5];
                }
                else if([sender tag]==kCranes)
                {
                        
                        [self.drawLayer.pen changePenToolWithType:3];
                }
                else
                {
                        [self.drawLayer.pen eraserFunc];
                }
                [self moveToolsToPreviousPosition:[sender tag]];
                
        }
}

#pragma mark - moveToolToOriginalPosition
-(void)moveToolsToPreviousPosition:(int)tag
{
        if(tag != [brushSpr tag])
        {
                CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(brushSpr.position.x,52)];
                id move_ease_bio = [CCEaseBackInOut actionWithAction:[[move copy] autorelease] ];
                [brushSpr runAction:move_ease_bio];
                // [brushSpr runAction:move];
        }
        if(tag!=[crayonSpr tag])
        {
                CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(crayonSpr.position.x,53)];
                id move_ease_bio = [CCEaseBackInOut actionWithAction:[[move copy] autorelease] ];
                [crayonSpr runAction:move_ease_bio];
                // [crayonSpr runAction:move];
        }
        if(tag!=[bucketSpr tag])
        {
                CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(bucketSpr.position.x,61)];
                id move_ease_bio = [CCEaseBackInOut actionWithAction:[[move copy] autorelease] ];
                [bucketSpr runAction:move_ease_bio];
                //  [bucketSpr runAction:move];
        }
        if(tag!=[eraserSpr tag])
        {
                CCMoveTo *move =[CCMoveTo actionWithDuration:0.7 position:ccp(eraserSpr.position.x,55)];
                id move_ease_bio = [CCEaseBackInOut actionWithAction:[[move copy] autorelease] ];
                [eraserSpr runAction:move_ease_bio];
                // [eraserSpr runAction:move];
        }
}
#pragma mark - Color Picker
-(void)intialiseColorPicker
{
        // create the sprite batch node
        spriteSheet	= [CCSpriteBatchNode batchNodeWithFile:@"colourPicker.png"];
        [self.drawLayer addChild:spriteSheet ];
        
        CCSprite  *bgSprOne =[CCSprite spriteWithSpriteFrameName:@"color-selection-3.png"];  //color-selection.png
        bgSprOne.position=ccp(948,65);
        [self.drawLayer addChild:bgSprOne z:13 ];
        
        
        selectedColorIndicatorSpr =[CCSprite spriteWithSpriteFrameName:@"color-selection_bg.png"];  //color-selection.png
        selectedColorIndicatorSpr.position=ccp(948,65);
        [self.drawLayer addChild:selectedColorIndicatorSpr z:11 ];
        [selectedColorIndicatorSpr setColor:ccc3(255, 0, 0)];
        // [selectedColorIndicatorSpr setScale:0.8]; //1.0
        //color-selection.png
        
        // MIPMAP
        ccTexParams params		= {GL_LINEAR_MIPMAP_LINEAR,GL_LINEAR,GL_REPEAT,GL_REPEAT};
        [spriteSheet.texture setAliasTexParameters];
        [spriteSheet.texture setTexParameters:&params];
        [spriteSheet.texture generateMipmap];
        
        // create colour picker panel
        [ self createColourPicker];
}
-(void)createColourPicker
{
        ColourPickerPanel  *colourPicker= [[ColourPickerPanel alloc]initWithTarget:spriteSheet withPos:ccp(947,67)]; //1300,-10
        //        // setup events
        [colourPicker addTarget:self action:@selector(colourValueChanged:) forControlEvents:CCControlEventColourChanged];
        //[colourPicker setScale:0.48];
        [self.drawLayer addChild:colourPicker z:10 ];
}

-(void)colourValueChanged:(ColourPickerPanel*)sender
{
        RGBA pickerColor = [ColourUtils sharedInstance].rgb;
        [self.drawLayer.pen setColourForBrushWithRed:pickerColor.r*255 WithGreen:pickerColor.g*255 withBlue:pickerColor.b*255];
        [crayonTip setColor:ccc3(pickerColor.r*255 , pickerColor.g*255 , pickerColor.b*255)];
        [bucketTip setColor:ccc3(pickerColor.r*255 , pickerColor.g*255 , pickerColor.b*255)];
        [magicMarkerTip setColor:ccc3(pickerColor.r*255 , pickerColor.g*255 , pickerColor.b*255 )];
        [selectedColorIndicator setVisible:false];
}


#pragma mark - destructor
-(void)dealloc
{
        self.sizeArray=nil;
        self.colorSArray=nil;
        self.imageArray=nil;
        
        self.selectedColorIndicatorSpr=nil;
        self.paperSideSpr=nil;
        self.paperSideSprOne=nil;
        self.thrashBg=nil;
        self.savSpr=nil;
        self.isSaveImagePresent=nil;
        self.isThrashImagePresent=nil;
        self.canPressBackGroundButtons=nil;

        [super dealloc];
        
}

@end


