//
//  PTEmail.m
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import "PTEmail.h"

@implementation PTEmail
@synthesize drawLayer;

#pragma mark - construcor
-(id)init {
        if (self = [super init])
        {
                self.drawLayer = [PTDataManager sharedManager].drawLayer;
                
                emailViewController = [[UIViewController alloc] init];
                [[CCDirector sharedDirector] addChildViewController:emailViewController];
        }
        return self;
}

#pragma  mark - mailCallBack
-(void)emailCallback
{
        if( self.drawLayer.uiManager.canPressBackGroundButtons)
        {
                [[CCDirector sharedDirector] pause];
                [[CCDirector sharedDirector] stopAnimation];
                
                MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
                if(picker!=nil)
                {
                        self.drawLayer.uiManager.canPressBackGroundButtons=false;
                        
                        picker.mailComposeDelegate = self;
                        [picker setSubject:@"This is test subject"];
                        [picker setMessageBody:@"This is test message body" isHTML:YES];
                        
                        [CCDirector sharedDirector].nextDeltaTimeZero = YES;
                        UIImage *image = [drawLayer.canvas getUIImage];
                        NSData *data = UIImagePNGRepresentation(image);
                        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
                        [picker addAttachmentData:data mimeType:@"image/png" fileName:@"attachment .png"];
                        
                        [emailViewController presentModalViewController:picker animated:YES];
                        [picker release];
                }
                else
                {
                        [self.drawLayer addDrawingBackToDrawScene];
                        [[CCDirector sharedDirector] resume];
                        [[CCDirector sharedDirector] startAnimation];
                        [picker release];
                }
        }
}

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
        [self.drawLayer addDrawingBackToDrawScene];
        [[CCDirector sharedDirector] resume];
        [[CCDirector sharedDirector] startAnimation];
        [controller dismissModalViewControllerAnimated:NO];
        self.drawLayer.uiManager.canPressBackGroundButtons=true;
}

#pragma mark - destructor
-(void)dealloc
{
        self.drawLayer=nil;
        [super dealloc];
        
}
@end



