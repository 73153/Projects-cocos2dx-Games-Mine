//
//  PTEmail.h
//  Paint
//
//  Created by Deepthi on 16/05/13.
//  Copyright (c) 2013 JuegoStudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MessageUI/MFMailComposeViewController.h>
#import "cocos2d.h"
#import "PTDrawScene.h"

@interface PTEmail : CCLayer <MFMailComposeViewControllerDelegate>
{
        UIViewController *emailViewController;
        CCMenu *menu;
        CCSprite *sprite;
        PTDrawScene *drawLayer;
}
@property (nonatomic,assign) PTDrawScene *drawLayer;
-(void)emailCallback;
@end
