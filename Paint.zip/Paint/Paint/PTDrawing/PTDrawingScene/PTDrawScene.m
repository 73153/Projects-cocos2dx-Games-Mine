//
//  PTGameScene.m
//  Paint
//
//  Created by Deepthi on 05/04/13.
//  Copyright (c) 2013 Deepthi. All rights reserved.
//

#import "PTDrawScene.h"
#import "PTPenNode.h"
#import "PTUIManager.h"
#import "HuePicker.h"
#import "PTHomeScene.h"
#import "PTDrawing.h"

@implementation PTDrawScene

@synthesize canvas;
@synthesize pen;
@synthesize uiManager;
@synthesize undoArray,redoArray,particleFireBall,currentSprite,isImagePresentAfterScroll,canDraw,superAnimationManager;

#pragma mark - scene

+(CCScene *)scene
{
        CCScene *scene = [CCScene node];
        PTDrawScene *layer = [PTDrawScene node];
        [scene addChild:layer];
        return scene;
}

#pragma mark - constructor

-(id)init
{
        if( (self=[super init]))
        {
                [PTDataManager sharedManager].drawLayer = self;
                
                CCSprite *bgSpr = [CCSprite spriteWithFile:@"BG.png"];
                bgSpr.position=ccp(512,384);
                [self addChild:bgSpr z:-2];
                
                CCSprite *bgWhiteSpr = [CCSprite spriteWithFile:@"paper.png"];
                bgWhiteSpr.position=ccp(519,428);
                [self addChild:bgWhiteSpr z:-1];
        }
        return self;
}

-(void)onEnter
{
        [super onEnter];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"PTUIImages.plist"];
        
        [self initialiseVariables];

        //Create Canvas
        canvas=[CCRenderTexture renderTextureWithWidth:980 height:623 pixelFormat:kCCTexture2DPixelFormat_RGBA8888 ]; //990,600
        canvas.position=ccp(517,430.8);  //500,450
        [ canvas retain];//517,430
      
        [self addChild:canvas z:2];
        
       [self addIntialCanvastoTheUndoArray];
        
        //Initialise managers
        PTUIManager  *_uiManager = [[PTUIManager alloc]init];
        self.uiManager=_uiManager;
        [ _uiManager release];
        
        PTSuperAnimationManager *_animationManager = [[PTSuperAnimationManager alloc]init];
        self.superAnimationManager = _animationManager;
        [_animationManager release];
        
        //Pen
        self.pen = [[PTPenNode alloc]init];
        [self addChild:self.pen z:6];
        self.pen.drawLayer=self;
                
        self.touchEnabled=true;
        tempCanvas=nil;
}

-(void)onExit
{
        [super onExit];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] removeSpriteFramesFromFile:@"PTUIImages.plist"];
        [[CCSpriteFrameCache sharedSpriteFrameCache] removeSpriteFramesFromFile:@"colourPicker.plist"];
}



-(void)initialiseVariables
{
        NSMutableArray *tempArr = [[NSMutableArray alloc]init];
        self.undoArray = tempArr;
        [tempArr release];
        
        NSMutableArray *tempArrOne = [[NSMutableArray alloc]init];
        self.redoArray = tempArrOne;
        [tempArrOne release];
        
        self. isImagePresentAfterScroll=false;
        self.canDraw=false;
}


#pragma mark - Undo & Redo
-(void)undoFunc
{
        if  ( [undoArray count] >0)
        {
                UndoMoveData* item = [undoArray lastObject];
                
                if([undoArray count]==1)
                {
                        [self renderTexture:item];
                }
                else
                {
                        [redoArray addObject:item];
                        [undoArray removeObject:item];
                     
                        item = [undoArray lastObject];
                        
                        //map previous texture onto the current one
                        [self renderTexture:item];
                }
        }
}

-(void)redoFunc
{
        if ( [redoArray count] > 0 )
        {
                UndoMoveData* item = [redoArray lastObject];
                [undoArray addObject:item];
                [redoArray removeObject:item];
              
                //map previous texture onto the current one
                [self renderTexture:item];
        }
}

-(void)addIntialCanvastoTheUndoArray
{
        UndoMoveData *undoData = [[UndoMoveData alloc]init];
        [canvas clear:1 g:1 b:1 a:1];
        undoData.lastTexture = canvas;
        [undoArray addObject:undoData];
        [undoData release];
}

#pragma mark -  RenderingTExture
-(void)renderTexture:(id)inTextureData
{
        [canvas clear:1 g:1 b:1 a:1];
        
        UndoMoveData *item =(UndoMoveData*)inTextureData;
        [canvas begin];
        [item.lastTexture visit];
        [canvas end];
}

#pragma mark - Drawings
-(void)addDrawingWithName:(NSString*)name
{
        PTDrawing *spr = [PTDrawing spriteWithFile:name];
        spr.drawingName=name;
        if(isImagePresentAfterScroll)
        {
                [self removeDrawing:currentSprite];
                
        }
        currentSprite=spr;
        spr.position=ccp(530,400);
        [self addChild:spr z:10];
        [self addIntialCanvastoTheUndoArray];
        
        isImagePresentAfterScroll=true;
        
        uiManager.canPressBackGroundButtons=true;
}

-(void)removeDrawing:(PTDrawing*)spr;
{
        [self removeChild:spr cleanup:TRUE];
        spr=nil;
        
}
-(void)addDrawingTocanvas
{
        if(isImagePresentAfterScroll)
        {
               currentSprite.position=ccp(503,281);
                
                tempCanvas=[CCRenderTexture renderTextureWithWidth:1100 height:1396 pixelFormat:kCCTexture2DPixelFormat_RGB888 ];
                tempCanvas.position=ccp(523,578.5);
                [tempCanvas retain];
                
                [self copyTexture:canvas to:tempCanvas];
                [self copyTexture:currentSprite to:canvas];
                [currentSprite setVisible:false];
        }
        
}
-(void)addDrawingBackToDrawScene
{
        if(isImagePresentAfterScroll)
        {
                
                [canvas clear:1 g:1 b:1 a:1];
                
                [currentSprite setVisible:true];
                currentSprite.position=ccp(530,400);

                
                [self copyTexture:tempCanvas to:canvas];
                
        }
        
}

-(void)copyTexture:(CCNode*)currentTex to:(CCRenderTexture*)newTex
{
        [newTex begin];
        [currentTex visit];
        [newTex end];

}

#pragma mark - Touches
-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
        NSSet *allTouches = [event allTouches];
        
        for( UITouch *touch in allTouches)
        {
                UITouch* touch = [touches anyObject];
                CGPoint location = [touch locationInView: [touch view]];
                
                CGPoint start = location;
                start = [[CCDirector sharedDirector] convertToGL:start];
                CGPoint end = start;
              
                //Check whether we can draw
                if([self checkWhetherWeCanDraw:start])
                {
                        canDraw=true;
                        if(canDraw)
                        {
                        start.y =start.y-130;
                        start.x =start.x-20;
                        end.y=start.y+3;
                        end.x=start.x+3;
                        
                        [pen drawPenWithPosition:start toThePosition:end];
                        }
                }
        }
}

-(void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
        NSSet *allTouches = [event allTouches];
        for( UITouch *touch in allTouches)
        {
                UITouch* touch = [touches anyObject];
                CGPoint location = [touch locationInView: [touch view]];
                
                CGPoint start=      location;
                start = [[CCDirector sharedDirector] convertToGL:start];
                
                CGPoint end =[touch previousLocationInView:[touch view]];
                end=[[CCDirector sharedDirector]convertToGL:end];
                
                if([self checkWhetherWeCanDraw:start])
                {
                        start.y =start.y-130;
                        start.x =start.x-20;
                        end.y=end.y-130;
                        end.x=end.x-20;
                        
                        [pen drawPenWithPosition:start toThePosition:end];
                }
        }
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
{
             if(canDraw)
             {
               [self saveAction];
             }
}

-(void)ccTouchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{

}

-(void)saveAction
{
        //Undo Redo
       UndoMoveData  *data = [[UndoMoveData alloc]init];
    
        CCRenderTexture  *tex=[CCRenderTexture renderTextureWithWidth:1100 height:1396 pixelFormat:kCCTexture2DPixelFormat_RGB888 ];
        tex.position=ccp(523,578.5);
        [tex begin];
        [canvas visit];
        [tex end];
        
        data.lastTexture = tex;
        
        if([undoArray count]>=6)
        {
                [undoArray removeObjectAtIndex:0];
        }
        [undoArray addObject:data];
        [data release];
        
        NSLog(@"%d",[undoArray count]);
       
        
        [redoArray removeAllObjects];
        canDraw=FALSE;
}

-(BOOL)checkWhetherWeCanDraw:(CGPoint)location
{
        if(CGRectContainsPoint([self.uiManager.paperSideSpr boundingBox], location))
        {
                return false;
        }
        else if(CGRectContainsPoint([self.uiManager.paperSideSprOne boundingBox], location))
        {
                return false;
        }
        if(uiManager.isThrashImagePresent)
        {
                if(CGRectContainsPoint([self.uiManager.thrashBg boundingBox], location))
                {
                        return false;
                }
        }
        if(uiManager.isSaveImagePresent)
        {
                
                if(CGRectContainsPoint([self.uiManager.savSpr boundingBox], location))
                {
                        
                        return false;
                        
                }
        }
        

        
       return  true;
}

#pragma mark -  destructor

-(void)dealloc
{
        [self.canvas release];
        self.canvas = nil;
        
    //  self.uiManager=nil;
        
        [self.pen release];
        self.pen = nil;
        
        [tempCanvas release];
        tempCanvas=nil;
        
        self.particleFireBall = nil;
        
        self.undoArray = nil;
        self.redoArray=nil;
        
     //   [self.superAnimationManager release];
     //   superAnimationManager=nil;
        
        //         [self.currentSprite release];
        self.currentSprite=nil;
        
        self.isImagePresentAfterScroll=nil;
        
        [super dealloc];
}

@end

#pragma mark - Undo Object

@implementation UndoMoveData

@synthesize lastTexture;

- (id)init
{
        self = [super init];
        if (self) {
                
        }
        return self;
}

-(void)dealloc
{
        self.lastTexture = nil;
        [super dealloc];
}
@end