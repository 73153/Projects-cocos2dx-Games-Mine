//
//  PTGameScene.h
//  Paint
//
//  Created by Deepthi on 05/04/13.
//  Copyright (c) 2013 Deepthi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "cocos2d.h"

#import "PTDataManager.h"

#import "PTUIManager.h"

#import "PTPenNode.h"

#import "ColourPickerPanel.h"

#import "PTSuperAnimationManager.h"


@class UndoMoveData;
@class PTDrawing;
@interface PTDrawScene : CCLayer
{
        //uimanager
        PTUIManager   *uiManager;

        CCRenderTexture			*canvas;

        //Pen
        PTPenNode					*pen;
        
        PTSuperAnimationManager       *superAnimationManager;
       
       
        //Undo & Redo
        NSMutableArray *undoArray;
        NSMutableArray *redoArray;
        
        //Drawing
        PTDrawing *currentSprite;
        
        //Temp Data
        CCRenderTexture *tempCanvas;
        
        bool isImagePresentAfterScroll;
        bool canDraw;
}

//Manager
@property(nonatomic,retain) PTUIManager   *uiManager;
@property(nonatomic,retain) PTSuperAnimationManager *superAnimationManager;

//Undo Redo
@property(nonatomic,retain) NSMutableArray *undoArray;
@property(nonatomic,retain) NSMutableArray *redoArray;

//Drawing
@property(nonatomic,assign) CCRenderTexture  *canvas;
@property(nonatomic,assign) PTPenNode	*pen;
@property(nonatomic,assign) CCParticleSystemQuad *particleFireBall;
@property(nonatomic,assign) PTDrawing *currentSprite;
@property(nonatomic,assign) bool isImagePresentAfterScroll;
@property(nonatomic,assign) bool canDraw;

///--- Functions
+(CCScene *) scene;

//Drawings
-(void)addDrawingWithName:(NSString*)name;
-(void)removeDrawing:(PTDrawing*)selectedAnimalIndex;

-(void)addDrawingTocanvas;
-(void)addDrawingBackToDrawScene;

//Undo &Redo
-(void)addIntialCanvastoTheUndoArray;

-(void)undoFunc;
-(void)redoFunc;

@end

//---------------------------Undo Object
@interface UndoMoveData : NSObject
{
        CCRenderTexture* lastTexture;
        UndoMoveType undoMoveType;
        CCSprite* lastAlteredSprite;
        ccColor3B lastColor;
}

@property(nonatomic,retain) CCRenderTexture  *lastTexture;

@end
