#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

#pragma mark - Default
CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

HelloWorld::HelloWorld() {
    
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback) );
    pCloseItem->setPosition(ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );

    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(pCloseItem, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);

    //touch Enabled
    this->setTouchEnabled(true);
    
    //Get Winsize
    size = CCDirector::sharedDirector()->getWinSize();

    //call to initialize methods
    this->initializeVariables();
    this->initializeGameUI();
    
    //call to tryPopMoles
    this->schedule(schedule_selector(HelloWorld::tryPopMoles), 0.5);
    
    return true;
}

#pragma mark - Initialize
void HelloWorld::initializeVariables() {
    
    hitCount = 0;
    missCount = 0;
    score = 0;
    gameOver = false;
    
    //Creating mole Array
    this->molesArr = CCArray::create();
    this->molesArr->retain();
}

#pragma mark - InitializeGameUI
void HelloWorld::initializeGameUI() {
    
    //Add "holes"
    int x1 = 300;
    int y1 = 460;
    
    //loading moleGame SpriteSheet
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("molesWhack.plist");
    
    //set position for holes
    for (int i = 1; i <= 6; i++) {
        
        CCSprite *hole = CCSprite::createWithSpriteFrameName("hole.png");
        
        hole->setPosition(ccp(x1, y1));
        hole->setTag(i);
        hole->setScale(0.2);
        this->addChild(hole);
        
        x1 = x1 + 200;
        
        if (i % 3 == 0) {
            
            x1 = 300;
            y1 = y1-250;
        }
    }
    
    //Add "moleToWhack"
    int x11 = 300;
    int y11 = 460;
    int moleTag = 1;
    
    //set position for moles
    for (int i = 1; i <= 6; i++) {
        
        CCSprite *mole = CCSprite::createWithSpriteFrameName("moleToWhack.png");
        mole->setPosition(ccp(x11, y11));
        mole->setTag(moleTag);
        moleTag++;
        this->addChild(mole);
        this->molesArr->addObject(mole);
        
        x11 = x11 + 200;
        
        if (i % 3 == 0) {
            
            x11 = 300;
            y11 = y11-250;
        }
    }
    
    //set Hit Score label
//    moleTapHit = CCLabelTTF::create("Hit", "Thonburi", 34);
//    moleTapHit->setPosition(ccp(size.width/2 - 350, size.height - 30));
//    this->addChild(moleTapHit, 1);
    
    //set Miss Score label
    moleTapMiss = CCLabelTTF::create("Miss", "Thonburi", 34);
    moleTapMiss->setPosition(ccp(size.width/2 + 350, size.height - 30));
    this->addChild(moleTapMiss, 1);
    
    //Add label
    float margin = 10;
    scoreLabel = CCLabelTTF::create("Score: 0", "Verdana",14.0);
    scoreLabel->setAnchorPoint(ccp(1,0));
    scoreLabel->setPosition(ccp(size.width - margin - 800, margin + 600));
    this->addChild(scoreLabel,10);
}

#pragma mark - logicMethods
void HelloWorld::popMole(CCSprite *mole) {
    
    if (totalSpawns >= 50) return;
    totalSpawns++;
    
    //Pop mole
    mole->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("moleToWhack.png"));
    
    CCMoveBy *moveUp = CCMoveBy::create(0.2, ccp(0, mole->getContentSize().height));
    CCCallFunc *setTappable = CCCallFuncN::create(this, callfuncN_selector(HelloWorld::setTappable));
    CCEaseInOut *easeMoveUp = CCEaseInOut::create(moveUp, 3.0);
    CCCallFuncN *unsetTappable = CCCallFuncN::create(this, callfuncN_selector(HelloWorld::unsetTappable));
    CCAction *easeMoveDown = easeMoveUp->reverse();
    
    CCFiniteTimeAction *seq = CCSequence::create(easeMoveUp, setTappable, unsetTappable, easeMoveDown, NULL);
    mole->runAction(seq);
}

void HelloWorld::setTappable(CCSprite *sender) {
    
    CCSprite *mole = (CCSprite *)sender;
    mole->setUserData((void *) 1);
}

void HelloWorld::unsetTappable(CCSprite *sender) {
    
    CCSprite *mole = (CCSprite *)sender;
    mole->setUserData((void *) 0);
}

void HelloWorld::tryPopMoles(CCTime dt) {
    
    if (gameOver) return;

    char scoreStr[12];
    sprintf(scoreStr, "hitCount %d", score);
    CCLog("hitCount %d",score);
    scoreLabel->setString(scoreStr);
    
    char tapMissStr[12];
    sprintf(tapMissStr, "hitCount %d", missCount);
    CCLog("hitCount %d",missCount);
    moleTapMiss->setString(tapMissStr);
    
    if (totalSpawns >= 50) {
        
        CCLabelTTF *gameStatusLabel = CCLabelTTF::create("Level Complete", "Verdana", 48.0);
        gameStatusLabel->setPosition(ccp(size.width/2, size.height/2 + 200));
        gameStatusLabel->setScale(0.1);
        this->addChild(gameStatusLabel,10);
        gameStatusLabel->runAction(CCScaleTo::create(0.5,1.0));
        gameOver = true;
        return;
    }
    
    CCObject *moleObj = NULL;
    CCARRAY_FOREACH(this->molesArr, moleObj){
        
        CCSprite * moleSpr = (CCSprite*)moleObj;
        
        if (arc4random() % 6 == 0) {
            
            if (moleSpr->numberOfRunningActions() == 0) {
                this->popMole(moleSpr);
            }
        }
    }
}

#pragma mark - Touch
bool HelloWorld::ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent){
    
    CCPoint touchPoint = this->convertTouchToNodeSpace(pTouch);

    CCObject *moleObj = NULL;
    CCARRAY_FOREACH(this->molesArr, moleObj){
        
        CCSprite * moleSpr = (CCSprite*)moleObj;
        
        if (moleSpr->getUserData() == ((void*)0)) continue;
        
        if (moleSpr->boundingBox().containsPoint(touchPoint)) {
            
            moleSpr->setUserData((void*)0);
            
            score+=10;
            
            moleSpr->stopAllActions();
            CCMoveBy *moveDown = CCMoveBy::create(0.2, ccp(0, -moleSpr->getContentSize().height));
            CCEaseInOut *easeMoveDown = CCEaseInOut::create(moveDown, 3.0);
            moleSpr->runAction(easeMoveDown);
        }
            missCount -= 10;
            char string[12];
            sprintf(string, "missCount %d", missCount);
            moleTapMiss->setString(string);
            moleTapMiss->setPosition(ccp(size.width/2, size.height/2 + 200));
            moleTapMiss->setScale(0.1);
            this->addChild(moleTapMiss,10);
            moleTapMiss->runAction(CCScaleTo::create(0.5, 1.0));
        }
    return true;
}

#pragma mark - Dealloc
HelloWorld::~HelloWorld() {
    
    CC_SAFE_RELEASE_NULL(this->molesArr);
}

void HelloWorld::menuCloseCallback(CCObject* pSender)
{
    CCDirector::sharedDirector()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
