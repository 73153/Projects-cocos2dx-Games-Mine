//
//  BaseEntity.h
//  HelloCocos
//
//  Created by Mohammad Azam on 12/15/10.
//  Copyright 2010 HighOnCoding. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface BaseEntity : NSObject {

	CGSize windowSize;
	
}

@property (nonatomic,assign) CGSize windowSize; 

@end
