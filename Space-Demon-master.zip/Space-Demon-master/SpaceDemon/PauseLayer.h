//
//  PauseLayer.h
//  SpaceDemon
//
//  Created by Mohammad Azam on 1/24/11.
//  Copyright 2011 HighOnCoding. All rights reserved.
//

#import "cocos2d.h" 


@interface PauseLayer : CCColorLayer {

	CGSize windowSize; 
	
}

@property (nonatomic,assign) CGSize windowSize; 

@end
