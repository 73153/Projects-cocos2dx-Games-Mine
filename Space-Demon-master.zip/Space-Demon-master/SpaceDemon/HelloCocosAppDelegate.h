//
//  HelloCocosAppDelegate.h
//  HelloCocos
//
//  Created by Mohammad Azam on 10/17/10.
//  Copyright HighOnCoding 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloCocosAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
