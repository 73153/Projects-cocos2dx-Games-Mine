
#import "Scene.h"

@interface TestHPScene : Scene {

}

@end
