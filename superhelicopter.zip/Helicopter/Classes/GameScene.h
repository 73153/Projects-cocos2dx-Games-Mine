//
//  GameScene.h
//  Heli
//
//  Created by vy phan on 02/08/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Scene.h"
#import "TestLayer.h"

@interface GameScene : Scene {

}

@end
