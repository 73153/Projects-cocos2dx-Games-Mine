//
//  TestDraw.h
//  Heli
//
//  Created by vy phan on 08/09/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface TestDraw : CocosNode {
	//ccColor3B
	CGPoint *vertices;
	ccColor3B color;
}

@end
