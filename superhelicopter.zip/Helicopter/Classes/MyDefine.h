/*
 *  MyDefine.h
 *  Heli
 *
 *  Created by vy phan on 19/08/2010.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

enum {
	CHARACTER_1,
	CHARACTER_2,
	ENEMY_HELI,
	ENEMY_HELI_2,
	ENEMY_HELI_3,
	ENEMY_BOSS,
	ENEMY_TANK,
	WEAPON_BOMB,
	WEAPON_NORMAL_BULLET,
	WEAPON_MISSILE_1,
	WEAPON_MISSILE_2,
	WEAPON_MISSILE_3,
	ITEM_HP,
	ITEM_MISSILE,
	ITEM_BOMB,
	ITEM_SUPER
};