//
//  CusSprite.h
//  Heli
//
//  Created by vy phan on 02/08/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "TouchDispatcher.h"
#import "AtlasSprite.h"

@interface CusSprite : AtlasSprite {
}

@end
