---
title: BlackBerry Developer Group Netherlands
redirect-page: Amsterdam
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to Amsterdam"
layout: redirect
---
