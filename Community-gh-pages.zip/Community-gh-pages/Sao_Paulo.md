---
layout: basic

title: Sao Paulo
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Sao Paulo, Brazil
([Wikipedia](http://en.wikipedia.org/wiki/Sao_Paulo), [City Website](http://www.prefeitura.sp.gov.br/)).

## Future Events

* August 23, 2012 - [Sao Paulo](http://www.blackberryjamworldtour.com/sao-paulo) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


