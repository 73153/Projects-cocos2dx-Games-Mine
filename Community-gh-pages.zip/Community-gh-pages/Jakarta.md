---
layout: basic

title: Jakarta
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Jakarta, Indonesia
([Wikipedia](http://en.wikipedia.org/wiki/Jakarta), [City Website](http://www.jakarta.go.id/)).

## Future Events

* July 10, 2012 - [Jakarta](http://www.blackberryjamworldtour.com/jakarta) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


