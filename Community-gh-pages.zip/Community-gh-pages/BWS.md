---
title: BWS
redirect-page: BlackBerry_Web_Services
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to BlackBerry_Web_Services"
layout: redirect
---
