---
layout: basic

title: Buenos Aires
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Buenos Aires, Argentina
([Wikipedia](http://en.wikipedia.org/wiki/Buenos_Aires), [City Website](http://www.buenosaires.gov.ar/)).

## Future Events

* August 16, 2012 - [Buenos Aires](http://www.blackberryjamworldtour.com/buenos-aires) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


