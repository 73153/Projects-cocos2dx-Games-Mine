---
layout: basic

title: Bangalore
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Bangalore, India.
([Wikipedia](http://en.wikipedia.org/wiki/Bangalore), [City Website](http://www.bbmp.gov.in/))

## Future Events

* July 2, 2012 - [Bangalore](http://www.blackberryjamworldtour.com/bangalore) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


