---
title: jQuery

layout: wanted
---
{% include common-defs.md %}

# jQuery

jquery.com

## See Also

[HTML5]

Can be used in combination with other frameworks, like [bbUI.js][bbUIjs], [Alice][AliceJS], or ZoeJS