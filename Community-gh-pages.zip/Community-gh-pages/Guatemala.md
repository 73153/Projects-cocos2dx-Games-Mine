---
layout: basic

title: Guatemala
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Guatemala
([Wikipedia](http://en.wikipedia.org/wiki/Guatemala), [Gov Website](http://www.guatemala.gob.gt/))

## Future Events

* Aug/31 Group Conference for Systems Engineering students at [UMG](http://goo.gl/Y5e1i)

## Past Events

TBD

## Developer Groups

* [BlackBerry Developer Group GT](http://goo.gl/ZMPQu)
* [@BBDevGT Twitter](http://goo.gl/gpHEO)
* [BBDevGT Facebook](http://goo.gl/6gHmC)

