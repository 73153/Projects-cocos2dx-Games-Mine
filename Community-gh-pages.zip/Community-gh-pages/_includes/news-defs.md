[latest_news]: <Latest_News.html> "Latest News"
[all_news]: <All_News.html> "All News"

[cliff]: <http://twitter.com/cliffordhung> "Clifford Hung"
[pelegri]: <http://twitter.com/pelegri> "Eduardo Pelegri-Llopart"
[alexk]: <http://twitter.com/alexkinsella> "Alex Kinsella"
[mdw]: <http://twitter.com/mdwrim> "Martin Woolley"
[jcm]: <http://twitter.com/jcmrim> "John Murray"

[jamtour]: <http://www.blackberryjamworldtour.com/> "BlackBerry 10 Jam World Tour"
[devblog]: <http://devblog.blackberry.com"> "Inside BlackBerry DevBlog"

<!-- Relative paths -->

[bb10jam]: <../BlackBerry_Jam.html> "BlackBerry 10 Jam"
[bbuijs]: <../bbUIjs.html> "A WebWorks-based Framework to write HTML5 applications using BBOS and BB10 Conventions"
[cascades]: <../Cascades.html> "Cascades Native Framework"
[bps]: <../BPS.html> "BlackBerry Platform Services"