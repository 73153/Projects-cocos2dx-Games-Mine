[tim_neil]: <../Tim_Neil.html> "Tim Neil"
[alec_saunders]: <../Alec_Saunders.html> "Alec Saunders"
[john_murray]: <../John_Murray.html> "John Murray"
[martin_woolley]: <../Martin_Wooley.html> "Martin Wooley"
[nick_landry]: <../Nick_Landry.html> "Nick Landry"
[david_cummings]: <../David_Cummings.html> "David Cummings"
[ken_wallis]: <../Ken_Wallis.html> "Ken Wallis"

[devcon]: <../Developer_Conferences.html> "Developer Conferences"
[devcon2011_america]: <../Developer_Conferences.html> "Developer Conferences"
[devcon2011_asia]: <../Developer_Conferences.html> "Developer Conferences"
[devcon2012_europe]: <../Developer_Conferences.html> "Developer Conferences"

[dc12e_dev339]: <devcon2012-europe/Which_Programming_Environment_for_You.html> "Which Programming Environment is Right for You?"
[dc12e_dev311]: <devcon2012-europe/Build_NFC_App.html> "How to Build an NFC-Enabled App"
[dc12e_dev319]: <devcon2012-europe/Introduction_to_PlayBook_NDK.html> "Introduction to the BlackBerry PlayBook Native SDK: Building a Sample Application"
[dc12e_dev301]: <devcon2012-europe/Introduction_to_WebWorks.html> "Introduction to BlackBerry WebWorks"
[dc12e_dev345]: <devcon2012-europe/Mastering_Java_Layouts.html> "Mastering Java Layouts: Fields, Managers, and Screens"

[mwc2012_asaunders]: <mwc2012/BlackBerry_Dev_Community.html> "The BlackBerry Developer Community"

[bb10jam]: <../BlackBerry_Jam.html> "BlackBerry 10 Jam"

[cascades]: <../Cascades.html> "Cascades"
[nfc]: <../NFC.html> "NFC"
