---
layout: basic

title: New York
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around New York, USA
([Wikipedia](http://en.wikipedia.org/wiki/New_York), [City Website](http://www.ny.gov))

## Future Events

* June 19, 2012 - [New York](http://www.blackberryjamworldtour.com/new-york) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

### New York BlackBerry Developers' Group

*Twitter*: [@BlackBerryDevNY](https://twitter.com/BlackBerryDevNY/)
*Meetup*: [BBDevNY](http://www.meetup.com/BBDevNY/)
