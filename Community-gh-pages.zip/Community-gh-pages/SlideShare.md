---
layout: basic

title: SlideShare
oneline: SlideShare Presentations and Users
tags: slides, presentations
---
{% include common-defs.md %}

### Description

Main [SlideShare](http://slideshare.com) users of interest to BlackBerry Developers.

### RIM Sponsored

* [BlackBerry - Research in Motion](http://www.slideshare.net/blackberry)
* [Developer Slides](http://www.slideshare.net/blackberry/tagged/developer)

### Others

Add your own.
