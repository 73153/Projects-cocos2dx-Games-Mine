---
layout: basic

title: Dubai
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Dubai, United Arab Emirates
([Wikipedia](http://en.wikipedia.org/wiki/Dubai), [City Website](http://www.dubai.ae/en/pages/default.aspx)).

## Future Events

* July 10, 2012 - [Dubai](http://www.blackberryjamworldtour.com/dubai) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


