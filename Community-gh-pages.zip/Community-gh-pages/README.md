This is the User-facing branch and it is usually accessed via the gh-pages machinery.

The developer/contributor-facing branch is the master branch.

We stage the contributions via the [blackberry-community](https://github.com/blackberry-community/Community).
