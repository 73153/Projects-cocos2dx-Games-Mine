---
layout: basic

title: Montreal
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Montreal, Quebec, Canada
([Wikipedia](http://en.wikipedia.org/wiki/Montreal), [City Website](http://www.ville.montreal.qc.ca/)).

## Future Events

* July 11, 2012 - [Montreal](http://www.blackberryjamworldtour.com/montreal) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


