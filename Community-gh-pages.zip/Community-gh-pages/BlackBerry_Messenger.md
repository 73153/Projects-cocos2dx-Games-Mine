﻿---
title: BlackBerry Messenger
oneline: Instant Messenger for BlackBerry Smartphone owners
forum: 
techlink: 
tags: server, bbm, messenger

layout: technology
---
{% include common-defs.md %}

### Description

BlackBerry® Messenger is an instant messaging app just for BlackBerry smartphone owners

[Main site](http://us.blackberry.com/developers/blackberrymessenger/)

### Also See
[BlackBerry Services]
