---
layout: wanted

title: Artem Simonov
oneline: RIM developer
tags: rim
---
{% include common-defs.md %}

TBD
