---
title: BlackBerry Community Wiki
redirect-page: news/Latest_News
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to the starting page"
layout: redirect
---
