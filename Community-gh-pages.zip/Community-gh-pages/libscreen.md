---
title: libscreen
oneline: Screen and Windowing API
forum: "http://supportforums.blackberry.com/t5/Cascades-Development/bd-p/NDK"
techlink: 
tags: cascades, native, blackberry10

layout-x: component
layout: wanted
---
{% include common-defs.md %}

### Description
The QNX Screen Composited Windowing API.

https://developer.blackberry.com/native/reference/com.qnx.doc.screen.lib_ref/topic/cscreen_api_components.html

### Support
TBD
 
### Filing Bugs
TBD

### LibScreen Samples
TBD

### Also See
TBD
