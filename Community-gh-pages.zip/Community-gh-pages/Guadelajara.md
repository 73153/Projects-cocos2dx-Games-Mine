---
layout: wanted

title: Guadelajara
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Guadelajara, Mexico
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


