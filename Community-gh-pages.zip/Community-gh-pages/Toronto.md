---
layout: basic

title: Toronto
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Toronto, Ontario, Canada
([Wikipedia](http://en.wikipedia.org/wiki/Toronto), [City Website](http://www.toronto.ca/)).

## Future Events

* June 21, 2012 - [Toronto](http://www.blackberryjamworldtour.com/toronto) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


