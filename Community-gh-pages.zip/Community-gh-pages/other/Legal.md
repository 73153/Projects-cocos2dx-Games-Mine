---
title: Legal Information

layout: basic
---
{% include other-defs.md %}

Any legal details about the Community Wiki would go here.
