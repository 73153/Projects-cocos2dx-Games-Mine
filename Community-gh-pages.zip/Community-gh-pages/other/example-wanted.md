---
title: Title of Wanted Page

layout: wanted
---
{% include wanted-defs.md %}

### Notes
Description and any relevant links and leads.  This includes leads you may have.

### Also See
Other pages that seem relevant

<!-- Clone this page, remove after this comment -->
## More on the Wanted Layout

### Layout and Variables
The *wanted* template only has the left-hand side *navigation* page.  It is intended to capture leads
and information on a page with minimal cost, for later 

The *wanted* template uses the following variables:

* _title_: Title of the Basic Page

### Extra Content (after YAML Header)
Follow the example shown in this page; clone the page and edit.