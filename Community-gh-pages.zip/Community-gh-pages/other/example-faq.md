---
title: Title of Question

layout: faq
---
{% include common-defs.md %}

### Description
Extra details go here

### Additional Links
* [link1](http://ramdom/link1)
* [link2](http://ramdom/link2)

### Also see
List of other pages that are relevant to this one.  Use references whenever possible (see common-defs.md in include directory).

<!-- Clone this page, remove after this comment -->
## More on FAQ Layout

This layout is still fluid.  Need to try out a few questions and answers.

### Layout and Variables
The _faq_ template just includes the *navigation* page.

The _faq_ template uses the following variables:

* _title_: Title of the FAQ page (and Question)

### Extra Content (after YAML Header)
Follow the example shown in this page; clone the page and edit.

### Future Work

Provide any additional context to the question,  
Then provide the anwer using a level-3 separator.  
Remember to provide an author/contact name (on wiki?) for each reply.  

