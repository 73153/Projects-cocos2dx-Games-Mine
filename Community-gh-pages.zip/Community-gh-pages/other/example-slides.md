---
layout: slides
title: The Title
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: Link to there it was presented  
*Author*: Link to presenter  
*Date*: Date  
*SlideShare*: Link to SlideShare presentation  

Here does the DIV extracted from the SlideShare EMBED.
Use the largest size (595x497) and remove the HREF to the original
and the HREF and COMMENT for extra slides.
The remaining structure is a DIV with an OBJECT that has several PARAMs and ends in an EMBED

## Notes and Comments

fill-in