---
layout: basic

title: BlackBerry 10.0.06 Samples
tags: BlackBerry 10
---
{% include common-defs.md %}

This is a list of all the Open Source Samples and other repositories
that are new or have changed around [BlackBerry 10.0.06][blackberry_10_0_06]

### Repositories

This release added 3 new repositories: [BB10-WebWorks-Samples][repo:bb10-webworks-samples],
[Community-APIs-for-AIR][repo:community-apis-for-air] and
[Qt2Cascades-Samples][repo:qt2cascades-samples].

### HTML5 Samples

[WebWorks-Community-APIs][repo:webworks-community-apis]  

[BB10-WebWorks-Samples][repo:bb10-webworks-samples]  
bar

[WebGL-Samples][repo:webgl-samples]  
bar

### Other Repositories

* [Samples-for-Java][repo:samples-for-java]

#### Java

TBD

Repo and technology goes here

### Also See
[BlackBerry 10][blackberry_10], [BlackBerry 10 Releases][blackberry_10_releases], [BlackBerry 10.0.06][blackberry_10_0_06]
