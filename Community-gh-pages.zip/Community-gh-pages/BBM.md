---
title: BBM
redirect-page: BlackBerry_Messenger
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to BlackBerry_Messenger"
layout: redirect
---
