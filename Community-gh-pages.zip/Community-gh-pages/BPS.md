---
title: BPS
redirect-page: BlackBerry_Platform_Services
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to BlackBerry_Platform_Services"
layout: redirect
---
