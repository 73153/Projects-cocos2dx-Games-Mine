---
layout: basic

title: Santa Clara
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Santa Clara, California, USA.
([Wikipedia](http://en.wikipedia.org/wiki/Santa_Clara,_California), [City Website](http://www.santaclaraca.gov/))

## Future Events

* June 7, 2012 - [Santa Clara](http://www.blackberryjamworldtour.com/santa-clara) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


