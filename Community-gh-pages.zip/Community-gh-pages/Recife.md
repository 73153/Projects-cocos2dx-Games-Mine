---
layout: wanted

title: Recife
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Recife, Brazil
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


