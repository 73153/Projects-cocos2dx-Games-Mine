---
layout: basic

title: Porto
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Porto, Portugal
([Wikipedia](http://en.wikipedia.org/wiki/Porto), [City Website](http://en.wikipedia.org/wiki/Porto)).

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


