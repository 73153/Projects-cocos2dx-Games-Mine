---
layout: basic

title: Paris
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Paris, France
([Wikipedia](http://en.wikipedia.org/wiki/Paris), [City Website](http://www.paris.fr))

## Future Events

* June 12, 2012 - [Paris](http://www.blackberryjamworldtour.com/paris) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


