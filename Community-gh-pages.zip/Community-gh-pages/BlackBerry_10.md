---
title: BlackBerry 10

layout: wanted
---
{% include common-defs.md %}

Clarification relative to PlayBook

History

[https://developer.blackberry.com/](https://developer.blackberry.com/)