---
layout: basic

title: Sydney
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Sydney, Australia
([Wikipedia](http://en.wikipedia.org/wiki/Sydney), [City Website](http://www.cityofsydney.nsw.gov.au/)).

## Future Events

* July 12, 2012 - [Sydney](http://www.blackberryjamworldtour.com/sydney) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


