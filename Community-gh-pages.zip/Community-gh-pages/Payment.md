---
title: Payment
redirect-page: BlackBerry_Payment_Service
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to BlackBerry_Payment_Service"
layout: redirect
---
