---
layout: basic

title: Milan
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Milan, Italy
([Wikipedia](http://en.wikipedia.org/wiki/Milan), [City Website](http://www.comune.milano.it/portale/wps/portal/CDMHome))

## Future Events

TBD

## Past Events

* May 29, 2012 - [Milan](http://www.blackberryjamworldtour.com/milan) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Developer Groups

TBD


