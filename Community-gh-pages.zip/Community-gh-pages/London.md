---
layout: basic

title: London
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around London, UK
([Wikipedia](http://en.wikipedia.org/wiki/London), [City Website](http://www.london.gov.uk/))

## Future Events

* June 14, 2012 - [London](http://www.blackberryjamworldtour.com/london) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


