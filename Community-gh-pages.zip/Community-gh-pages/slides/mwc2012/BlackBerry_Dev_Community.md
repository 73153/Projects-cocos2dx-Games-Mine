---
layout: slides
title: The BlackBerry Developer Community
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: [Mobile World Congress 2012](http://uk.blackberry.com/mwc12/)
*Author*: [Alec Saunders]  
*Date*: Feb 28, 2012  
*SlideShare*: [{{ page.title }}](http://www.slideshare.net/BlackBerry/mwc-developer-day-sessions)



## Notes and Comments

fill-in