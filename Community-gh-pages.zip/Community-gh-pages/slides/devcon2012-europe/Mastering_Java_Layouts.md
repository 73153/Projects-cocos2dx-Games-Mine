---
layout: slides
title: "Mastering Java Layouts: Fields, Managers, and Screens"
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: [DevCon 2012 Europe](https://devcon.blackberryconferences.net/europe2012/scheduler/sessionDetails.do?SESSION_ID=DEV345)  
*Author*: Michael Brown   
*Date*: Feb 7-8, 2012  
*SlideShare*: [{{ page.title }}](http://www.slideshare.net/BlackBerry/dev345-brown)



## Notes and Comments

fill-in