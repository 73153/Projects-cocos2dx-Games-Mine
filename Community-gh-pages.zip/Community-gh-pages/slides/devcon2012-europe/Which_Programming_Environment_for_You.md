---
layout: slides
title: Which Programming Environment is Right for You?
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: [DevCon 2012 Europe](https://devcon.blackberryconferences.net/europe2012/scheduler/sessionDetails.do?SESSION_ID=DEV339)  
*Author*: [Tim Neil]  
*Date*: Feb 7-8, 2012  
*SlideShare*: [{{ page.title }}](http://www.slideshare.net/BlackBerry/which-programming-environment-is-right-for-you)


## Notes and Comments

fill-in