---
layout: slides
title: "Introduction to BlackBerry WebWorks"
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: [DevCon 2012 Europe](https://devcon.blackberryconferences.net/europe2012/scheduler/sessionDetails.do?SESSION_ID=DEV301)  
*Author*: [Ken Wallis]  
*Date*: Feb 7-8, 2012  
*SlideShare*: [{{ page.title }}](http://www.slideshare.net/BlackBerry/introduction-to-blackberry-webworks)



## Notes and Comments

fill-in