---
layout: slides
title: How to Build an NFC-Enabled App
---
{% include slides-defs.md %}

## {{ page.title }}
*Originally Presented*: [DevCon 2012 Europe](https://devcon.blackberryconferences.net/europe2012/scheduler/sessionDetails.do?SESSION_ID=DEV311)  
*Author*: [John Murray], [Martin Woolley]  
*Date*: Feb 7-8, 2012  
*SlideShare*: [{{ page.title }}](http://www.slideshare.net/BlackBerry/dev311-woolley-murray) 



## Notes and Comments

fill-in