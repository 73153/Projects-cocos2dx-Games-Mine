---
title: Blogs

layout: wanted
---
{% include common-defs.md %}

# Blogs Useful to BlackBerry Developers

## RIM Sponsored

See [Inside BlackBerry]

## Others

* [CrackBerry](http://crackberry.com "CrackBerry .com")
* [OSBB](http://opensourcebb.com/ "Open Source BlackBerry")
* [the BlackBerry thing](http://thebbthing.wordpress.com/)
  by [nunodonato](http://twitter.com/nunodonato)
* [RapidBerry](http://rapidberry.net/category/developers-2/)
* [OnOnOn!](http://ononon.weebly.com/)

### Portugues
* http://www.planetaberry.net/
* http://www.planetaberry.net/comunidade/