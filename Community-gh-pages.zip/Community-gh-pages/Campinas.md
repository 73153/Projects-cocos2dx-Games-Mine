---
layout: wanted

title: Campinas
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Campinas, Brazil
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


