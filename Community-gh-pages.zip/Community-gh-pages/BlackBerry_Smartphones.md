---
title: BlackBerry Smartphones

layout: wanted
---
{% include common-defs.md %}

Link to authoritative link to devices