---
title: TinyHippos

layout: wanted
---
{% include common-defs.md %}

# TinyHippos

Acquired by RIM. 

Logo

Wikipedia

Creators of Ripple

See [Ripple]
