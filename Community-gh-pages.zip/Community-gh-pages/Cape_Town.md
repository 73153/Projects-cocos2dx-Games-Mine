---
layout: basic

title: Cape Town
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Cape Town, South Africa
([Wikipedia](http://en.wikipedia.org/wiki/Cape_Town), [City Website](http://www.capetown.gov.za/)).

## Future Events

* July 31, 2012 - [Cape Town](http://www.blackberryjamworldtour.com/cape-town) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


