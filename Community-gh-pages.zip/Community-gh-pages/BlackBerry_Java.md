---
title: BlackBerry Java

layout: wanted
---
{% include common-defs.md %}

https://developer.blackberry.com/java/

Link to statement about NOT supported in PlayBook and BlackBerry 10

Links to java.com and JavaME.
