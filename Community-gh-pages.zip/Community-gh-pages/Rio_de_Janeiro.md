---
layout: wanted

title: Rio de Janeiro
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Rio de Janeiro, Brazil
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


