---
layout: wanted
title: Google APIs
---

### Info

Useful information to write clients interacting with Google APIs.

* [Google APIs Client Library for JavaScript](http://code.google.com/p/google-api-javascript-client/)
* [Google APIs Explorer](https://developers.google.com/apis-explorer/#p/)

### See Also
TBD