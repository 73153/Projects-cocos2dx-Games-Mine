---
layout: basic

title: Barcelona
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Barcelona, Spain
([Wikipedia](http://en.wikipedia.org/wiki/Barcelona), [City Website](http://www.bcn.cat/ca/chome.htm)).

## Future Events

TBD

## Past Events

* May 31, 2012 - [Barcelona](http://www.blackberryjamworldtour.com/barcelona) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Developer Groups

TBD


