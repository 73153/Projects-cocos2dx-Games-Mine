---
layout: basic

title: Staying Connected
---
{% include common-defs.md %}

This should include a link to all Blogs, Fan Web Sites, official sites and micro-sites, etc.

RIM *AND* non-RIM.

### Additional Links
* The [BlackBerry Slideshare Channel](http://www.slideshare.net/blackberry)

### Contacts

### See Also
TBD
