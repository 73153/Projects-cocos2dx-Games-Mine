---
layout: basic

title: Austin
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Austin, Texas
([Wikipedia](http://en.wikipedia.org/wiki/Austin,_Texas), [City Website](http://www.austintexas.gov))

## Future Events

* June 5, 2012 - [Austin](http://www.blackberryjamworldtour.com/austin) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


