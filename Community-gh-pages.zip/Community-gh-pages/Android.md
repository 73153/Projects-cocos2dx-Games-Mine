---
title: Android

layout: wanted
---
{% include common-defs.md %}

# Runtime for Android Apps

https://developer.blackberry.com/android/

* Runtime
* Repackaging Tools
* Publish to AppWorld

See also [Code_Signing]
