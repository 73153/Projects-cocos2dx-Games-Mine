---
layout: wanted

title: Laurent Hasson
oneline: RIM developer
tags: rim
---
{% include common-defs.md %}

TBD
