---
layout: basic

title: Delhi
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Delhi, India
([Wikipedia](http://en.wikipedia.org/wiki/Delhi), [City Website](http://delhi.gov.in/)).

## Future Events

* July 4, 2012 - [Delhi](http://www.blackberryjamworldtour.com/delhi) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


