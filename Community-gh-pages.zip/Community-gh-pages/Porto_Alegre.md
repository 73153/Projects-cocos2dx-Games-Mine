---
layout: wanted

title: Porto Alegre
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Porto Alegre, Brazil
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


