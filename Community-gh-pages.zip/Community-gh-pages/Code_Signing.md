---
title: Code Signing

layout: wanted
---
{% include common-defs.md %}

see https://bdsc.webapps.blackberry.com/CodeSigningHelp/
or
https://developer.blackberry.com/CodeSigningHelp/

[Get Signed Keys](https://www.blackberry.com/SignedKeys)

[AppWorld]
