---
title: Ripple Emulator is now Open Source
layout: post
---
{% include posts-defs.md %}

Today the [Ripple Emulator](http://devblog.blackberry.com/2011/06/blackberry-webworks-tooling-evolved/) has now become open source under an Apache 2.0 license.

Currently there are two repositories [Ripple-UI](https://github.com/blackberry/Ripple-UI) and [Ripple-Framework](https://github.com/blackberry/Ripple-Framework).  A third repository Ripple-qtwebview will be available shortly once a code review has completed.