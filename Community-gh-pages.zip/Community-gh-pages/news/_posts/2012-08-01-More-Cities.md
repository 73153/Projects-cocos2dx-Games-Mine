---
title: "Additional Cities in BlackBerry 10 Jam World Tour"
layout: post
---
{% include posts-defs.md %}

New cities added to the BlacKBerry 10 Jam World Tour: August 23 in [Waterloo, Ontario, Canada](http://www.blackberryjamworldtour.com/kitchener-waterloo),
August 28 in [Vancouver, BC, Canada](http://www.blackberryjamworldtour.com/vancouver)
and September 18th in [Amsterdam](http://www.blackberryjamworldtour.com/amsterdam).

_Source_: [Alex Kinsella][akinsella], via [DevBlog](http://devblog.blackberry.com/2012/08/blackberry_10_jam_new_cities_august/), on August 1, 2012
