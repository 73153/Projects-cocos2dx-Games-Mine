---
title: SNEP Support in BlackBerry 10
layout: post
---
{% include posts-defs.md %}

[Martin Wooley][mdw] and [John Murray][jcm] have added
[SNEP](http://www.nfc-forum.org/specs/spec_list/#protts) support to their NfcTool sample
([commit](https://github.com/blackberry/Cascades-Community-Samples/commit/ac7a409893bb5ea9815f492cb7c7a687ba017840)).
More details in the [Code](https://github.com/blackberry/Cascades-Community-Samples/tree/master/NfcTool) and in their
[Article](http://supportforums.blackberry.com/t5/Native-Development/NFC-on-BlackBerry-10-peer-to-peer-communication-using-SNEP/ta-p/1758859)  

_Source_: [Martin][mdw] and [John][jcm], on June 13, 2012
