---
title: "23 Extensions in WebWorks-Community-APIs"
layout: post
---
{% include posts-defs.md %}

As of this writing, the [Webworks-Community-APIs](http://github.com/blackberry/WebWorks-Community-APIs)
repository has 23 extensions: 17 for 
[Smartphone](https://github.com/blackberry/WebWorks-Community-APIs/tree/master/Smartphone)
and 6 for
[Tablet](https://github.com/blackberry/WebWorks-Community-APIs/tree/master/Tablet).
More on the way.

_Source_: [Eduardo Pelegri-Llopart][pelegri], on July 13, 2012
