---
title: "New Native Sample: NativeCamera"
layout: post
---
{% include posts-defs.md %}

Another sample from Sean: [NativeCamera](https://github.com/blackberry/Cascades-Community-Samples/tree/master/NativeCamera)
shows how to set up a Camera viewfinder in a non-cascades environment using libscreen.

_Source_: [Sean McVeight][smcveight], via [Community Wiki](http://blackberry.github.com/Community/Camera.html), on June 8, 2012.
