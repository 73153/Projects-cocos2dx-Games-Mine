---
title: "New Contributors: Rory and Martin"
layout: post
---
{% include posts-defs.md %}

We have two [new contributors](http://blackberry.github.com/approvedSignatories.html):

Rory Craig-Barnes ([glasspear](https://github.com/glasspear))
is contributing to [bbUI.js](http://github.com/blackberry/bbui.js)
and [WebWorks-Samples](http://github.com/blackberry/WebWorks-Samples).

Martin Kleinschrodt ([MaKleSoft](http://github.com/maklesoft]) is contributing to
[WebWorks-Community-APIs](https://github.com/blackberry/WebWorks-Community-APIs).

Welcome to both!  And an encouragement to others to participate in any of our projects.  Some, like
WebWorks-Community-APIs
already show a healthy
[number of contributors](https://github.com/blackberry/WebWorks-Community-APIs/contributors).


_Source_: [Eduardo Pelegri-Llopart][pelegri], on March 31, 2012
