---
title: "Refresh of BlackBerry 10 WebWorks SDK"
layout: post
---
{% include posts-defs.md %}

[Ken Wallis][kwallis] describes the latest version of the BlackBerry 10 WebWorks SDK.  Features include:
support for the Invocation Framework, File and File Transfer, Push, Context Menu, Swipe Down Event and
Multiple Localizable Splash Screens and Applications Icons.
There is also an update to the Ripple (almost out there).

_Source_: [Ken Wallis][kwallis], via [DevBlog](http://devblog.blackberry.com/2012/07/webworks-beta-july/), on July 19, 2012
