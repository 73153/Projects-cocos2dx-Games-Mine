---
title: Payment Service Sample Added
layout: post
---
{% include posts-defs.md %}

A sample application demonstrating how to use the [BlackBerry&reg; Payment Service](http://supportforums.blackberry.com/t5/Web-and-WebWorks-Development/Sample-App-BlackBerry-WebWorks-Payment-Service/ta-p/1193335) in a BlackBerry&reg; WebWorks&trade; application for the BlackBerry Tablet OS
has been added to the [WebWorks-Samples](https://github.com/blackberry/WebWorks-Samples/tree/master/payment) repository on github. The Payment Service JavaScript API provides an end-to-end payment solution for monetizing application content.