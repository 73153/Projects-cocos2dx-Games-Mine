---
title: "New Cascades Sample: LocationDiagnostics"
layout: post
---
{% include posts-defs.md %}

[Shadiq Haque][shadiq] has released a new [Cascades](../Cascades.html) sample that shows how to use the
BlackBerry 10 C++ Location APIs.  Code is available at RIM's GitHub organization, under
the [Cascades-Community-Samples repo](https://github.com/blackberry/Cascades-Community-Samples/tree/master/LocationDiagnostics).

_Source_: [Shadiq Haque][shadiq], on August 1, 2012
