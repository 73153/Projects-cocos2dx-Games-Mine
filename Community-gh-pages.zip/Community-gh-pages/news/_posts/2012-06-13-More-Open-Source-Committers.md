---
title: "More Open Source Committers: Jason (jQuery) and Gord (Apache Cordova)"
layout: post
---
{% include posts-defs.md %}

Jason Scott is now part of the [jQuery team](http://jquery.org/team). And Gord Tanner is now a committer
at [Apache Cordova](http://incubator.apache.org/projects/callback.html).  Congrats!  

_Source_: Jason and Gord, on June 13, 2012