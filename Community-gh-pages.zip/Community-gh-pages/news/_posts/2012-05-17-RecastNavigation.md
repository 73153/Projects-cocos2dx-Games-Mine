---
title: "New Repo: RecastNavigation"
layout: post
---
{% include posts-defs.md %}


The new [RecastNavigation](https://github.com/blackberry/recastnavigation) Repository at GitHub
has a port of the Recast Naviation toolkit to build navigation-meshes.  The repo has the Detour, DetourCrowd
and Recast libraries, all ported (from [Upstream](http://code.google.com/p/recastnavigation/ "RecastNavigation Upstream")) to run with BlackBerry Tablet OS and BlackBerry 10 OS.
The library will be used in a future release of Gameplay.  

_Source_: [Eduardo Pelegri-Llopart][pelegri], on May 17, 2012
