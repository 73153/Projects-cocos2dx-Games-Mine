---
title: "Roadmap for BlackBerry 10 SDKs"
layout: post
---
{% include posts-defs.md %}

Tim Neil has published the roadmap for the next BlackBerry 10 SDKs.
R4 was May, R6 is today, July.  In the future are
R8 (September), R9 (October) and R10 (November).
More details at [DevBlog](http://devblog.blackberry.com/2012/07/blackberry-10-beta-sdk-updates/).

_Source_: [Tim Neil][tneil], via [DevBlog](http://devblog.blackberry.com/2012/07/blackberry-10-beta-sdk-updates/), on Jul 19, 2012
