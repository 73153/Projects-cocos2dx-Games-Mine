---
title: "New Cascades Sample: HelloCamera"
layout: post
---
{% include posts-defs.md %}

Sean McVeight has added a new [Cascades] sample showing how to use the Camera on BlackBerry 10.
Check out the code at the [Cascades-Community-Samples](http://github.com/blackberry/Cascades-Community-Samples),
under [HelloCamera](https://github.com/blackberry/Cascades-Community-Samples/tree/master/HelloCamera).

_Source_: [Sean McVeight][smcveight], on June 1, 2012
