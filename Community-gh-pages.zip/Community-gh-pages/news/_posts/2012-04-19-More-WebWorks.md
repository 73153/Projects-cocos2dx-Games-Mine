---
title: "More WebWorks Repositories"
layout: post
---
{% include posts-defs.md %}

The WebWorks team recently promoted two of their repositories from
[BlackBerry-WebWorks](https://github.com/blackberry-webworks/)
to the top-level
[BlackBerry](http://github.com/BlackBerry) organization.

The
[BB10-WebWorks-Packager](http://github.com/blackberry/BB10-Webworks-Packager)
bundles the content of a WebWorks
Application with the
[BB10-WebWorks-Framework](http://github.com/blackberry/BB10-WebWorks-Framework)
to create a BAR that will
run on the BB10 Device (or simulator).

_Source_: [Eduardo Pelegri-Llopart][pelegri], via [OpenBBNews](http://openbbnews.wordpress.com/2012/04/19/more-webworks/), on April 19, 2012  

