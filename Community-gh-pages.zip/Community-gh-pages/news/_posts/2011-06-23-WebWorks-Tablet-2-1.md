---
title: BlackBerry WebWorks SDK for Tablet OS v2.1 Now Available
layout: post
---
{% include posts-defs.md %}

With the release of v2.1 of the BlackBerry&reg; WebWorks&trade; SDK for Tablet OS, new APIs and application functionality are [now available for download](http://devblog.blackberry.com/2011/06/blackberry-webworks-sdk-tablet-os-version-2-1/)!

The goals for this release are focused on narrowing the gap between the BlackBerry WebWorks API functionality available on the BlackBerry&reg; Smartphone OS and the APIs available on the Tablet OS, as well as exposing more BlackBerry&reg; PlayBook&trade; tablet development functionality to web developers.