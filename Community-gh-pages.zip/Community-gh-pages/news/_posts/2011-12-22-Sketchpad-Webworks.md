---
Title: SketchPad WebWorks Sample Now Available
layout: post
---
{% include posts-defs.md %}

The most recent addition to the [GitHub.com/BlackBerry/WebWorks-Samples](http://github.com/blackberry/WebWorks-Samples) 
repository is SketchPad.  This WebWorks application demonstrates how HTML5 and Touch Events can be used to drawn an image on the screen using the touch sceen or the trackpad.

SketchPad requires BlackBerry&reg; 6 or higher or BlackBerry Table OS&reg;. 
