---
title: "RIM looking for Developers!"
layout: post
---
{% include posts-defs.md %}

Research In Motion is looking to hire developers in the [WebWorks Team](http://devblog.blackberry.com/2012/07/hiring-devs/)
and in the [Developer Relations](http://devblog.blackberry.com/2012/06/hiring-javascript-developers)
teams.
There are positions available in
Canada,
China
France,
India,
Indonesia,
Poland,
Singapore,
South Korea,
and
UAE.

_Source_: DevRel, via [DevBlog](http://devblog.blackberry.com/2012/07/hiring-devs/), on July 4, 2012
