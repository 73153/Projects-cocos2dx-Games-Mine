---
title: "BlackBerry 10 Jam World Tour Update"
layout: post
---
{% include posts-defs.md %}


Updates to the [Jam Tour][jamtour] page with new cities and dates.  

_Source_: [Alex Kinsella][alexk], via [DevBlog](http://devblog.blackberry.com/2012/05/blackberry_10_jam_world_tour_update_2/ "BlackBerry 10 Jam World Tour Update"), on May 5, 2012   
