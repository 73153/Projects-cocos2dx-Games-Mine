---
title: Ogg Vorbis Now Available
layout: post
---
{% include posts-defs.md %}

Ogg Vorbis has been ported to BlackBerry&copy; PlayBook OS.  Sources are available at [GitHub.com](http://github.com/blackberry/OggVorbis). Feedback via [SupportForums](http://supportforums.blackberry.com/t5/Native-SDK-for-BlackBerry-Tablet/bd-p/native_sdk) and [Issues](https://github.com/blackberry/OggVorbis/issues).

The [Vorbis project](http://vorbis.com) produces an audio format specification and software implementation (codec) for lossy audio compression. Vorbis is most commonly used in conjunction with the Ogg container format and it is therefore often referred to as Ogg Vorbis.