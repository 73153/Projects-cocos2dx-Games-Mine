---
title: "New Cascades Sample: HelloOggVorbis"
layout: post
---
{% include posts-defs.md %}

[Ramprasad Madhavan][ram7] authored a new sample to [Cascades-Community-Samples](http://github.com/BlackBerry/Cascades-Community-Samples)
that shows how to do basic Ogg file handling using OpenAL and OggVorbis from Cascades.
The [commit](https://github.com/blackberry/Cascades-Community-Samples/pull/9) was accepted today.

_Source_: [Ramprasad Madhavan](https://github.com/rmadhavan), on July 23, 2012

