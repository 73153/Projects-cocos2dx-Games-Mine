---
title: BlackBerry Open Source Wiki now Live
layout: post
---
{% include posts-defs.md %}

We now have a [single wiki for all open source projects](http://blackberry.github.com) at Research In Motion.  This allows us to move wiki content out of the repository based wiki's and to the main one covering all OSS projects.

Keeping wiki's on a per-repository basis made it difficult to find project based information.  