---
title: Cleanup of Qt Repo and Gitorious
layout: post
---
{% include posts-defs.md %}

We are now contributing directly upstream to [Gitorious](http://qt.gitorious.org/qt), and, as a consequence,
the [old repo](https://github.com/blackberry/Qt) is, at best, a duplicate.
Code has been removed but download files will still be here - currently a tad out of date.

_Source_: Rafael Roquetto, on June 13, 2012