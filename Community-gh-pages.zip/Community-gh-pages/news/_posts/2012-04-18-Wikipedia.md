---
title: "Official Wikipedia App"
layout: post
---
{% include posts-defs.md %}

The HTML5/PhoneGap-based [mentioned in January](http://openbbnews.wordpress.com/2012/01/25/wikipediamobile-on-playbook/)
is now available for the
PlayBook. This is the official client to Wikipedia from the
[Wikimedia foundation](http://wikimediafoundation.org/).

Go [visit AppWorld](http://appworld.blackberry.com/webstore/content/105171/?lang=en)
and download it.

_Source_: [Eduardo Pelegri-Llopart][pelegri], via [OpenBBNews](http://openbbnews.wordpress.com/2012/04/18/wikipedia-app-available/), on April 18, 2012  

