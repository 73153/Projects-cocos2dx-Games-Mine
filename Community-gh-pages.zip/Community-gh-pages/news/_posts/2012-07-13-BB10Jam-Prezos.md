---
title: "BlackBerry 10 Jam Tour Presentations"
layout: post
---
{% include posts-defs.md %}

BlackBerry 10 Jam World Tour presentations are [Now Available](http://www.blackberryjamworldtour.com/presentations)

_Source_: [Eduardo Pelegri-Llopart][pelegri], on July 13, 2012
