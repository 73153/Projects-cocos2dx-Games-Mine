---
title: "Lua and Bullet Physics Updates"
layout: post
---
{% include posts-defs.md %}

[Lua](../Lua.html) was updated to version 5.2 on [May 15, 2012](https://github.com/blackberry/Lua/commit/ecfbcc12ff04a88927b4d1ff6ba542fcd61be59a).
[Bullet Physics](../Bullet_Physics.html) was updated to version 2.8 on
[May 17, 2012](https://github.com/blackberry/Bullet/commit/f3c9586c66f80a289dd26e4c33f243317e5da66f).

_Source_: RIM Gaming group, on June 22, 2012
