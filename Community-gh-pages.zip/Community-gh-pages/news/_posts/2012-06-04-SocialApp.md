---
title: "New at Samples-for-Java: SocialApp"
layout: post
---
{% include posts-defs.md %}

[SocialApp](https://github.com/blackberry/Samples-for-Java/tree/master/SocialApp)
demonstrates how BlackBerry Java developers
can integrate with native social apps such as Facebook, Twitter etc.

_Source_: [Shadiq Haque](https://github.com/shaque), on June 4, 2012
