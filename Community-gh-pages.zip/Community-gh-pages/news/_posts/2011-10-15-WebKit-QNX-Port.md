---
title: WebKit QNX Port
layout: post
---
{% include posts-defs.md %}

RIM is in the process of integrating its QNX port into the [WebKit.org](http://webkit.org) repository.  RIM has included WebKit into its products since 2009 but this announcement marks an intention to do more development at webkit.org.

For full details, see [George's email](https://lists.webkit.org/pipermail/webkit-dev/2011-October/018264.html) to the WebKit DEV mailing list.

