---
title: "New to Samples-for-AIR: SampleBPSANE"
layout: post
---
{% include posts-defs.md %}

Julian has added the sample shown at [BlackBerry 10 Jam][bb10jam] in Orlando that accessed
[BPS] using [Native Extensions for Adobe AIR](http://www.adobe.com/devnet/air/native-extensions-for-air.html).
Code in the [SampleBPSANE](https://github.com/blackberry/Samples-for-AIR/tree/master/SampleBPSANE) directory of
[Samples-for-AIR](http://github.com/blackberry/Samples-for-AIR) repo.

_Source_: [Julian Dolce][jdolce], on June 12, 2012
