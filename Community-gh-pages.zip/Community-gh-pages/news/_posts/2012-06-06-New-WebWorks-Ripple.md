---
title: "Update to WebWorks and Ripple"
layout: post
---
{% include posts-defs.md %}

New versions of BlackBerry 10 WebWorks SDK and Ripple available from [download page](http://devblog.blackberry.com/2012/06/blackberry-10-webworks-sdk-ripple-update/).
Open Source repos are [Ripple-UI](https://github.com/blackberry/Ripple-UI) and
[BB10-WebWorks-Packager](https://github.com/blackberry/BB10-Webworks-Packager).
On the last one, we are in the middle of consolidating the WebWorks repos for BlackBerry 10, so stay tuned.

_Source_: [Ken Wallis][kwallis], at [DevBlog](), on June 6, 2012
