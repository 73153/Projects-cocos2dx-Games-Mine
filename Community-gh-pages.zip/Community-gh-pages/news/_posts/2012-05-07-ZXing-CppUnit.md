---
title: "ZXing and CppUnit ported to BlackBerry 10"
layout: post
---
{% include posts-defs.md %}

Cliff has ported [ZXing](http://github.com/blackberry/zxing)
and
[CppUnit](http://github.com/blackberry/CppUnit) to BlackBerry 10.

_Source_: [Cliff Hung][chung], via [OpenBBNews](http://openbbnews.wordpress.com/2012/05/07/zxing-cppunit/), on May 7, 2012 

