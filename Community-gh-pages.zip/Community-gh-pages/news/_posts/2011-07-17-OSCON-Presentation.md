---
title: OSCON Presentation
layout: post
---
{% include posts-defs.md %}

Recently RIM attended [OSCON](http://www.oscon.com/oscon2011) to talk about our open source goals. You can check out the slides from the session below.

[BlackBerry And Open Source, Really? Why You Should Care](http://www.oscon.com/oscon2011/public/schedule/detail/21532)