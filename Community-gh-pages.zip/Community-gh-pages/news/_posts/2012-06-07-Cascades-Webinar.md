---
title: "Online Webinar for Cascades"
layout: post
---
{% include posts-defs.md %}

Next June 19th there will be an online webinar for Cascades.  Check out [Details](http://devblog.blackberry.com/2012/06/your-second-chance-at-getting-started-with-cascades/)
and [register](http://developer.blackberry.com/cascades/webcasts).
Time is 11am ET - or [convert to your timezone](http://www.timeanddate.com/worldclock/fixedtime.html?iso=20120619T1500).

_Source_: [DevBlog](http://devblog.blackberry.com/2012/06/your-second-chance-at-getting-started-with-cascades/), on June 7, 2012
