---
title: New Community APIs Repository
layout: post
---
{% include posts-defs.md %}

The [WebWorks-Community-APIs repository](https://github.com/blackberry/WebWorks-Community-APIs) has been created as an area where members of the community can post up their JavaScript Extensions to share with the rest of the world.

This area is a collection of APIs that are not part of the official BlackBerry&reg; WebWorks&trade; SDK but may prove as a testing ground for new APIs before they are officially added to the WebWorks SDK

All APIs shared in this repository are Open Source under the Apache 2.0 License