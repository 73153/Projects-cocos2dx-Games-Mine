---
title: "BlackBerry Samples for jQuery Mobile"
layout: post
---
{% include posts-defs.md %}

New repo [jQuery-Mobile-Samples](http://github.com/blackberry/jquery-mobile-samples) to be used
to contribute to the [jQuery Mobile Cookbook](http://jquerymobilecookbook.com/) project.  

_Source_: [Tim Windsor][twindsor], via [DevBlog](http://devblog.blackberry.com/2012/05/jquery-mobile-blackberry-samples/ "BlackBerry Samples for jQuery Mobile"), on May 14, 2012   

