---
title: JDE Samples Now Available
layout: post
---
{% include posts-defs.md %}

The JDE-Samples open source project, [GitHub.com/BlackBerry/JDE-Samples](http://github.com/blackberry/JDE-Samples), contains the source code for samples provided in the BlackBerry JDE and BlackBerry Java Plug-in for Eclipse. These samples cover the many APIs available in the BlackBerry Java SDK, starting from the 4.5.0 release.

Read more about the components and the repository in this [Introduction Post](http://openbbnews.wordpress.com/2011/12/12/java-sample-repositories/).
