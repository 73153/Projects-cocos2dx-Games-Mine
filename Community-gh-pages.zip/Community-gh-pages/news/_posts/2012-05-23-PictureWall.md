---
title: "PictureWall Sample"
layout: post
---
{% include posts-defs.md %}


[PictureWall](http://github.com/blackberry/picturewall) is a new HTML5 sample that displays one or more pictures
on a _wall_ of PlayBooks, served from a [node.js](http://nodejs.org/) application
using [socket.io](http://socket.io/).
More details at [DevBlog](http://devblog.blackberry.com/2012/05/picturewall-html5-sample/)

_Source_: [Eduardo Pelegri-LLopart][pelegri], on May 23, 2012
