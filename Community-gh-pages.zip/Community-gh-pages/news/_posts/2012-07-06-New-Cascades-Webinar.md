---
title: "New Cascades Webinar"
layout: post
---
{% include posts-defs.md %}

[Register now](http://www.blackberrydeveloperevents.com/events/webcast/registration/register.html?scoid=1051105884) for the next Cascades Webinar.  The topic is
*"Connecting, Retrieving, Storing and Displaying your Data"*.
Date is July 10, 2012, 11am ET
\([TZ converter](http://www.timeanddate.com/worldclock/fixedtime.html?iso=20120710T1500)\).

_Source_: [Garett], via [DevBlog](http://devblog.blackberry.com/2012/07/cascades-cascades-cascades-webcasts-webcasts-webcasts/), on July 6, 2012
