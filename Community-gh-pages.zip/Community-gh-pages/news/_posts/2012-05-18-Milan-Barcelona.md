---
title: "Registration open for Milan and Barcelona"
layout: post
---
{% include posts-defs.md %}


Registration for the Milan and Barcelona stops of the BlackBerry 10 [Jam World Tour][jamtour] is now open.  

_Source_: [Eduardo Pelegri-Llopart][pelegri], on May 18, 2012  
