---
title: "New Camera Sample: Video Recording"
layout: post
---
{% include posts-defs.md %}

[Sean McVeigh][smcveight] pushed out a new sample to the Cascades-Community-Samples repository.
Download [HelloVideoCamera](https://github.com/blackberry/Cascades-Community-Samples/tree/master/HelloVideoCamera) and try it out on your Dev Alpha!

_Source_: [Sean McVeigh][smcveight], on July 6, 2012


