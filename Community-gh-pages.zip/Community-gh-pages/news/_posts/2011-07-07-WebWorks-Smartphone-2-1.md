---
title: BlackBerry WebWorks SDK for Smartphones v2.1 Now Available
layout: post
---
{% include posts-defs.md %}

New APIs and application functionality are [now available for download](http://devblog.blackberry.com/2011/07/blackberry-webworks-sdk-smartphones-v2-1/) with the release of v2.1 of the BlackBerry&reg; WebWorks&trade; SDK for smartphones! 

The goals for this release are focused on bringing new BlackBerry WebWorks functionality and APIs to the BlackBerry&reg; smartphone OS and continue the convergence between the BlackBerry WebWorks SDK on BlackBerry&reg; Tablet OS.