---
title: "BlackBerry 10 Games at NordicGame"
layout: post
---
{% include posts-defs.md %}


Sean Taylor and [Anders Jeppsson][ajeppsson] (RIM) and Tim Closs (Marmalade) will present on Gaming on BlackBerry 10
and Native Development for BlackBerry 10 at [NordicGame](http://nordicgame.com/).
Sean will present the latest features of [Gameplay](http://github.com/blackberry/gameplay "Gameplay at our GitHub").  

_Source_: [Eduardo Pelegri-Llopart][pelegri], on May 20, 2012 

