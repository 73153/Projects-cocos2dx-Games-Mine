---
title: Aura Now Available
layout: post
---
{% include posts-defs.md %}

Aura is a proof-of-concept WebWorks application created by [TAT](http://tat.se)  that integrates HTML5, Accelerometer data and CSS3.  Aura was initially [demonstrated at Mobile World Congress 2011](http://www.youtube.com/watch?v=uH7NKhNyygw) and allows a user to select from a 4-day Weather forecast of [Barcelona](http://en.wikipedia.org/wiki/Barcelona), and interact with the application elements by physically moving the BlackBerry device.

On August 5th, _Aura_ became the first sample at the new [WebWorks-Samples](https://github.com/blackberry/WebWorks-Samples/tree/master/Aura) repository under the Apache 2.0 License.  Expect more samples to follow in the near future.
