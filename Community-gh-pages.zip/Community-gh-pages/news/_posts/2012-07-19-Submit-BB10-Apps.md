---
title: "Submit your BlackBerry 10 Applications now!"
layout: post
---
{% include posts-defs.md %}

Tim has announced that developers can start submitting their BlackBerry 10 Applications to
BlackBerry App World today to share with other BlackBerry 10 developers for early feedback.

_Source_: [Tim Neil][tneil], via [DevBlog](http://devblog.blackberry.com/2012/07/blackberry-10-beta-sdk-updates/), on Jul 19, 2012
