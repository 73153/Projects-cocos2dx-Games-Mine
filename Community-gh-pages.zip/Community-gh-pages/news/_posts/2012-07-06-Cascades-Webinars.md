---
title: "Recordings of Cascades Webcasts Available"
layout: post
---
{% include posts-defs.md %}

The recordings of the first two [Cascades](../Cascades.html) webinars
are now available in the
[videos page](https://developer.blackberry.com/cascades/documentation/videos/index.html) of the microsite.

_Source_: [Garett], via [DevBlog](http://devblog.blackberry.com/2012/07/cascades-cascades-cascades-webcasts-webcasts-webcasts/), on July 6, 2012

