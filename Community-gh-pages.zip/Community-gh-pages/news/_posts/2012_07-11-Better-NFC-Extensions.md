---
title: "Improved WebWorks NFC Extension"
layout: post
---
{% include posts-defs.md %}

Improved WebWorks NFC Extension for Smartphones
([WebWorks-Community-APIs#79](https://github.com/blackberry/WebWorks-Community-APIs/pull/79))
with support for a wide range of message types
that can be stored on an NFC tag.

_Source_: [Rob Williams], July 11, 2012
 
