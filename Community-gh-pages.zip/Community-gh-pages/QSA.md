---
title: QSA
redirect-page: QNX_Sound_Architecture
redirect-seconds: 0
redirect-message: "Please wait while we redirect you to QNX_Sound_Architecture"
layout: redirect
---
