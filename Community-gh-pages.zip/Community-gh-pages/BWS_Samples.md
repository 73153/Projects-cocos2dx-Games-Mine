---
layout: wanted

title: BlackBerry Web Services Samples
oneline: Repo with samples showcasing BlackBerry Web Services
tags: BWS, HTML5
---
{% include common-defs.md %}

### RIM Repositories
[BlackBerry Web Services Samples][repo:bws]

### Other Repositories
TBD

### See Also
[BWS]