---
title: FreeImage

layout: wanted
---
{% include common-defs.md %}

## Notes

[WebSite](http://freeimage.sourceforge.net/license.html)

Port:
[tweet](http://bit.ly/MaMulx)/[@lynxluna](http://twitter.com/lynxluna), [repo](https://github.com/lynxluna/freeimage)
