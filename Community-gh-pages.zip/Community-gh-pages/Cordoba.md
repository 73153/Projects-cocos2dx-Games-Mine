---
layout: wanted

title: Cordoba
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Cordoba, Argentina
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


