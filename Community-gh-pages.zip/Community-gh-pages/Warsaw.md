---
layout: basic

title: Warsaw
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Warsaw, Poland
([Wikipedia](http://en.wikipedia.org/wiki/warsaw), [City Website](http://www.um.warszawa.pl/)).

## Future Events

* July 3, 2012 - [Warsaw](http://www.blackberryjamworldtour.com/warsaw) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


