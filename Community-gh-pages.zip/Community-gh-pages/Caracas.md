---
layout: wanted

title: Caracas
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Caracas, Venezuela
TBD

## Future Events

TBD

## Past Events

TBD

## Developer Groups

TBD


