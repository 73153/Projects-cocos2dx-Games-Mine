---
layout: people

title: Tim Neil
oneline: RIM developer
tags: rim
---
{% include common-defs.md %}

### Description

WebWorks founder. Product Manager. [bbUI.js] lead

### Additional Links

### Also See
[bbUI.js]
