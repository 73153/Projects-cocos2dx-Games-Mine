---
layout: people

title: Laurence Muller
oneline: Individual Developer
tags: individual
---
{% include common-defs.md %}

### Description

Partner in MultiGesture.net.  One of leads in port of [OpenFrameworks]

### Additional Links
* [Multigesture.net](http://www.multigesture.net/)
* [NodeBeat](http://nodebeat.com)

### See Also
[OpenFrameworks], [NodeBeat]
