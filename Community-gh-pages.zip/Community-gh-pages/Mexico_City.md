---
layout: basic

title: Mexico City
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Mexico City, Mexico
([Wikipedia](http://en.wikipedia.org/wiki/Mexico_city), [City Website](http://www.df.gob.mx/)).

## Future Events

* August 21, 2012 - [Mexico City](http://www.blackberryjamworldtour.com/mexico-city) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


