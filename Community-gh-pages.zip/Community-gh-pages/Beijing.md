---
layout: basic

title: Beijing
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Beijing, China
([Wikipedia](http://en.wikipedia.org/wiki/Beijing), [City Website](http://www.ebeijing.gov.cn/)).

## Future Events

* July 6, 2012 - [Beijing](http://www.blackberryjamworldtour.com/beijing) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


