---
layout: basic

title: Singapore
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Singapore
([Wikipedia](http://en.wikipedia.org/wiki/Singapore), [City Website](http://www.gov.sg/)).

## Future Events

* July 9, 2012 - [Singapore](http://www.blackberryjamworldtour.com/singapore) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


