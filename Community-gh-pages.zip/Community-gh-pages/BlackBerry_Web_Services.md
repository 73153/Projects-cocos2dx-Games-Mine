---
title: BlackBerry Web Services
oneline: BlackBerry Web Services for Enterprise Adminstration
forum: 
techlink: 
tags: server, bes

layout: technology
---
{% include common-defs.md %}

### Description

A collection of document-style web services to perform adminstration tasks on a [BlackBerry Enterprise Server][BES].

See the [Main Page](https://developer.blackberry.com/services/push/)

### Samples

See [Samples at GitHub](https://github.com/blackberry/BWS-Samples)

### Also See
[BlackBerry Services]
