---
layout: wanted
x-layout: component

title: Box2D
name: Box2D
oneline: Physics engine
status: 
platform: Native
complink: http://box2d.org
license: ZLIB
tags: OpenSource, Native, Component
---
{% include common-defs.md %}

### Description
Box2D Physics Engine - A 2D rigid body simulation physics library for games

### Additional Links

* [Port](http://github.com/blackberry/Box2D)
* Official [website](http://Box2D.org), [About](http://Box2D.org/about) and [documentation](http://Box2D.org/documentation)
* Tutorial at [iForce2d](http://www.iforce2d.net/b2dtut/introduction)

### Contacts
TBD

### Also See
[Gaming], [Gameplay]
