---
layout: basic

title: Berlin
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Berlin, Germany
([Wikipedia](http://en.wikipedia.org/wiki/Berlin), [City Website](http://www.berlin.de/international/index.en.php)).

## Future Events

* June 28, 2012 - [Berlin](http://www.blackberryjamworldtour.com/santa-clara) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


