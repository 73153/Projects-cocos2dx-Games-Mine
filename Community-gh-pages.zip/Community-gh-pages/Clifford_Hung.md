---
layout: people

title: Clifford Hung
oneline: Team Lead at RIM
tags: RIM
---
{% include common-defs.md %}

### Description

Development lead at RIM for several open source ports to PlayBook and SQLite on BlackBerry.

Cliff is a good guy (tm) :)

### Additional Links
* [Posts by Cliff at OpenBBNews](http://openbbnews.wordpress.com/author/chungrim)
* [Cliff at GitHub](http://github.com/hungc)

### Also See
TBD
