---
layout: basic

title: Moscow
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Moscow, Russia
([Wikipedia](http://en.wikipedia.org/wiki/Moscow), [City Website](http://www.mos.ru/)).

## Future Events

* June 26, 2012 - [Moscow](http://www.blackberryjamworldtour.com/moscow) stop in [BlackBerry 10 Jam World Tour][bb10jam].

## Past Events

TBD

## Developer Groups

TBD


