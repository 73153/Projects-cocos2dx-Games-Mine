---
layout: basic

title: Amsterdam
---
{% include common-defs.md %}

## Overview

BlackBerry Developer Community in the area around Amsterdam
([Wikipedia](http://en.wikipedia.org/wiki/Amsterdam), [City Website](http://www.amsterdam.nl/)).

## Future Events

TBD

## Past Events

TBD

## Developer Groups

### BlackBerry Developer Group Netherlands

*Website*: [bbdevgroup.nl](http://bbdevgroup.nl/)  
*Twitter*: [@BBDevGroupNL](https://www.twitter.com/BBDevGroupNL)  
*FaceBook*: [BBDevGroupNL](http://www.facebook.com/pages/BBDevGroupNL/236098699811093)  
*Meetup*: [BBDevGroupNL](http://www.meetup.com/BBDevGroupNL/)  
*Mail*: [info@bbdevgroup.nl](mailto:info@bbdevgroup.nl)  

