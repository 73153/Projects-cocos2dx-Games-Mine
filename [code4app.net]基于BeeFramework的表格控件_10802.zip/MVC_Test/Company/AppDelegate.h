//
//  AppDelegate.h
//  Company
//
//  Created by azayyl on 13-7-5.
//  Copyright (c) 2013年 azayyl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
