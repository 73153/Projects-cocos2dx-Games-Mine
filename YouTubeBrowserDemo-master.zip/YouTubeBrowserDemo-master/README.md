YouTubeBrowserDemo
==================

A fully functional iOS app that uses the YouTube JSON search API to demonstrate JSONModel usage

![Browser screen](http://www.touch-code-magazine.com/wp-content/uploads/2013/02/yt_run1.png)
![Player screen](http://www.touch-code-magazine.com/wp-content/uploads/2013/02/yt_playing.png)

This project accompanies the following tutorial, for detailed explanation and code walk-through click here: 

http://www.touch-code-magazine.com/how-to-make-a-youtube-app-using-mgbox-and-jsonmodel/
