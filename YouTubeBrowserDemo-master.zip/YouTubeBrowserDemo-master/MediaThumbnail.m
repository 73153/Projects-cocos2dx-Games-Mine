//
//  MediaThumbnail.m
//  YTBrowser
//
//  Created by Marin Todorov on 03/01/2013.
//  Copyright (c) 2013 Underplot ltd. All rights reserved.
//

#import "MediaThumbnail.h"

@implementation MediaThumbnail

@end
