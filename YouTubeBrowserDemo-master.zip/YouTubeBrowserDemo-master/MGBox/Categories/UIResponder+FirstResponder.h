//
//  By VJK on Stack Overflow: http://stackoverflow.com/a/10358135/790036
//

@interface UIResponder (FirstResponder)

- (id)currentFirstResponder;

@end
