//
//  Created by Matt Greenfield on 24/05/12
//  http://bigpaua.com/
//

#import "MGTableBox.h"

@interface MGTableBoxStyled : MGTableBox

@end
