PWLoadMoreTableFooter
=====================

A similar control to the load more control. Idea come from [enormego / EGOTableViewPullRefresh](https://github.com/enormego/EGOTableViewPullRefresh)

## How to use?
### With [CocoaPods](http://cocoapods.org)
Edit your Podfile with  
```
pod 'PWLoadMoreTableFooter', '~>1.0.1'
```  
### Without CocoaPods
1. Add the PWLoadMoreTableFooterView.h and PWLoadMoreTableFooterView.m file to your project
2. Follow the demo project to code right
3. And it should work!

## What's next?
1. Tell me

## Authors and Contributors
In 2013, Puttin Wong([@puttin](https://github.com/puttin)) founded PWLoadMoreTableFooter.

## Support or Contact
Having trouble with this project? Create a new issue.
