//
//  testpickerviewTests.h
//  testpickerviewTests
//
//  Created by hou wenjie on 11-7-12.
//  Copyright 2011年 cqupt. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface testpickerviewTests : SenTestCase {
@private
    
}

@end
