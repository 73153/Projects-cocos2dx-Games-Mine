//
//  testpickerviewTests.m
//  testpickerviewTests
//
//  Created by hou wenjie on 11-7-12.
//  Copyright 2011年 cqupt. All rights reserved.
//

#import "testpickerviewTests.h"


@implementation testpickerviewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in testpickerviewTests");
}

@end
