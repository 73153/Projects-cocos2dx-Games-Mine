/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatSprite.h"

#include "CatScript.h"
#include "CatBrick.h"
#include "CatUtils.h"
#include "CCGeometry.h"
#include "CCTextureCache.h"
#include "CCActionManager.h"

using namespace cocos2d;

CatSprite::CatSprite( const std::string& name ) : mName( name ), mReceivedSignal( "" )
{
}

CatSprite::~CatSprite()
{
}

CatSprite* CatSprite::newCatSpriteWithNameAndCostume( const std::string& name, const std::string& path )
{
    CatSprite *sprite = new CatSprite( name );
    if ( sprite && sprite->initWithFile( path.c_str() ) )
    {
        sprite->autorelease();
        sprite->addCostumeTexture( sprite->getTexture() );
        sprite->mCurrentCostumeIndex = 0;
        return sprite;
    }
    CC_SAFE_DELETE( sprite );
    return NULL;
}

void CatSprite::setCatProject( const SharedPtr<CatProject>::Type& project )
{
    mCatProject = WeakPtr<CatProject>::Type( project );
}

void CatSprite::addCostumeTexture( const std::string& path )
{
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage( path.c_str() );
    addCostumeTexture( texture );
}

void CatSprite::addCostumeTexture( CCTexture2D* texture )
{
    mCostumeTextures.push_back( texture );
}

void CatSprite::addCatScript( SharedPtr<CatScript>::Type script )
{
    mCatScripts.push_back( script );
}

void CatSprite::setCostumeTexture( const size_t& index )
{
    if ( index < mCostumeTextures.size() )
    {
        setTexture( mCostumeTextures[index] );
        mCurrentCostumeIndex = index;
    }
}

void CatSprite::setNextCostumeTexture()
{
    if ( mCurrentCostumeIndex < mCostumeTextures.size() - 1 )
    {
        mCurrentCostumeIndex++;
    }
    else
    {
        mCurrentCostumeIndex = 0;
    }
    setTexture( mCostumeTextures[mCurrentCostumeIndex] );
}

const std::string CatSprite::name()
{
    return mName;
}

const std::vector<SharedPtr<CatScript>::Type>& CatSprite::catScripts()
{
    return mCatScripts;
}

const SharedPtr<CatProject>::Type CatSprite::catProject()
{
    return mCatProject.lock();
}

void CatSprite::scheduleOnStart()
{
    scheduleOnce( schedule_selector( CatSprite::onStart ), 0 );
}

void CatSprite::scheduleOnTouch()
{
    scheduleOnce( schedule_selector( CatSprite::onTouch ), 0 );
}

void CatSprite::scheduleOnSignal( const CatScript::ControlType& signal )
{
    mReceivedSignal = signal;
    scheduleOnce( schedule_selector( CatSprite::onSignal ), 0 );
}

void CatSprite::onStart()
{
    runScript( CatScript::ON_START );
}

void CatSprite::onTouch()
{
    runScript( CatScript::ON_TOUCH );
}

void CatSprite::onSignal()
{
    runScript( mReceivedSignal );
}

void CatSprite::runScript( const CatScript::ControlType& type )
{
    for ( int i = 0; i < mCatScripts.size(); i++ )
    {
        SharedPtr<CatScript>::Type script = mCatScripts[i];
        if ( script->controlType() == type && !script->isScriptRunning() )
        {
            try
            {
                script->runScript( this );
            }
            catch ( CatException e )
            {
                CCLog( "[IRONPAWS] Cannot run script: %s", e.what() );
                CCMessageBox( "Cannot run script.", "ERROR" );
            }
        }
    }
}

bool CatSprite::collidesWith( const CCPoint& point )
{
    // Very basic collision detection using bounding boxes. Maybe implement this later:
    // http://www.learn-cocos2d.com/2011/12/fast-pixelperfect-collision-detection-cocos2d-code-1of2
    const CCPoint& costumePosition = getPosition();
    const CCSize& costumeSize = getContentSize();
    
    CCRect rect = CCRectMake(costumePosition.x - costumeSize.width / 2,
                             costumePosition.y - costumeSize.height / 2,
                             costumeSize.width,
                             costumeSize.height);
    
    return rect.containsPoint( point );
}
