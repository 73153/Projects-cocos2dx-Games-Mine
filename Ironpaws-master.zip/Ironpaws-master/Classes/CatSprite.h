/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATSPRITE_H_
#define _CATSPRITE_H_

#include "CatCommon.h"
#include "CatScript.h"
#include "CCSprite.h"
#include <string>
#include <vector>

class CatProject;

/**
 * CatSprite is an auto-release object, it is managed by the cocos2d-x framework.
 */
class CatSprite : public cocos2d::CCSprite
{
private:
    CatSprite( const std::string& name );
    CatSprite( const CatSprite& cp );
    
    void onStart();
    void onTouch();
    void onSignal();
    
    void runScript( const CatScript::ControlType& type );
    
    std::vector<SharedPtr<CatScript>::Type> mCatScripts;
    std::vector<cocos2d::CCTexture2D*> mCostumeTextures;
    
    const std::string mName;
    size_t mCurrentCostumeIndex;
    CatScript::ControlType mReceivedSignal;
    WeakPtr<CatProject>::Type mCatProject;
    
public:
    ~CatSprite();
        
    static CatSprite* newCatSpriteWithNameAndCostume( const std::string& name,
                                                      const std::string& path );
    
    void setCatProject( const SharedPtr<CatProject>::Type& project );
    void addCostumeTexture( cocos2d::CCTexture2D* texture );
    void addCostumeTexture( const std::string& path );
    void addCatScript( SharedPtr<CatScript>::Type script );
    void setCostumeTexture( const size_t& index );
    void setNextCostumeTexture();
        
    void scheduleOnStart();
    void scheduleOnTouch();
    void scheduleOnSignal( const CatScript::ControlType& signal );
    
    const std::string name();
    const std::vector<SharedPtr<CatScript>::Type>& catScripts();
    const SharedPtr<CatProject>::Type catProject();
    
    bool collidesWith( const cocos2d::CCPoint& point );
};

#endif // _CATSPRITE_H_
