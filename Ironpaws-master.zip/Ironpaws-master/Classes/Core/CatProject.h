/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATPROJECT_H_
#define _CATPROJECT_H_

#include "CatCommon.h"
#include <string>
#include <vector>

class CatSprite;

/**
 * CatProject is the root object in a Catrobat program. Shared pointers are used
 * for all Cat-objects except when they are derived from cocos-classes.
 * All cocos2dx-objects are auto-released. This means no 'delete' command should
 * be used anywhere in this code.
 */
class CatProject
{
private:
    CatProject( const CatProject& cp );
            
    std::string mProjectName;
    // CatSprite is an auto-release object.
    std::vector<CatSprite*> mCatSprites;
    
public:
    CatProject( const std::string& projectName );
    ~CatProject();
            
    void addCatSprite( CatSprite* sprite );
    
    const std::string& projectName() const;
    const std::vector<CatSprite*>& catSprites() const;
    
    void changeSpriteZOrderBy( CatSprite* sprite, int dz );
};

#endif // _CATPROJECT_H_
