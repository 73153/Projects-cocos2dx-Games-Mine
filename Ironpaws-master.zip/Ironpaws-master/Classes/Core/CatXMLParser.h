/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATXMLPARSER_H_
#define _CATXMLPARSER_H_

#include "CatCommon.h"
#include "tinyxml2.h"
#include <string>
#include <vector>
#include <stdexcept>

class CatProject;
class CatSprite;
class CatScript;
class CatBrick;
namespace cocos2d { class CCPoint; }

class CatXMLParser
{
private:
    CatXMLParser( const CatXMLParser& cp );
    
    CatSprite* parseCatSprite( const tinyxml2::XMLElement* xml );
    std::vector<SharedPtr<CatScript>::Type> parseCatScript( const tinyxml2::XMLElement* xml );
    SharedPtr<CatScript>::Type newCatScript( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseCatBrick( const tinyxml2::XMLElement* xml );
    
    SharedPtr<CatBrick>::Type parseSetCostumeBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseGlideToBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parsePlaceAtBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseSetXCoordBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseSetYCoordBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseChangeXByBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseChangeYByBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseGoNStepsBackBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseSetOpacityBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseChangeOpacityBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseWaitBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parsePlaySoundBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseLoopFiniteBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseSetScaleBrick( const tinyxml2::XMLElement* xml );
    SharedPtr<CatBrick>::Type parseChangeScaleBrick( const tinyxml2::XMLElement* xml );
    const cocos2d::CCPoint coordinateHelper( const float& x, const float& y );
    
    tinyxml2::XMLDocument mXMLDoc;
    const std::string mProjectRoot;
    std::vector<SharedPtr<CatScript>::Type> mEmbeddedScripts;
    bool mIsParsingEmbeddedScript;
    
public:
    CatXMLParser( const std::string& projectRoot );
    ~CatXMLParser();
    
    SharedPtr<CatProject>::Type parseCatProject();
    
    class CatParseException : public std::runtime_error
    {
    public:
        CatParseException( const std::string& error ) : std::runtime_error( error ) {}
    };
    
private:
    class CatParseSkipException : public std::runtime_error
    {
    public:
        CatParseSkipException( const std::string& error ) : std::runtime_error( error ) {}
    };
    
    class EmbeddedScriptException : public std::runtime_error
    {
    public:
        EmbeddedScriptException( const std::string& error ) : std::runtime_error( error ) {}
    };
};

#endif // _CATXMLPARSER_H_
