/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "SpritePlaceAction.h"

SpritePlaceAction::SpritePlaceAction( const float& x, const float& y, const ModificationType& type ) :
    CatBaseAction( type ), mX( x ), mY( y )
{
}

cocos2d::CCFiniteTimeAction* SpritePlaceAction::createOffsetBy( const float& x, const float& y )
{
    RETURN_CAT_ACTION( new SpritePlaceAction( x, y, Relative ) );
}

cocos2d::CCFiniteTimeAction* SpritePlaceAction::createSetPosition( const float& x, const float& y )
{
    RETURN_CAT_ACTION( new SpritePlaceAction( x, y, Absolute ) );
}

cocos2d::CCFiniteTimeAction* SpritePlaceAction::createSetXPosition( const float& x )
{
    RETURN_CAT_ACTION( new SpritePlaceAction( x, NAN, Other ) );
}

cocos2d::CCFiniteTimeAction* SpritePlaceAction::createSetYPosition( const float& y )
{
    RETURN_CAT_ACTION( new SpritePlaceAction( NAN, y, Other ) );
}

void SpritePlaceAction::action( CatSprite *sprite )
{
    if ( mType == Relative )
    {
        cocos2d::CCPoint position = sprite->getPosition();
        position.x += mX;
        position.y += mY;
        sprite->setPosition( position );
    }
    else if ( mType == Absolute )
    {
        sprite->setPosition( cocos2d::CCPoint( mX, mY ) );
    }
    else if ( mY == NAN )
    {
        const cocos2d::CCPoint& oldPosition = sprite->getPosition();
        sprite->setPosition( cocos2d::CCPoint( mX, oldPosition.y ) );
    }
    else
    {
        const cocos2d::CCPoint& oldPosition = sprite->getPosition();
        sprite->setPosition( cocos2d::CCPoint( oldPosition.x, mY ) );
    }
}
