/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _SPRITE_PLACE_ACTION_H_
#define _SPRITE_PLACE_ACTION_H_

#include "CatBaseAction.h"

class SpritePlaceAction : public CatBaseAction
{
private:
    SpritePlaceAction( const float& x, const float& y, const ModificationType& type );
    const float mX;
    const float mY;
    
public:
    static CCFiniteTimeAction* createOffsetBy( const float& x, const float& y );
    static CCFiniteTimeAction* createSetPosition( const float& x, const float& y );
    static cocos2d::CCFiniteTimeAction* createSetXPosition( const float& x );
    static cocos2d::CCFiniteTimeAction* createSetYPosition( const float& y );
    virtual void action( CatSprite* sprite );
};

#endif // _SPRITE_PLACE_ACTION_H_
