/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "SpriteZOrderAction.h"
#include "CatProject.h"

SpriteZOrderAction::SpriteZOrderAction( const int& dz, const ModificationType& type ) :
    CatBaseAction( type ), mDz( dz )
{
}

cocos2d::CCFiniteTimeAction* SpriteZOrderAction::createReorderSpriteFront()
{
    RETURN_CAT_ACTION( new SpriteZOrderAction( 0, Absolute ) );
}

cocos2d::CCFiniteTimeAction* SpriteZOrderAction::createCangeZOrderBy( const int& dz )
{
    RETURN_CAT_ACTION( new SpriteZOrderAction( dz, Relative ) );
}

void SpriteZOrderAction::action( CatSprite *sprite )
{
    if ( mType == Relative )
    {
        sprite->catProject()->changeSpriteZOrderBy( sprite, mDz );
    }
    else if ( mType == Absolute )
    {
        std::vector<CatSprite*> allSprites = sprite->catProject()->catSprites();
        
        int maxZOrder, dz = 0;
        
        for ( int i = 0; i < allSprites.size(); i++ )
        {
            int otherZ = allSprites[i]->getZOrder();
            maxZOrder = otherZ > maxZOrder ? otherZ : maxZOrder;
        }
        
        dz = sprite->getZOrder() - maxZOrder;
        
        sprite->catProject()->changeSpriteZOrderBy( sprite, dz );
    }
}
