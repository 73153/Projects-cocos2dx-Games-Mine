/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef _CATXML_H_
#define _CATXML_H_

#define PROJECT_FILE_NAME "projectcode.xml"

/* XML HEADER VALUES */
#define XML_PROJECT_NAME( xmldoc ) \
    xmldoc.FirstChildElement( "Content.Project" )->FirstChildElement( "projectName" )->GetText()

#define XML_ORIGIN_RES_WIDTH( xmldoc ) \
xmldoc.FirstChildElement( "Content.Project" )->FirstChildElement( "screenWidth" )->GetText()

#define XML_ORIGIN_RES_HEIGHT( xmldoc ) \
xmldoc.FirstChildElement( "Content.Project" )->FirstChildElement( "screenHeight" )->GetText()

/* XML ROOT NODES */
#define XML_FIRST_SPRITE( xmldoc ) \
    xmldoc.FirstChildElement( "Content.Project" )->FirstChildElement( "spriteList" )->FirstChildElement()

#define XML_SPRITE_NAME( node ) \
    node->FirstChildElement( "name" )->GetText()

#define XML_FIRST_COSTUME( node ) \
    node->FirstChildElement( "costumeDataList" )->FirstChildElement( "Common.CostumeData" )

#define XML_COSTUME_FILE( node ) \
    node->FirstChildElement( "fileName" )->GetText()

#define XML_FIRST_SCRIPT( node ) \
    node->FirstChildElement( "scriptList" )->FirstChildElement()

#define XML_FIRST_BRICK( node ) \
    node->FirstChildElement( "brickList" )->FirstChildElement()

#define XML_WHEN_SCRIPT_ACTION( node ) \
    node->FirstChildElement( "action" )->GetText()

#define XML_BROADCAST_SCRIPT_SIGNAL( node ) \
    node->FirstChildElement( "receivedMessage" )->GetText()

/* SET COSTUME BRICK */
#define XML_SET_COSTUME_BRICK_IS_EMPTY( node )\
    ( node->FirstChildElement( "costumeData" ) == NULL )

#define XML_SET_COSTUME_BRICK_KEY( node ) \
    node->FirstChildElement( "costumeData" )->FirstAttribute()->Value()

/* GLIDE TO BRICK */
#define XML_GLIDE_TO_BRICK_DURATION( node ) \
    node->FirstChildElement( "durationInMilliSeconds" )->GetText()

#define XML_GLIDE_TO_BRICK_POINT_X( node ) \
    node->FirstChildElement( "xDestination" )->GetText()

#define XML_GLIDE_TO_BRICK_POINT_Y( node ) \
    node->FirstChildElement( "yDestination" )->GetText()

/* PLACE AT/SET X,Y BRICK */
#define XML_PLACE_AT_BRICK_POINT_X( node ) \
    node->FirstChildElement( "xPosition" )->GetText()

#define XML_PLACE_AT_BRICK_POINT_Y( node ) \
    node->FirstChildElement( "yPosition" )->GetText()

#define XML_SET_X_COORD_BRICK_POINT_X( node ) \
    node->FirstChildElement( "xPosition" )->GetText()

#define XML_SET_Y_COORD_BRICK_POINT_Y( node ) \
    node->FirstChildElement( "yPosition" )->GetText()

/* CHANGE X/Y BY BRICK */
#define XML_CHANGE_X_BY_BRICK_PIXELS( node ) \
    node->FirstChildElement( "xMovement" )->GetText()

#define XML_CHANGE_Y_BY_BRICK_PIXELS( node ) \
    node->FirstChildElement( "yMovement" )->GetText()

/* GO N STEPS BACK_BRICK */
#define XML_GO_STEPS_BACK_BRICK_STEPS( node ) \
    node->FirstChildElement( "steps" )->GetText()

/* WAIT BRICK */
#define XML_WAIT_BRICK_DURATION( node ) \
    node->FirstChildElement( "timeToWaitInMilliSeconds" )->GetText()

/* PLAY SOUND BRICK */
#define XML_PLAY_SOUND_BRICK_IS_EMPTY( node )\
( node->FirstChildElement( "soundInfo" ) == NULL  ||\
  node->FirstChildElement( "soundInfo" )->FirstChildElement( "fileName" ) == NULL )

#define XML_PLAY_SOUND_BRICK_PATH( node ) \
    node->FirstChildElement( "soundInfo" )->FirstChildElement( "fileName" )->GetText()

/* LOOP FINITE BRICK */
#define XML_LOOP_FINITE_BRICK_ITERATIONS( node ) \
    node->FirstChildElement( "timesToRepeat" )->GetText()

/* SET/CHANGE SIZE BRICK */
#define XML_SET_SCALE_BRICK_SCALE( node ) \
    node->FirstChildElement( "size" )->GetText()

#define XML_CHANGE_SCALE_BRICK_SCALE( node ) \
    node->FirstChildElement( "size" )->GetText()

/* BROADCAST BRICK */
#define XML_BROADCAST_BRICK_SIGNAL( node ) \
    node->FirstChildElement( "broadcastMessage" )->GetText()

/* FADE TO/BY BRICK */
#define XML_FADE_TO_BRICK_TRANSPARENCY( node ) \
    node->FirstChildElement( "transparency" )->GetText()

#define XML_FADE_BY_BRICK_TRANSPARENCY( node ) \
    node->FirstChildElement( "changeGhostEffect" )->GetText()

/* XML TAG NAMES */
#define XML_START_SCRIPT         "Content.StartScript"
#define XML_BROADCAST_SCRIPT     "Content.BroadcastScript"
#define XML_WHEN_SCRIPT          "Content.WhenScript"
#define XML_WHEN_ACTION_TAPPED   "Tapped"

#define XML_SET_COSTUME_BRICK    "Bricks.SetCostumeBrick"
#define XML_NEXT_COSTUME_BRICK   "Bricks.NextCostumeBrick"
#define XML_GLIDE_TO_BRICK       "Bricks.GlideToBrick"
#define XML_PLACE_AT_BRICK       "Bricks.PlaceAtBrick"
#define XML_SET_X_COORD_BRICK    "Bricks.SetXBrick"
#define XML_SET_Y_COORD_BRICK    "Bricks.SetYBrick"
#define XML_CHANGE_X_BY_BRICK    "Bricks.ChangeXByBrick"
#define XML_CHANGE_Y_BY_BRICK    "Bricks.ChangeYByBrick"
#define XML_GO_STEPS_BACK_BRICK  "Bricks.GoNStepsBackBrick"
#define XML_COME_TO_FRONT_BRICK  "Bricks.ComeToFrontBrick"
#define XML_HIDE_BRICK           "Bricks.HideBrick"
#define XML_SHOW_BRICK           "Bricks.ShowBrick"
#define XML_FADE_TO_BRICK        "Bricks.SetGhostEffectBrick"
#define XML_FADE_BY_BRICK        "Bricks.ChangeGhostEffectBrick"
#define XML_WAIT_BRICK           "Bricks.WaitBrick"
#define XML_PLAY_SOUND_BRICK     "Bricks.PlaySoundBrick"
#define XML_STOP_SOUNDS_BRICK    "Bricks.StopAllSoundsBrick"
#define XML_LOOP_INFINITE_BRICK  "Bricks.ForeverBrick"
#define XML_LOOP_FINITE_BRICK    "Bricks.RepeatBrick"
#define XML_LOOP_END_BRICK       "Bricks.LoopEndBrick"
#define XML_SET_SCALE_BRICK      "Bricks.SetSizeToBrick"
#define XML_CHANGE_SCALE_BRICK   "Bricks.ChangeSizeByNBrick"
#define XML_SET_BRIGHTNESS_BRICK "Bricks.SetBrightnessBrick"
#define XML_BROADCAST_BRICK      "Bricks.BroadcastBrick"
#define XML_BROADCAST_WAIT_BRICK "Bricks.BroadcastWaitBrick"

#endif // _CATXML_H_
