/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatBrick.h"

#include "SetCostumeBrick.h"
#include "GlideToBrick.h"
#include "PlaceAtBrick.h"
#include "OffsetByBrick.h"
#include "ChangeZOrderBrick.h"
#include "HideBrick.h"
#include "ShowBrick.h"
#include "ChangeOpacityBrick.h"
#include "WaitBrick.h"
#include "PlaySoundBrick.h"
#include "StopAllSoundsBrick.h"
#include "LoopInfiniteBrick.h"
#include "LoopFiniteBrick.h"
#include "LoopEndBrick.h"
#include "SetScaleBrick.h"
#include "SendSignalBrick.h"

CatBrick::CatBrick()
{
}

CatBrick::~CatBrick()
{
}

SharedPtr<CatBrick>::Type CatBrick::newSetCostumeBrick( const int& index )
{
    return SharedPtr<CatBrick>::Type( new SetCostumeBrick( index ) );
}

SharedPtr<CatBrick>::Type CatBrick::newSetNextCostumeBrick()
{
    return SharedPtr<CatBrick>::Type( new SetCostumeBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newGlideToBrick( const float& duration, const cocos2d::CCPoint& position )
{
    return SharedPtr<CatBrick>::Type( new GlideToBrick( duration , position ) );
}

SharedPtr<CatBrick>::Type CatBrick::newPlaceAtBrick( const cocos2d::CCPoint& position )
{
    return SharedPtr<CatBrick>::Type( new PlaceAtBrick( position, PlaceAtBrick::BothCoords ) );
}

SharedPtr<CatBrick>::Type CatBrick::newSetXCoordBrick( const float& x )
{
    return SharedPtr<CatBrick>::Type( new PlaceAtBrick( cocos2d::CCPoint( x, 0 ), PlaceAtBrick::XCoord ) );
}

SharedPtr<CatBrick>::Type CatBrick::newSetYCoordBrick( const float& y )
{
    return SharedPtr<CatBrick>::Type( new PlaceAtBrick( cocos2d::CCPoint( 0, y ), PlaceAtBrick::YCoord ) );
}

SharedPtr<CatBrick>::Type CatBrick::newChangeXByBrick( const float& x )
{
    return SharedPtr<CatBrick>::Type( new OffsetByBrick( x, 0 ) );
}

SharedPtr<CatBrick>::Type CatBrick::newChangeYByBrick( const float& y )
{
    return SharedPtr<CatBrick>::Type( new OffsetByBrick( 0, y ) );
}

SharedPtr<CatBrick>::Type CatBrick::newChangeZOrderBrick( const int& dz )
{
    return SharedPtr<CatBrick>::Type( new ChangeZOrderBrick( dz ) );
}

SharedPtr<CatBrick>::Type CatBrick::newComeToFrontBrick()
{
    return SharedPtr<CatBrick>::Type( new ChangeZOrderBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newHideBrick()
{
    return SharedPtr<CatBrick>::Type( new HideBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newShowBrick()
{
    return SharedPtr<CatBrick>::Type( new ShowBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newSetOpacityBrick( const float& opacity )
{
    return SharedPtr<CatBrick>::Type( new ChangeOpacityBrick( opacity, ChangeOpacityBrick::Absolute ) );
}

SharedPtr<CatBrick>::Type CatBrick::newChangeOpacityBrick( const float& opacity )
{
    return SharedPtr<CatBrick>::Type( new ChangeOpacityBrick( opacity, ChangeOpacityBrick::Relative ) );
}


SharedPtr<CatBrick>::Type CatBrick::newWaitBrick( const float& duration )
{
    return SharedPtr<CatBrick>::Type( new WaitBrick( duration ) );
}

SharedPtr<CatBrick>::Type CatBrick::newPlaySoundBrick( const std::string& path )
{
    return SharedPtr<CatBrick>::Type( new PlaySoundBrick( path ) );
}

SharedPtr<CatBrick>::Type CatBrick::newStopAllSoundsBrick()
{
    return SharedPtr<CatBrick>::Type( new StopAllSoundsBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newLoopInfiniteBrick()
{
    return SharedPtr<CatBrick>::Type( new LoopInfiniteBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newLoopFiniteBrick( const unsigned& iterations )
{
    return SharedPtr<CatBrick>::Type( new LoopFiniteBrick( iterations ) );
}

SharedPtr<CatBrick>::Type CatBrick::newLoopEndBrick()
{
    return SharedPtr<CatBrick>::Type( new LoopEndBrick() );
}

SharedPtr<CatBrick>::Type CatBrick::newSetScaleBrick( const float& scale )
{
    return SharedPtr<CatBrick>::Type( new SetScaleBrick( scale, SetScaleBrick::Absolute ) );
}

SharedPtr<CatBrick>::Type CatBrick::newChangeScaleByBrick( const float& scale )
{
    return SharedPtr<CatBrick>::Type( new SetScaleBrick( scale, SetScaleBrick::Relative ) );
}

SharedPtr<CatBrick>::Type CatBrick::newSendSignalBrick( const std::string& signal )
{
    return SharedPtr<CatBrick>::Type( new SendSignalBrick( CatScript::ControlType( signal )));
}

cocos2d::CCFiniteTimeAction* CatBrick::createAction()
{
    throw CatException( "CreateAction not implemented." );
}

const size_t CatBrick::iterationCount()
{
    throw CatException( "IterationCount not implemented." );
}
