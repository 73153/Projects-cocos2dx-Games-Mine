/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatScript.h"

#include "CatBrick.h"
#include "CatSprite.h"
#include "CatUtils.h"
#include "ScriptEndAction.h"
#include "SendSignalAction.h"
#include "CCCommon.h"
#include "CCArray.h"
#include "CCActionInterval.h"

const CatScript::ControlType CatScript::ON_START = CatScript::ControlType( "IRONPAWS_ON_START" );
const CatScript::ControlType CatScript::ON_TOUCH = CatScript::ControlType( "IRONPAWS_ON_TOUCH" );

CatScript::CatScript( const ControlType& type ) :
    mControlType( type ),
    mScriptRunning( false ),
    mCatBricks()
{
}

CatScript::~CatScript()
{
}

SharedPtr<CatScript>::Type CatScript::newOnStartScript()
{
    CatScript* script = new CatScript( ON_START );
    return SharedPtr<CatScript>::Type( script );
}

SharedPtr<CatScript>::Type CatScript::newOnTouchScript()
{
    CatScript* script = new CatScript( ON_TOUCH );
    return SharedPtr<CatScript>::Type( script );
}

SharedPtr<CatScript>::Type CatScript::newOnSignalScript( const std::string& signal )
{
    CatScript* script = new CatScript( ControlType( signal ) );
    return SharedPtr<CatScript>::Type( script );
}

void CatScript::addCatBrick( SharedPtr<CatBrick>::Type brick )
{
    mCatBricks.push_back( brick );
}

const std::vector<SharedPtr<CatBrick>::Type>& CatScript::catBricks() const
{
    return mCatBricks;
}

const CatScript::ControlType& CatScript::controlType() const
{
    return mControlType;
}

const bool& CatScript::isScriptRunning() const
{
    return mScriptRunning;
}

void CatScript::runScript( CatSprite* sprite )
{
    std::vector<cocos2d::CCFiniteTimeAction*> allActions;
    std::vector<cocos2d::CCFiniteTimeAction*> loopActions;
    int iterationCount = 0;
    bool loop = false;
        
    for ( int i = 0; i < mCatBricks.size(); i++ )
    {
        switch ( mCatBricks[i]->brickType() )
        {
            case CatBrick::Action:
                if ( !loop )
                {
                    allActions.push_back( mCatBricks[i]->createAction() );
                }
                else
                {
                    loopActions.push_back( mCatBricks[i]->createAction() );
                }
                break;
            case CatBrick::LoopBegin:
                loop = true;
                iterationCount = mCatBricks[i]->iterationCount();
                break;
            case CatBrick::LoopEnd:
                if ( loopActions.size() > 1 )
                {
                    cocos2d::CCSequence* sequence = createActionSequence( loopActions );
                    cocos2d::CCRepeat* repeat = cocos2d::CCRepeat::create( sequence, iterationCount );
                    allActions.push_back( repeat );
                }
                else
                {
                    cocos2d::CCRepeat* repeat = cocos2d::CCRepeat::create( loopActions[0], iterationCount );
                    allActions.push_back( repeat );
                }
                loop = false;
                iterationCount = 0;
                loopActions.clear();
                break;
        }
    }
        
    if ( allActions.size() > 0 )
    {        
        // On-signal scripts might have been started by broadcast-wait bricks and need to return a signal.
        if ( mControlType != ON_START && mControlType != ON_TOUCH )
        {
            ControlType returnSignal = ControlType( CatUtils::returnSignalName( mControlType.raw() ));
            allActions.push_back( SendSignalAction::create( returnSignal ) );
        }
        
        // This member variable is passed by reference and will be set back to false.
        mScriptRunning = true;
        allActions.push_back( ScriptEndAction::create( mScriptRunning ) );
        
        sprite->runAction( createActionSequence( allActions ) );
    }
}

// Build a nested set of 2-action CCSequences because creating a sequence from an array only gives us a
// CCFiniteTimeAction and not a CCActionInterval. This way we can also use a vector instead of CCArray.
cocos2d::CCSequence* CatScript::createActionSequence( const std::vector<cocos2d::CCFiniteTimeAction*>& actions )
{
    if ( actions.size() < 2 )
    {
        throw CatException( "ActionSequence must contain at least 2 actions." );
    }
    
    const size_t n = actions.size() - 1;
    cocos2d::CCSequence* sequence = cocos2d::CCSequence::createWithTwoActions( actions[n - 1], actions[n] );
    
    for ( int i = n - 2; i >= 0; i-- )
    {
        sequence = cocos2d::CCSequence::createWithTwoActions( actions[i], sequence );
    }
    
    return sequence;
}
