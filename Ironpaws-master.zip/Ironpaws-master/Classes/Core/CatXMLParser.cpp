/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatXMLParser.h"

#include "CatXML.h"
#include "CatProject.h"
#include "CatSprite.h"
#include "CatScript.h"
#include "CatBrick.h"
#include "CatUtils.h"
#include "CatFileHelper.h"
#include "CCSprite.h"

CatXMLParser::CatXMLParser( const std::string& projectRoot ) :
    mProjectRoot( CatUtils::withFilesystemDelimiter( projectRoot ) ),
    mXMLDoc()
{
}

CatXMLParser::~CatXMLParser()
{
}

SharedPtr<CatProject>::Type CatXMLParser::parseCatProject()
{
    std::string xmlPath = mProjectRoot + PROJECT_FILE_NAME;
    
    if ( mXMLDoc.LoadFile( xmlPath.c_str() ) != tinyxml2::XML_NO_ERROR )
    {
        throw CatParseException( "Cannot read " + xmlPath );
    }
        
    SharedPtr<CatProject>::Type project( new CatProject( XML_PROJECT_NAME( mXMLDoc )));
    
    tinyxml2::XMLElement* xml = XML_FIRST_SPRITE( mXMLDoc );
    
    while ( xml )
    {
        CatSprite* sprite = parseCatSprite( xml );
        if ( sprite )
        {
            sprite->setCatProject( project );
            project->addCatSprite( sprite );
        }
        xml = xml->NextSiblingElement();
    }
    
    return project;
}

CatSprite* CatXMLParser::parseCatSprite( const tinyxml2::XMLElement* xml )
{
    const tinyxml2::XMLElement* costumeXML = XML_FIRST_COSTUME( xml );
    
    if ( !costumeXML )
    {
        return NULL;
    }
    const std::string path = mProjectRoot + XML_COSTUME_FILE( costumeXML );
    // CatSprite is an auto-release object.
    CatSprite* catSprite = CatSprite::newCatSpriteWithNameAndCostume( XML_SPRITE_NAME( xml ), path );
    
    if ( !catSprite )
    {
        throw CatParseException( "Cannot create sprite from " + path );
    }
    
    costumeXML = costumeXML->NextSiblingElement();

    while ( costumeXML )
    {
        const std::string path = mProjectRoot + XML_COSTUME_FILE( costumeXML );
        catSprite->addCostumeTexture( path );
        costumeXML = costumeXML->NextSiblingElement();
    }
    
    const tinyxml2::XMLElement* scriptXML = XML_FIRST_SCRIPT( xml );
    
    while ( scriptXML )
    {
        std::vector<SharedPtr<CatScript>::Type> scripts = parseCatScript( scriptXML );
        for ( int i = 0; i < scripts.size(); i++ )
        {
            catSprite->addCatScript( scripts[i] );
        }
        scriptXML = scriptXML->NextSiblingElement();
    }
    
    return catSprite;
}

std::vector<SharedPtr<CatScript>::Type> CatXMLParser::parseCatScript( const tinyxml2::XMLElement* xml )
{
    // This vector will contain the main script and possible embedded scripts.
    std::vector<SharedPtr<CatScript>::Type> catScripts;
    SharedPtr<CatScript>::Type catScript = newCatScript( xml );
    catScripts.push_back( catScript );
    
    const tinyxml2::XMLElement* brickXML = XML_FIRST_BRICK( xml );
    
    while ( brickXML )
    {
        try
        {
            SharedPtr<CatBrick>::Type brick = parseCatBrick( brickXML );
            catScript->addCatBrick( brick );
        }
        catch ( CatParseSkipException e )
        {
            cocos2d::CCLog( "[IRONPAWS] %s", e.what() );
        }
        catch ( EmbeddedScriptException e )
        {
            // We handle the broadcast-wait brick by adding an ordinary broadcast brick
            // and then creating a new on-signal-script for the remaining bricks, which
            // will run after a receiver of the sent signal finishes.
            cocos2d::CCLog( "[IRONPAWS] embedded script '%s'", e.what() );
            const std::string signal = XML_BROADCAST_BRICK_SIGNAL( brickXML );
            const std::string returnSignal = CatUtils::returnSignalName( signal );
            SharedPtr<CatBrick>::Type brick = CatBrick::newSendSignalBrick( signal );
            catScript->addCatBrick( brick );
            
            catScript = CatScript::newOnSignalScript( returnSignal );
            catScripts.push_back( catScript );
        }
        brickXML = brickXML->NextSiblingElement();
    }
    
    return catScripts;
}

SharedPtr<CatScript>::Type CatXMLParser::newCatScript( const tinyxml2::XMLElement* xml )
{
    const std::string& name = xml->Value();
    
    if ( name == XML_START_SCRIPT )
    {
        return CatScript::newOnStartScript();
    }
    else if ( name == XML_WHEN_SCRIPT )
    {
        const std::string& action = XML_WHEN_SCRIPT_ACTION( xml );
        
        if ( action == XML_WHEN_ACTION_TAPPED )
        {
            return CatScript::newOnTouchScript();
        }
        throw CatParseException( "Undefined action tag " + name );
    }
    else if ( name == XML_BROADCAST_SCRIPT )
    {
        return CatScript::newOnSignalScript( XML_BROADCAST_SCRIPT_SIGNAL( xml ) );
    }
    throw CatParseException( "Undefined script tag " + name );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseCatBrick( const tinyxml2::XMLElement* xml )
{
    const std::string& name = xml->Value();
        
    if ( name == XML_SET_COSTUME_BRICK )
    {
        return parseSetCostumeBrick( xml );
    }
    if ( name == XML_NEXT_COSTUME_BRICK )
    {
        return CatBrick::newSetNextCostumeBrick();
    }
    else if ( name == XML_GLIDE_TO_BRICK )
    {
        return parseGlideToBrick( xml );
    }
    else if ( name == XML_PLACE_AT_BRICK )
    {
        return parsePlaceAtBrick( xml );
    }
    else if ( name == XML_SET_X_COORD_BRICK )
    {
        return parseSetXCoordBrick( xml );
    }
    else if ( name == XML_SET_Y_COORD_BRICK )
    {
        return parseSetYCoordBrick( xml );
    }
    else if ( name == XML_CHANGE_X_BY_BRICK )
    {
        return parseChangeXByBrick( xml );
    }
    else if ( name == XML_CHANGE_Y_BY_BRICK )
    {
        return parseChangeYByBrick( xml );
    }
    else if ( name == XML_GO_STEPS_BACK_BRICK )
    {
        return parseGoNStepsBackBrick( xml );
    }
    else if ( name == XML_COME_TO_FRONT_BRICK )
    {
        return CatBrick::newComeToFrontBrick();
    }
    else if ( name == XML_HIDE_BRICK )
    {
        return CatBrick::newHideBrick();
    }
    else if ( name == XML_SHOW_BRICK )
    {
        return CatBrick::newShowBrick();
    }
    else if ( name == XML_FADE_TO_BRICK )
    {
        return parseSetOpacityBrick( xml );
    }
    else if ( name == XML_FADE_BY_BRICK )
    {
        return parseChangeOpacityBrick( xml );
    }
    else if (name == XML_WAIT_BRICK )
    {
        return parseWaitBrick( xml );
    }
    else if ( name == XML_PLAY_SOUND_BRICK )
    {
        return parsePlaySoundBrick( xml );
    }
    else if ( name == XML_STOP_SOUNDS_BRICK )
    {
        return CatBrick::newStopAllSoundsBrick();
    }
    else if ( name == XML_LOOP_INFINITE_BRICK )
    {
        return CatBrick::newLoopInfiniteBrick();
    }
    else if ( name == XML_LOOP_FINITE_BRICK )
    {
        return parseLoopFiniteBrick( xml );
    }
    else if ( name == XML_LOOP_END_BRICK )
    {
        return CatBrick::newLoopEndBrick();
    }
    else if ( name == XML_SET_SCALE_BRICK )
    {
        return parseSetScaleBrick( xml );
    }
    else if ( name == XML_CHANGE_SCALE_BRICK )
    {
        return parseChangeScaleBrick( xml );
    }
    else if ( name == XML_SET_BRIGHTNESS_BRICK )
    {
        throw CatParseSkipException( "Skip unimplemented SetBrightnessBrick." );
    }
    else if ( name == XML_BROADCAST_BRICK )
    {
        return CatBrick::newSendSignalBrick( XML_BROADCAST_BRICK_SIGNAL( xml ) );
    }
    else if ( name == XML_BROADCAST_WAIT_BRICK )
    {
        throw EmbeddedScriptException("BroadcastWaitBrick");
    }
    throw CatParseException( "Undefined brick tag " + name );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseSetCostumeBrick( const tinyxml2::XMLElement* xml )
{
    if ( XML_SET_COSTUME_BRICK_IS_EMPTY(xml) )
    {
        throw CatParseSkipException( "Skip empty SetCostumeBrick." );
    }
    std::string key = XML_SET_COSTUME_BRICK_KEY( xml );
    size_t a = key.find_last_of( '[' );
    int index = 0;
    if ( a != std::string::npos )
    {
        size_t b = key.find_first_of( ']', a );
        key = key.substr( a + 1, b - a - 1 );
        index = atoi( key.c_str() ) - 1;
    }
    return CatBrick::newSetCostumeBrick( index );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseGlideToBrick( const tinyxml2::XMLElement* xml )
{
    float duration = CatUtils::millisecondsToSeconds( atol( XML_GLIDE_TO_BRICK_DURATION( xml ) ) );
    float x = atof( XML_GLIDE_TO_BRICK_POINT_X( xml ) );
    float y = atof( XML_GLIDE_TO_BRICK_POINT_Y( xml ) );
    return CatBrick::newGlideToBrick( duration, coordinateHelper( x, y ) );
}

SharedPtr<CatBrick>::Type CatXMLParser::parsePlaceAtBrick( const tinyxml2::XMLElement* xml )
{
    float x = atof( XML_PLACE_AT_BRICK_POINT_X( xml ) );
    float y = atof( XML_PLACE_AT_BRICK_POINT_Y( xml ) );
    return CatBrick::newPlaceAtBrick( coordinateHelper( x, y ) );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseSetXCoordBrick( const tinyxml2::XMLElement* xml )
{
    float x = atof( XML_SET_X_COORD_BRICK_POINT_X( xml ) );
    return CatBrick::newPlaceAtBrick( coordinateHelper( x, 0 ) );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseSetYCoordBrick( const tinyxml2::XMLElement* xml )
{
    float y = atof( XML_SET_Y_COORD_BRICK_POINT_Y( xml ) );
    return CatBrick::newPlaceAtBrick( coordinateHelper( 0, y ) );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseChangeXByBrick( const tinyxml2::XMLElement* xml )
{
    float x = atof( XML_CHANGE_X_BY_BRICK_PIXELS( xml ) );
    cocos2d::CCPoint point = coordinateHelper( x, 0 );
    return CatBrick::newChangeXByBrick( point.x );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseChangeYByBrick( const tinyxml2::XMLElement* xml )
{
    float y = atof( XML_CHANGE_Y_BY_BRICK_PIXELS( xml ) );
    cocos2d::CCPoint point = coordinateHelper( 0, y );
    return CatBrick::newChangeYByBrick( point.y );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseGoNStepsBackBrick( const tinyxml2::XMLElement* xml )
{
    int dz = atoi( XML_GO_STEPS_BACK_BRICK_STEPS( xml ) ) * -1;
    return CatBrick::newChangeZOrderBrick( dz );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseSetOpacityBrick( const tinyxml2::XMLElement* xml )
{
    float transparency = atof( XML_FADE_TO_BRICK_TRANSPARENCY( xml ) );
    float opacity = 1.0f - ( transparency / 100.0f );
    return CatBrick::newSetOpacityBrick( opacity );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseChangeOpacityBrick( const tinyxml2::XMLElement* xml )
{
    float opacity = 1.0f - ( atof( XML_FADE_BY_BRICK_TRANSPARENCY( xml ) ) / 100.0f );
    return CatBrick::newChangeOpacityBrick( opacity );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseWaitBrick( const tinyxml2::XMLElement* xml )
{
    float duration = CatUtils::millisecondsToSeconds( atof( XML_WAIT_BRICK_DURATION( xml )));
    return CatBrick::newWaitBrick( duration );
}

SharedPtr<CatBrick>::Type CatXMLParser::parsePlaySoundBrick( const tinyxml2::XMLElement* xml )
{
    if ( XML_PLAY_SOUND_BRICK_IS_EMPTY( xml ) )
    {
        throw CatParseSkipException( "Skip empty PlaySoundBrick." );
    }
    const std::string path = mProjectRoot + XML_PLAY_SOUND_BRICK_PATH( xml );
    return CatBrick::newPlaySoundBrick( path );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseLoopFiniteBrick( const tinyxml2::XMLElement* xml )
{
    unsigned iterations = atoi( XML_LOOP_FINITE_BRICK_ITERATIONS( xml ) );
    return CatBrick::newLoopFiniteBrick( iterations );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseSetScaleBrick( const tinyxml2::XMLElement* xml )
{
    float scale = atof( XML_SET_SCALE_BRICK_SCALE( xml ) ) / 100.0f;
    return CatBrick::newSetScaleBrick( scale );
}

SharedPtr<CatBrick>::Type CatXMLParser::parseChangeScaleBrick( const tinyxml2::XMLElement* xml )
{
    float scale = ( atof( XML_CHANGE_SCALE_BRICK_SCALE( xml ) ) / 100.0f ) + 1.0f;
    return CatBrick::newChangeScaleByBrick( scale );
}

const cocos2d::CCPoint CatXMLParser::coordinateHelper( const float& x, const float& y )
{
    int originResWidth = atoi( XML_ORIGIN_RES_WIDTH( mXMLDoc ) );
    int originResHeight = atoi( XML_ORIGIN_RES_HEIGHT( mXMLDoc ));
    return CatUtils::catrobatToCocosCoordinates( originResWidth, originResHeight, x, y );
}
