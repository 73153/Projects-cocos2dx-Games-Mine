/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATBRICK_H_
#define _CATBRICK_H_

#include "CatCommon.h"

class CatSprite;
namespace cocos2d { class CCFiniteTimeAction; class CCPoint; }

class CatBrick
{
public:
    enum BrickType { Action, LoopBegin, LoopEnd };
    
private:
    CatBrick( const CatBrick& cp );
    
protected:
    CatBrick();

public:
    virtual ~CatBrick();
    
    virtual const BrickType brickType() = 0;
    
    virtual cocos2d::CCFiniteTimeAction* createAction();
    virtual const size_t iterationCount();
        
    static SharedPtr<CatBrick>::Type newWhenStartedBrick();
    static SharedPtr<CatBrick>::Type newSetCostumeBrick( const int& index );
    static SharedPtr<CatBrick>::Type newSetNextCostumeBrick();
    static SharedPtr<CatBrick>::Type newGlideToBrick( const float& duration, const cocos2d::CCPoint& position );
    static SharedPtr<CatBrick>::Type newPlaceAtBrick( const cocos2d::CCPoint& position );
    static SharedPtr<CatBrick>::Type newSetXCoordBrick( const float& x );
    static SharedPtr<CatBrick>::Type newSetYCoordBrick( const float& y );
    static SharedPtr<CatBrick>::Type newChangeXByBrick( const float& x );
    static SharedPtr<CatBrick>::Type newChangeYByBrick( const float& y );
    static SharedPtr<CatBrick>::Type newChangeZOrderBrick( const int& dz );
    static SharedPtr<CatBrick>::Type newComeToFrontBrick();
    static SharedPtr<CatBrick>::Type newHideBrick();
    static SharedPtr<CatBrick>::Type newShowBrick();
    static SharedPtr<CatBrick>::Type newSetOpacityBrick( const float& opacity );
    static SharedPtr<CatBrick>::Type newChangeOpacityBrick( const float& opacity );
    static SharedPtr<CatBrick>::Type newWaitBrick( const float& duration );
    static SharedPtr<CatBrick>::Type newPlaySoundBrick( const std::string& path );
    static SharedPtr<CatBrick>::Type newStopAllSoundsBrick();
    static SharedPtr<CatBrick>::Type newLoopInfiniteBrick();
    static SharedPtr<CatBrick>::Type newLoopFiniteBrick( const unsigned& iterations );
    static SharedPtr<CatBrick>::Type newLoopEndBrick();
    static SharedPtr<CatBrick>::Type newSetScaleBrick( const float& scale );
    static SharedPtr<CatBrick>::Type newChangeScaleByBrick( const float& scale );
    static SharedPtr<CatBrick>::Type newSendSignalBrick( const std::string& signal );
};

#endif // _CATBRICK_H_
