/**
 *  Catroid: An on-device visual programming system for Android devices
 *  Copyright (C) 2010-2012 The Catrobat Team
 *  (<http://developer.catrobat.org/credits>)
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License a
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid/licenseadditionalterm
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATSCRIPT_H_
#define _CATSCRIPT_H_

#include "CatCommon.h"
#include <string>
#include <vector>

class CatBrick;
class CatSprite;

namespace cocos2d { class CCSequence; class CCFiniteTimeAction; }

class CatScript
{
public:
    class ControlType
    {
    private:
        std::string mType;
    public:
        ControlType( const std::string& type ) : mType( type ) {}
        const std::string& raw() const { return mType; }
        bool operator==( const ControlType& other ) const
        {
            return mType == other.mType;
        }
        bool operator!=( const ControlType& other ) const
        {
            return mType != other.mType;
        }
    };
    
    static const CatScript::ControlType ON_START;
    static const CatScript::ControlType ON_TOUCH;

private:
    CatScript( const ControlType& type );
    CatScript( const CatScript& cp );
    
    cocos2d::CCSequence* createActionSequence( const std::vector<cocos2d::CCFiniteTimeAction*>& actions );
        
    bool mScriptRunning;
    const ControlType mControlType;
    std::vector<SharedPtr<CatBrick>::Type> mCatBricks;

public:
    ~CatScript();
    
    static SharedPtr<CatScript>::Type newOnStartScript();
    static SharedPtr<CatScript>::Type newOnTouchScript();
    static SharedPtr<CatScript>::Type newOnSignalScript( const std::string& signal );
    
    void addCatBrick( SharedPtr<CatBrick>::Type brick );
    const std::vector<SharedPtr<CatBrick>::Type>& catBricks() const;
    const ControlType& controlType() const;
    const bool& isScriptRunning() const;
    
    void runScript( CatSprite* sprite );
};

#endif // _CATSCRIPT_H_
