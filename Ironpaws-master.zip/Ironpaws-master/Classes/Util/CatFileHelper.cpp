/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatFileHelper.h"

#include "CatUtils.h"
#include "CCFileUtils.h"
#include "CCCommon.h"
#include <iostream>
#include <fstream>

bool CatFileHelper::extractFile(const std::string& filePath, const std::string& extractPath )
{
    unzFile pFile = NULL;
    int err = -1;
    
    do
    {
        CC_BREAK_IF( filePath.length() == 0 || extractPath.length() == 0 );
        
        pFile = cocos2d::unzOpen( filePath.c_str() );
        CC_BREAK_IF( !pFile );
        
        cocos2d::unz_global_info64 gi;
        err = unzGetGlobalInfo64( pFile, &gi );
        CC_BREAK_IF( err != UNZ_OK );
        
        for ( uLong i = 0; i < gi.number_entry; i++ )
        {
            err = doExtractCurrentfile( pFile, extractPath ) ? UNZ_OK : UNZ_INTERNALERROR;
            CC_BREAK_IF( err != UNZ_OK );
            
            if ( ( i+1 ) < gi.number_entry )
            {
                err = cocos2d::unzGoToNextFile( pFile );
                CC_BREAK_IF( err != UNZ_OK );
            }
        }
        cocos2d::unzCloseCurrentFile( pFile );
        
    } while ( 0 );
    
    if ( pFile )
    {
        cocos2d::unzClose( pFile );
    }
    
    return ( err == UNZ_OK );
}

bool CatFileHelper::doExtractCurrentfile( unzFile pFile, const std::string& extractPath )
{
    bool fileWasExtracted = false;
    char* pBuffer = NULL;
    int err = 0;
    
    do
    {
        // Get the path info of the file in the archive.
        char filepathInZip[256];
        cocos2d::unz_file_info FileInfo;
        err = unzGetCurrentFileInfo( pFile,
                                     &FileInfo,
                                     filepathInZip,
                                     sizeof( filepathInZip ),
                                     NULL, 0, NULL, 0 );
        CC_BREAK_IF( UNZ_OK != err );
        
        // Filenames ending with '/' are folders, we need to skip them.
        const std::string sFilepathInZip( filepathInZip );
        if ( sFilepathInZip[sFilepathInZip.length() - 1] == CC_FILESYSTEM_DELIMITER )
        {
            return true;
        }
        
        err = cocos2d::unzOpenCurrentFile( pFile );
        CC_BREAK_IF( err != UNZ_OK );
        
        // Allocate buffer for the file.
        pBuffer = new char[FileInfo.uncompressed_size];
        CC_BREAK_IF( !pBuffer );
        
        // Read file from archive into buffer.
        int size = 0;
        size = cocos2d::unzReadCurrentFile( pFile, pBuffer, FileInfo.uncompressed_size );
        CC_BREAK_IF( size < 0 );
        
        // Create full path for the extracted file.
        std::string outFilePath =
        CatUtils::withFilesystemDelimiter( extractPath ) +
        sFilepathInZip.substr( sFilepathInZip.find_last_of( CC_FILESYSTEM_DELIMITER ) + 1 );
        
        // Write file to the extraction path.
        std::ofstream outFile;
        outFile.open( outFilePath.c_str(), std::ios::out | std::ios::binary );
        outFile.write( pBuffer, FileInfo.uncompressed_size );
        outFile.close();
        fileWasExtracted = outFile.good();
        
    } while ( 0 );
    
    if ( pBuffer )
    {
        delete[] pBuffer;
        pBuffer = NULL;
    }
    
    return fileWasExtracted;
}
