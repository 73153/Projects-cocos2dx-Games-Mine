/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatUtils.h"
#include "CCGeometry.h"
#include "CCDirector.h"

const std::string CatUtils::withFilesystemDelimiter( const std::string& str )
{
    return str[str.length() - 1] == CC_FILESYSTEM_DELIMITER ?
           str :
           str + CC_FILESYSTEM_DELIMITER;
}

const float CatUtils::millisecondsToSeconds( long millis )
{
    return ( float )( millis / 1000.0f );
}

const cocos2d::CCPoint CatUtils::catrobatToCocosCoordinates( const int& originResWidth,
                                                             const int& originResHeight,
                                                             const float& x,
                                                             const float& y )
{
    cocos2d::CCSize windowSize = cocos2d::CCDirector::sharedDirector()->getWinSize();
    
    float newX = 0, newY = 0;
    // Transform coordinates from original to target resolution.
    if ( originResWidth < windowSize.width )
    {
        newX = x / ( originResWidth / windowSize.width );
        newY = y / ( originResHeight / windowSize.height );
    }
    else
    {
        newX = x * ( windowSize.width / originResWidth );
        newY = y * ( windowSize.height / originResHeight  );
    }
    // Account for the offset of Catrobat coordinates, which are (0,0) at the screen center.
    newX += windowSize.width / 2.0f;
    newY += windowSize.height / 2.0f;
        
    return cocos2d::CCPoint( newX, newY );
}

const std::string CatUtils::returnSignalName( const std::string& signal )
{
    return signal + "_RETURN_SIGNAL";
}
