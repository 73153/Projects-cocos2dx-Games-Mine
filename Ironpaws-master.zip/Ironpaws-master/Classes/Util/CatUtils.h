/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CATUTILS_H_
#define _CATUTILS_H_

#include "CCPlatformConfig.h"
#include <vector>
#include <string>

#if ( CC_TARGET_PLATFORM == CC_PLATFORM_WIN32 )
#define CC_FILESYSTEM_DELIMITER '\\'
#else
#define CC_FILESYSTEM_DELIMITER '/'
#endif

namespace cocos2d { class CCPoint; }

class CatUtils
{
private:
    CatUtils();
public:
    static const std::string withFilesystemDelimiter( const std::string& str );
    static const float millisecondsToSeconds( long millis );
    static const cocos2d::CCPoint catrobatToCocosCoordinates( const int& originResWidth,
                                                              const int& originResHeight,
                                                              const float& x,
                                                              const float& y );
    static const std::string returnSignalName( const std::string& signal );
};

#endif // _CATUTILS_H_
