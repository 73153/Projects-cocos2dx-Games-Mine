/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatApplication.h"

#include "CatFileHelper.h"
#include "CatXMLParser.h"
#include "CatProject.h"
#include "CatStageScene.h"
#include "SimpleAudioEngine.h"
#include "cocos2d.h"

USING_NS_CC;

CatApplication::CatApplication()
{
}

CatApplication::~CatApplication()
{
}

bool CatApplication::applicationDidFinishLaunching()
{
    CCDirector *pDirector = CCDirector::sharedDirector();
    pDirector->setOpenGLView( CCEGLView::sharedOpenGLView() );
    pDirector->setAnimationInterval( 1.0 / 60 );
    pDirector->setDisplayStats( true );
    // pDirector->enableRetinaDisplay( true );
    
    if ( !CatFileHelper::extractFile( mArchivePath, mExtractPath ) )
    {
        std::string message = "Cannot extract " + mArchivePath;
        CCMessageBox( message.c_str(), "ERROR" );
        // cocos2d-x will not terminate the app even if false is returned.
        pDirector->end();
        return false;
    }
    
    SharedPtr<CatProject>::Type catProject;
    
    try
    {
        CatXMLParser xmlParser( mExtractPath );
        catProject = xmlParser.parseCatProject();
    }
    catch( CatXMLParser::CatParseException& e )
    {
        CCLog( "[IRONPAWS] Cannot load project: %s", e.what() );
        CCMessageBox( e.what(), "ERROR" );
        pDirector->end();
        return false;
    }
            
    pDirector->runWithScene( CatStageScene::scene( catProject ) );
    return true;
}

void CatApplication::applicationDidEnterBackground()
{
    CCDirector::sharedDirector()->pause();
    CocosDenshion::SimpleAudioEngine::sharedEngine()->pauseAllEffects();
}

void CatApplication::applicationWillEnterForeground()
{
    CCDirector::sharedDirector()->resume();
    CocosDenshion::SimpleAudioEngine::sharedEngine()->resumeAllEffects();
}

void CatApplication::setArchivePath( const char* archivePath )
{
    mArchivePath = archivePath;
}

void CatApplication::setExtractPath( const char* extractPath )
{
    mExtractPath = extractPath;
}
