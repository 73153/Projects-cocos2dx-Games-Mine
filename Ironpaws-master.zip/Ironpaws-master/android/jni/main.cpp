/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "CatStageScene.h"

#include "CatApplication.h"
#include "cocos2d.h"
#include "CCEventType.h"
#include "CCEGLViewProtocol.h"
#include "platform/android/jni/JniHelper.h"
#include <jni.h>
#include <android/log.h>

#define  LOG_TAG    "main"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

using namespace cocos2d;

extern "C"
{

jint JNI_OnLoad( JavaVM* vm, void* reserved )
{
    JniHelper::setJavaVM( vm );
    return JNI_VERSION_1_4;
}

void Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeInit( JNIEnv*  env, jobject thiz, jint w, jint h )
{
    if ( !CCDirector::sharedDirector()->getOpenGLView() )
    {
        CCEGLView* view = CCEGLView::sharedOpenGLView();
        view->setFrameSize( w, h );
        // view->setDesignResolutionSize( w, h, kResolutionShowAll );

        // Must be first instantiated by CatApplication::getInstance in nativeSetArchiveAndExtractPaths!
        CCApplication::sharedApplication()->run();
    }
    else
    {
        ccDrawInit();
        ccGLInvalidateStateCache();
        
        CCShaderCache::sharedShaderCache()->reloadDefaultShaders();
        CCTextureCache::reloadAllTextures();
        CCNotificationCenter::sharedNotificationCenter()->postNotification( EVNET_COME_TO_FOREGROUND, NULL );
        CCDirector::sharedDirector()->setGLDefaultValues(); 
    }
}

void Java_at_tugraz_ist_Ironpaws_GLViewActivity_nativeSetArchiveAndExtractPaths( JNIEnv* env,
                                                                                 jobject thiz,
                                                                                 jstring archivePath,
                                                                                 jstring extractPath )
{
    const char* archiveCString = env->GetStringUTFChars( archivePath, 0 );
    const char* extractCString = env->GetStringUTFChars( extractPath, 0 );

    CatApplication::getInstance().setArchivePath( archiveCString );
    CatApplication::getInstance().setExtractPath( extractCString );

    env->ReleaseStringUTFChars( archivePath, archiveCString );
    env->ReleaseStringUTFChars( extractPath, extractCString );
}

}
