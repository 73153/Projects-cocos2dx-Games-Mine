[Ironpaws](http://catrobat.github.com/Ironpaws) attempts to implement a cross-platform interpreter for the Catrobat language, using [Cocos2d-x](http://cocos2d-x.org/) as an engine. Currently supported platforms are:
* Android 2.2+ (build on Linux, OS X 10.7)
* iOS 5+ (build on OS X 10.7)

For iOS builds
--------------------
1. Install latest Xcode (4.3+).
2. Open Ironpaws.xcodeproj.
3. Build and run one of the targets.

*Note:* you need to place a Catrobat project file inside the `Documents` folder of the app. For the emulator this is under `~/Library/Application\ Support/iPhone\ Simulator/5.1/Applications/Ironpaws-app-folder/Documents`.

For Android builds
--------------------
1. Install Eclipse, Android SDK and [Android NDK](http://developer.android.com/tools/sdk/ndk/index.html).
2. Import `android/Ironpaws.project` into Eclipse.
3. Set global environment variable `NDK_ROOT="path/to/android-ndk"` ([Ubuntu](http://help.ubuntu.com/community/EnvironmentVariables#System-wide_environment_variables) / OS X:`launchctl setenv NDK_ROOT`).
4. In Eclipse *Run As* -> *Android Application*.

*Note:* you should have a Catrobat project file on your SD-card.

---

* To just build the shared library run `make all` in `android/`
* If you are using the emulator, make sure to use an armeabi-v7a image with active GPU emulation.

Directory structure
--------------------
* **Classes/**...................*shared cpp sources*
* **Ironpaws.xcodeproj**.........*iOS project file*
* **LICENSE_catroid.txt**........*Catrobat default license*
* **README.md**..................*this file*
* **Resources/**.................*shared graphical assets*
* **android/**...................*Android specific sources*
* **ios/**.......................*iOS specific sources*
* **libs/**......................*shared libraries*
* **misc/**......................*miscellaneous files*

Catrobat implementation progress
--------------------
* WhenStarted (Script)
* OnTouch (Script)
* OnSignal (Script)
* SetCostumeBrick
* GlideToBrick
* WaitBrick
* PlaySoundBrick
* StopAllSoundsBrick
* Loop Bricks
* SetScaleBrick
* BroadcastBrick
* Change X/Y By Brick
* Hide/Show Brick
* PlaceAtBrick
* Go back / come to front Brick
* NextCostumeBrick
* GhostEffectBrick
* BroadcastWaitBrick

