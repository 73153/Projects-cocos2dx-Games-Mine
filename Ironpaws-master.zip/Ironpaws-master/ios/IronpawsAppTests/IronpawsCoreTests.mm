/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#import "IronpawsCoreTests.h"

#include "CatApplication.h"
#include "CatFileHelper.h"
#include "CatXMLParser.h"
#include "CatProject.h"
#include "CatSprite.h"
#include "CatProjectXml.h"

#include "CCString.h"
#include <string>

@interface IronpawsCoreTests()
@property (nonatomic, strong) NSString *archivePath;
@property (nonatomic, strong) NSString *extractPath;
@end

@implementation IronpawsCoreTests

@synthesize archivePath = _archivePath;
@synthesize extractPath = _extractPath;

- (void)setUp
{
    [super setUp];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory, NSUserDomainMask, YES );
    
    self.archivePath = [[paths objectAtIndex:0] stringByAppendingString:@"/HelloCatroid.catroid"];
    self.extractPath = NSTemporaryDirectory();
    
    STAssertTrue( [[NSFileManager defaultManager] fileExistsAtPath:self.archivePath], @"Test-data doesn't exist." );
}

- (void)tearDown
{
    [super tearDown];
}

- (void)testCreateNewCatProject
{
    bool success = CatFileHelper::extractFile( [self.archivePath UTF8String], [self.extractPath UTF8String] );
    STAssertTrue( success, @"Could not extract project." );
    
    CatXMLParser parser( [self.extractPath UTF8String] );
//    CatProject* project = parser.parseCatProject();
    
//    STAssertFalse( project == NULL, @"Could not create new project." );
//    
//    NSString *path = [self.extractPath stringByAppendingString:@"B978398F6E8D16B857AA81618F3EF879_Hintergrund"];
//    STAssertTrue( [[NSFileManager defaultManager] fileExistsAtPath:path], @"Couldn't extract project file." );
//    
//    path = [self.extractPath stringByAppendingString:@"7064E57016F4326F59F0B098D83EB259_Katze normal"];
//    STAssertTrue( [[NSFileManager defaultManager] fileExistsAtPath:path], @"Couldn't extract project file." );
    
//    delete project;
}

//- (void)testReadProjectFileIntoCatProject
//{
//    STAssertTrue( 0 == project->projectName().compare( "HelloCatroid" ), @"Wrong project name." );
//    
//    STAssertFalse( project->sprites().empty(), @"Empty sprites vector." );
//    
//    STAssertTrue( 2 == project->sprites().size(), @"Wrong number of sprites." );
//    
//    STAssertTrue( 0 == project->sprites()[0]->spriteName().compare( "Hintergrund" ), @"Wrong sprite name." );
//    STAssertTrue( 0 == project->sprites()[1]->spriteName().compare( "Catroid" ), @"Wrong sprite name." );
//    
//    const std::vector<cocos2d::CCSprite *>& costumeSprites = project->sprites()[0]->costumeSprites();
//    
//    STAssertFalse( costumeSprites.empty(), @"Empty costume-sprites vector." );
//    
//    STAssertTrue( 1 == costumeSprites.size(), @"Wrong number of costume-sprites." );
//}

@end
