/**
 *  Catroid: An on-device graphical programming language for Android devices
 *  Copyright (C) 2010-2012 The Catroid Team
 *  (<http://code.google.com/p/catroid/wiki/Credits>)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *  
 *  An additional term exception under section 7 of the GNU Affero
 *  General Public License, version 3, is available at
 *  http://www.catroid.org/catroid_license_additional_term
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *   
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#import "StartViewController.h"

#import "RootViewController.h"

@interface StartViewController ()
@property (strong, nonatomic) NSString *selectedProjectFilePath;
@end

@implementation StartViewController

@synthesize selectedProjectFilePath = _selectedProjectFilePath;
@synthesize startProjectButton = _startProjectButton;
@synthesize documentTableView = _documentTableView;
@synthesize documentArray = _documentArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.startProjectButton setEnabled:NO];
    
    [self.documentTableView setDataSource:self];
    [self.documentTableView setDelegate:self];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory, NSUserDomainMask, YES );
    NSString *documentPath = [paths objectAtIndex:0];
    self.documentArray = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:documentPath
                                                                             error:NULL];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.documentArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellId = @"DocumentCellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault
                                      reuseIdentifier:cellId];
    }
    
    cell.textLabel.text = [self.documentArray objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [[paths objectAtIndex:0] stringByAppendingString:@"/"];
    NSString *docName = [self.documentArray objectAtIndex:indexPath.row];
    self.selectedProjectFilePath = [docPath stringByAppendingString:docName];
    [self.startProjectButton setEnabled:YES];
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{    
    if([segue.identifier isEqualToString:@"START_RPOJECT_SEGUE"])
    {
        [segue.destinationViewController setProjectFilePath:self.selectedProjectFilePath];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return ( UIInterfaceOrientationPortrait == interfaceOrientation );
}

- (void)viewDidUnload
{
    [self setDocumentTableView:nil];
    [self setStartProjectButton:nil];
    [super viewDidUnload];
}

@end
