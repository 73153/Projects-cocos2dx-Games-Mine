# leafsoar 的代码示例

源代码路径： ./Classes

资源文件路径： ./Resources

详情请见博文

Eclipse 组织跨平台开发 Cocos2d-x 游戏 <http://blog.leafsoar.com/archives/2013/04-23-16.html>

Eclipse Cocos2d-x 开发自动管理 <http://blog.leafsoar.com/archives/2013/04-24-12.html>
