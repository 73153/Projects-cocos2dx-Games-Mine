#ifndef _TEST_RESOURCE_H_
#define _TEST_RESOURCE_H_

static const char sf_defaultFont[] = "SimHei";		// 默认字体
static const char s_pClose[]          = "close.png";


#endif
