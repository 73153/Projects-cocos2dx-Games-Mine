//
//  YFJLeftSwipeDeleteTableViewTests.m
//  YFJLeftSwipeDeleteTableViewTests
//
//  Created by Yuichi Fujiki on 6/27/13.
//  Copyright (c) 2013 Yuichi Fujiki. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface YFJLeftSwipeDeleteTableViewTests : XCTestCase

@end

@implementation YFJLeftSwipeDeleteTableViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
