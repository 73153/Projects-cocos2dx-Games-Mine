ripple-cpu
==========

ripple effect using cpu
