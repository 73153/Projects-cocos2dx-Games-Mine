﻿#ifndef __APPMACROS_H__
#define __APPMACROS_H__

#include<iostream>
#include<string>
using namespace std;
#include "cocos2d.h"
//Éè¼Æ·Ö±æÂÊ
static cocos2d::CCSize designResolutionSize = cocos2d::CCSizeMake(480, 320);
static string resourceSearchDic="iphone";

#endif /* __APPMACROS_H__ */
