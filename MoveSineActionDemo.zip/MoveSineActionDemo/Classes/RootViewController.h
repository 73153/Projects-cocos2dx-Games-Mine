//
//  RootViewController.h
//  MoveSineActionDemo
//
//  Created by supersuraccoon on 9/16/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
