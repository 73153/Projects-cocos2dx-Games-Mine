//
//  HelloWorldLayer.m
//  MoveSineActionDemo
//
//  Created by supersuraccoon on 9/16/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "MoveSineAction.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"MoveSineAction Demo" fontName:@"Marker Felt" fontSize:32];
		CGSize size = [[CCDirector sharedDirector] winSize];
		label.position =  ccp( size.width /2 , 300);
		[self addChild: label];
		
		CCSprite *raccoonSprite1 = [CCSprite spriteWithFile:@"raccoon.png"];
		raccoonSprite1.position = ccp(50, 250);
		raccoonSprite1.scale = 0.6f;
		[self addChild:raccoonSprite1];
		
		//using default setting a: 30.0f f:0.15f
		[raccoonSprite1 runAction:[MoveSineAction actionWithDuration:8.0f
															 length:430.0f]];
		
		CCSprite *raccoonSprite2 = [CCSprite spriteWithFile:@"raccoon.png"];
		raccoonSprite2.position = ccp(50, 150);
		raccoonSprite2.scale = 0.6f;
		raccoonSprite2.color = ccRED;
		[self addChild:raccoonSprite2];
		
		[raccoonSprite2 runAction:[MoveSineAction actionWithDuration:8.0f
															  length:430.0f
														   amplitude:100.0f
														   frequency:0.05f]];
				
		CCSprite *raccoonSprite3 = [CCSprite spriteWithFile:@"raccoon.png"];
		raccoonSprite3.position = ccp(50, 50);
		raccoonSprite3.scale = 0.6f;
		raccoonSprite3.color = ccGREEN;
		[self addChild:raccoonSprite3];
		
		[raccoonSprite3 runAction:[MoveSineAction actionWithDuration:8.0f
															  length:430.0f
														   amplitude:20.0f
														   frequency:1.0f]];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
