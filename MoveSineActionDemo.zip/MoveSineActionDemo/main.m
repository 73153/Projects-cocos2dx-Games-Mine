//
//  main.m
//  MoveSineActionDemo
//
//  Created by supersuraccoon on 9/16/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"MoveSineActionDemoAppDelegate");
	[pool release];
	return retVal;
}
