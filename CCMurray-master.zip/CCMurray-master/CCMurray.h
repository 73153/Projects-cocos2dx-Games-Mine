/** CCMurray.h
 *
 * Created By: Anthony Bongers
 * Email: bongers.anthony@gmail.com
 *
 * Retrieves an image of Bill Murray for a quick temp graphic.
 */

#ifndef CCMURRAY_H_
#define CCMURRAY_H_

#include "cocos2d.h"

class CCMurray : public cocos2d::CCSprite
{
public:
  /** Returns an autoreleased Bill Murray sprite.
   *
   * size: The graphic dimensions in pixels.
   */
  static CCMurray *create(cocos2d::CCSize size);
};

#endif  /* CCMURRAY_H_ */