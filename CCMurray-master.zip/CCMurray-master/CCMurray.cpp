#include "CCMurray.h"
#include "curl.h"

USING_NS_CC;

/* A cURL write function for writing to file.
 * http://curl.haxx.se/libcurl/c/curl_easy_setopt.html#CURLOPTWRITEFUNCTION
 */
size_t curl_write(void *ptr, size_t size, size_t nmemb, FILE *stream) {
  return fwrite(ptr, size, nmemb, stream);
} 

/* 1) Retrieves graphic using cURL.
 * 2) Stores graphic in a temporary file.
 * 3) Returns an auto-released graphic of Bill Murray, or NULL on fail.
 */
CCMurray *CCMurray::create(CCSize size) {
  std::string dir = CCFileUtils::sharedFileUtils()->getWriteablePath();
  dir.append("temp_murray.jpg");
  
  CURL *curl = curl_easy_init();
  if(curl) {
    // Open up writable temp graphic.
    FILE *file = fopen(dir.c_str(), "wb");

    // Generate URL for proper image size.
    char url[64];
    sprintf(url, "fillmurray.com/%d/%d", (int)size.width, (int)size.height);

    // Allow follow location for "302 File Found" redirect.
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, file); 

    // Write the image to the file.
    curl_easy_perform(curl);
    
    fclose(file);
  }

  curl_easy_cleanup(curl);

  // Create and return an auto-released Murray.
  CCMurray *murray = new CCMurray();
  if (murray && murray->initWithFile(dir.c_str())) {
      murray->autorelease();
      return murray;
  }

  // Otherwise return NULL on fail.
  CC_SAFE_DELETE(murray);
  return NULL;
}