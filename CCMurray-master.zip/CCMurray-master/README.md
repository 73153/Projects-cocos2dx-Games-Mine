CCMurray
========

I've found myself wanting to get images on the scene of a game quickly, but I'm hindered by needing to make temp sprites in many pixel dimentions for different objects. 

That's where Bill Murray comes in! 

Now all you need to do is call a single static create function with a CCSize parameter, and you have a derived CCSprite object of Bill Murray in the exact size you wanted! How cool is that?

Example:

```javascript
  // This will add a 760x800 CCSprite of Bill Murray the the scene.
  this->addChild(CCMurray::create(CCSize(760, 800)));
```
