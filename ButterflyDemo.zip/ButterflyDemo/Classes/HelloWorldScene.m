//
//  HelloWorldLayer.m
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright none 2010. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"
#import "Butterfly.h"
#import "Background.h"

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

- (void)doStep:(ccTime)delta
{
	if(_isBgMoving) {
		if([_background move: delta]) {
			_isBgMoving = NO;
			_butterfly.velocity = ccp(50, -20);
		}
	}
	
	[_butterfly move: delta];
}

- (void)keepFlyingUp:(ccTime)delta
{
	[_butterfly flyUp];
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super init] )) {
		
		[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
		
		_isBgMoving = YES;
		_isFlyingUp = NO;
		
		_background = [Background backgroundWithTexture: [[CCTextureCache sharedTextureCache] addImage: @"bg.png"]];
		_background.anchorPoint = CGPointZero;
		_background.position = ccp(0, 0);
		_startingVelocity = ccp(-30, 0);
		_background.velocity = _startingVelocity;
		
		[self addChild: _background z: -1];
		
		_butterfly = [Butterfly butterflyWithTexture: [[CCTextureCache sharedTextureCache] addImage: @"butterfly.png"]];
		_startingVelocity = ccp(0, -40);
		_butterfly.position = ccp(50, 300);
		_butterfly.velocity = _startingVelocity;
		
		[self addChild: _butterfly];
			
		[self schedule:@selector(doStep:)];
	}
	return self;
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location = [touch locationInView: [touch view]];
	CGPoint touchPoint = [[CCDirector sharedDirector]convertToGL:location];
	
	if(touchPoint.x < 240) {
		_butterfly.velocity = ccpAdd(_butterfly.velocity, ccp(80, 0));
	}
	
	else {
		_isFlyingUp = YES;
		[_butterfly flyUp];
		
		if(_isFlyingUp) {
			[self schedule: @selector(keepFlyingUp:) interval: 0.1f];
		}
	}

	return YES;
}

- (void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
	_isFlyingUp = NO;
	[self unschedule: @selector(keepFlyingUp:)];
}

- (void) dealloc
{
	[_butterfly release];
	[_background release];
	[super dealloc];
}
@end
