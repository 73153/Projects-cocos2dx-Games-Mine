//
//  Butterfly.m
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright 2010 none. All rights reserved.
//

#import "Butterfly.h"

@implementation Butterfly

@synthesize velocity;

- (CGRect)rect
{
	CGSize s = [self.texture contentSize];
	return CGRectMake(self.position.x -s.width / 2, 
					  self.position.y -s.height / 2, 
					  s.width, 
					  s.height);
}

+ (id)butterflyWithTexture:(CCTexture2D *)aTexture
{
	return [[[self alloc] initWithTexture:aTexture] autorelease];
}

- (void)move:(ccTime)delta
{	
	self.position = ccpAdd(self.position, ccpMult(self.velocity, delta));
	
	if(self.position.y - self.rect.size.height/2 < 0) {
		self.position = ccp(self.position.x, self.rect.size.height/2);
	}
	
	if(self.position.y + self.rect.size.height/2 > 320) {
		self.position = ccp(self.position.x, 320 - self.rect.size.height/2);
	}
	
	if(self.velocity.y > -40) {
		self.velocity = ccpAdd(self.velocity, ccp(0, -2));
	}
	
	if(self.velocity.y > 40) {
		self.velocity = ccp(self.velocity.x, 40);
	}
	
	if(self.velocity.x > 0) {
		self.velocity = ccpAdd(self.velocity, ccp(-5, 0));
	}
}

-(void)flyUp
{	
	if(self.position.y + self.rect.size.height/2 <= 320) {
		
		self.velocity = ccpAdd(self.velocity, ccp(0, 30));
	}
}

@end
