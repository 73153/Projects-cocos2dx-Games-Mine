//
//  ButterflyDemoAppDelegate.h
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright none 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButterflyDemoAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
