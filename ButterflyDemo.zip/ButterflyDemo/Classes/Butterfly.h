//
//  Butterfly.h
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright 2010 none. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Butterfly : CCSprite {
	CGPoint velocity;
}

@property(nonatomic) CGPoint velocity;
@property(nonatomic, readonly) CGRect rect;

+ (id)butterflyWithTexture:(CCTexture2D *)texture;
- (void)move:(ccTime)delta;
- (void)flyUp;

@end
