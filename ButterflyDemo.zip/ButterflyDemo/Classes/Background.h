//
//  Background.h
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright 2010 none. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Background : CCSprite {
	CGPoint velocity;
}

@property(nonatomic) CGPoint velocity;
@property(nonatomic, readonly) CGRect rect;

+ (id)backgroundWithTexture:(CCTexture2D *)texture;
- (bool)move:(ccTime)delta;

@end
