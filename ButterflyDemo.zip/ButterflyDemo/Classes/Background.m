//
//  Background.m
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright 2010 none. All rights reserved.
//

#import "Background.h"


@implementation Background

@synthesize velocity;

- (CGRect)rect
{
	CGSize s = [self.texture contentSize];
	return CGRectMake(self.position.x -s.width / 2, 
					  self.position.y -s.height / 2, 
					  s.width, 
					  s.height);
}

+ (id)backgroundWithTexture:(CCTexture2D *)aTexture
{
	return [[[self alloc] initWithTexture:aTexture] autorelease];
}

- (bool)move:(ccTime)delta
{
	CGPoint orgPt = self.position;

	self.position = ccpAdd(self.position, ccpMult(velocity, delta));
	
	if(480 - self.position.x >= self.rect.size.width) {
		self.position = orgPt;
		return YES;
	}
	else {
		return NO;
	}
}

@end
