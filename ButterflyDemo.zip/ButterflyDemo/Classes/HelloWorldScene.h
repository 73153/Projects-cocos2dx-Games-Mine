//
//  HelloWorldLayer.h
//  ButterflyDemo
//
//  Created by xiaochen su on 16/10/2010.
//  Copyright none 2010. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

@class Butterfly;
@class Background;

@interface HelloWorld : CCLayer
{
	bool _isBgMoving;
	bool _isFlyingUp;
	Background *_background;
	Butterfly *_butterfly;
	CGPoint _startingVelocity;
}


+(id) scene;

@end
