//
//  gameLayer.h
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright 2010 zhong. All rights reserved.
//

#import "cocos2d.h"
#import "tankSprite.h"
//地图移动枚举
typedef enum {
	kUp=1,
	kDown=2,
	kLeft=3,
	kRight=4,
	kFire=5,
	kStay=6,
}mapAction;
@interface gameLayer : CCLayer {
	
	//游戏地图
	CCTMXTiledMap *gameWorld;
	

	
	//坦克精灵
	tankSprite *tank;
	
	NSMutableArray *enemyList;
	
	float mapX,mapY;
	float screenWidth,screenHight,tileSize;
	float viewOrgX,viewOrgY,viewOrgZ;

}
@property (nonatomic,readwrite,assign) float mapX;
@property (nonatomic,readwrite,assign) float mapY;
@property (nonatomic,readwrite,assign) float screenWidth;
@property (nonatomic,readwrite,assign) float screenHight;
@property (nonatomic,readwrite,assign) float tileSize;
@property (nonatomic,readwrite,assign) CCTMXTiledMap *gameWorld;
@property (nonatomic,readwrite,assign) tankSprite *tank;
@property (nonatomic,readwrite,assign) NSMutableArray *enemyList;


-(float)gameWorldWidth;
-(float)gameWorldHeight;
-(void)onMapAction:(mapAction)kma;
-(void)onTankaction:(tankAction)tAct;
-(void)showExplodeAt:(CGPoint)posAt;
-(CGPoint)tileCoordinateFromPos:(CGPoint)pos;
@end
