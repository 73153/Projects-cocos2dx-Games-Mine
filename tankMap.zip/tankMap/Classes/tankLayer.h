//
//  tankLayer.h
//  tankMap
//
//  Created by mirror on 10-5-25.
//  Copyright 2010 zhong. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface tankLayer : NSObject {

}

@end
