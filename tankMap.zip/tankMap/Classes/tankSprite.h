//
//  tankSprite.h
//  tankMap
//
//  Created by mirror on 10-5-25.
//  Copyright 2010 zhong. All rights reserved.
//

#import "cocos2d.h"
#import "bulletSprite.h"

typedef enum{
	tUp=1,
	tDown=2,
	tLeft=3,
	tRight=4,
	tStay=5,
	tFire=6,
}tankAction;

@interface tankSprite : CCSprite {
	BOOL isEnemy;
	tankAction tAct;
	float runSpeed,turnSpeed,moveStep;
	CCLayer *gLayer;
	float joint;
	bulletSprite *bullet;
	int randomcount;

}


@property(nonatomic,readwrite,assign)tankAction tAct;
@property(nonatomic,readwrite,assign)BOOL isEnemy;
@property(nonatomic,readwrite,assign)float moveStep;

+(id)tankWithLayer:(CCLayer *)layer imageFile:(NSString *)imgFile;
-(void)tankMoveUp:(CCLayer *)layer;
-(void)tankMoveDown:(CCLayer *)layer;
-(void)tankMoveLeft:(CCLayer *)layer;
-(void)tankMoveRight:(CCLayer *)layer;
-(void)tankFire:(CCLayer *)layer;
-(void)tankStay:(CCLayer *)layer;
@end
