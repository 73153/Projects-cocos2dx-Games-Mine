//
//  controlLayer.m
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright 2010 zhong. All rights reserved.
//

#import "controlLayer.h"

@implementation controlLayer
@synthesize glayer;


-(id)init{
	self=[super init];
	if (self) {
		CCSpriteSheet *mgr=[CCSpriteSheet spriteSheetWithFile:@"JoyStickMenu.png"];
		[self addChild:mgr];


		item_f_n = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((2+5)*11,0,11,11)];
		[item_f_n setPosition:ccp(0,0)];		
		[mgr addChild:item_f_n];

		
		//UP
		item_u_on = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((0+5)*11,0,11,11)];
		item_u_out = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((0+0)*11,0,11,11)];
		[item_u_on setPosition:ccp(0,11)];
		[item_u_out setPosition:ccp(0,11)];		
		[mgr addChild:item_u_on];
		[mgr addChild:item_u_out];
		[item_u_on setVisible:NO];
		
		//DOWN
		item_d_on = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((4+5)*11,0,11,11)];
		item_d_out = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((4+0)*11,0,11,11)];
		[item_d_on setPosition:ccp(0,-11)];
		[item_d_out setPosition:ccp(0,-11)];		
		[mgr addChild:item_d_on];
		[mgr addChild:item_d_out];
		[item_d_on setVisible:NO];
		
		//Left
		item_l_on = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((1+5)*11,0,11,11)];
		item_l_out = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((1+0)*11,0,11,11)];
		[item_l_on setPosition:ccp(-11,0)];
		[item_l_out setPosition:ccp(-11,0)];		
		[mgr addChild:item_l_on];
		[mgr addChild:item_l_out];
		[item_l_on setVisible:NO];
		
		//Right
		item_r_on = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((3+5)*11,0,11,11)];
		item_r_out = [CCSprite spriteWithTexture:mgr.texture rect:CGRectMake((3+0)*11,0,11,11)];
		[item_r_on setPosition:ccp(11,0)];
		[item_r_out setPosition:ccp(11,0)];		
		[mgr addChild:item_r_on];
		[mgr addChild:item_r_out];
		[item_r_on setVisible:NO];
		
		mgr.position=ccp(240,30);
		
		[self setIsTouchEnabled:YES];
	}	
	return self;
}

//控制地图连续移动
-(void)keepDoing{
	//[glayer onMapAction:kAct];
	[glayer onTankaction:tAct];
}

-(void)registerWithTouchDispatcher{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
													 priority:INT_MIN+1
											  swallowsTouches:YES];
}
-(CGRect)AtlasRect:(CCSprite *)atlSpr{
	CGRect crect=[atlSpr textureRect];
	return CGRectMake(-crect.size.width/2,-crect.size.height/2,crect.size.width,crect.size.height);
}
-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
	CGPoint location;
	CGRect temprect;
	location=[item_f_n convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_f_n];
	if (CGRectContainsPoint(temprect, location)) {
		tAct=tFire;
		[self schedule:@selector(keepDoing) interval:1/30];
		return YES;
	}
	
	location=[item_u_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_u_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_u_on setVisible:NO];
		[item_u_out setVisible:YES];
		tAct=tUp;
		[self schedule:@selector(keepDoing) interval:1/30];
		return YES;
	}
	
	location=[item_d_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_d_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_d_on setVisible:NO];
		[item_d_out setVisible:YES];
		tAct=tDown;
		[self schedule:@selector(keepDoing) interval:1/30];
		return YES;
	}
	
	location=[item_l_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_l_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_l_on setVisible:NO];
		[item_l_out setVisible:YES];
		tAct=tLeft;
		[self schedule:@selector(keepDoing) interval:1/30];
		return YES;
	}
	
	location=[item_r_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_r_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_r_on setVisible:NO];
		[item_r_out setVisible:YES];
		tAct=tRight;
		[self schedule:@selector(keepDoing) interval:1/30];
		return YES;
	}
	
	return NO;
}
-(void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event{
	CGPoint location;
	CGRect temprect;
	BOOL bHit=NO;
	mapAction lastAct;
	
	lastAct=kAct;
	location=[item_u_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_u_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_u_on setVisible:NO];
		[item_u_out setVisible:YES];
		kAct=kUp;
		bHit=YES;
	}
	
	location=[item_d_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_d_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_d_on setVisible:NO];
		[item_d_out setVisible:YES];
		kAct=kDown;
		bHit=YES;
	}
	
	location=[item_l_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_l_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_l_on setVisible:NO];
		[item_l_out setVisible:YES];
		kAct=kLeft;
		bHit=YES;
	}
	
	location=[item_r_on convertTouchToNodeSpaceAR:touch];
	temprect=[self AtlasRect:item_r_on];
	if (CGRectContainsPoint(temprect, location)) {
		[item_r_on setVisible:NO];
		[item_r_out setVisible:YES];
		kAct=kRight;
		bHit=YES;
	}
	
	if (!bHit) {
		[self unschedule:@selector(keepDoing)];
		[item_u_on setVisible:YES];
		[item_u_out setVisible:NO];
		[item_d_on setVisible:YES];
		[item_d_out setVisible:NO];
		[item_l_on setVisible:YES];
		[item_l_out setVisible:NO];
		[item_r_on setVisible:YES];
		[item_r_out setVisible:NO];
		
		kAct=kStay;
	}else {
		if (lastAct!=kAct) {
			[self schedule:@selector(keepDoing) interval:1/30];
		}
	}

}
-(void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
	[self unschedule:@selector(keepDoing)];
	[item_u_on setVisible:YES];
	[item_u_out setVisible:NO];
	[item_d_on setVisible:YES];
	[item_d_out setVisible:NO];
	[item_l_on setVisible:YES];
	[item_l_out setVisible:NO];
	[item_r_on setVisible:YES];
	[item_r_out setVisible:NO];
	
	kAct=kStay;
}


-(void)dealloc{
	[super dealloc];
}
@end
