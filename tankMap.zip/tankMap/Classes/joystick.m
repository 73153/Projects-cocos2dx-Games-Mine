//
//  joystick.m
//  tankMap
//
//  Created by mirror on 10-5-25.
//  Copyright 2010 zhong. All rights reserved.
//

#import "joystick.h"


@implementation joystick
@synthesize glayer;

+(id)initWithArgument:(CGPoint)aPoint Radius:(float)radius jsSprite:(CCSprite *)ajs jsSpriteBg:(CCSprite *)ajsBg
{
	return [[[joystick alloc] initWithArgument:aPoint Radius:radius jsSprite:ajs jsSpriteBg:ajsBg] autorelease];
}
-(id)initWithArgument:(CGPoint)aPoint Radius:(float)radius jsSprite:(CCSprite *)ajs jsSpriteBg:(CCSprite *)ajsBg
{
	self=[super init];
	if (self) {
		centerPoint=aPoint;
		currentPoint=centerPoint;
		isActive=NO;
		Radius=radius;
		
		jsSprite=ajs;
		jsSpriteBg=ajsBg;
		
		jsSprite.position=centerPoint;
		jsSpriteBg.position=centerPoint;
		
		jsSprite.opacity=0.0f;
		jsSpriteBg.opacity=0.0f;
		
		[self addChild:jsSprite z:2];
		[self addChild:jsSpriteBg z:1];
	}
	return self;
}
-(void)jsActive{
	if (!isActive) {
		isActive=YES;
		
		[jsSprite runAction:[CCFadeTo actionWithDuration:0.5f opacity:100]];
		[jsSpriteBg runAction:[CCFadeTo actionWithDuration:0.5f opacity:100]];
		//添加触摸委托
		[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
														 priority:INT_MIN+1
												  swallowsTouches:YES];
		//添加更新函数
		[self schedule:@selector(UpDatePos:)];
		
	}
}
-(void)jsUnActive{
	if (isActive) {
		isActive=NO;
		[self unschedule:@selector(UpDatePos:)];
		[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	}
}
-(void)UpDatePos:(ccTime)dt{
	jsSprite.position = ccpAdd(jsSprite.position,ccpMult(ccpSub(currentPoint, jsSprite.position),0.5));
	[self keepDoing];
}

//控制地图连续移动
-(void)keepDoing{
	//计算摇杆偏移的度数
	float distanX=jsSprite.position.x-centerPoint.x;
	float distanY=jsSprite.position.y-centerPoint.y;
	float angle=361.00f;
	
	if (distanX>0&&distanY>0){
		distanX=fabsf(distanX);
		distanY=fabsf(distanY);
		angle=atan2(distanX, distanY)*180/M_PI;		
	}else if(distanX<0&&distanY>0){
		distanX=fabsf(distanX);
		distanY=fabsf(distanY);
		angle=atan2(distanY, distanX)*180/M_PI;
		angle+=270;
	}else if (distanX>0&&distanY<0){
		distanX=fabsf(distanX);
		distanY=fabsf(distanY);
		angle=atan2(distanY, distanX)*180/M_PI;
		angle+=90;
	}else if (distanX<0&&distanY<0){
		distanX=fabsf(distanX);
		distanY=fabsf(distanY);
		angle=atan2(distanX, distanY)*180/M_PI;
		angle+=180;
	}
	//偏移度数决定上下左右
	if ((angle<45||angle>=315)&&angle<=360) {
		tAct=tUp;
	}else if (angle>=45&&angle<135) {
		tAct=tRight;
	}else if (angle>=135&&angle<215) {
		tAct=tDown;
	}else if (angle>=215&&angle<315) {
		tAct=tLeft;
	}else {
		tAct=tStay;
	}
	//获取离中心点的长度，设定移动的步长
	float length=sqrtf(distanX*distanX+distanY*distanY);
	if (length>0&&length<20) {
		glayer.tank.moveStep=1;
	}else if (length>=20&&length<40) {
		glayer.tank.moveStep=2;
	}else if (length>40&&length<Radius) {
		glayer.tank.moveStep=4;
	}
	
	[glayer onTankaction:tAct];
}
//获取摇杆方位
-(CGPoint)getDirection{
	return ccpNormalize(ccpSub(centerPoint, currentPoint));
}
//获取摇杆力度
-(float)getVelocity{
	return ccpDistance(centerPoint, currentPoint);
}
-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
	
	if (!isActive) {
		return NO;
	}
	CGPoint touchPoint=[touch locationInView:[touch view]];
	touchPoint=[[CCDirector sharedDirector] convertToGL:touchPoint];
	
	if (ccpDistance(touchPoint, centerPoint)>Radius) {
		return NO;
	}else {
		[jsSpriteBg runAction:[CCFadeTo actionWithDuration:0.05 opacity:255]];
		[jsSprite runAction:[CCFadeTo actionWithDuration:0.05 opacity:255]];
		
		currentPoint=touchPoint;
		return YES;
	}	
}
-(void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event{
	CGPoint touchPoint=[touch locationInView:[touch view]];
	touchPoint=[[CCDirector sharedDirector] convertToGL:touchPoint];
	
	[jsSpriteBg runAction:[CCFadeTo actionWithDuration:0.05 opacity:255]];
	[jsSprite runAction:[CCFadeTo actionWithDuration:0.05 opacity:255]];
	
	if (ccpDistance(touchPoint, centerPoint)>Radius) {
		currentPoint =ccpAdd(centerPoint,ccpMult(ccpNormalize(ccpSub(touchPoint, centerPoint)),Radius));
	}else {
		currentPoint=touchPoint;
	}	
}
-(void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
	[jsSprite runAction:[CCFadeTo actionWithDuration:3 opacity:150]];
	[jsSpriteBg runAction:[CCFadeTo actionWithDuration:3 opacity:150]];
	
	currentPoint=centerPoint;
}
-(void)dealloc{
	[super dealloc];
}
@end
