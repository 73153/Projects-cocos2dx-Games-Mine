//
//  mainScene.m
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright 2010 zhong. All rights reserved.
//

#import "mainScene.h"
#import "gameLayer.h"
#import "controlLayer.h"
#import "joystick.h"
#import "fireBtn.h"

@implementation mainScene


+(id)scene{
	mainScene *scene=[mainScene node];
	
	return scene;
}
-(id)init{
	self=[super init];
	if (self) {
		gameLayer *glayer=[gameLayer node];
		controlLayer *clayer=[controlLayer node];
		clayer.glayer=glayer;
		
		fireBtn *firebtn=[fireBtn node];
		firebtn.gLayer=glayer;
		[firebtn fireActive];
		
		//添加摇杆
		CCSprite *ajs=[CCSprite spriteWithFile:@"cup1.png"];
		CCSprite *ajsBg=[CCSprite spriteWithFile:@"js.png"];
		joystick *ajoystick=[joystick initWithArgument:ccp(80,80)
												Radius:60
											  jsSprite:ajs
											jsSpriteBg:ajsBg];
		[self addChild:ajoystick z:99];
		[ajoystick jsActive];
		ajoystick.glayer=glayer;
		
		[self addChild:glayer];
		[self addChild:clayer];
		[self addChild:firebtn z:99];
	}
	return self;
}
-(void)dealloc{
	[super dealloc];
}
@end
