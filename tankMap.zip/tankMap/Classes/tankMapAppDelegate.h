//
//  tankMapAppDelegate.h
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright zhong 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tankMapAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
