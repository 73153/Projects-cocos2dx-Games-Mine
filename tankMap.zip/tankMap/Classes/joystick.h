//
//  joystick.h
//  tankMap
//
//  Created by mirror on 10-5-25.
//  Copyright 2010 zhong. All rights reserved.
//
#import <math.h>
#import "cocos2d.h"
#import "tankSprite.h"
#import "gameLayer.h"

@interface joystick : CCLayer {
	CGPoint centerPoint;	//中心点
	CGPoint currentPoint;	//当前位置
	float Radius;			//半径
	bool isActive;			//是否激活
	CCSprite *jsSprite;		//摇杆
	CCSprite *jsSpriteBg;	//摇杆背景
	
	
	
	tankAction tAct;
	// action button
	CCSprite *item_f_n, *item_f_s, *item_u_out, *item_u_on, *item_l_out, *item_l_on, *item_r_out, *item_r_on, *item_d_out, *item_d_on;
	gameLayer *glayer;
	
}
@property(nonatomic,readwrite,assign)gameLayer *glayer;

//连续移动
-(void)keepDoing;

+(id)initWithArgument:(CGPoint)aPoint Radius:(float)radius jsSprite:(CCSprite *)ajs jsSpriteBg:(CCSprite *)ajsBg;
-(id)initWithArgument:(CGPoint)aPoint Radius:(float)radius jsSprite:(CCSprite *)ajs jsSpriteBg:(CCSprite *)ajsBg;

-(void)jsActive;
-(void)jsUnActive;
@end
