//
//  mainScene.h
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright 2010 zhong. All rights reserved.
//

#import "cocos2d.h"


@interface mainScene : CCScene {

}
+(id)scene;
@end
