//
//  tankSprite.m
//  tankMap
//
//  Created by mirror on 10-5-25.
//  Copyright 2010 zhong. All rights reserved.
//

#import "tankSprite.h"
#import "gameLayer.h"


@implementation tankSprite

@synthesize tAct,isEnemy,moveStep;


+(id)tankWithLayer:(CCLayer *)layer imageFile:(NSString *)imgFile{
	
	gameLayer *ly=(gameLayer *)layer;
	
	CCSpriteSheet *animationSheet=[CCSpriteSheet spriteSheetWithFile:imgFile capacity:3];
	[ly.gameWorld addChild:animationSheet z:99 tag:1];
	
	tankSprite *tank=[tankSprite spriteWithTexture:animationSheet.texture rect:CGRectMake(0, 0, 40, 40)];
	[animationSheet addChild:tank z:0 tag:2];
	
	[tank setLayer:layer];
	//坦克初始化
	[tank tankInit];
	
	return tank;
}
-(void)setLayer:(CCLayer *)layer{
	gLayer=layer;
}
-(void)tankInit{
	runSpeed=20;
	moveStep=2;
	tAct=tStay;
	joint=2.9;
}
-(void)tankMoveUp:(CCLayer *)layer{
	gameLayer *ly=(gameLayer *)layer;
	CGPoint npt;
	unsigned tid;
	tAct=tUp;

	//转向角度
	[self setRotation:0];
	//选取3个点作为检测前方是否存在障碍物,转换到瓦片坐标是草地(GID=4)才能向前移动
	float x=self.position.x;
	float y=self.position.y;
	

	float tempWidth=x-self.textureRect.size.width/joint;
	float tempHeight=y+self.textureRect.size.height/2+moveStep;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempWidth=x;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempWidth=x+self.textureRect.size.width/joint;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}	
	//地图边界检测
	if ([ly gameWorldHeight]-y<=self.textureRect.size.height/2) {
		[self setPosition:ccp(x,[ly gameWorldHeight]-self.textureRect.size.height/2)];
	}else {
		[self setPosition:ccp(x,y+moveStep)];
	}

}
-(void)tankMoveDown:(CCLayer *)layer{
	gameLayer *ly=(gameLayer *)layer;
	CGPoint npt;
	unsigned tid;
	tAct=tDown;
	
	//转向角度
	[self setRotation:180];
	//选取5个点作为检测前方是否存在障碍物,转换到瓦片坐标是草地(GID=4)才能向前移动
	float x=self.position.x;
	float y=self.position.y;
	
	float tempWidth=x-self.textureRect.size.width/joint;
	float tempHeight=y-self.textureRect.size.height/2-moveStep;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempWidth=x;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempWidth=x+self.textureRect.size.width/joint;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	//地图边界检测
	if (y-ly.mapY<=self.textureRect.size.height/2) {
		[self setPosition:ccp(x,self.textureRect.size.height/2)];
	}else {
		[self setPosition:ccp(x,y-moveStep)];
	}

}
-(void)tankMoveLeft:(CCLayer *)layer{
	gameLayer *ly=(gameLayer *)layer;
	CGPoint npt;
	unsigned tid;
	tAct=tLeft;
	
	//转向角度
	[self setRotation:-90];
	//选取5个点作为检测前方是否存在障碍物,转换到瓦片坐标是草地(GID=4)才能向前移动
	float x=self.position.x;
	float y=self.position.y;

	float tempWidth=x-self.textureRect.size.width/2-moveStep;
	float tempHeight=y-self.textureRect.size.height/joint;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempHeight=y+moveStep;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	tempHeight=y+self.textureRect.size.height/joint;
	npt=ccp(tempWidth,tempHeight);
	tid=[ly tileIDFromPosition:npt];
	if (tid!=4) {
		return;
	}
	//地图边界检测
	if (x-[ly mapX]<=self.textureRect.size.width/2) {
		[self setPosition:ccp(self.textureRect.size.width/2,y)];
	}else {
		[self setPosition:ccp(x-moveStep,y)];
	}

}
-(void)tankMoveRight:(CCLayer *)layer{
	gameLayer *ly=(gameLayer *)layer;
	CGPoint npt;
	unsigned tid;
	tAct=tRight;
	
	//转向角度
	[self setRotation:90];
	//选取5个点作为检测前方是否存在障碍物,转换到瓦片坐标是草地(GID=4)才能向前移动
	float x=self.position.x;
	float y=self.position.y;
	

		float tempWidth=x+self.textureRect.size.width/2+moveStep;
		float tempHeight=y-self.textureRect.size.height/joint;
		npt=ccp(tempWidth,tempHeight);
		tid=[ly tileIDFromPosition:npt];
		if (tid!=4) {
			return;
		}
		tempHeight=y;
		npt=ccp(tempWidth,tempHeight);
		tid=[ly tileIDFromPosition:npt];
		if (tid!=4) {
			return;
		}
		tempHeight=y+self.textureRect.size.height/joint;
		npt=ccp(tempWidth,tempHeight);
		tid=[ly tileIDFromPosition:npt];
		if (tid!=4) {
			return;
		}

	//地图边界检测
	if ([ly gameWorldWidth]-x<=self.textureRect.size.width/2) {
		[self setPosition:ccp([ly gameWorldWidth]-x<=self.textureRect.size.width/2,y)];
	}else {
		[self setPosition:ccp(x+moveStep,y)];
	}

}
-(void)tankFire:(CCLayer *)layer isEnemy:(BOOL)flag{
	
	CGPoint cptbullet;
	
	bullet=[bulletSprite initWithLayer:gLayer];
	bullet.isEnemy=flag;
	switch (tAct) {
		case tUp:
			[bullet setPosition:ccp(self.position.x+2,self.position.y+self.textureRect.size.height/2)];
			cptbullet=ccp(self.position.x,self.position.y+1024);
			break;
		case tDown:
			[bullet setPosition:ccp(self.position.x+2,self.position.y-self.textureRect.size.height/2)];
			cptbullet=ccp(self.position.x,self.position.y-1024);
			break;
		case tLeft:
			[bullet setPosition:ccp(self.position.x-self.textureRect.size.width/2,self.position.y-2)];
			cptbullet=ccp(self.position.x-1024,self.position.y);
			break;
		case tRight:
			[bullet setPosition:ccp(self.position.x+self.textureRect.size.width/2,self.position.y-2)];
			cptbullet=ccp(self.position.x+1024,self.position.y);
			break;
		default:
			break;
	}
	
	id ac1=[CCShow action];
	id ac2=[CCMoveTo actionWithDuration:3 position:cptbullet];
	
	id seq=[CCSequence actions:ac1,ac2,nil];
	[bullet runAction:seq];
	[bullet schedule:@selector(checkBullectCollision) interval:1/60];
}

-(void)enemyActive{
	float rand=CCRANDOM_0_1();
	if (rand<=0.2) {
		tAct=tUp;
	}else if (rand>0.2&&rand<=0.4) {
		tAct=tLeft;
	}else if (rand>0.4&&rand<=0.6) {
		tAct=tRight;
	}else {
		tAct=tDown;
	}
	
	randomcount=0;
	[self schedule:@selector(keepPlay) interval:1/30];
}
-(void)keepPlay{
	switch (tAct) {
		case tUp:
			[self tankMoveUp:gLayer];
			break;
		case tDown:
			[self tankMoveDown:gLayer];
			break;
		case tLeft:
			[self tankMoveLeft:gLayer];
			break;
		case tRight:
			[self tankMoveRight:gLayer];
			break;
		default:
			break;
	}
	randomcount+=1;
	if (randomcount>=20) {
		[self unschedule:@selector(keepPlay)];
		[self tankFire:gLayer isEnemy:YES];
	}
}
-(void)tankDeath{
	
}
-(void)tankStay:(CCLayer *)layer{
	
}
-(void)dealloc{
	[super dealloc];
}
@end
