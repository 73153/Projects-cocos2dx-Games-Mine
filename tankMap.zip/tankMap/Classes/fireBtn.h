//
//  fireBtn.h
//  tankMap
//
//  Created by mirror on 10-5-30.
//  Copyright 2010 zhong. All rights reserved.
//

#import "cocos2d.h"
#import "gameLayer.h"
#import "tankSprite.h"

@interface fireBtn : CCLayer {
	gameLayer *gLayer;
	tankAction tAct;
	
	CCSprite *sprite;
	BOOL isActive;
}
@property(nonatomic,readwrite,assign)gameLayer *gLayer;
-(void)fireActive;
@end
