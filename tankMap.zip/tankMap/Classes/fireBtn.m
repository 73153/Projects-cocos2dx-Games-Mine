//
//  fireBtn.m
//  tankMap
//
//  Created by mirror on 10-5-30.
//  Copyright 2010 zhong. All rights reserved.
//

#import "fireBtn.h"


@implementation fireBtn
@synthesize gLayer;

-(id)init{
	self=[super init];
	if (self) {
		sprite=[CCSprite spriteWithFile:@"fire.png"];
		[self addChild:sprite];
		[sprite setPosition:ccp(400,80)];
		sprite.opacity=0.0f;
		
		[self setIsTouchEnabled:YES];
	}
	return self;
}
-(void)fireActive{
	if (!isActive) {
		isActive=YES;
		
		[sprite runAction:[CCFadeTo actionWithDuration:0.5f opacity:100]];
		//添加触摸委托
		[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
														 priority:INT_MIN+1
												  swallowsTouches:YES];
		[self schedule:@selector(keepDoing)];
	}
}
-(void)fireUnActive{
	if (isActive) {
		isActive=NO;
		[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	}
}

//待研究
-(CGRect)AtlasRect:(CCSprite *)atlSpr{
	CGRect crect=[atlSpr textureRect];
	return CGRectMake(-crect.size.width/2,-crect.size.height/2,crect.size.width,crect.size.height);
}
-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
	
	[sprite runAction:[CCFadeTo actionWithDuration:0.1f opacity:250]];
	CGPoint touchPoint=[sprite convertTouchToNodeSpaceAR:touch];
	CGRect tempRect=[self AtlasRect:sprite];
	if (CGRectContainsPoint(tempRect, touchPoint)) {
		tAct=tFire;
		return YES;
	}
	return NO;
}
-(void)keepDoing{
	[gLayer onTankaction:tAct];
}
-(void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event{
	[sprite runAction:[CCFadeTo actionWithDuration:0.1f opacity:250]];
	CGPoint touchPoint=[sprite convertTouchToNodeSpaceAR:touch];
	CGRect tempRect=[self AtlasRect:sprite];
	if (CGRectContainsPoint(tempRect, touchPoint)) {
		tAct=tFire;
		[self keepDoing];
	}
}
-(void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
	tAct=tStay;
	[sprite runAction:[CCFadeTo actionWithDuration:5 opacity:100]];
}

-(void)dealloc{
	[super dealloc];
}
@end
