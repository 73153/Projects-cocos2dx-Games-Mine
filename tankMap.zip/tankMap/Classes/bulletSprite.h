//
//  bulletSprite.h
//  tankMap
//
//  Created by mirror on 10-5-26.
//  Copyright 2010 zhong. All rights reserved.
//

#import "cocos2d.h"


@interface bulletSprite : CCSprite {
	CCLayer *gLayer;
	//爆炸精灵
	CCSpriteSheet *sheetExplode;
	CCSprite *spriteExplode;
	
	BOOL isEnemy;
	
	
	//粒子效果
	CCParticleSystem *smokeEmitter;
	CCParticleSystem *fireEmitter;
}
@property (nonatomic,readwrite,assign)BOOL isEnemy;

+(id)initWithLayer:(CCLayer *)layer;
-(void)setGameLayer:(CCLayer *)layer;
@end
