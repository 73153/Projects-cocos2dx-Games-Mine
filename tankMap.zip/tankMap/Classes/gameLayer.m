//
//  gameLayer.m
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright 2010 zhong. All rights reserved.
//

#import "gameLayer.h"
#import "tankSprite.h"
#import "joystick.h"
#import "bulletSprite.h"

@implementation gameLayer



@synthesize mapX,mapY,screenWidth,screenHight,tileSize;
@synthesize gameWorld,tank,enemyList;


-(id)init{
	self=[super init];
	if (self) {
		gameWorld=[CCTMXTiledMap tiledMapWithTMXFile:@"Level1.tmx"];
		[self addChild:gameWorld z:0 tag:9];
		//gameWorld.position=ccp(0,-250);
		
		
		//添加坦克精灵
		tank=[tankSprite tankWithLayer:self imageFile:@"Tank.PNG"];
		tank.isEnemy=NO;
		tank.position=ccp(60,30);
		
		//添加敌方坦克
		enemyList=[[NSMutableArray alloc] initWithCapacity:3];
		tankSprite *enemy;
		for (int i=0; i<5; i++) {
			enemy=[tankSprite tankWithLayer:self imageFile:@"enemy.png"];
			enemy.isEnemy=YES;
			enemy.position=ccp(i*100,560);
			//敌方坦克激活初始化
			[enemy schedule:@selector(enemyActive) interval:0.5];
			[enemyList addObject:enemy];
		}
				
		[self setIsTouchEnabled:YES];
		
		//瓦片宽度
		tileSize=gameWorld.tileSize.width;
		mapX=0;
		mapY=0;
		
		CGSize size=[[CCDirector sharedDirector] winSize];
		screenHight=size.height;
		screenWidth=size.width;
	}
	return self;
}

-(float)gameWorldWidth{
	return gameWorld.mapSize.width*tileSize;
}
-(float)gameWorldHeight{
	return gameWorld.mapSize.height*tileSize;
}
-(void)onTankaction:(tankAction)tAct{
	switch (tAct) {
		case tUp:
			[tank tankMoveUp:self];
			[self setGameWorldPosition];
			break;
		case tDown:
			[tank tankMoveDown:self];
			[self setGameWorldPosition];
			break;
		case tLeft:
			[tank tankMoveLeft:self];
			[self setGameWorldPosition];
			break;
		case tRight:
			[tank tankMoveRight:self];
			[self setGameWorldPosition];
			break;
		case tFire:
			[tank tankFire:self isEnemy:NO];
			break;
		case tStay:
			[tank tankStay:self];
			break;
		default:
			break;
	}
}
//设置地图移动
-(void)setGameWorldPosition{
	CGRect cr=[tank textureRect];
	
	//设置地图相对坦克的位置
	if (tank.position.y<screenHight/2-cr.size.height/2) {
		mapY=0;
	}else if (tank.position.y>[self gameWorldHeight]-screenHight/2) {
		mapY=-[self gameWorldHeight];
	}else {
		mapY=-(tank.position.y-screenHight/2+cr.size.height/2);
	}

	if (tank.position.x<screenWidth/2-cr.size.width/2) {
		mapX=0;
	}else if (tank.position.x>[self gameWorldWidth]-screenWidth/2) {
		mapX=-[self gameWorldWidth];
	}else {
		mapX=-(tank.position.x-screenWidth/2+cr.size.width/2);
	}
	//上下左右移动超出地图的时候设置地图的最大边值
	if(mapX>0)mapX=0;
	if(mapY>0)mapY=0;
	if (mapX<-([self gameWorldWidth]-screenWidth)) {
		mapX=-([self gameWorldWidth]-screenWidth);
	}
	if (mapY<-([self gameWorldHeight]-screenHight)) {
		mapY=-([self gameWorldHeight]-screenHight);
	}
	
	gameWorld.position=ccp(mapX,mapY);

}
-(void)onMapAction:(mapAction)kma{
	switch (kma) {
		case kUp:
			mapY=mapY-2;
			break;
		case kDown:
			mapY=mapY+2;
			break;
		case kLeft:
			mapX=mapX+2;
			break;
		case kRight:
			mapX=mapX-2;
			break;
		default:
			break;
	}
	//上下左右移动超出地图的时候设置地图的最大边值
	if(mapX>0)mapX=0;
	if(mapY>0)mapY=0;
	if (mapX<-([self gameWorldWidth]-screenWidth)) {
		mapX=-([self gameWorldWidth]-screenWidth);
	}
	if (mapY<-([self gameWorldHeight]-screenHight)) {
		mapY=-([self gameWorldHeight]-screenHight);
	}
	
	gameWorld.position=ccp(mapX,mapY);
}
-(void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
	return;
	//获取触摸点位置
	UITouch *touch=[touches anyObject];
	CGPoint touchPoint=[touch locationInView:[touch view]];
	touchPoint=[[CCDirector sharedDirector] convertToGL:touchPoint];
	
	touchPoint.x=touchPoint.x-mapX;
	touchPoint.y=touchPoint.y-mapY;
	
	CGPoint cpt=[self tileCoordinateFromPos:touchPoint];
	if (cpt.x!=-1) {
		CCTMXLayer *ly=[gameWorld layerNamed:@"tile"];
		unsigned tid;
		tid=[ly tileGIDAt:cpt];
		
		//获取瓦片地图的gid，事先地图上已设定好，用下一种瓦片效果代替
		//显示爆炸效果
		[self showExplodeAt:CGPointMake(touchPoint.x, touchPoint.y)];
		
		if (tid == 2)//砖墙
			[ly setTileGID:5 at:cpt];
		if (tid == 4)//草地
			[ly setTileGID:4 at:cpt];
		if (tid == 5)//爆炸过的砖墙
			[ly setTileGID:4 at:cpt];		
		if (tid == 6)//
			[ly setTileGID:1 at:cpt];	
	}else {
		NSLog(@"NO tile here");
	}

	
}
//触摸坐标转换成地图的瓦片坐标集
-(CGPoint)tileCoordinateFromPos:(CGPoint)pos{
	
	int cox,coy;
	
	CCTMXLayer *ly=[gameWorld layerNamed:@"tile"];
	if (ly==nil) {
		return ccp(-1,-1);
	}
	//地图包含的瓦片的格数
	CGSize szlayer=[ly layerSize];
	//单个瓦片地图的宽高
	CGSize sztile=[gameWorld tileSize];
	
	cox=pos.x/sztile.width;
	coy=szlayer.height-pos.y/sztile.height;
	
	if (cox>=0&&cox<szlayer.width&&coy>=0&&coy<szlayer.height) {
		return ccp(cox,coy);
	}else {
		return ccp(-1,-1);
	}
}
-(unsigned int)tileIDFromPosition:(CGPoint)pos{
	CGPoint cpt=[self tileCoordinateFromPos:pos];
	CCTMXLayer *ly=[gameWorld layerNamed:@"tile"];
	if (cpt.x<0||cpt.y<0||cpt.x>=ly.layerSize.width||cpt.y>=ly.layerSize.height) {
		return -1;
	}
	return [ly tileGIDAt:cpt];
}

-(void)dealloc{
	[super dealloc];
}
@end
