//
//  main.m
//  tankMap
//
//  Created by mirror on 10-5-22.
//  Copyright zhong 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"tankMapAppDelegate");
	[pool release];
	return retVal;
}
