//
//  STTableViewController.h
//  SvpplyTable
//
//  Created by Anonymous on 13-8-13.
//  Copyright (c) 2013年 Minqian Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STCategory.h"

@interface STTableViewController : UITableViewController
<
  UITableViewDataSource,
  UITableViewDelegate
>

@end
