//
//  CustomSprite.h
//  sample
//
//  Created by i-CRG Labs Virupaksh on 8/3/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


#import <Foundation/Foundation.h>

#import "cocos2d.h"
@interface TGCustomSprite : CCSprite {
    
    BOOL IsshouldCreate;
}
@property(nonatomic,assign)BOOL IsshouldCreate;
@end
