//
//  TGCustomSprite.m
//  TruckModule2
//
//  Created by i-CRG Labs Virupaksh on 7/28/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "TGCustomSprite.h"


@implementation TGCustomSprite
@synthesize IsshouldCreate;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here
        self.IsshouldCreate = TRUE;
    }
    
    return self;
}

-(void)dealloc {
    
    [super dealloc];
}


@end
