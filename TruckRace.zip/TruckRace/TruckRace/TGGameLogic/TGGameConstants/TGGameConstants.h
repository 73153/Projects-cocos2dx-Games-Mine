//
//  TGGameConstants.h
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#define DataManager [TGDataManager sharedManager]

#define MainGameLayer self.gameLayer 

#define kTruckSpeed 3
#define PTM_RATIO 32.0f


#define kMineTag 111