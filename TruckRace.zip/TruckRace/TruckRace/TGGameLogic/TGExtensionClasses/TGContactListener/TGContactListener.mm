//
//  MyContactListener.m
//  Box2DPong
//
//  Created by Ray Wenderlich on 2/18/10.
//  Copyright 2010 Ray Wenderlich. All rights reserved.
//

#import "TGContactListener.h"
#import "Terrain.h"
#import "HelloWorldLayer.h"

TGContactListener::TGContactListener() : _contacts() {
}

TGContactListener::~TGContactListener() {
}

void TGContactListener::BeginContact(b2Contact* contact) {
    // We need to copy out the data because the b2Contact passed in
    // is reused.
    MyContact myContact = { contact->GetFixtureA(), contact->GetFixtureB() };
    _contacts.push_back(myContact);
    
    [TGDataManager sharedManager].isBodiesTouching = this->bodiesAreTouching([TGDataManager sharedManager].gameLayer._terrain->terrain, [TGDataManager sharedManager].gameLayer._truck->frontWheel);
    
    //    [TGDataManager sharedManager].gameLayer._truck->truckBody->SetFixedRotation(false);
//    else
//        [TGDataManager sharedManager].gameLayer._truck->truckBody->SetFixedRotation(false);
    
printf("touch is %d",[TGDataManager sharedManager].isBodiesTouching);
}

void TGContactListener::EndContact(b2Contact* contact) {
    MyContact myContact = { contact->GetFixtureA(), contact->GetFixtureB() };
    std::vector<MyContact>::iterator pos;
    pos = std::find(_contacts.begin(), _contacts.end(), myContact);
    if (pos != _contacts.end()) {
        _contacts.erase(pos);
        NSLog(@"end");
      //  [TGDataManager sharedManager].gameLayer._truck->truckBody->SetFixedRotation(true);
    }
    [TGDataManager sharedManager].isBodiesTouching = this->bodiesAreTouching([TGDataManager sharedManager].gameLayer._terrain->terrain, [TGDataManager sharedManager].gameLayer._truck->frontWheel);

        
//    else
//        [TGDataManager sharedManager].gameLayer._truck->truckBody->SetFixedRotation(false);
    printf("touch is %d",[TGDataManager sharedManager].isBodiesTouching);
    
}

void TGContactListener::PreSolve(b2Contact* contact, const b2Manifold* oldManifold) {
}

void TGContactListener::PostSolve(b2Contact* contact, const b2ContactImpulse* impulse) {
}

bool TGContactListener::bodiesAreTouching( b2Body* body1, b2Body* body2 )
{
	for (b2ContactEdge* edge = body1->GetContactList(); edge; edge = edge->next)
	{
		if ( !edge->contact->IsTouching() )
			continue;
		b2Body* bA = edge->contact->GetFixtureA()->GetBody();
		b2Body* bB = edge->contact->GetFixtureB()->GetBody();
		if ( ( bA == body1 && bB == body2 ) || ( bB == body1 && bA == body2 ) )
			return true;
	}
	return false;
}