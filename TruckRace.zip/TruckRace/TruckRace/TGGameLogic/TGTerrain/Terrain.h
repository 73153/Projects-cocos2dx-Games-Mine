#import "Box2D.h"
#import "cocos2d.h"
#import "TGGameConstants.h"
#import "TGUtility.h"
#import "PRFilledPolygon.h"
#import "GB2ShapeCache.h"
#import "TGDataManager.h"
#define kMaxHillKeyPoints 1000
#define kHillSegmentWidth 10
#define kMaxHillVertices 4000
#define kMaxBorderVertices 800 


@interface Terrain : CCNode 
{
@public
    b2World *_world;
    CGSize size;
    b2Body *ground;
    b2Body *terrain;
    b2Body *ter;
    b2Vec2 vertices[1000];
    b2Vec2 vertices1[30];
    PRFilledPolygon *filledPolygon;
    NSMutableArray *polygonPoints;
   
   //NSMutableArray *obstaclesArray;
    
     CGPoint _hillKeyPoints[100];
    
    CCSprite *_stripes;
    
    int _fromKeyPointI;
    int _toKeyPointI;
    
    int _nHillVertices;
    CGPoint _hillVertices[kMaxHillVertices];
    CGPoint _hillTexCoords[kMaxHillVertices];
    int _nBorderVertices;
    CGPoint _borderVertices[kMaxBorderVertices];

    
   
}
@property(nonatomic,retain) NSMutableArray *polygonPoints;
@property (retain) CCSprite * stripes;
//@property(nonatomic,retain)NSMutableArray *obstaclesArray;
- (void)createGroundWithWorld:(b2World*)world withSize:(CGSize)terrainSize;
- (void)generateTerrainWithStartPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint;

-(void)addObstaclesToTerrain:(int)positionVertex;
- (void)destroy;
-(void)removeSpriteFromWorld:(b2Body*)spriteBody;
-(void)resetHillVertices;

@end