#import "Terrain.h"

#import "TGDataManager.h"
#import "HelloWorldLayer.h"
//#define kHillSegmentWidth 10

#define kTagPoly 10

@implementation Terrain
@synthesize polygonPoints;//,obstaclesArray;
@synthesize stripes = _stripes;
-(id)init
{
    if(self==[super init])
    {
        NSMutableArray *tempArray=[[NSMutableArray alloc]init];
        self.polygonPoints=tempArray;
        [tempArray release];
        [self resetHillVertices];

    }
    return self;
}
- (void)createGroundWithWorld:(b2World*)world withSize:(CGSize)terrainSize
{
    _world = world;
    size = terrainSize;
    
    b2BodyDef bd;
    bd.position.Set(0.0, 0.0);
    
    // b2Body *ground
    ground = _world->CreateBody(&bd);
    b2PolygonShape shape;
    b2FixtureDef fd;
    fd.shape = &shape;
    fd.density = 0.0;
    fd.friction = 1;
    
    // bottom
    shape.SetAsEdge(b2Vec2(0.0, 0.0), b2Vec2(size.width/PTM_RATIO, 0.0));
    ground->CreateFixture(&fd);
    // left
    shape.SetAsEdge(b2Vec2(0.0, 0.0), b2Vec2(0.0, size.height/PTM_RATIO));
    ground->CreateFixture(&fd);
    // top
    shape.SetAsEdge(b2Vec2(0.0, size.height/PTM_RATIO), 
                    b2Vec2(size.width/PTM_RATIO, size.height/PTM_RATIO));
    ground->CreateFixture(&fd);
    //right
    shape.SetAsEdge(b2Vec2(size.width/PTM_RATIO, size.height/PTM_RATIO), 
                    b2Vec2(size.width/PTM_RATIO, 0.0));
    ground->CreateFixture(&fd);

    //polygonPoints = [[NSMutableArray alloc] init];
    
}

-(void)addObstaclesToTerrain
{
    for(int i=0;i<40;i++)
    {
        int randomVertex=[TGUtility getRandomFrom:5 ToNo:90];
        
        [self addObstaclesToTerrain:randomVertex];
    }
}

- (void)generateTerrainWithStartPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint
{
    //int vertCount = 1000;
    
    //float interval = fabs((endPoint.x - startPoint.x))/vertCount;
    
    b2BodyDef bd;
    
    bd.position.Set(0.0, 0.0);
    terrain = _world->CreateBody(&bd);
    b2PolygonShape shape;
    b2FixtureDef fd;
    fd.shape = &shape;
    fd.friction = 0.3;
    fd.density = 20;
       
    CGSize winSize = [CCDirector sharedDirector].winSize;
    
    float minDX = 150;
    float minDY = 5;
    int rangeDX = 120;
    int rangeDY = 40;
    
    float x = minDX;
    float y = 10;
    
    float dy, ny;
    float sign = -1; // +1 - going up, -1 - going  down
    float paddingTop = 40;
    float paddingBottom = 20;
    
   
    for (int i=0; i<100; i++) {
        
        _hillKeyPoints[i] = CGPointMake(x, y);
        
       
        
        if (i == 0) {
            x = 90;
            y =2;
            
            
        } else {
            //y = winSize.height/4;
            x += rand()%rangeDX+minDX;
            while(true) {
                dy = rand()%rangeDY+minDY;
                ny = y + dy*sign;
                if(ny < winSize.height-paddingTop && ny > paddingBottom) {
                    break;   
                }
            }
            y = ny;
            
            
        }
        sign *= -1;
    }
     
    
    for(int i = 1; i < 100; ++i) {    
        
                
        CGPoint p0 = _hillKeyPoints[i-1];
        CGPoint p1 = _hillKeyPoints[i];
        
        int hSegments = floorf((p1.x-p0.x)/kHillSegmentWidth);
        // NSLog(@"seg is %d",hSegments);
        
        float dx = (p1.x - p0.x) / hSegments;
        // NSLog(@"dx is %f",dx);
        
        float da = M_PI / hSegments;
        //  NSLog(@"da is %f",da);
        
        float ymid = (p0.y + p1.y) / 2;
        float ampl = (p0.y - p1.y) / 2;
        
        CGPoint pt0, pt1;
        pt0 = p0;
        [polygonPoints addObject:[NSValue valueWithCGPoint:ccp(pt0.x,pt0.y)]];
        for (int j = 0; j < hSegments+1; ++j) {
            
            
            pt1.x = p0.x + j*dx;
            pt1.y = ymid + ampl * cosf(da*j);
            
            [polygonPoints addObject:[NSValue valueWithCGPoint:ccp(pt0.x,pt0.y)]];
            
            shape.SetAsEdge(b2Vec2(pt0.x/PTM_RATIO,pt0.y/PTM_RATIO), b2Vec2(pt1.x/PTM_RATIO,pt1.y/PTM_RATIO));
            
            
            pt0 = pt1;
            terrain->CreateFixture(&fd);
            
        }
        
        
    }
    
    
    printf("count of array is %d \n",[polygonPoints count]);
    for(int i=1;i<[polygonPoints count];i++)
    {
        
       // NSLog(@"previous %@ current %@", NSStringFromCGPoint([[polygonPoints objectAtIndex:i - 1] CGPointValue]),NSStringFromCGPoint([[polygonPoints objectAtIndex:i] CGPointValue]));
    }
    
    
                   
    //adding obstacles
    [self addObstaclesToTerrain]; 
    
    //CCTexture2D *texture = [[CCTextureCache sharedTextureCache] addImage:@"newpattern5.png"];
    //filledPolygon = [[[PRFilledPolygon alloc] initWithPoints:polygonPoints andTexture:texture] autorelease];
   //[[TGDataManager sharedManager].gameLayer addChild:filledPolygon z:2 tag:kTagPoly];
    
    
        
}
-(void)addObstaclesToTerrain:(int)positionVertex
{
    int tagno;
    
    int randomObstacle=[TGUtility getRandomFrom:1 ToNo:5];
    int randomtype=[TGUtility getRandomFrom:1 ToNo:4];
    NSString *spriteName;
    NSString *name;
    if(randomObstacle==1)
    {
        spriteName=@"stone_3.png";
        name=@"stone_1";
        tagno=111;
    }
    else if(randomObstacle==2)
    {
        spriteName=@"stone_2.png";
        name=@"stone_2";
        tagno=222;
    }
    else
    {
         spriteName=@"stone_1.png";
        name=@"stone_3";
        tagno=333;
    }
        
    CCSprite *obstacleSprite=[CCSprite spriteWithFile:spriteName];
    obstacleSprite.tag=tagno;
    [DataManager.gameLayer addChild:obstacleSprite z:-10 tag:2];
    CGPoint point=ccp(_hillKeyPoints[positionVertex].x,_hillKeyPoints[positionVertex].y);
    if(tagno==222)
    {
    obstacleSprite.position=ccp(point.x-20,point.y-45);
    }
    else if(tagno==333)
    {
        obstacleSprite.position=ccp(point.x+30,point.y-5);
    }
    else 
    {
        obstacleSprite.position=ccp(point.x+30,point.y-10);
    }

    
    b2BodyDef obsatacleDef;
      
    obsatacleDef.position=b2Vec2(obstacleSprite.position.x/PTM_RATIO,obstacleSprite.position.y/PTM_RATIO);
    if(randomtype==2)
    {
        obsatacleDef.type=b2_staticBody;
         //obstacleSprite.position=ccp(point.x-20,point.y-10);
    }
    else
    {
    obsatacleDef.type=b2_staticBody;
    }
    obsatacleDef.userData=obstacleSprite;
    b2Body *obstacleBody=_world->CreateBody(&obsatacleDef);
    [[GB2ShapeCache sharedShapeCache] addShapesWithFile:@"stoneObstacles.plist"];
    [[GB2ShapeCache sharedShapeCache] addFixturesToBody:obstacleBody forShapeName:name];
    [obstacleSprite setAnchorPoint:[[GB2ShapeCache sharedShapeCache] anchorPointForShape:name]];
        
}

- (void)resetHillVertices {
    
    CGSize winSize = [CCDirector sharedDirector].winSize;
    
    static int prevFromKeyPointI = -1;
    static int prevToKeyPointI = -1;
    
    
    //if (prevFromKeyPointI != _fromKeyPointI || prevToKeyPointI != _toKeyPointI) {
    
    // vertices for visible area
    _nHillVertices = 0;
    _nBorderVertices = 0;
    CGPoint p0, p1, pt0, pt1;
    p0 = _hillKeyPoints[0];
    for (int i=1; i<100; i++) {
        p1 = _hillKeyPoints[i];
        
        // triangle strip between p0 and p1
        int hSegments = floorf((p1.x-p0.x)/kHillSegmentWidth);
        float dx = (p1.x - p0.x) / hSegments;
        float da = M_PI / hSegments;
        float ymid = (p0.y + p1.y) / 2;
        float ampl = (p0.y - p1.y) / 2;
        pt0 = p0;
        _borderVertices[_nBorderVertices++] = pt0;
        for (int j=1; j<hSegments+1; j++) {
            pt1.x = p0.x + j*dx;
            pt1.y = ymid + ampl * cosf(da*j);
            _borderVertices[_nBorderVertices++] = pt1;
            
            _hillVertices[_nHillVertices] = CGPointMake(pt0.x, 0);
            _hillTexCoords[_nHillVertices++] = CGPointMake(pt0.x/512, 1.0f);
            _hillVertices[_nHillVertices] = CGPointMake(pt1.x, 0);
            _hillTexCoords[_nHillVertices++] = CGPointMake(pt1.x/512, 1.0f);
            
            _hillVertices[_nHillVertices] = CGPointMake(pt0.x, pt0.y);
            _hillTexCoords[_nHillVertices++] = CGPointMake(pt0.x/512, 0);
            _hillVertices[_nHillVertices] = CGPointMake(pt1.x, pt1.y);
            _hillTexCoords[_nHillVertices++] = CGPointMake(pt1.x/512, 0);
            
            pt0 = pt1;
        }
        
        p0 = p1;
    }
    
    //prevFromKeyPointI = _fromKeyPointI;
    //prevToKeyPointI = _toKeyPointI;        
    //}
    
}
- (void) draw {
    
    glBindTexture(GL_TEXTURE_2D, _stripes.texture.name);
    glDisableClientState(GL_COLOR_ARRAY);
    
    glColor4f(1, 1, 1, 1);
    glVertexPointer(2, GL_FLOAT, 0, _hillVertices);
    glTexCoordPointer(2, GL_FLOAT, 0, _hillTexCoords);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, (GLsizei)_nHillVertices);
    
}
-(void)removeSpriteFromWorld:(b2Body*)spriteBody
{
    if (spriteBody->GetUserData() != NULL) {
        CCSprite *sprite = (CCSprite *) spriteBody->GetUserData();
        [sprite removeFromParentAndCleanup:YES];
        
    }
    _world->DestroyBody(spriteBody);
}

- (void)destroy
{
    _world->DestroyBody(terrain);
    _world->DestroyBody(ground);
}

- (void)dealloc
{
    [_stripes release];
    _stripes = NULL;

    [polygonPoints release];
    filledPolygon=nil;
    [super dealloc];
}

@end