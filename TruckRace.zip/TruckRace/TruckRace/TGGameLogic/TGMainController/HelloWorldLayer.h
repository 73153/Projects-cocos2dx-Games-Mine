#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"

#import "MonsterTruck.h"
#import "Terrain.h"
#import "TGCustomSprite.h"
#import "TGDataManager.h"
#import "TGContactListener.h"
#import "TGGameConstants.h"
#import "TGUtility.h"
#import "optionsScene.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
    b2World *_world;
    GLESDebugDraw *_debugDraw;
    
    TGContactListener *_contactListener;
    MonsterTruck *_truck;
    Terrain *_terrain;

    CGPoint startPoint, endPoint;
    CGPoint middleLayerParallaxRatio;
    CGPoint frontLayerParallaxRatio;

    CGSize terrainSize;
    CGSize screenSize;
    CCParallaxNode *backGroundNode;
    
    CCLayer *middleLayer;
    CCLayer *farLayer;
    CCLayer *frontLayer;
    
    NSMutableArray *backGroundArray;
    NSMutableArray *toDeleteArray;
    NSMutableArray *touchArray;
    NSMutableArray *truckArray;
    NSMutableArray *tyreArray1;
       
    
    int counter;
    float timeCounter;
    float middleLayerLength;
    float frontLayerlength;
       
    BOOL isTouched;
    
    
    BOOL isTruckparticleShouldAdd;
    BOOL isObstacleParticleShouldAdd;
    
    CCParticleSystem* truckWheelparticle;
    CCParticleSystem* obstacleParticle;
    CGPoint obstaclePosition;
          
}
@property(nonatomic,assign)CGSize screenSize;
@property(nonatomic,assign)CCParallaxNode *backGroundNode;

@property(nonatomic,assign)CCLayer *middleLayer;
@property(nonatomic,assign)CCLayer *farLayer;
@property(nonatomic,assign)CCLayer *frontLayer;

@property(nonatomic,retain)NSMutableArray *backGroundArray;
@property(nonatomic,retain)NSMutableArray *toDeleteArray;
@property(nonatomic,retain)NSMutableArray *touchArray;
@property(nonatomic,retain)NSMutableArray *truckArray;
@property(nonatomic,retain)NSMutableArray *tyreArray1;

@property(nonatomic,assign)CGPoint middleLayerParallaxRatio;
@property(nonatomic,assign)CGPoint frontLayerParallaxRatio;
@property(nonatomic,assign)CGPoint obstaclePosition;

@property(nonatomic,assign)int counter;
@property(nonatomic,assign) float timeCounter;
@property(nonatomic,assign)float middleLayerLength;
@property(nonatomic,assign)float frontLayerlength;

@property(nonatomic,assign)BOOL isTouched;

@property(nonatomic,assign)BOOL isTruckparticleShouldAdd;
@property(nonatomic,assign)BOOL isObstacleParticleShouldAdd;
@property(nonatomic,assign)CCParticleSystem* truckWheelparticle;
@property(nonatomic,assign)CCParticleSystem* obstacleParticle;

@property(nonatomic,retain)MonsterTruck *_truck;
@property(nonatomic,retain)Terrain *_terrain;

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;
-(void)addNewSprite:(CGPoint)position1;
-(void)deleteBackGround;
-(void)rotateWheels; 
-(void)updateMiddleLayer;
-(void)addtrucksToMiddleLayer:(int)NoOfTrucks;
-(void)updateTruckSpeed;
-(void)updateMainTruckSpeed;

-(void)removeBox2dBody:(CCSprite*)sprite;
-(void)runBirdAnimation;
@end