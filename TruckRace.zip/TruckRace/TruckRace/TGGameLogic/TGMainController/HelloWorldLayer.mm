//
//  HelloWorldLayer.mm
//  sample
//
//  Created by i-CRG Labs Virupaksh on 8/1/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"


//Pixel to metres ratio. Box2D uses metres as the unit for measurement.
//This ratio defines how many pixels correspond to 1 Box2D "metre"
//Box2D is optimized for objects of 1x1 metre therefore it makes sense
//to define the ratio so that your most common object type is 1x1 metre.

// enums that will be used as tags
enum {
	kTagTileMap = 1,
	kTagBatchNode = 1,
	kTagAnimation1 = 1,
};


// HelloWorldLayer implementation
@implementation HelloWorldLayer
@synthesize backGroundArray,toDeleteArray,touchArray,tyreArray1, truckArray,screenSize,counter,backGroundNode;
@synthesize middleLayer,farLayer,frontLayer;
@synthesize isTouched,isTruckparticleShouldAdd,isObstacleParticleShouldAdd;
@synthesize middleLayerParallaxRatio,frontLayerParallaxRatio,middleLayerLength,frontLayerlength,obstaclePosition;
@synthesize timeCounter;
@synthesize truckWheelparticle,obstacleParticle;
@synthesize _truck,_terrain;

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
    CCLayer *staticLayer = [CCLayer node];
    
    [scene addChild:staticLayer z:10];
    
	[TGDataManager sharedManager].staticLayer=staticLayer;
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}
- (void)createWorld
{
    b2Vec2 gravity = b2Vec2(0.0, -20.0);
    bool doSleep = true;
    _world = new b2World(gravity, doSleep);
    _world->SetContinuousPhysics(true);
    DataManager.gameWorld=_world;
}

- (void)setDebugDraw
{
    
    _debugDraw = new GLESDebugDraw(PTM_RATIO);
    uint32 flags = 0;
    flags += 1 * b2DebugDraw::e_shapeBit;
    flags += 1 * b2DebugDraw::e_jointBit;
    // flags += 1 * b2DebugDraw::e_aabbBit;
    // flags += 1 * b2DebugDraw::e_pairBit;
    // flags += 1 * b2DebugDraw::e_centerOfMassBit;
    _debugDraw->SetFlags(flags);
    _world->SetDebugDraw(_debugDraw);
     
}

// on "init" you need to initialize your instance
-(id) init
{
    if( (self=[super init])) 
    {
        
        [TGDataManager sharedManager].gameLayer=self;
        
        self.isTouchEnabled=YES;
        // Craete a new world
        [self createWorld];
        
        
        // set debug draw
        [self setDebugDraw];
        
        self.middleLayerParallaxRatio=ccp(0.3,0);
        self.frontLayerParallaxRatio=ccp(1,0);
        
        //Array Initialization
        NSMutableArray *tempArray=[[NSMutableArray alloc]init];
        self.backGroundArray=tempArray;
        [tempArray release];
        
        NSMutableArray *tempArray1=[[NSMutableArray alloc]init];
        self.toDeleteArray=tempArray1;
        [tempArray1 release];
        
        tempArray1=[[NSMutableArray alloc]init];
        self.touchArray=tempArray1;
        [tempArray1 release];
        
        
        tempArray1=[[NSMutableArray alloc]init];
        self.truckArray=tempArray1;
        [tempArray1 release];
        
        tempArray1=[[NSMutableArray alloc]init];
        self.tyreArray1=tempArray1;
        [tempArray1 release];
        
        //Collision
//        _contactListener = new TGContactListener();
//        _world->SetContactListener(_contactListener);
        
        
        
        CGSize winSize = [CCDirector sharedDirector].winSize;
        screenSize=winSize;
        
        terrainSize = CGSizeMake(winSize.width * 40, winSize.height * 10);
        self.frontLayerlength=terrainSize.width;
        self.middleLayerLength=self.frontLayerlength*middleLayerParallaxRatio.x;
        
        // NSLog(@"frontLayerlength is %f",self.frontLayerlength);
        //NSLog(@"middleLayerLength is %f",self.middleLayerLength);
        
        
        
        startPoint = ccp(100, 15);
        endPoint = ccp(terrainSize.width-150, 150);
        
        //Front Layer
        self.frontLayer=[CCLayer node];
        self.frontLayer.position=ccp(0,0);
        // create terrain
        _terrain = [[Terrain alloc]init];
        [self.frontLayer addChild:_terrain z:10];
        
        [_terrain createGroundWithWorld:_world withSize:terrainSize];
        [_terrain generateTerrainWithStartPoint:ccp(150, -20) endPoint:ccp(terrainSize.width-300, -20)];
       
               
        
        
        //create Truck
        _truck = [[MonsterTruck alloc]init];
        [self addChild:_truck z:10];
        [_truck createTruckWithWorld:_world withPosition:ccp(110,40)];
        
        
        
        //parallax
        backGroundNode=[CCParallaxNode node];
        
        self.middleLayer=[CCLayer node];
        self.middleLayer.position=ccp(0,0);
        
        self.farLayer=[CCLayer node];
        self.farLayer.position=ccp(0,0);
        
        [self.backGroundNode addChild:middleLayer z:1 parallaxRatio:self.middleLayerParallaxRatio positionOffset:ccp(0,0)];
        [self.backGroundNode addChild:farLayer z:-5 parallaxRatio:ccp(0,0) positionOffset:ccp(0,0)];
        [self.backGroundNode addChild:frontLayer z:2 parallaxRatio:self.frontLayerParallaxRatio positionOffset:ccp(0,0)];
        
        
        //Adding Background Sprites
        TGCustomSprite *background=[TGCustomSprite spriteWithFile:@"farLayerSky.png"];
        //[self.farLayer addChild:background z:-2];
        background.position=ccp(240,220);
        
        TGCustomSprite *background1=[TGCustomSprite spriteWithFile:@"farLayerMountain.png"];
       // [self.farLayer addChild:background1];
        background1.position=ccp(240,140);
        
        TGCustomSprite *middleBackground=[TGCustomSprite spriteWithFile:@"middleLayerBackGround.png"];
        //[self.middleLayer addChild:middleBackground];
        middleBackground.position=ccp(240,60);
        [backGroundArray addObject:middleBackground];
        
        
        //adding additional trucks
       // [self addtrucksToMiddleLayer:5];
        
        //Adding Restart Button
        CCMenuItemImage *menuitem1=[CCMenuItemImage itemFromNormalImage:@"Restart_but.png" selectedImage:@"Restart_but.png" target:self selector:@selector(restartGame)];
        CCMenu *menu1=[CCMenu menuWithItems:menuitem1, nil];
        [DataManager.staticLayer addChild:menu1];
        menu1.position=ccp(60, 270);
        
        //Adding Options Button
        CCMenuItemImage *menuitem2=[CCMenuItemImage itemFromNormalImage:@"option_Button_01.png" selectedImage:@"option_Button_01.png" target:self selector:@selector(gotoOptionMenu)];
        CCMenu *menu2=[CCMenu menuWithItems:menuitem2, nil];
        [DataManager.staticLayer addChild:menu2];
        menu2.position=ccp(460, 270);
        
        
        //Environment effect
       // CCParticleSystem* environmentParicle=[CCParticleSystemQuad particleWithFile:@"smoke3.plist"];
        //[self addChild:environmentParicle z:0];
        //environmentParicle.position=ccp(300,120);
        
        //CCParticleSystem* environmentParicle2=[CCParticleSystemQuad particleWithFile:@"smoke5.plist"];
        //[self addChild:environmentParicle2 z:0];
        //environmentParicle2.position=ccp(100,110);
        
        
       self.truckWheelparticle=[CCParticleSystemQuad particleWithFile:@"BackWheel.plist"];
        [self addChild:self.truckWheelparticle z:10];
        self.truckWheelparticle.position=ccp(1000,1000);
        
        
        self.obstacleParticle=[CCParticleSystemQuad particleWithFile:@"Dust1-Particles.plist"];
        [self.farLayer addChild:self.obstacleParticle  z:10];
        self.obstacleParticle.position=ccp(100,280);
        
        
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"BirdAnimation.plist"];
        
        //[self runBirdAnimation];

        
        //camera Movement
        [self runAction:[CCFollow 
                         actionWithTarget:_truck 
                         worldBoundary:CGRectMake(0, 0, terrainSize.width, terrainSize.height)]];
        
        [self addChild:self.backGroundNode];
        self.counter=middleBackground.contentSize.width/2;
        self.isTouched=FALSE;
        //self.isTruckInAir=false;
        self.isTruckparticleShouldAdd=false;
        self.isObstacleParticleShouldAdd=false;
       
       
        
        CCSprite *stripes = [TGCustomSprite spriteWithFile:@"newpattern5.png"];;
        ccTexParams tp2 = {GL_LINEAR, GL_LINEAR, GL_REPEAT, GL_CLAMP_TO_EDGE};
        [stripes.texture setTexParameters:&tp2];
        _terrain.stripes = stripes;

        [self schedule:@selector(tick:)];
        
    }
    return self;
}

-(void)addParticleEffect
{
    CCParticleSystem* environmentParicle=[CCParticleSystemQuad particleWithFile:@"smoke3.plist"];
    //[self addChild:environmentParicle z:0];
    environmentParicle.position=ccp(300,120);

}
-(void)runBirdAnimation
{
    NSMutableArray *framesArray=[[NSMutableArray alloc]init];
    CCSprite *bird = [CCSprite spriteWithSpriteFrameName:@"hind_bird1.png"];
    bird.position=ccp(50,50);
    bird.scale=0.4;
    [self.farLayer addChild:bird];
    
    for(int i=1;i<=7;i++)
    {
        CCSpriteFrame *frame=[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"hind_bird%d.png",i]];
        [framesArray addObject:frame];
    }
    CCAnimation *characterAnimation=[CCAnimation animationWithFrames:framesArray delay:0.1f];
    CCAnimate *characterAnimate=[CCAnimate actionWithAnimation:characterAnimation];
    id animationSequence = [CCRepeatForever actionWithAction:characterAnimate];
    id seq=[CCSequence actions:characterAnimate,animationSequence,nil];
    [bird runAction:seq];
    id moveAction = [CCMoveTo actionWithDuration:12 position:ccp(bird.position.x + 480, bird.position.y + 300)];
    id actionCallBack = [CCCallFuncN actionWithTarget:self selector:@selector(removeSprite:)];
    id sequence = [CCSequence actions:moveAction,actionCallBack, nil];
    [bird runAction:sequence];

       
    
}
-(void)removeSprite:(id)sender {
    
    CCSprite *tempSprite = (CCSprite *)sender;
    [tempSprite removeFromParentAndCleanup:YES];
}



-(void)restartGame
{
    
   [[CCDirector sharedDirector]replaceScene:[HelloWorldLayer scene]];
}
-(void)gotoOptionMenu
{
   [[CCDirector sharedDirector] pushScene: [CCTransitionSlideInL transitionWithDuration:0.1 scene:[optionsScene scene]]];
}
-(void)addNewSprite:(CGPoint)position1
{
    self.counter=self.counter+480;
    TGCustomSprite *background=[TGCustomSprite spriteWithFile:@"middleLayerBackGround.png"];
    self.counter=self.counter+background.contentSize.width;
    [ self.middleLayer addChild:background];
    background.position=position1;
    [backGroundArray addObject:background];
    
}

-(void)addtrucksToMiddleLayer:(int)NoOfTrucks
{
    
    float x=150,y=40;
    int k=1;
    int order=NoOfTrucks*4;
    
    for(int i=0;i<NoOfTrucks;i++)
    {
        
        TGCustomSprite *racingTruck1=[TGCustomSprite spriteWithFile:@"smalltruck.png"];
        TGCustomSprite *racingTrucktyre1=[TGCustomSprite spriteWithFile:@"smalltyre.png"];
        TGCustomSprite *racingTrucktyre2=[TGCustomSprite spriteWithFile:@"smalltyre.png"];
        TGCustomSprite *truckLoad=[TGCustomSprite spriteWithFile:@"truck_lode.png"];
        
        if(i==0)
        {
            racingTruck1.scale=0.8;
            racingTrucktyre1.scale=0.9;
            racingTrucktyre2.scale=0.9;
        }
        else if(i==1)
        {
            racingTruck1.scale=0.75;
            racingTrucktyre1.scale=0.85;
            racingTrucktyre2.scale=0.85;
            
        }
        else if(i==2)
        {
            racingTruck1.scale=0.70;
            racingTrucktyre1.scale=0.80;
            racingTrucktyre2.scale=0.80;
        }
        else if(i==3)
        {
            racingTruck1.scale=0.65;
            racingTrucktyre1.scale=0.75;
            racingTrucktyre2.scale=0.75;
        }
        else if(i==4)
        {
            racingTruck1.scale=0.65;
            racingTrucktyre1.scale=0.75;
            racingTrucktyre2.scale=0.75;
        }
        
        
        
        [self.middleLayer addChild:racingTruck1 z:order];
        racingTruck1.position=ccp(x,y);
        racingTruck1.tag=k;
        
        
        racingTrucktyre1.tag=k;
        [racingTruck1 addChild:racingTrucktyre1];
        racingTrucktyre1.position=ccp(25,8);
        [self.tyreArray1 addObject:racingTrucktyre1];
        
        
        racingTrucktyre2.tag=k;
        [racingTruck1 addChild:racingTrucktyre2];
        [self.tyreArray1 addObject:racingTrucktyre2];
        racingTrucktyre2.position=ccp(75,8);
        
        
        [racingTruck1 addChild:truckLoad];
        truckLoad.position=ccp(30,52);
        truckLoad.scale=0.8;
        
        [truckArray addObject:racingTruck1];
        [self rotateWheels];
        
        y=y+10;
        k++;
        order=order-2;
        
    }
}
-(void)rotateWheels {
    for(TGCustomSprite *tyre in self.tyreArray1)
    {
        id actionRotate1 = [CCRotateTo actionWithDuration:0.18 angle: tyre.rotation + 180];
        id actionRotate2 = [CCRotateTo actionWithDuration:0.18 angle:tyre.rotation + 360];
        id actionSequence2 = [CCSequence actions:actionRotate1,actionRotate2, nil];
        CCAction *actionRepeat2 = [CCRepeatForever actionWithAction:actionSequence2];
        actionRepeat2.tag=222;
        [tyre runAction:actionRepeat2];
        
    }
}

-(void)deleteBackGround
{
    for(TGCustomSprite *sp in toDeleteArray)
    {
        [backGroundArray removeObject:sp];
        [sp removeFromParentAndCleanup:YES];
    }
    [toDeleteArray removeAllObjects];
}

-(void)updateMiddleLayer
{
    for(TGCustomSprite *sprite in backGroundArray)
    {
        for(TGCustomSprite *racingTruck in truckArray)
        {
            
            //NSLog(@"_truck.position.x*self.middleLayerParallaxRatio.x(self.middleLayerParallaxRatio.x*1000) is %f",_truck.position.x*self.middleLayerParallaxRatio.x);
            
            if(_truck.position.x>=self.counter && sprite.IsshouldCreate)
            {
                
                [self addNewSprite:ccp(sprite.position.x+sprite.contentSize.width-0.8,sprite.position.y)];
                sprite.IsshouldCreate=FALSE;
                
                
            }
            if(sprite.position.x+sprite.contentSize.width/2<=racingTruck.position.x-240 && sprite.position.x+sprite.contentSize.width/2<=_truck.position.x*self.middleLayerParallaxRatio.x-240)
            {
                [toDeleteArray addObject:sprite];
                
            }
        }
        
    }
    [self deleteBackGround]; 
    
}
 

-(void)updateMainTruckSpeed
{
    float torque;
    if(self.isTouched)
    {
        
        if(DataManager.userTruckSpeedValue>=8 && DataManager.userTruckSpeedValue<=10)
        {
            torque=5;
        }
        else if(DataManager.userTruckSpeedValue>=10 && DataManager.userTruckSpeedValue<=13)
        {
            torque=4;
        }
        else if(DataManager.userTruckSpeedValue>=13 && DataManager.userTruckSpeedValue<=16)
        {
            torque=6;
        }
        else
        {
            torque=10;
        }
         
        //torque=DataManager.userTruckSpeedValue/2;
        //NSLog(@" speed value is %f and torque value is %f",DataManager.userTruckSpeedValue,torque);
    [_truck upArrowPressed:DataManager.userTruckSpeedValue withTorque:torque];
        
    }
}
-(void)updateTruckSpeed
{
    for(TGCustomSprite *truck in self.truckArray)
    {
              
        if(truck.position.x<=self.middleLayerLength)
        {
            if(truck.tag==1)
            {
                
                truck.position=ccp(truck.position.x+DataManager.truck1SpeedValue,truck.position.y);
            }
            else if(truck.tag==2)
            {
               
                truck.position=ccp(truck.position.x+DataManager.truck2SpeedValue,truck.position.y);
            }
             else if(truck.tag==3)
            {
               
                truck.position=ccp(truck.position.x+DataManager.truck3SpeedValue,truck.position.y);
                
            }
            else if(truck.tag==4)
            {
               
                truck.position=ccp(truck.position.x+DataManager.truck4SpeedValue,truck.position.y);
                

            }
            else
            {
                
                truck.position=ccp(truck.position.x+DataManager.truck5SpeedValue,truck.position.y);
                

            }
        }
        else
        {
            for(TGCustomSprite *tyre1 in self.tyreArray1)
            {
                
                if(truck.position.x>=self.middleLayerLength)
                {
                    if(tyre1.tag==truck.tag)
                    {
                        [tyre1 stopAllActions];
                    }
                }
                
                
            }
            
            
        }
    }
    
}
- (void)tick:(ccTime)dt
{  
    //[self updateMiddleLayer];
    //[self updateTruckSpeed];
    [self updateMainTruckSpeed];
    [_truck updateSprings];
    
    if(self.isTruckparticleShouldAdd)
    {
        //self.truckWheelparticle.position=ccp(_truck.position.x-13,_truck.position.y-20);
    }
    if(self.isObstacleParticleShouldAdd)
    {
        //self.obstacleParticle.position=ccp(self.obstaclePosition.x,self.obstaclePosition.y+20);
    }
        

    
    //It is recommended that a fixed time step is used with Box2D for stability
    //of the simulation, however, we are using a variable time step here.
    //You need to make an informed choice, the following URL is useful
    //http://gafferongames.com/game-physics/fix-your-timestep/
    
    // Instruct the world to perform a single step of simulation. It is
    // generally best to keep the time step and iterations fixed.
    
    _world->Step(1.0/60, 15, 15);
    
    //int32 velocityIterations = 8;
	//int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	//_world->Step(dt, velocityIterations, positionIterations);
    
	
	//Iterate over the bodies in the physics world
	for (b2Body* b = _world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) {
			//Synchronize the AtlasSprites position and rotation with the corresponding body
			CCSprite *myActor = (CCSprite*)b->GetUserData();
			myActor.position = CGPointMake( b->GetPosition().x * PTM_RATIO, b->GetPosition().y * PTM_RATIO);
			myActor.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle());
		}	
	}
    
    
    
    /*
    //contact Listner
    std::vector<b2Body *>toDestroy; 
    std::vector<MyContact>::iterator pos;
    for(pos = _contactListener->_contacts.begin(); 
        pos != _contactListener->_contacts.end(); ++pos)
    {
        MyContact contact = *pos;
        
        b2Body *bodyA = contact.fixtureA->GetBody();
        b2Body *bodyB = contact.fixtureB->GetBody();
        
        if (bodyA->GetUserData() != NULL && bodyB->GetUserData() != NULL)
        {
            CCSprite *spriteA = (CCSprite *) bodyA->GetUserData();
            CCSprite *spriteB = (CCSprite *) bodyB->GetUserData();
            
            
            
            if (spriteA.tag == 1 && spriteB.tag == 2) 
            {
               // self.isObstacleParticleShouldAdd=TRUE;
                //self.obstaclePosition=spriteB.position;
                //[self removeBox2dBody:spriteB];
                break;
                
            }
            else if (spriteA.tag == 2 && spriteB.tag == 1) 
            {
               // self.isObstacleParticleShouldAdd=TRUE;
                //self.obstaclePosition=spriteA.position;
                //[self removeBox2dBody:spriteA];
                break;
                
            } 
            
                   
        }  
        
               
        
    }
    */
    
}

//Remove Box2d Body
-(void)removeBox2dBody:(CCSprite*)sprite
{
    // Loop through all of the Box2D bodies in our Box2D world...
    // We're looking for the Box2D body corresponding to the sprite.
    b2Body *spriteBody = NULL;
    for (b2Body* b = _world->GetBodyList(); b; b = b->GetNext()) {
        
        // See if there's any user data attached to the Box2D body
        // There should be, since we set it in addBoxBodyForSprite
        if (b->GetUserData() != NULL) {
            
            // We know that the user data is a sprite since we set
            // it that way, so cast it...
            CCSprite *curSprite = (CCSprite *)b->GetUserData();
                      // If the sprite for this body is the same as our current
            // sprite, we've found the Box2D body we're looking for!
            if (curSprite == sprite) {
                spriteBody = b;
                break;
            }
        }
    }
    
    // If we found the body, we want to destroy it since the cat is offscreen now.
    if (spriteBody != NULL) {
       _world->DestroyBody(spriteBody);
        [sprite removeFromParentAndCleanup:YES];
    }
}

- (void)draw
{
    // Defaut GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
    // Needed states: GL_VERTEX_ARRAY,
    // Unneeded states: GL_TEXTURE_2D, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
    glDisable(GL_TEXTURE_2D);
    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    
    _world->DrawDebugData();
    
    glEnable(GL_TEXTURE_2D);
    glEnableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    self.timeCounter=0;
   
    
    //Add a new body/atlas sprite at the touched location
	for( UITouch *touch in touches ) {
		CGPoint location = [touch locationInView: [touch view]];
		
		location = [[CCDirector sharedDirector] convertToGL: location];
        //[self.toDeleteArray addObject:touches];
        [self.touchArray removeObject:touches];
        if([self.touchArray count]<1)
        {
            self.isTouched=FALSE;
        }
	}
    
    [_truck downArrowPressed];
    [_truck upDownArrowReleased];
}

-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    self.isTouched=TRUE;
    
    self.isTruckparticleShouldAdd=TRUE;
    
    for( UITouch *touch in touches ) {
        self.isTruckparticleShouldAdd=TRUE;
        CGPoint location=[touch locationInView:[touch view]];
        location=[[CCDirector sharedDirector] convertToGL:location];
        
        [self.touchArray addObject:touches];
        
        if(touch.tapCount==2)
        {
            [_truck applyImpulseForJump];
        }
        
    }
    if([touchArray count]>1)
    {
        if(DataManager.isBodiesTouching)
        {
            //[_truck applyImpulseForJump];
           
        }
        
        
    }
    
    
 
}

-(void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    // NSLog(@"time value is %d",self.timeCounter);
    for(UITouch *touch in touches)
    {
        CGPoint location=[touch locationInView:[touch view]];
        location=[[CCDirector sharedDirector] convertToGL:location];
                
    }
    
}  

-(void)dealloc
{
    [_truck release];
    [_terrain release];
    
    self.backGroundArray=nil;
    self.toDeleteArray=nil;
    self.touchArray=nil;
    self.truckArray=nil;
    self.tyreArray1=nil;
    delete _contactListener;
    [super dealloc];
}
@end
