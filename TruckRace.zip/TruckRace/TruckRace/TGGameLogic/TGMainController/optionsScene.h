//
//  optionsScene.h
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCControlSlider.h"

@interface optionsScene:CCLayer {
    
    CCControlSlider* truckSpeedSlider1;
    CCControlSlider* truckSpeedSlider2;
    CCControlSlider* truckSpeedSlider3;
    CCControlSlider* truckSpeedSlider4;
    CCControlSlider* truckSpeedSlider5;
    CCControlSlider* userTruckSpeedSlider;
}
+(CCScene *) scene;

@end
