//
//  optionsScene.m
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "optionsScene.h"
#import "TGDataManager.h"
#import "TGGameConstants.h"

@implementation optionsScene
+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
    
	optionsScene *layer = [optionsScene node];
	
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
        
        CCLabelTTF *label1=[CCLabelTTF labelWithString:@"Change truck1 speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label1];
        label1.position=ccp(140,260);
        truckSpeedSlider1 = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];
        truckSpeedSlider1.position = ccp(350,260);
        truckSpeedSlider1.rotation = 0;
        truckSpeedSlider1.value = 1;
        truckSpeedSlider1.minimumValue = 0.5;
        truckSpeedSlider1.maximumValue = 4;
		truckSpeedSlider1.value = [TGDataManager sharedManager].truck1SpeedValue ;
       [self addChild:truckSpeedSlider1];
        
        CCLabelTTF *label2=[CCLabelTTF labelWithString:@"Change truck2 speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label2];
        label2.position=ccp(140,220);

        truckSpeedSlider2 = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];
        
        truckSpeedSlider2.position = ccp(350,220);
        truckSpeedSlider2.rotation = 0;
        truckSpeedSlider2.value = 1;
        truckSpeedSlider2.minimumValue = 0.5;
        truckSpeedSlider2.maximumValue = 4;
		truckSpeedSlider2.value = [TGDataManager sharedManager].truck2SpeedValue ;
        [self addChild:truckSpeedSlider2];
        
        CCLabelTTF *label3=[CCLabelTTF labelWithString:@"Change truck3 speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label3];
        label3.position=ccp(140,180);

        truckSpeedSlider3 = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];
        
        truckSpeedSlider3.position = ccp(350,180);
        truckSpeedSlider3.rotation = 0;
        truckSpeedSlider3.value = 1;
        truckSpeedSlider3.minimumValue = 0.5;
        truckSpeedSlider3.maximumValue = 4;
		truckSpeedSlider3.value = [TGDataManager sharedManager].truck1SpeedValue ;
        [self addChild:truckSpeedSlider3];
        
        CCLabelTTF *label4=[CCLabelTTF labelWithString:@"Change truck4 speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label4];
        label4.position=ccp(140,140);

         truckSpeedSlider4 = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];
        truckSpeedSlider4.position = ccp(350,140);
        truckSpeedSlider4.rotation = 0;
        truckSpeedSlider4.value = 1;
        truckSpeedSlider4.minimumValue = 0.5;
        truckSpeedSlider4.maximumValue = 4;
		truckSpeedSlider4.value = [TGDataManager sharedManager].truck1SpeedValue ;
        [self addChild:truckSpeedSlider4];
        
        CCLabelTTF *label5=[CCLabelTTF labelWithString:@"Change truck5 speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label5];
        label5.position=ccp(140,100);

         truckSpeedSlider5 = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];        
        truckSpeedSlider5.position = ccp(350,100);
        truckSpeedSlider5.rotation = 0;
        truckSpeedSlider5.value = 1;
        truckSpeedSlider5.minimumValue = 0.5;
        truckSpeedSlider5.maximumValue = 4;
		truckSpeedSlider5.value = [TGDataManager sharedManager].truck1SpeedValue ;
        [self addChild:truckSpeedSlider5];
        
        
        CCLabelTTF *label6=[CCLabelTTF labelWithString:@"Change userTruck speed here..." fontName:@"arial" fontSize:15];
        [self addChild:label6];
        label6.position=ccp(140,60);

        userTruckSpeedSlider = [CCControlSlider  sliderWithBackgroundSprite:[CCSprite spriteWithFile:@"option_bar_bg.png"] progressSprite:[CCSprite spriteWithFile:@"option_bg_enable.png"] thumbSprite:[CCSprite spriteWithFile:@"slider_knob.png"]];        
        userTruckSpeedSlider.position = ccp(350,60);
        userTruckSpeedSlider.rotation = 0;
        userTruckSpeedSlider.value = 1;
        userTruckSpeedSlider.minimumValue = 9;
        userTruckSpeedSlider.maximumValue = 20;
		userTruckSpeedSlider.value = [TGDataManager sharedManager].userTruckSpeedValue ;
        [self addChild:userTruckSpeedSlider];
        
        

        
        CCMenuItemImage *menuitem=[CCMenuItemImage itemFromNormalImage:@"option_Button_01.png" selectedImage:@"option_Button_01.png" target:self selector:@selector(gotoOptionMenu)];
        menuitem.scaleX=.9;
        
        CCMenu *menu=[CCMenu menuWithItems:menuitem, nil];
        [self addChild:menu];
        menu.position=ccp(400, 300);
        
       
        [self schedule:@selector(update)];
    }
    return self;
}
-(void)gotoOptionMenu
{
    [[CCDirector sharedDirector] popScene];
}



-(void)update{
    [TGDataManager sharedManager].truck1SpeedValue = truckSpeedSlider1.value;
    [TGDataManager sharedManager].truck2SpeedValue = truckSpeedSlider2.value;
    [TGDataManager sharedManager].truck3SpeedValue = truckSpeedSlider3.value;
    [TGDataManager sharedManager].truck4SpeedValue = truckSpeedSlider4.value;
    [TGDataManager sharedManager].truck5SpeedValue = truckSpeedSlider5.value;
    [TGDataManager sharedManager].userTruckSpeedValue=userTruckSpeedSlider.value;
}


@end
 
