#import "cocos2d.h"
#import "Box2D.h"
#import "cocos2d.h"
#import "TGGameConstants.h"
#import "TGCustomSprite.h"
#import "GB2ShapeCache.h"


//#define PTM_RATIO 32.0f

@interface MonsterTruck : CCNode
{
@public
    b2World *_world;
    b2Body *truckBody, *frontWheel, *rearWheel, *frontAxle, *rearAxle,*loadBody;
    b2PrismaticJoint *frontSpring, *rearSpring;
    b2RevoluteJoint *frontMotor, *rearMotor;
}

- (void)createTruckWithWorld:(b2World *)world withPosition:(CGPoint)pos ;
- (CGPoint)position;
- (void)updateSprings;
- (void)upArrowPressed:(float)truckSpeedvalue withTorque:(float)truckTorqueValue;
- (void)downArrowPressed;
- (void)upDownArrowReleased;
- (void)leftArrowPressed;
- (void)rightArrowPressed;
- (void)leftRightArrowReleased;
- (void)destroy;
-(void)applyImpulseForJump;

@end

