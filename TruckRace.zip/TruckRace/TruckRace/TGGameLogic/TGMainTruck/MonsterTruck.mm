#import "MonsterTruck.h"


@implementation MonsterTruck


// get the position of the truck.
- (CGPoint)position
{
    return ccp(truckBody->GetPosition().x*PTM_RATIO, truckBody->GetPosition().y*PTM_RATIO);
}
- (void)addTruckWithCoords:(CGPoint)pos
{  
    TGCustomSprite *truck1=[TGCustomSprite spriteWithFile:@"smalltruck.png"];
    //[self addChild:truck1 z:10 tag:1];
    truck1.scale=0.9;
    truck1.position=ccp(pos.x,pos.y);
    
     TGCustomSprite *truckLoad=[TGCustomSprite spriteWithFile:@"truck_lode.png"];
   // [truck1 addChild:truckLoad];
    truckLoad.position=ccp(30,52);
    truckLoad.scale=0.8;

    
    TGCustomSprite *trucktyre1=[TGCustomSprite spriteWithFile:@"truckTyre.png"];
   // [self addChild:trucktyre1 z:10 tag:1];
    trucktyre1.position=ccp(pos.x-30,pos.y-15);
    trucktyre1.scale=0.7;
    
    TGCustomSprite *trucktyre2=[TGCustomSprite spriteWithFile:@"truckTyre.png"];
    //[self addChild:trucktyre2 z:10 tag:1];
    trucktyre2.position=ccp(pos.x+26,pos.y-15);
    trucktyre2.scale=0.7;
    // Crate the body of the Truck.
    // use two box to make it looks like a truck.
    {
        b2BodyDef truckBodyDef;
        truckBodyDef.type = b2_dynamicBody;
        //truckBodyDef.userData=truck1;
        truckBodyDef.position.Set(pos.x/PTM_RATIO, (pos.y+5)/PTM_RATIO);
        //truckBodyDef.angularDamping = 0.1;
        //truckBodyDef.linearDamping = 0.1;
        
        truckBody = _world->CreateBody(&truckBodyDef);
        truckBodyDef.linearDamping = 0.2;
        
              [[GB2ShapeCache sharedShapeCache] addShapesWithFile:@"mainTruck.plist"];
        [[GB2ShapeCache sharedShapeCache] addFixturesToBody:truckBody forShapeName:@"smalltruck"];
        [truck1 setAnchorPoint:[[GB2ShapeCache sharedShapeCache] anchorPointForShape:@"smalltruck"]];
        
        /*
        b2BodyDef loadBodyDef;
        loadBodyDef.type=b2_dynamicBody;
        loadBodyDef.position.Set(pos.x/PTM_RATIO, (pos.y+15)/PTM_RATIO);
        loadBody=_world->CreateBody(&loadBodyDef);
        float r=10;
        b2CircleShape circle;
        circle.m_radius=r/PTM_RATIO;
        b2FixtureDef loadBodyFixtureDef;
        loadBodyFixtureDef.shape=&circle;
        loadBodyFixtureDef.density=2;
        
        loadBody->CreateFixture(&loadBodyFixtureDef);
         */
         
    
    }
    
    // we need two axle to join the truck body and the wheels together
    // and add two springs to join the truck body and axle together.
    {
        b2PrismaticJointDef pjd;
        pjd.lowerTranslation = -0.1;
        pjd.upperTranslation = 0.2;
        pjd.enableLimit = true;
        pjd.enableMotor = true;
        
        b2BodyDef bd;
        bd.type = b2_dynamicBody;
        bd.allowSleep = false;
        
        b2PolygonShape shape;
        b2FixtureDef fd;
        fd.shape = &shape;
        fd.density = 5;
        fd.friction = 0.1;
        fd.restitution = 0.01;
        fd.filter.groupIndex = -1;
        
        
        // front axle and front spring
        bd.position.Set(pos.x/PTM_RATIO, (pos.y+5)/PTM_RATIO);
        
        frontAxle = _world->CreateBody(&bd);
        shape.SetAsBox(5.0/PTM_RATIO, 
                       3.0/PTM_RATIO, 
                       b2Vec2((32-10*cos(M_PI/3))/PTM_RATIO, (-18+5*sin(M_PI/3))/PTM_RATIO), 
                       -M_PI/3);
        frontAxle->CreateFixture(&fd);
        
        pjd.Initialize(truckBody, frontAxle, frontAxle->GetWorldCenter(), 
                       b2Vec2(-cos(M_PI/4), sin(M_PI/4)));
        frontSpring = (b2PrismaticJoint *)_world->CreateJoint(&pjd);
        
        // rear axle and front spring
        bd.position.Set(pos.x/PTM_RATIO, (pos.y+5)/PTM_RATIO);
        
        shape.SetAsBox(5.0/PTM_RATIO, 
                       3.0/PTM_RATIO, 
                       b2Vec2((-32+10*cos(M_PI/3))/PTM_RATIO, (-18+5*sin(M_PI/3))/PTM_RATIO), 
                       M_PI/3);
        rearAxle = _world->CreateBody(&bd);
        rearAxle->CreateFixture(&fd);
        
        pjd.Initialize(truckBody, rearAxle, rearAxle->GetWorldCenter(), 
                       b2Vec2(cos(M_PI/3), sin(M_PI/3)));
        rearSpring = (b2PrismaticJoint *)_world->CreateJoint(&pjd);    
    }
    
    // add two big wheels
    {
        float radius = 10.0f;
        b2BodyDef bd;
        bd.type = b2_dynamicBody;
        
        bd.angularDamping = 0.1;
        bd.linearDamping = 0.1;
        
        b2CircleShape shape;
        shape.m_radius = radius/PTM_RATIO;
        
        b2FixtureDef fd;
        fd.shape = &shape;
        fd.density = 3;
        fd.friction = 20;
        fd.restitution = 1;
        fd.filter.groupIndex = -1;
        
        b2FixtureDef fd1;
        fd1.shape = &shape;
        fd1.density = 7;
        fd1.friction = 20;
        fd1.restitution = 0.2;
        fd1.filter.groupIndex = -1;

        
        // front wheel
        bd.position.Set(frontAxle->GetWorldCenter().x+5*cos(M_PI/3)/PTM_RATIO,
                        frontAxle->GetWorldCenter().y-5*sin(M_PI/3)/PTM_RATIO);
        //bd.userData=trucktyre1;
        frontWheel = _world->CreateBody(&bd);
        frontWheel->CreateFixture(&fd);
        
        // rear wheel
        bd.position.Set(rearAxle->GetWorldCenter().x-5*cos(M_PI/3)/PTM_RATIO,
                        rearAxle->GetWorldCenter().y-5*sin(M_PI/3)/PTM_RATIO);
       //bd.userData=trucktyre2;
        rearWheel = _world->CreateBody(&bd);
        rearWheel->CreateFixture(&fd1);
    }
    
    { // add joints
        b2RevoluteJointDef rjd;
        rjd.enableMotor = true;
        
        rjd.Initialize(frontAxle, frontWheel, frontWheel->GetWorldCenter());
        frontMotor = (b2RevoluteJoint*)_world->CreateJoint(&rjd);
        
        rjd.Initialize(rearAxle, rearWheel, rearWheel->GetWorldCenter());
        rearMotor = (b2RevoluteJoint*)_world->CreateJoint(&rjd);
    }
}




- (void)createTruckWithWorld:(b2World *)world withPosition:(CGPoint)pos
{
    _world = world;
    [self addTruckWithCoords:pos];
}

// update springs constantly
- (void)updateSprings
{
    if (frontSpring != NULL && rearSpring != NULL)
    {
        frontSpring->SetMaxMotorForce(7 + abs(75 * pow(frontSpring->GetJointTranslation(), 2)));
        
        frontSpring->SetMotorSpeed(-3 * pow(frontSpring->GetJointTranslation(), 1));
        
        rearSpring->SetMaxMotorForce(7 + abs(75 * pow(rearSpring->GetJointTranslation(), 2)));
        rearSpring->SetMotorSpeed(-3 * pow(rearSpring->GetJointTranslation(), 1));
    }
}
-(void)applyImpulseForJump
{
    float impulse = truckBody->GetMass() * 20;
    b2Vec2 vel=truckBody->GetLinearVelocity();
    //impulse=vel.x;
    
    

    truckBody->ApplyLinearImpulse(b2Vec2(0,impulse),truckBody->GetPosition());
}

// methods responsing to key events
- (void)leftArrowPressed
{
    truckBody->ApplyTorque(280.0);
}

- (void)rightArrowPressed
{
    truckBody->ApplyTorque(-280.0);
}

- (void)leftRightArrowReleased
{
    truckBody->ApplyTorque(0.0);
}

- (void)upArrowPressed:(float)truckSpeedvalue withTorque:(float)truckTorqueValue
{
    
    frontMotor->SetMotorSpeed(truckSpeedvalue * M_PI * -1);
    frontMotor->SetMaxMotorTorque(truckTorqueValue);
    rearMotor->SetMotorSpeed(truckSpeedvalue * M_PI * -1);
    rearMotor->SetMaxMotorTorque(truckTorqueValue+3);
}

- (void)downArrowPressed
{
    frontMotor->SetMotorSpeed(0 * M_PI * 1);
    frontMotor->SetMaxMotorTorque(0.1);
    rearMotor->SetMotorSpeed(0 * M_PI * 1);
    rearMotor->SetMaxMotorTorque(0.1);
}

- (void)upDownArrowReleased
{
    frontMotor->SetMotorSpeed(0);
    frontMotor->SetMaxMotorTorque(0);
    rearMotor->SetMaxMotorTorque(0);
    rearMotor->SetMotorSpeed(0);
}

- (void) destroy
{
    _world->DestroyJoint(frontMotor);
    _world->DestroyJoint(rearMotor);
    _world->DestroyBody(truckBody);
    _world->DestroyBody(frontWheel);
    _world->DestroyBody(rearWheel);
    _world->DestroyBody(frontAxle);
    _world->DestroyBody(rearAxle);
    
    // since we join truck body and axles with springs,
    // when the truck and axles are destroyed, the springs are never exist.
    // so we needn't destroy the two springs.
    // _world->DestroyJoint(frontSpring);
    // _world->DestroyJoint(rearSpring);
}

- (void)dealloc
{
    [super dealloc];
}

// BTW, if you need update sprite, add the following method and schedule it.
/*
 - (void)update
 {
 for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
 {
 if (b->GetUserData() != NULL) 
 {
 CCSprite *sprite= (CCSprite*)b->GetUserData();
 sprite.position = CGPointMake( b->GetPosition().x * PTM_RATIO, b->GetPosition().y * PTM_RATIO);
 sprite.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle());
 }
 }
 }
 */
@end