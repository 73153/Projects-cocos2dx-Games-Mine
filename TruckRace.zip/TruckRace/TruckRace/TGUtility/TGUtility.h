//
//  TGUtility.h
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Box2D.h"


@interface TGUtility : NSObject {
    
}
+(float) getAngleFromCurrentPoint:(CGPoint )p1 toPoint:(CGPoint)p2;
+(CGRect) rectForSprite:(CCSprite * )sprite; 
+(int)getRandomFrom:(int)min ToNo:(int)max;
+(BOOL)bodiesAreTouching:(b2Body*) body1 withBody:(b2Body*) body2;

@end
