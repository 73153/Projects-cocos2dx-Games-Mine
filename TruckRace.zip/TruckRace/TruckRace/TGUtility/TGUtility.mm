//
//  TGUtility.m
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "TGUtility.h"

@implementation TGUtility
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

-(void)dealloc {
    
    [super dealloc];
}
+(float) getAngleFromCurrentPoint:(CGPoint )p1 toPoint:(CGPoint)p2
{
    CGPoint difference = ccpSub(p1,p2);
    double angle = -1 * (atan2(difference.y, difference.x) * 180 / M_PI + 90);
    if(angle<0)
    {
        angle=angle+360;
    }
    return angle;
}

+(CGRect) rectForSprite:(CCSprite * )sprite{
    
	float w = [sprite contentSize].width;
    float h = [sprite contentSize].height;
	float x = sprite.position.x - w/2;
	float y = sprite.position.y - h/2;
    
	CGRect rect = CGRectMake(x,y,w,h);
	return rect;
}

+(int)getRandomFrom:(int)min ToNo:(int)max {
    
    int toNumber = max+1;
	int fromNumber = min;
	
	int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
	return randomNumber; 
}

+(BOOL)bodiesAreTouching:(b2Body*) body1 withBody:(b2Body*) body2 {
    
    for (b2ContactEdge* edge = body1->GetContactList(); edge; edge = edge->next)
	{
		if ( !edge->contact->IsTouching() )
			continue;
		b2Body* bA = edge->contact->GetFixtureA()->GetBody();
		b2Body* bB = edge->contact->GetFixtureB()->GetBody();
		if ( ( bA == body1 && bB == body2 ) || ( bB == body1 && bA == body2 ) )
			return true;
	}
	return false;
}

@end
