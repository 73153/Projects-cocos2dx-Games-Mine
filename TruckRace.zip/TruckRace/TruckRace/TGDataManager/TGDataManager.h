//
//  TGDataManager.h
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Box2D.h"
#import "cocos2d.h"

@class HelloWorldLayer;

@interface TGDataManager : NSObject{
    
    HelloWorldLayer *gameLayer;
    CGSize screenSize;
    b2World *gameWorld;
    int gameScore;
    
    CCLayer *staticLayer;
    int touchTimeCounter;
    float truck1SpeedValue;
    float truck2SpeedValue;
    float truck3SpeedValue;
    float truck4SpeedValue;
    float truck5SpeedValue;
    float userTruckSpeedValue;
    
    bool isBodiesTouching;
}
+(TGDataManager *)sharedManager;
@property(nonatomic,assign)HelloWorldLayer *gameLayer;
@property(nonatomic,assign)CGSize screenSize;
@property(nonatomic,assign)b2World *gameWorld;
@property(nonatomic,assign)int gameScore;
@property(nonatomic,assign) CCLayer *staticLayer;
@property(nonatomic,assign)int touchTimeCounter;
@property(nonatomic,assign)float truck1SpeedValue;
@property(nonatomic,assign)float truck2SpeedValue;
@property(nonatomic,assign)float truck3SpeedValue;
@property(nonatomic,assign)float truck4SpeedValue;
@property(nonatomic,assign)float truck5SpeedValue;
@property(nonatomic,assign)float userTruckSpeedValue;
@property(nonatomic,assign)bool isBodiesTouching;
@end
