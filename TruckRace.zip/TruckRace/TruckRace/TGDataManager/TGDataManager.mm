//
//  TGDataManager.m
//  TruckGame
//
//  Created by i-CRG Labs Virupaksh on 7/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "TGDataManager.h"
#import "HelloWorldLayer.h"

@implementation TGDataManager
@synthesize gameLayer,screenSize,gameWorld,gameScore,staticLayer,touchTimeCounter;
@synthesize truck1SpeedValue,truck2SpeedValue,truck3SpeedValue,truck4SpeedValue,truck5SpeedValue,userTruckSpeedValue,isBodiesTouching;

static  TGDataManager *sSharedInstance = nil;

+(TGDataManager *)sharedManager {
    
    @synchronized([TGDataManager class])
	{
		if (!sSharedInstance)
			[[self alloc] init];
        
		return sSharedInstance;
	}
	return nil; 
}

+(id)alloc
{
	@synchronized([TGDataManager class])
	{
		NSAssert(sSharedInstance == nil, @"Attempted to allocate a second instance of a singleton.");
		sSharedInstance = [super alloc];
		return sSharedInstance;
	}
    
	return nil;
}

- (id)init
{
    self = [super init];
    if (self) {
        
        // Initialization code here.
        self.truck1SpeedValue=1.2;
         self.truck2SpeedValue=1.4;
         self.truck3SpeedValue=1.6;
         self.truck4SpeedValue=1.7;
         self.truck5SpeedValue=1.3;
        self.userTruckSpeedValue=8;
        
    }
    
    return self;
}

-(void) dealloc {
    
    [super dealloc];
}



@end
