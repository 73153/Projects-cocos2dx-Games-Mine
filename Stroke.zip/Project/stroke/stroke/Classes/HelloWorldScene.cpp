#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCRenderTexture* HelloWorld::createStroke(CCSprite* label, int size, ccColor3B color, GLubyte opacity)
{

    CCRenderTexture* rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2, label->getTexture()->getContentSize().height+size * 2);
    
    CCPoint originalPos = label->getPosition();
    
    ccColor3B originalColor = label->getColor();

    GLubyte originalOpacity = label->getOpacity();
    
    bool originalVisibility = label->isVisible();
    
    label->setColor(color);
    
    label->setOpacity(opacity);
    
    label->setVisible(true);
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    
    label->setBlendFunc(bf);
    
    CCPoint bottomLeft = ccp(label->getTexture()->getContentSize().width * label->getAnchorPoint().x + size, label->getTexture()->getContentSize().height * label->getAnchorPoint().y + size);
    
    
    rt->begin();
    
    for (int i=0; i<360; i+= 15)
        {
          label->setPosition(
          ccp(bottomLeft.x + sin(CC_DEGREES_TO_RADIANS(i))*size, bottomLeft.y + cos(CC_DEGREES_TO_RADIANS(i))*size));
          label->visit();
        }
    
    rt->end();
    
        label->setPosition(originalPos);
        label->setColor(originalColor);
        label->setBlendFunc(originalBlend);
        label->setVisible(originalVisibility);
        label->setOpacity(originalOpacity);
    
    rt->setPosition(originalPos);
    
    return rt;

}

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *pCloseItem = CCMenuItemImage::create(
                                        "CloseNormal.png",
                                        "CloseSelected.png",
                                        this,
                                        menu_selector(HelloWorld::menuCloseCallback) );
    pCloseItem->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );
    
    CCMenuItemImage *item1 = CCMenuItemImage::create("CloseNormal.png", "CloseNormal.png");
    CCMenuItemImage *item2 = CCMenuItemImage::create("CloseSelected.png", "CloseSelected.png");

    // create menu, it's an autorelease object
    CCMenuItemToggle *toggle = CCMenuItemToggle::createWithTarget(this, menu_selector(HelloWorld::menuCloseCallback), item1, item2, NULL);
    toggle->setPosition( ccp(CCDirector::sharedDirector()->getWinSize().width - 20, 20) );
    
    toggle->setSelectedIndex(0);
    
    CCMenu* pMenu = CCMenu::create(toggle, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    

    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label
    CCLabelTTF* pLabel = CCLabelTTF::create("Hello World", "Thonburi", 34);

    // ask director the window size
    size = CCDirector::sharedDirector()->getWinSize();

    // position the label on the center of the screen
    pLabel->setPosition( ccp(size.width / 2, size.height - 20) );

    // add the label as a child to this layer
    this->addChild(pLabel, 1);

    // add "HelloWorld" splash screen"
    CCSprite* pSprite = CCSprite::create("HelloWorld.png");

    // position the sprite on the center of the screen
    pSprite->setPosition( ccp(size.width/2, size.height/2) );

    // add the sprite as a child to this layer
//    this->addChild(pSprite, 0);
    
    
    sprite = CCSprite::create("airPlane4.png");
    
    sprite->setPosition(ccp(size.width/2, size.height/2));
    
    addChild(sprite);
    
    tex = createStroke(sprite, 2.5, ccc3(0, 255, 0), 100 );
    
    addChild(tex, sprite->getZOrder() - 1);
    
    
    
    
    return true;
}

void HelloWorld::menuCloseCallback(CCObject* pSender)
{
    CCMenuItemToggle *item = (CCMenuItemToggle*)pSender;
    
    int i = item->getSelectedIndex();
    
    CCLOG("selectedIndex:%d,",i);
    
    changeSprite(i);
    
}

void HelloWorld::changeSprite(int index)
{
    removeChild(sprite, true);
    removeChild(tex, true);
    
    if (index == 0)
    {
        sprite = CCSprite::create("airPlane4.png");
    }
    else
    {
     sprite = CCSprite::create("settings_itunes.png");
    }
    
    sprite->setPosition(ccp(size.width/2, size.height/2));
    
    addChild(sprite);
    
    tex = createStroke(sprite, 2.5, ccc3(0, 255, 0), 100 );
    
    addChild(tex, sprite->getZOrder() - 1);
}
