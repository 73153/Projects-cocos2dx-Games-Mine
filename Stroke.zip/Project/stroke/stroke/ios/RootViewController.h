//
//  strokeAppController.h
//  stroke
//
//  Created by Manuel Escalante on 5/13/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
