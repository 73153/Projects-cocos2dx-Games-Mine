NDControlGauge Example
=================
NDControlGauge is a simple gauge control built atop a modified CCControl, originally written by Yannick Loriot. This is an example that demonstrates the gauge's functionalities. You'll need cocos2d for iOS to build.

The source code is shared under the MIT License. 

How to get the source
===================== 

```
git clone git@github.com:EricYim/NDControlGaugeExample.git
cd NDControlGaugeExample

# to get latest stable source from master branch, use this command:
git checkout -t origin/master
```
