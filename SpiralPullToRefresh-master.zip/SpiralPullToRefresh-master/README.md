Spiral Pull-to-Refresh
======================

"Twitter music" like pull-to-refresh controller but a bit more enhanced and flexible.

##Download
    $ git clone https://github.com/kronik/SpiralPullToRefresh.git
    $ cd SpiralPullToRefresh/

##Usage
Please check out the demo project included.