//
//  ZIGameManager.cpp
//  ZergInvasion
//
//  Created by ICRG LABS on 13/09/12.
//
//

#include "ZIGameManager.h"

ZIGameManager::ZIGameManager(void) {
    
    printf("Game Manager initiating");
}

ZIGameManager::~ZIGameManager(void) {
    
    printf("destructor Game Manager");
}

