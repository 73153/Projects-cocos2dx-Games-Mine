Apparticle
==========

A Mac OS X particle editor for and with Cocos2D
