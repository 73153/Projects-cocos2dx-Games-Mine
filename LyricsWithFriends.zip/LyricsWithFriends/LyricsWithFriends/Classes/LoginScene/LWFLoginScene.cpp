//
//  LWFLoginScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#include "LWFLoginScene.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFRegisterScene.h"
#include "LWFMainScene.h"
#include "LWFGenreListScene.h"
#include "LWFRegisterScene.h"
#include "LWFGameProgressScreen.h"
#include "LWFDataManager.h"



//#include "LWFGameScene.h"
using namespace cocos2d;

CCScene* LWFLoginScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFLoginScene *layer = LWFLoginScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma  mark - constructor
LWFLoginScene::LWFLoginScene()
{
    this->initialiseUI();
    this->initialiseFunctions();
}


#pragma mark - initialiseUI
void LWFLoginScene::initialiseUI()
{
    CCSize winsize=CCDirector::sharedDirector()->getWinSize();
    
    CCSprite *topbarSpr = CCSprite::create("LoginPage/username.png");
    topbarSpr->setPosition(ccp(160,458));
    this->addChild(topbarSpr);
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    addChild(labelStatusCode,20);
    
        
    CCSprite *bgSpr = CCSprite::create("LoginPage/Username-Loginre-bg.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    
    CCSprite *userNameSpr = CCSprite::create("LoginPage/username_tab.png");
    userNameSpr->setPosition(ccp(160,274));
    this->addChild(userNameSpr);
    
    CCSprite *passwordSpr = CCSprite::create("LoginPage/passwordtab.png");
    passwordSpr->setPosition(ccp(160,240));
    this->addChild(passwordSpr);
    
    CCSprite *backButtonNormalSpr = CCSprite::create("LoginPage/back_bt.png");
    CCSprite *backButtonSelectedSpr = CCSprite::create("LoginPage/back_bt.png");
    
    CCMenuItemSprite *backButtonMenuItem = CCMenuItemSprite::create(backButtonNormalSpr, backButtonSelectedSpr, this, menu_selector(LWFLoginScene::goBackToMainScene));
    backButtonMenuItem->setPosition(CCPointMake(28,458));
    
    CCSprite *loginButtonNormalSpr = CCSprite::create("LoginPage/login.png");
    CCSprite *loginButtonSelectedSpr = CCSprite::create("LoginPage/login.png");
    
    loginButtonMenuItem = CCMenuItemSprite::create(loginButtonNormalSpr, loginButtonSelectedSpr, this, menu_selector(LWFLoginScene::onClickOfLogin));
    loginButtonMenuItem->setPosition(CCPointMake(162,168));
    loginButtonMenuItem->setEnabled(true);
    
    CCSprite *createAccountButtonNormalSpr = CCSprite::create("LoginPage/creat-acc.png");
    CCSprite *createAccountSelectedSpr = CCSprite::create("LoginPage/creat-acc.png");
    
    CCMenuItemSprite *createAccountMenuItem = CCMenuItemSprite::create(createAccountButtonNormalSpr, createAccountSelectedSpr, this, menu_selector(LWFLoginScene::onClickOfCreateAccount));
    createAccountMenuItem->setPosition(CCPointMake(41,24));

    
    CCSprite *bottombarSpr = CCSprite::create("LoginPage/bottombar.png");
    bottombarSpr->setPosition(ccp(160,26));
    this->addChild(bottombarSpr,1);
    
    
    CCMenu *tempMenu = CCMenu::create(backButtonMenuItem,loginButtonMenuItem, createAccountMenuItem,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
}

#pragma mark - initialiseFunctions
void LWFLoginScene::initialiseFunctions()
{
    this->userNameFunc();
    this->passwordFunc();
}

#pragma MARK - replaceScene
void LWFLoginScene::goBackToMainScene()
{
      CCDirector::sharedDirector()->replaceScene(LWFMainScene::scene());
}


#pragma mark - CreateAccount
void LWFLoginScene::onClickOfCreateAccount()
{
    CCDirector::sharedDirector()->replaceScene(LWFRegisterScene::scene());
}

#pragma mark - loginButton
void LWFLoginScene::onClickOfLogin()
{
    loginButtonMenuItem->setEnabled(false);
    this->checkForNetWork();
    
}

#pragma MARK - EditBoxFunctions
void LWFLoginScene::editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox)
{
    CCLog("editBox %p DidBegin !", editBox);
}

void LWFLoginScene::editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox)
{
    CCLog("editBox %p DidEnd !", editBox);
}

void LWFLoginScene::editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text)
{
    
    
    CCLog("editBox %p TextChanged, text: %s ", editBox, text.c_str());
    
    //userId =userName->getText();
    userId=userName->getText();
    userPassword=passWord->getText();
    
}

void LWFLoginScene::editBoxReturn(cocos2d::extension::CCEditBox* editBox)
{
}


#pragma mark - OnClickOfUserNameFunc
void LWFLoginScene::userNameFunc()
{
    CCSize editBoxSize = CCSizeMake(276,34);
    userName=cocos2d::extension::CCEditBox::create(editBoxSize,cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    userName->setPosition(ccp(245,274));        ;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	userName->setFont("Arial", 20);
#else
	userName->setFont("fonts/Paint Boy.ttf", 20);
#endif
    userName->setFontColor(ccRED);
    
    userName->setPlaceholderFontColor(ccWHITE);
    userName->setMaxLength(15);
    userName->setReturnType(cocos2d::extension::kKeyboardReturnTypeDone);
    userName->setDelegate(this);
    addChild(userName,2);
    
}

#pragma mark - onClickOfPasswordFunc
void LWFLoginScene::passwordFunc()
{
    
    passWord = cocos2d::extension::CCEditBox::create(CCSize(276,34), cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    passWord->setPosition(ccp(245,240));
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	passWord->setFont("American Typewriter", 20);
#else
	passWord->setFont("fonts/American Typewriter.ttf", 20);
#endif
    passWord->setFontColor(ccGREEN);
    
    passWord->setMaxLength(10);
    passWord->setInputFlag(cocos2d::extension::kEditBoxInputFlagPassword);
    passWord->setInputMode(cocos2d::extension::kEditBoxInputModeSingleLine);
    passWord->setDelegate(this);
    addChild(passWord,2);
}


#pragma mark - checkForNetWork
//used to check whether network is present
void LWFLoginScene::checkForNetWork()
{
    LWFHttpRequest* request = new    LWFHttpRequest();
    std::string url="http://google.com";
    request->setUrl(url.c_str());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFLoginScene::onNetworkCheckIsFinished));
    // optional fields
    request->setTag("Network test");
    LWFHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    
    labelStatusCode->setString("waiting...");
    
    
}

//response for the request
void LWFLoginScene::onNetworkCheckIsFinished(cocos2d::CCNode *sender, void *data)
{
    //using namespace httpios;
    //   DLOG("");
    if (!this->isRunning()) {
        return;
    }
    
    LWFHttpResponse *response = (LWFHttpResponse*)data;
    if(!response->isSucceed())
    {
        isNetWorkPresent=false;
        labelStatusCode->setString("Network Error");
        loginButtonMenuItem->setEnabled(true);
    }
    else
    {
        //if succeded then login
        isNetWorkPresent=true;
        this->loginFunc();
    }
}


#pragma mark request,response-OnClickOfLogin
void LWFLoginScene::loginFunc()
{
  if( isNetWorkPresent)
  {
    std::string type="signin";
    LWFHttpRequest * request = new LWFHttpRequest();
  
    CCLOG("%s",userId.c_str());
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createLoginURL(userId,userPassword,type).c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFLoginScene::onHttpRequestCompleted));
    request->setTag("GET test1");
    LWFHttpClient::getInstance()->send(request);
    request->release();

    labelStatusCode->setString("waiting...");
     }
 }

void LWFLoginScene::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning()) {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    
    if(document.HasMember("user"))
    {
        LWFDataManager::sharedManager()->currentUserID=document["user"]["userId"].GetString();
        CCLOG("%s=currentUserID",LWFDataManager::sharedManager()->currentUserID.c_str());
    }
     this->displayTheAlertLabel(document,message);
  
 }

#pragma mark - alertMsg
void LWFLoginScene::displayTheAlertLabel(rapidjson::Document & doc,std::string msg)
{
   
    std::string errorMsg="Email not found!!!";
    std::string successMsg="User signed in successfully";
  
    //if user has not registered
    if(strcmp(msg.c_str(), errorMsg.c_str())==0)
    {
        labelStatusCode->setString("YOU SHOULD REGISTER FIRST");
        loginButtonMenuItem->setEnabled(true);

    }
    
    //if loggin successfully
    else if(strcmp(msg.c_str(), successMsg.c_str())==0)
    {
        std::string api =doc ["user"]["APIKey"].GetString();
        CCUserDefault::sharedUserDefault()->setStringForKey("APIKey", api);
        cocos2d::CCUserDefault::sharedUserDefault()->flush();
        CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
    }
    
    else
    {
          loginButtonMenuItem->setEnabled(true);
          labelStatusCode->setString(msg.c_str());
    }

}

#pragma mark - destructor
LWFLoginScene::~LWFLoginScene()
{
    
}
