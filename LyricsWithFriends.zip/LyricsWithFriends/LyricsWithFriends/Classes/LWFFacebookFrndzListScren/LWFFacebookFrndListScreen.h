//
//  LWFFacebookFrndListScreen.h
//  LyricsWithFriends
//
//  Created by Deepthi on 17/07/13.
//
//

#ifndef __LyricsWithFriends__LWFFacebookFrndListScreen__
#define __LyricsWithFriends__LWFFacebookFrndListScreen__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include "CommonUtils.h"
//#include "CCSpriteFromUrl.h"

using namespace cocos2d;
using namespace cocos2d::extension;


class LWFFacebookFrndListScreen : public cocos2d::CCLayer,public cocos2d::extension::CCTableViewDataSource,public cocos2d::extension::CCTableViewDelegate, public cocos2d::CCTextFieldDelegate
{
public:
    LWFFacebookFrndListScreen();
    
    ~LWFFacebookFrndListScreen();
    
    virtual bool init();
    
    //  virtual void onExit();
    
    //   virtual void onEnterTransitionDidFinish();
    
    // static CCScene* scene();
    
    LWF_CREATECOCOS2DSCENE(LWFFacebookFrndListScreen);
    void FetchFriendList();
    void FetchInstalledFriendList();
    void sortList();
    
    virtual cocos2d::CCSize cellSizeForTable(cocos2d::extension::CCTableView *table);
    virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(cocos2d::extension::CCTableView *table);
    
    void scrollToIndex(CCObject* sender);
    void tableCellTouched(cocos2d::extension::CCTableView *table, cocos2d::extension::CCTableViewCell *cell);
    void scrollToIndexCh(char ch);
    
    void reinitlist()
    {
        tableView->setContentOffset(tableView->minContainerOffset());
    }
    
    bool onTextFieldInsertText(cocos2d::CCTextFieldTTF * pSender, const char * text, int nLen);
    bool onTextFieldModifedText(cocos2d::CCTextFieldTTF * pSender, std::string text, int nLen);
    bool onTextFieldDeleteBackward(cocos2d::CCTextFieldTTF * sender, const char * delText, int nLen);
    
    //
    void loadFriendList();
    bool issearching;
    ;
    void loadnormalView(CCObject* sender);
    void loadLabelMenu();
    
    void search(CCObject* sender);
    void startsearch(CCObject* sender);
    
    void endsearch(CCObject* sender);
    void switchTab(CCObject* sender);
    
   void loadActivity(CCObject* sender);
    
    
    void onGamePlayRequestCompleted(cocos2d::CCNode *sender, void *data);
    void checkForNetWork();
    void onnetworkRequestCompleted(cocos2d::CCNode *sender, void *data);
    
   void BackButton(CCObject* sender);
   void remove();
    
    void sendInvitation( const char * facebookid ,const char * username);
    void sendPlayRequestInvitation( const char * facebookid ,const char * username);
    void realsendInvitation(const char * facebookid ,const char * username);
    void InvitationFailed(const char * facebookid ,const char * username);
    static  void postToFB(const char *inFBPostStr);
    static void postToFB(const char* inPost,int score, bool isLike);
    static  bool isFBLogedIn();
    static void loginToFB();
    static void facebookLoginDone(bool succesful);
    
    //private:
    
    cocos2d::extension::CCTableView * tableView;
    
    cocos2d::CCArray * friendsInstaledList;
    cocos2d::CCArray * friendsNotInstaledList;
    
    cocos2d::CCArray * friendsList;
    cocos2d::CCArray * filteredfriendsList;
    cocos2d::CCSprite * box;
    cocos2d::CCMenu * searchBox;
    
    cocos2d::CCTextFieldTTF * pTextField;
    
    
    bool isActiveTabPlay;
    
    bool loadedFriendList;
    int requestTag;
    cocos2d::CCMenuItemSprite * playTab;
    cocos2d::CCMenuItemSprite * inviteTab;
    
    void filterSearch(const char * ptr);
    
    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view) {
    };
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view) {
    }
    void onScreenBack();
    
    
};

#pragma mark - FacebookFriendCell functions
class FacebookFriendCell:public CCTableViewCell
{
    bool minvite;
    
public:
    std::string name,facebookid;
    
    LWFFacebookFrndListScreen * screen;
    
    static FacebookFriendCell * create(std::string inname,std::string infinacebookid,bool isinvite=false)
    {
        FacebookFriendCell * facebookfriend = new FacebookFriendCell;
        facebookfriend->init(inname, infinacebookid,isinvite);
        
        facebookfriend->autorelease();
        return facebookfriend;
    }
    
    void facebookInvite()
    {
        
        if(minvite)
            screen->sendInvitation(facebookid.c_str(),name.c_str());
        else
            screen->sendPlayRequestInvitation( facebookid.c_str() ,name.c_str());
    }
    
    bool init(std::string inname,std::string infacebookid,bool isinvite=false)
    {
        name=inname;
        facebookid=infacebookid;
        CCSprite * sprite = CCSprite::create("selectedChallengePage/colm1.png");
        
        this->addChild(sprite);
        CCLog("%f=sprite->getContentSize().width",sprite->getContentSize().width);
        this->setContentSize(sprite->getContentSize());
        CCNodePlaceAtCenter(sprite);
        
        
        CCLabelTTF * labelttf = CCLabelTTF::create("", "Helvetica", 20);
        this->addChild(labelttf);
        labelttf->setColor(ccBLACK);
        CCNodePlaceAtLeft(labelttf,ccp(105,0));
        
        labelttf->setString(inname.c_str());
        
        {
            minvite = isinvite;
            
//            CCSpriteFaceBook * profileimage=
//            CCSpriteFaceBook::create(facebookid.c_str());
//            
//            this->addChild(profileimage);
//            CCNodePlaceAtLeft(profileimage,ccp(9,0));
            
        }
        return true;
    }
};
#endif /* defined(__LyricsWithFriends__LWFFacebookFrndListScreen__) */
