//
//  LWFChallenge.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#include "LWFChallenge.h"

LWFChallenge::LWFChallenge()
{
    score = 0;
}

LWFChallenge::~LWFChallenge()
{
    
}