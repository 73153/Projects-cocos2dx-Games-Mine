//
//  LWFChallenges.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#include "LWFChallenges.h"

LWFChallenges::LWFChallenges()
{
    
}

LWFChallenges::~LWFChallenges()
{
    
}