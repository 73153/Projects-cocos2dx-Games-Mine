//
//  LWFGame.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#include "LWFGame.h"

LWFGame::LWFGame()
{
    this->isSpace=FALSE;
}

LWFGame::~LWFGame()
{
    
}