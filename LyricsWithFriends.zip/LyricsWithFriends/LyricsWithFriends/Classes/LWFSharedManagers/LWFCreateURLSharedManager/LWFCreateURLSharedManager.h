//
//  LWFCreateURLSharedManager.h
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//

#ifndef LyricsWithFriends_LWFCreateURLSharedManager_h
#define LyricsWithFriends_LWFCreateURLSharedManager_h

#include "cocos2d.h"

#include "cocos-ext.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"
USING_NS_CC;


class LWFCreateURLSharedManager: public cocos2d::CCObject
{
public:
    
    //Basic Vars & Methods of Shared Manager
    static LWFCreateURLSharedManager* sharedManager(void);
    bool init(void);
    LWFCreateURLSharedManager();
    ~LWFCreateURLSharedManager();


    std::string createLoginURL(std::string emailID,std::string password,std::string signin);
    std::string createRegistrationURL(std::string userName,std::string emailID,std::string password,std::string signup);
    std::string createLogOutURL();
    std::string createURLToGetLyrics();
    std::string createURLToGetRandomOpponents();
    std::string createURLToSubmitChallenge();
    std::string createURLToLoadCurrentGames();
    std::string createURLToCloseChallenge();
    std::string createURLToGetChallenge();
    std::string createURLToLoginThroughFB(std::string emailID,std::string faceBookID,std::string facebookThumbnail,std::string userName,std::string gender);
    std::string createURLForPush();
    std::string createURLToLoadSelectedOpponent(std::string emailID);
    std::string createURLToGetFaceBookUserDetails( const char * facebookid);
};




#endif
