//
//  LWFNetworkSharedManager.h
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//
//
#ifndef LyricsWithFriends_LWFNetworkResponseSharedManager_h
#define LyricsWithFriends_LWFNetworkResponseSharedManager_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"
#include "httpiOS.h"

using namespace cocos2d;
using namespace cocos2d::extension;
USING_NS_CC;

#include <string>

USING_NS_CC;
USING_NS_CC_EXT;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient


class LWFNetworkResponseSharedManager: public cocos2d::CCObject
{
public:
    
    //Basic Vars & Methods of Shared Manager
    static LWFNetworkResponseSharedManager* sharedManager(void);
    bool init(void);
    
    LWFNetworkResponseSharedManager();
    ~LWFNetworkResponseSharedManager();
    
    void getResponseBuffer(cocos2d::CCNode *sender, void *data , rapidjson::Document &  document);


 
};


#endif
