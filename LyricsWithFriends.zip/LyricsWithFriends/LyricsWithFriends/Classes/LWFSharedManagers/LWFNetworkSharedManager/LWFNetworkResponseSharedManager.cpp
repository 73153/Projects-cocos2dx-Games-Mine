//
//  LWFNetworkSharedManager.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//

#include "LWFNetworkResponseSharedManager.h"
#include "LWFLoginScene.h"
#include "SimpleAudioEngine.h"
#include <string>

USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;
using namespace CocosDenshion;


static LWFNetworkResponseSharedManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

LWFNetworkResponseSharedManager::LWFNetworkResponseSharedManager(void)
{
    
}

LWFNetworkResponseSharedManager::~LWFNetworkResponseSharedManager(void)
{
    
}


LWFNetworkResponseSharedManager* LWFNetworkResponseSharedManager::sharedManager(void) {
    
	LWFNetworkResponseSharedManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new LWFNetworkResponseSharedManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool LWFNetworkResponseSharedManager::init(void)
{
    
	return true;
}



void LWFNetworkResponseSharedManager::getResponseBuffer(cocos2d::CCNode *sender, void *data , rapidjson::Document &  document)
{
    LWFHttpResponse *response = (LWFHttpResponse*)data;
    
    if (!response)
    {
        return;
    }
    
    // You can get original request type from: response->request->reqType
    if (0 != strlen(response->getHttpRequest()->getTag()))
    {
        CCLog("%s completed", response->getHttpRequest()->getTag());
    }
    
    int statusCode = response->getResponseCode();
    char statusString[64] = {};
    sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode, response->getHttpRequest()->getTag());
    
    if (!response->isSucceed())
    {
        CCLog("response failed");
        return;
    }
    
    // dump data
    std::vector<char> *buffer = response->getResponseData();
    
    char * charbuffer =new char[buffer->size()+1];
    
    
    printf("Http Test, dump data: ");
    for (unsigned int i = 0; i < buffer->size(); i++)
    {
        //   printf("%c", (*buffer)[i]);
        
        charbuffer[i]=(*buffer)[i];
        
    }
    charbuffer[buffer->size()]=0;
    
    printf("Http Test, dump data:%s ",charbuffer);
    
    document.Parse<0>(charbuffer);
    
    //if apikey sessionout then replce scene to login scene
    std::string message=document["msg"].GetString();
    if(message=="APIKey session out!!!")
    {
        CCDirector::sharedDirector()->replaceScene(LWFLoginScene::scene());
    }
    if(message=="No user exists")
    {
        CCLabelTTF *label =CCLabelTTF::create("Goto browser and clear the challenge"," ", 15, CCSizeMake(250,90), kCCTextAlignmentCenter);
        CCDirector::sharedDirector()->getRunningScene()->addChild(label);
        label->setPosition(ccp(150,240));
    }
    delete[] charbuffer;
}

