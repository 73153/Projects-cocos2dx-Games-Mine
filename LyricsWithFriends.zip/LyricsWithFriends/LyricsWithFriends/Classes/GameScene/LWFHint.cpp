//
//  LWFHint.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 24/06/13.
//
//

#include "LWFHint.h"

LWFHint::LWFHint()
{
    
}


LWFHint::~LWFHint()
{
    
}