//
//  LWFGameScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#include "LWFGameScene.h"
#include "LWFGenreListScene.h"
#include "LWFLoginScene.h"
#include "LWFKeyboardBTN.h"
#include "LWFEmptyBox.h"
#include "SimpleAudioEngine.h"
#include "LWFDataManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFQuestionLoadingscene.h"
#include "LWFSubmitChallenge.h"
#include "LWFObjectiveCCalls.h"
#include "LWFHint.h"
#include "LWFAlphabet.h"

#define kBoxTag 200

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* LWFGameScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFGameScene *layer = LWFGameScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFGameScene::LWFGameScene()
{
    
}

#pragma mark - onEnter onExit
void LWFGameScene::onEnter()
{
    CCLayer::onEnter();
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GameScene/gameSceneImages.plist");
    
    //keyBoardAlpahbets=NULL;
    canDragTheAlphabet=true;
    this->setTouchEnabled(true);
    this->initialiseFunc();
    
}

void LWFGameScene::onExit()
{
    CCLayer::onExit();
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GameScene/gameSceneImages.plist");
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
}

#pragma mark - initialiseVariables
void LWFGameScene::initialiseVariables()
{
    //used to check whether space is found at the begging of each line in emptyBox 
    isSpaceFoundInBeggining=false;
    
    isGameOver=false;
    
    //keyBoard
    keyBoardLettersArr = CCArray::create();
    keyBoardLettersArr->retain();
    
    //answer array
    alphabetArray=CCArray::create();
    alphabetArray->retain();
    
    //Empty Box
    this->emptyBoxArr = CCArray::create();
    this->emptyBoxArr->retain();
    

    seconds =10;

    this->canStartTheGame=false;
    this->isDragingAnyKeyboardAlphabet = false;
    this->isPlacedAlphabet=false;
    
    score = 0;
    this->correctPlacedAlphabets=0;
    this->lyricsCompletedBonus=0;
    

    this->isDoneScreenAdded=false;
    
    this->startIndex=0;
    this->placedCharactersInaLine=0;
    this->noOfWordsCompleted=0;
    this->keyBoardCharacterCount=0;
    
    if(LWFDataManager::sharedManager()->roundCount%2==0)
    {
        LWFDataManager::sharedManager()->opponentScore=0;
    }
    
    lettersDragged = CCLabelTTF::create("", "Arial",17);
    lettersDragged->setPosition(ccp(235,335));
    this->addChild(lettersDragged,40);
    
    wordCompleted= CCLabelTTF::create("", "Arial",17);
    wordCompleted->setPosition(ccp(235,290));
    this->addChild(wordCompleted,40);
    
    lyricsCompletedBonusLabel= CCLabelTTF::create("", "Arial",17);
    lyricsCompletedBonusLabel->setPosition(ccp(225,245));
    this->addChild(lyricsCompletedBonusLabel,40);
    
    
    scoreLabel= CCLabelTTF::create("", "Arial",17);
    scoreLabel->setPosition(ccp(230,135));
    this->addChild(scoreLabel,40);
    
 
    
}

#pragma mark - initialiseFunc
void LWFGameScene::initialiseFunc()
{
    this->initialiseVariables();
    this->addAnswertToArray();
    this->findSpacePositionInAnswer();
    this->checkForKeyboardUILayout();
    this->checkForEmptyBoxLayout();
    this->checkForQuestionLayOut();
    this->initialiseUI();
    this->addEmptyBox();
    this->addKeyBoard();
    this->loadTheQuestion();
    this->playSongFunc();
    
}
#pragma mark - playSong
void  LWFGameScene::playSongFunc()
{
    LWFObjectiveCCalls::playSong();
    canStartTheGame=true;
    playButton->setEnabled(false);
    this->schedule(schedule_selector(LWFGameScene::startTimerFunc),1);

}

#pragma mark - adding contentsOfAnsToArray
void LWFGameScene::addAnswertToArray()
{
    emptyBoxCharacters = LWFDataManager::sharedManager()->answer;
      for(int i=0;i<emptyBoxCharacters.length();i++)
    {
       
        LWFAlphabet *alphabet= new LWFAlphabet();
        alphabet->alphabet= emptyBoxCharacters.at(i);
        alphabet->isHint=false;
        
        alphabetArray->addObject(alphabet);
        
      }
   
}

#pragma mark - initialiseUI
void LWFGameScene::initialiseUI()
{
    CCSize winsize=CCDirector::sharedDirector()->getWinSize();
    
    CCSprite *bgSpr = CCSprite::create("GameScene/GameScreenB-large-tiles-X2.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    CCSprite *topBarSpr = CCSprite::createWithSpriteFrameName("topbar.png");
    topBarSpr->setScaleY(1.1);
    topBarSpr->setPosition(ccp(159,461));
    this->addChild(topBarSpr);
    
    CCSprite *playbgSpr = CCSprite::createWithSpriteFrameName("play_bg.png");
    playbgSpr->setPosition(ccp(158,410));
    this->addChild(playbgSpr);
    
    CCLabelTTF *scoreLabel = CCLabelTTF::create("SCORE", "Arial", 11);
    scoreLabel->setPosition(ccp(85, 400));
    this->addChild(scoreLabel);
    
    CCLabelTTF *opponentScoreLabel = CCLabelTTF::create("OPPONENT", "Arial", 11);
    opponentScoreLabel->setPosition(ccp(230, 400));
    this->addChild(opponentScoreLabel);
    
    pointLabel = CCLabelTTF::create("", "Arial",15);
    pointLabel->setPosition(ccp(85,415));
    this->addChild(pointLabel);
    
    sprintf(LWFDataManager::sharedManager()->scoreCount,"%d", score);
    pointLabel->setString(LWFDataManager::sharedManager()->scoreCount);
    
    char opponeScor[50]={};
    opponentScoreLabel=CCLabelTTF::create("", "Arial", 15);
    opponentScoreLabel->setPosition(ccp(230,415));
    this->addChild(opponentScoreLabel);
    
    sprintf(opponeScor,"%d", LWFDataManager::sharedManager()->opponentScore);
    opponentScoreLabel->setString(opponeScor);
    
    CCSprite *playButtonNormalSpr = CCSprite::createWithSpriteFrameName("play.png");
    CCSprite *playButtonSelectedSpr = CCSprite::createWithSpriteFrameName("play.png");
    
    CCSprite *disabledSpr = CCSprite::createWithSpriteFrameName("pause.png");
    
    playButton = CCMenuItemSprite::create(playButtonNormalSpr, playButtonSelectedSpr, disabledSpr,this, menu_selector(LWFGameScene::playFunc));
    playButton->setPosition(CCPointMake(150,410));
    
    CCSprite *doneButtonNormalSpr = CCSprite::create("GameScene/skip_bt.png");
    CCSprite *doneButtonSelectedSpr = CCSprite::create("GameScene/skip_bt.png");
    
    skipButton = CCMenuItemSprite::create(doneButtonNormalSpr, doneButtonSelectedSpr, this, menu_selector(LWFGameScene::skipFunc));
    skipButton->setPosition(CCPointMake(285,462));
    
    CCSprite *menuButtonButtonNormalSpr = CCSprite::createWithSpriteFrameName("menu_bt.png");
    CCSprite *menuButtonButtonSelectedSpr = CCSprite::createWithSpriteFrameName("menu_bt.png");
    
    menuButton = CCMenuItemSprite::create(menuButtonButtonNormalSpr, menuButtonButtonSelectedSpr, this, menu_selector(LWFGameScene::menuFunc));
    menuButton->setPosition(CCPointMake(36,462));
    menuButton->setEnabled(true);
    
    CCSprite *hintButtonButtonNormalSpr = CCSprite::create("GameScene/hint-3.png");
    CCSprite *hintButtonButtonSelectedSpr = CCSprite::create("GameScene/hint-3.png");
    
     hintButton= CCMenuItemSprite::create(hintButtonButtonNormalSpr, hintButtonButtonSelectedSpr, this, menu_selector(LWFGameScene::generateRandomHint));
    hintButton->setPosition(CCPointMake(294,411));
    hintButton->setEnabled(true);

    
    CCMenu *tempMenu = CCMenu::create(menuButton,playButton,skipButton,hintButton, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
    //label for displaying timer
    timerLabel=CCLabelTTF::create("","Arial",16);
    this->addChild(timerLabel,5);
    timerLabel->setPosition(ccp(150,400));
    
    char time[100]={};
    sprintf(time,"%d",seconds);
    timerLabel->setString(time);
}

#pragma mark - findsSpacepositions
//this function loads all space position inside  locationsOfSpaceInAnswer array
void LWFGameScene::findSpacePositionInAnswer()
{
    char findIt = ' ';
    //used to find space in answer
    locationsOfSpaceInAnswer = findLocation(LWFDataManager::sharedManager()->answer,findIt);
}

#pragma mark - EmptyBox
void LWFGameScene::checkForEmptyBoxLayout()
{
    emptyBoxLineNo=1;
    if (alphabetArray->count()<=33)
    {
        emptyBoxXval=20;
        emptyBoxYval=260;
        xStartVal=20;
        spaceBtnTwoemptyBoxHorizontally=28;
        spaceBtnTwoemptyBoxVertically=40;
        emptyBoxScaleVal=1.0;
        noOfemptyBoxInLine=11;
        ySpaceValInitial=0;
        ySpaceValAfter=spaceBtnTwoemptyBoxVertically;
       
    }
    
    else if(alphabetArray->count()<=48)
    {
        emptyBoxXval=16;
        xStartVal=16;
        emptyBoxYval=266;  //270
        spaceBtnTwoemptyBoxHorizontally=26;
        spaceBtnTwoemptyBoxVertically=30;
        emptyBoxScaleVal=0.8;
        noOfemptyBoxInLine=12;
        ySpaceValInitial=0;
         ySpaceValAfter=spaceBtnTwoemptyBoxVertically;

    }
    
}

void LWFGameScene::addEmptyBox()
{
    CCPoint pos;
  
    pos.x=emptyBoxXval;
    pos.y=emptyBoxYval;
    placedEmptyBoxCount=0;
 
    for(int i=0;i<alphabetArray->count();i++)
    {
        
        LWFAlphabet *alphabet =(LWFAlphabet*)alphabetArray->objectAtIndex(i);
        
        emptyBoxSpr = LWFEmptyBox::createWithSpriteFrameName("emptybox.png");
        

        pos=emptyBoxSpr->getEmptyBoxPosition(placedEmptyBoxCount,pos.x,pos.y,spaceBtnTwoemptyBoxHorizontally,spaceBtnTwoemptyBoxVertically,noOfemptyBoxInLine*emptyBoxLineNo,xStartVal);
      
     
   
        if(placedEmptyBoxCount==noOfemptyBoxInLine*emptyBoxLineNo)
        {
            emptyBoxLineNo=emptyBoxLineNo+1;
        }
       placedEmptyBoxCount++;
        if(this->checkWhetherSpaceIsPresentAtIndex(i))
        {
            //if space is found at beggining then place next emptybox to beginning
            
            if(pos.x==xStartVal)
            {
                this->emptyBoxArr->addObject(emptyBoxSpr);
                pos.x=xStartVal;
                placedEmptyBoxCount= placedEmptyBoxCount-1;
                spaceBtnTwoemptyBoxVertically=ySpaceValInitial;
                continue;
                
            }
            else
            {
                emptyBoxSpr->setVisible(false);
                spaceBtnTwoemptyBoxVertically=ySpaceValAfter;
                isSpaceFoundInBeggining=false;
            }
        }
        
        emptyBoxSpr->setPosition(pos);
        emptyBoxSpr->setScale(emptyBoxScaleVal);
        pos.x=pos.x+spaceBtnTwoemptyBoxHorizontally;
        
        //initially FALSE..true when alphabet is placed to emptyBox
        emptyBoxSpr->isSolved=false;
        //true when word is formed
        emptyBoxSpr->isWordGroupFormed=false;
        this->addChild(emptyBoxSpr);
        if(!isSpaceFoundInBeggining)
        {
            emptyBoxSpr->alphabet=alphabet->alphabet;
           
        }
        
        this->emptyBoxArr->addObject(emptyBoxSpr);
       
        
        emptyBoxSpr->isHintBox =false;
        isSpaceFoundInBeggining=false;
        
    }
    
}

void LWFGameScene::addAlphabetToEmptyBox(LWFKeyboardBTN *currentDraggedKeyboardAlphabet, LWFEmptyBox *emptyBox)
{
    this->currentDraggedKeyboardAlphabet->setPosition(emptyBox->getPosition());
    this->keyBoardLettersArr->removeObject(this->currentDraggedKeyboardAlphabet);
    
    emptyBox->isSolved=true;
    emptyBox->canAddAlphabet=false;
    
    this->startIndex=0;
    this->placedCharacterCount=0;
    
    this->isPlacedAlphabet=true;
    this->canDragTheAlphabet=true;
    
    correctPlacedAlphabets++;
    this->addScoreAfterEachAlphabetSucessfullyPlacing();
    this->checkForkeyBoardArrayEmpty();
    this->checkForWordComplete();
    
    this->currentDraggedKeyboardAlphabet = NULL;
    
}

#pragma mark - Hint
void  LWFGameScene::generateRandomHint()
{
//    if(keyBoardLettersArr->count()==0)
//    {
//        hintButton->setEnabled(false);
//        this->doneFunc();
//        return;
//    }

    int rand=getRandomNumberBetween(0,keyBoardLettersArr->count()-1);
    LWFKeyboardBTN *btn = (LWFKeyboardBTN*)keyBoardLettersArr->objectAtIndex(rand);
    std::string key=btn->alphabet;
    
    for(int i=0;i<emptyBoxArr->count();i++)
    {
        LWFEmptyBox *emp =(LWFEmptyBox*)emptyBoxArr->objectAtIndex(i);
        if(emp->alphabet==key)
        {
            if(!emp->isSolved)
            {
                if(canStartTheGame)
                {
                    //   this->addAlphabetToEmptyBox(currentDraggedKeyboardAlphabet, aEmptyBoxSpr);
                    this->checkForWordComplete();
                    this->addScoreAfterEachAlphabetSucessfullyPlacing();
                    correctPlacedAlphabets++;
                    hintButton->setEnabled(false);
                    emp->canAddAlphabet=false;
                    emp->isSolved=true;
                    CCMoveTo *move =CCMoveTo::create(.1, emp->getPosition());
                    btn->runAction(move);
                    btn->setZOrder(30);
                    btn->setScale(emptyBoxScaleVal);
                    keyBoardLettersArr->removeObject(btn);
                    
                    if(keyBoardLettersArr->count()==0)
                    {
                        hintButton->setEnabled(false);
                        this->doneFunc();
                        return;
                    }

                    
                    break;
                }
            }
        }
    }
}


#pragma mark - checkForSpaceInAnswer
bool LWFGameScene::checkWhetherSpaceIsPresentAtIndex(int indexVal)
{
    for(int i=0;i<locationsOfSpaceInAnswer.capacity();i++)
    {
        if(locationsOfSpaceInAnswer[i]==indexVal)
        {
            return true;
        }
    }
    return false;
}

void LWFGameScene::checkForWordComplete()
{
    
    for(int i=0;i<=locationsOfSpaceInAnswer.capacity();i++)
    {
        this->placedCharacterCount=0;
        //for word after last space
        if(i==locationsOfSpaceInAnswer.capacity())
        {
            this->checkForWordCompleteFromStartIndexToEndIndex(startIndex,emptyBoxArr->count());
        }
        else
        {
          
            this->checkForWordCompleteFromStartIndexToEndIndex(startIndex, locationsOfSpaceInAnswer[i]);
            
        }
        
    }
    
}


void LWFGameScene::checkForWordCompleteFromStartIndexToEndIndex(int startVal,int endVal)
{
    
    for(int i=startVal;i<endVal;i++)
    {
     
        LWFEmptyBox *aEmptyBoxSpr = (LWFEmptyBox *)emptyBoxArr->objectAtIndex(i);
        
        if(aEmptyBoxSpr->isSolved)
        {
            
            if(!aEmptyBoxSpr->isWordGroupFormed)
                this->placedCharacterCount++;
            if(this->placedCharacterCount==endVal-startVal)
            {
                 this->noOfWordsCompleted++;
                this->addScoreAfterCompletingEachWord();
               
                for(int i=startVal;i<endVal;i++)
                {
                    LWFEmptyBox *aEmptyBoxSpr = (LWFEmptyBox *)emptyBoxArr->objectAtIndex(i);
                    aEmptyBoxSpr->isWordGroupFormed=true;
                }
                break;
            }
        }
        
        else
        {
            break;
        }
    }
    //to start with Next word
    startIndex=endVal+1;
}




#pragma mark - score
void LWFGameScene::addScoreAfterCompletingEachWord()
{
    score=   score+10;
    sprintf(LWFDataManager::sharedManager()->scoreCount,"%d",  score);
    pointLabel->setString(LWFDataManager::sharedManager()->scoreCount);
    
}

void LWFGameScene::addScoreAfterEachAlphabetSucessfullyPlacing()
{
    score = score+5;
    sprintf(LWFDataManager::sharedManager()->scoreCount,"%d",score);
    pointLabel->setString(LWFDataManager::sharedManager()->scoreCount);
}

void LWFGameScene::addScoreAfterGameCompletion()
{
    score=   score +lyricsCompletedBonus;
    CCLOG("%d",score);
    sprintf(LWFDataManager::sharedManager()->scoreCount,"%d",score);
    pointLabel->setString(LWFDataManager::sharedManager()->scoreCount);
    
}


#pragma MARK - Keyboard
//initialise the value for keyboard based on character count
void LWFGameScene::checkForKeyboardUILayout()
{
    int keyBoardCharacter=this->numberOfCharactersInkeyBoard();

    if(keyBoardCharacter<=32)
    {
        keyBoardXval=21;
        keyBoardYval=168;
        keyboardScaleVal=1.0;
        noOfCharactersInLine=8;
        spaceBtnTwoCharactersHorizontally=40;
        spaceBtnTwoCharactersVertically=37;
        alphabetAllignmentVal=0;
    }
    else  if(keyBoardCharacter>=33 && keyBoardCharacter<=45)
    {
        keyBoardXval=20;
        keyBoardYval=160;
        keyboardScaleVal=.75;
        noOfCharactersInLine=9;
        spaceBtnTwoCharactersHorizontally=35;
        spaceBtnTwoCharactersVertically=28;
        alphabetAllignmentVal=5;
    }
    else  if(keyBoardCharacter>=46 && keyBoardCharacter<=60)
    {
        keyBoardXval=17;
        keyBoardYval=164;
        keyboardScaleVal=.72;
        noOfCharactersInLine=10;
        spaceBtnTwoCharactersHorizontally=32;
        spaceBtnTwoCharactersVertically=25;
        alphabetAllignmentVal=9;
    }
}

void LWFGameScene::addKeyBoard()
{
    //Keyboard Alphabets
    std::string pszPathOne = CCFileUtils::sharedFileUtils()->fullPathForFilename("LWFKeyboard.plist");
    CCDictionary *keyboardAlphabetsDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPathOne.c_str());
     CCDictionary *keyBoardAlpahbets=CCDictionary::createWithDictionary((CCDictionary*)keyboardAlphabetsDict->valueForKey("KeyboardItems"));

    
    int newLineStartIndex=0;
    int lineNo=0;
    
    CCPoint keyBoardPos;
    keyBoardPos.x=keyBoardXval;
    keyBoardPos.y=keyBoardYval;
    
    //shuffle array;
    int no_to_randomize[100];
    for (int i = 0 ; i <alphabetArray->count(); i++)
    {
        no_to_randomize[i] = i;
    }
    store_randomArray  =this->shuffleArray(no_to_randomize,alphabetArray->count()-1);
    
    std::string keyBoardAlphabet[100];
    for(int i=0;i<alphabetArray->count();i++)
    {
        int randomIndex = this->store_randomArray[i];
        if(this->checkWhetherSpaceIsPresentAtIndex(randomIndex))
        {
            continue;
        }
        LWFAlphabet *alphabet =(LWFAlphabet*)alphabetArray->objectAtIndex(randomIndex);
        keyBoardAlphabet[i]=alphabet->alphabet;
        
        CCDictionary *dicContents= (CCDictionary*)keyBoardAlpahbets->valueForKey(keyBoardAlphabet[i].c_str());
        
        
        const char *imageName= (const char*)dicContents->valueForKey("alphabetImageName")->getCString();
        
        
        LWFKeyboardBTN *keyBoardBtnSpr = LWFKeyboardBTN::createWithSpriteFrameName(imageName);
        keyBoardBtnSpr->alphabet = alphabet->alphabet;
        alphabet->isHint=false;
        
        keyBoardBtnSpr->setScale(keyboardScaleVal);
        keyBoardPos=keyBoardBtnSpr->getEmptyBoxPosition(keyBoardCharacterCount, keyBoardPos.x, keyBoardPos.y,spaceBtnTwoCharactersHorizontally,spaceBtnTwoCharactersVertically,noOfCharactersInLine*lineNo);
        
        
        this->addChild(keyBoardBtnSpr,10);
        this->keyBoardLettersArr->addObject(keyBoardBtnSpr);
        
        
        keyBoardBtnSpr->setPosition(keyBoardPos);
        keyBoardPos.x=keyBoardPos.x+spaceBtnTwoCharactersHorizontally;
        
        keyBoardCharacterCount++;
        placedCharactersInaLine++;
        
        //used to check for keyBoardLayout
        if(placedCharactersInaLine==noOfCharactersInLine)
        {
            
            placedCharactersInaLine=0;
            lineNo=lineNo+1;
            newLineStartIndex=keyBoardCharacterCount;
            
        }
        
    }
    
    
    if(keyBoardLettersArr->count()==keyBoardCharacterCount)
    {
        if(placedCharactersInaLine!=noOfCharactersInLine)
        {
            //to adjust the keyboard to the centre
            this->placeAlphabetAtTheCentreOfLine(newLineStartIndex);
        }
    }
    CC_SAFE_RELEASE_NULL(keyboardAlphabetsDict);
}

int LWFGameScene::numberOfCharactersInkeyBoard()
{
    int charcterCount=0;
    for(int i=0;i<alphabetArray->count();i++)
    {
        LWFAlphabet *alphabet =(LWFAlphabet*)alphabetArray->objectAtIndex(i);
        if((alphabet->isHint==true) || ( this->checkWhetherSpaceIsPresentAtIndex(i)))
        {
            continue;
        }
        charcterCount++;
    }
    return charcterCount;
    
}

//
void LWFGameScene::placeAlphabetAtTheCentreOfLine(int startVal)
{
    int totalContentSize=0;
    float contentSpace=10;
    
    
    CCSize winsize =CCDirector::sharedDirector()->getWinSize();
    
    for(int i=startVal;i<keyBoardLettersArr->count();i++)
    {
        LWFKeyboardBTN *keyBoardAlphabet =(LWFKeyboardBTN*)keyBoardLettersArr->objectAtIndex(i);
        totalContentSize += contentSpace+ keyBoardAlphabet->getContentSize().width-keyboardScaleVal*alphabetAllignmentVal;
    }
    
    float diffWidthH = (winsize.width-totalContentSize)/2;
    
    for(int i=startVal;i<keyBoardLettersArr->count();i++)
    {
        LWFKeyboardBTN *keyBoardAlphabet =(LWFKeyboardBTN*)keyBoardLettersArr->objectAtIndex(i);
        keyBoardAlphabet->setPosition(ccp(keyBoardAlphabet->getPositionX()+diffWidthH,keyBoardAlphabet->getPositionY()));
        
    }
}
void LWFGameScene::checkForkeyBoardArrayEmpty()
{
    if(keyBoardLettersArr->count()==0)
    {
        this->doneFunc();
    }
}

#pragma mark - shuffle

int * LWFGameScene ::shuffleArray(int num[100],int count) {
    
    //variables used for swapping
    int temp;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i <= count; i++){
        
        rand_no = arc4random() % count;
        temp = num[rand_no];
        num[rand_no]= num[i];
        num[i] = temp;
    }
    return num;
    
}



#pragma mark - loadTheQuestion
void LWFGameScene::checkForQuestionLayOut()
{
//    LWFDataManager::sharedManager()->selectedSong= "HHHHHHHHH HHYRT YHUGTYRDEGG JGFTDDEEQQA BYFGDRSER VTDE BTFOP BBBNNN BVCC CFTRT VTFRR NHH VDS NHTR NTYFE GVETE NDEGFCE BFERTFTRRE BYGERT NGFYR BBRG NJI NMKLPO MKLOPPP NMPO";

    std::string question =LWFDataManager::sharedManager()->selectedSong.c_str();
    CCLOG("%d=question.length",question.length());
    if(question.length()<=110)
    {
        questionFontSize=17;
        labelXval=300;
        labelYval=70;
        labelXpos=160;
        labelYpos=325;
    }
//    else if(question.length()<=100)
//    {
//        questionFontSize=16;
//        labelXval=305;
//        labelYval=86;
//        labelXpos=160;
//        labelYpos=325;
//
//    }
    else if(question.length()<=170)
    {
        questionFontSize=15;
        labelXval=305;
        labelYval=86;
        labelXpos=160;
        labelYpos=325;
        
    }
}

void LWFGameScene::loadTheQuestion()
{
    CCLabelTTF *selectedSongLabel;
    
    selectedSongLabel=CCLabelTTF::create(LWFDataManager::sharedManager()->selectedSong.c_str(), "Arial", questionFontSize, CCSizeMake(labelXval, labelYval), kCCTextAlignmentCenter);

    selectedSongLabel->setPosition(ccp(labelXpos,labelYpos)); //315
    selectedSongLabel->setColor(ccc3(0,162,255));
    this->addChild(selectedSongLabel);
}

#pragma mark - doneFunc
void LWFGameScene::backBtnAction()
{
    if(isDoneScreenAdded)
    {
    doneButon->setEnabled(false);
    }
    LWFObjectiveCCalls::stopSong();
   LWFDataManager::sharedManager()->answer.clear();
  CCDirector::sharedDirector()->replaceScene(LWFSubmitChallenge::scene());
}
#pragma mark - menuFunc
void LWFGameScene::menuFunc()
{
    LWFObjectiveCCalls::stopSong();

    isGameOver=true;
    canStartTheGame=false;
    skipButton->setEnabled(false);
    hintButton->setEnabled(false);
    this->unscheduleAllSelectors();
    LWFDataManager::sharedManager()->answer.clear();

       this->addDoneScreen();
}

#pragma mark - skipFunc
void LWFGameScene::skipFunc()
{
    if(LWFDataManager::sharedManager()->canPressSkipButton && seconds>=75)
    {
        
        LWFObjectiveCCalls::stopSong();
        LWFDataManager::sharedManager()->answer.clear();
        LWFDataManager::sharedManager()->canPressSkipButton=false;
        CCDirector::sharedDirector()->replaceScene(LWFQuestionLoadingscene::scene());
    }
}

#pragma mark - doneFunc
void LWFGameScene::doneFunc()
{
    skipButton->setEnabled(false);
    canStartTheGame=false;
    LWFObjectiveCCalls::stopSong();
    if(keyBoardLettersArr->count()==0)
    {
        
     
         lyricsCompletedBonus=25;
        this->addScoreAfterGameCompletion();
        CCLabelTTF   *correctAns = CCLabelTTF::create("CORRECT ANSWER", "Arial", 30);
        correctAns->setPosition(ccp(160,50));
        correctAns->setColor(ccc3(245,230,81));
        this->addChild(correctAns);
        skipButton->setEnabled(false);
        this->unscheduleAllSelectors();
        
        this->gameOver();
        
    }
    
    else
    {
        CCLabelTTF   *wrongAns = CCLabelTTF::create("WRONG ANSWER", "Arial", 30);
        wrongAns->setPosition(ccp(150,20));
        wrongAns->setColor(ccc3(245,230,81));
        this->addChild(wrongAns);
        skipButton->setEnabled(false);
        this->unscheduleAllSelectors();
        
        this->gameOver();
        
    }
    
}

void LWFGameScene::gameOver()
{
    isGameOver=true;
    canStartTheGame=false;
     hintButton->setEnabled(false);
    LWFObjectiveCCalls::stopSong();
    LWFDataManager::sharedManager()->answer.clear();
    //15
    CCSequence *actionAddRelicFallDust = CCSequence::create(CCDelayTime::create(2.0),CCCallFuncN::create(this, callfuncN_selector(LWFGameScene::addDoneScreen)),NULL);
//                                                            ,CCDelayTime::create(3.0), CCCallFuncN::create(this, callfuncN_selector(LWFGameScene::backBtnAction)),NULL);
 this->runAction(actionAddRelicFallDust);
}

void LWFGameScene::addDoneScreen()
{
    CCSize winsize=CCDirector::sharedDirector()->getWinSize();
    
    CCSprite *bgSpr = CCSprite::create("DonePage/popup-2.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,31);
    
    CCSprite *doneButtonButtonNormalSpr = CCSprite::create("DonePage/done-bt.png");
    CCSprite *doneButtonButtonselSpr = CCSprite::create("DonePage/done-bt.png");
    
    doneButon= CCMenuItemSprite::create(doneButtonButtonNormalSpr, doneButtonButtonselSpr, this, menu_selector(LWFGameScene::backBtnAction));
    doneButon->setPosition(CCPointMake(160,70));
    doneButon->setEnabled(true);
    
    

    sprintf(LWFDataManager::sharedManager()->scoreCount,"%d",  score);
    pointLabel->setString(LWFDataManager::sharedManager()->scoreCount);
    
    CCMenu *tempMenu = CCMenu::create(doneButon, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,40);
    
    isDoneScreenAdded=true;
    
    menuButton->setEnabled(false);
    skipButton->setEnabled(false);

    char a[100]={};
    sprintf(a, "%d * 5",this->correctPlacedAlphabets);
    lettersDragged->setString(a);
    
    char b[100]={};
    sprintf(b,"%d * 10",this->noOfWordsCompleted);
    wordCompleted->setString(b);
    
    char d[100]={};
    sprintf(d,"%d",lyricsCompletedBonus);
    lyricsCompletedBonusLabel->setString(d);
    
    
    char c[100]={};
    sprintf(c,"%d", this->score);
    scoreLabel->setString(c);
    
    
//    char d[100]={};
//    sprintf(d,"%d",this->seconds);
//    timeBonusLabel->setString(d);
    
//    CCSequence *actionAddRelicFallDust = CCSequence::create(CCDelayTime::create(3.0),CCCallFuncN::create(this, callfuncN_selector(LWFGameScene::backBtnAction)),NULL);                                                       
//    this->runAction(actionAddRelicFallDust);

  
}

#pragma mark - getStringWithOutSpace
std::string LWFGameScene::getStringWithOutSpace(std::string answerWithSpace)
{
    std::string::iterator newEnd = std::remove_if( answerWithSpace.begin(), answerWithSpace.end(), isspace );
    std::string answerWithOutSpace= std::string(answerWithSpace.begin(), newEnd);
    
    return answerWithOutSpace;
}


#pragma mark - playFunc
void LWFGameScene::playFunc()
{
    
    //   LWFObjectiveCCalls::playSong();
    
    //    const char  *selectedSongName= (const char *)selectedSongDict->valueForKey("mp3Name")->getCString();
    //    char songName[100]={};
    //    sprintf(songName, "Sounds/%s",selectedSongName);
    //    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(songName,false);
    //
    //  canStartTheGame=true;
    // playButton->setEnabled(false);
    // this->schedule(schedule_selector(LWFGameScene::startTimerFunc),1);
}

#pragma mark - TimerFunc

void LWFGameScene::startTimerFunc(CCTime dt)
{
    seconds--;
    if(seconds==0)
    {
        if(keyBoardLettersArr->count()!=0)
        {
        this->unscheduleAllSelectors();
            lyricsCompletedBonus=0;
        this->placingAllkeyBoardAlphabetToEmptyBoxAfterTimerExpires();
        }
        else
        {
             this->gameOver();
        }
   
      }
    char time[100]={};
    sprintf(time,"%d",seconds);
    timerLabel->setString(time);
}

void LWFGameScene::placingAllkeyBoardAlphabetToEmptyBoxAfterTimerExpires()
{
    CCLOG("%d=key",keyBoardLettersArr->count());
    while(keyBoardLettersArr->count()>0)
    {
        LWFKeyboardBTN *btn = (LWFKeyboardBTN*)keyBoardLettersArr->objectAtIndex(0);
        std::string key=btn->alphabet;
        for(int i=0;i<emptyBoxArr->count();i++)
        {
            
            LWFEmptyBox *emp =(LWFEmptyBox*)emptyBoxArr->objectAtIndex(i);
            if(emp->alphabet==key)
            {
                if(!emp->isSolved)
                {
                    if(canStartTheGame)
                    {
                        emp->canAddAlphabet=false;
                        emp->isSolved=true;
                        CCMoveTo *move =CCMoveTo::create(.1, emp->getPosition());
                        btn->runAction(move);
                        btn->setZOrder(30);
                        btn->setScale(emptyBoxScaleVal);
                        keyBoardLettersArr->removeObject(btn);
                        CCLog("keyBoardArrayCount=%d",keyBoardLettersArr->count());
                        if(keyBoardLettersArr->count()==0)
                        {
                            this->currentDraggedKeyboardAlphabet=NULL;
                            isGameOver=true;
                            this->gameOver();
                        }

                        break;
                    }
                }
            }
        }
    }
    
}

#pragma mark - Touches

void LWFGameScene::ccTouchesBegan(CCSet* touches,CCEvent* event)
{
    if(isGameOver)
    {
        return;
    }
    if(this->canStartTheGame==false)
    {
        return;
    }
     if(this->isDoneScreenAdded)
    {
        return;
    }
    this->currentDraggedKeyboardAlphabet = NULL;
    
    CCSetIterator it;
    CCTouch* touch;
    
    for( it = touches->begin(); it != touches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        CCObject* aKeyboardAlphabetObj = NULL;
        CCARRAY_FOREACH(this->keyBoardLettersArr, aKeyboardAlphabetObj)
        {
            LWFKeyboardBTN *aKeyboardAlphabetSpr = (LWFKeyboardBTN *)aKeyboardAlphabetObj;
            if(this->canDragTheAlphabet)
            {
                if (aKeyboardAlphabetSpr->boundingBox().containsPoint(location))
                {
                    this->isDragingAnyKeyboardAlphabet = true;
                    this->currentDraggedKeyboardAlphabet=aKeyboardAlphabetSpr;
                    this->currentDraggedKeyboardAlphabet->setScale(1.2);
                    originalKeyPosition=this->currentDraggedKeyboardAlphabet->getPosition();
                    this->canDragTheAlphabet=false;
                    break;
                }
            }
        }
    }
}

void LWFGameScene::ccTouchesMoved(CCSet* touches,CCEvent *event)
{
    CCSetIterator it;
    CCTouch* touch;
    
    if(isGameOver)
    {
        return;
    }

    for( it = touches->begin(); it != touches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        if(this->isDragingAnyKeyboardAlphabet)
        {
            if(!isGameOver)
            {
            this->currentDraggedKeyboardAlphabet->setZOrder(30);
            this->currentDraggedKeyboardAlphabet->setPosition(location);
            }
        }
        
    }
}


void LWFGameScene::ccTouchesEnded(CCSet* touches, CCEvent* event)
{
    this-> isPlacedAlphabet=false;
    if(this->canStartTheGame==false)
    {
        return;
    }
    if(isGameOver)
    {
        return;
    }

    CCSetIterator it;
    CCTouch* touch;
    
    for( it = touches->begin(); it != touches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        
        //To Add a Charater to empty Box
        if(this->isDragingAnyKeyboardAlphabet)
        {
            CCObject* childSpriteObj = NULL;
            CCARRAY_FOREACH(this->emptyBoxArr, childSpriteObj)
            {
                LWFEmptyBox *aEmptyBoxSpr = (LWFEmptyBox *)childSpriteObj;
                float distance = ccpDistance(aEmptyBoxSpr->getPosition(), location);
                if(distance<=20)
                {
                    if((aEmptyBoxSpr->alphabet.c_str()==currentDraggedKeyboardAlphabet->alphabet )&& (aEmptyBoxSpr->canAddAlphabet )&& (!aEmptyBoxSpr->isHintBox))
                    {
                        this->currentDraggedKeyboardAlphabet->setScale(emptyBoxScaleVal);
                        this->addAlphabetToEmptyBox(currentDraggedKeyboardAlphabet, aEmptyBoxSpr);
                        break;
                    }
                    
                    else
                    {
                        
                        this-> isPlacedAlphabet=false;
                        
                    }
                }
            }
            
            if(!isPlacedAlphabet)
            {
              if(!seconds<=1)
              {
                CCMoveTo *move = CCMoveTo::create(.2, originalKeyPosition);
                currentDraggedKeyboardAlphabet->runAction(move);
                this->currentDraggedKeyboardAlphabet->setScale(keyboardScaleVal);
                CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(.2),CCCallFunc::create(this, callfunc_selector(LWFGameScene::canDragAlphabetFunc)),NULL);
                this->runAction(seq);
              }
                
            }
        }
    }
    
    this->currentDraggedKeyboardAlphabet = NULL;
    this->isDragingAnyKeyboardAlphabet = false;
}

void LWFGameScene::canDragAlphabetFunc()
{
    this->canDragTheAlphabet=true;
}


void LWFGameScene::ccTouchesCancelled(CCSet* touches, CCEvent* event)
{
    this->currentDraggedKeyboardAlphabet->removeFromParentAndCleanup(true);
    this->currentDraggedKeyboardAlphabet = NULL;
    this->isDragingAnyKeyboardAlphabet = false;
}


#pragma mark - Utility
//Returns the array of charatcer locations
std::vector<int> LWFGameScene::findLocation(std::string sample, char findIt)
{
    std::vector<int> characterLocations;
    for(int i =0; i < sample.size(); i++)
        if(sample[i] == findIt)
            characterLocations.push_back(i);
    
    return characterLocations;
}

int LWFGameScene::getRandomNumberBetween(int min, int max)
{
    int toNumber = max + 1;
    int fromNumber = min;
    
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    
    return randomNumber;
}
#pragma mark - destructor
LWFGameScene::~LWFGameScene()
{
    CC_SAFE_RELEASE_NULL(keyBoardLettersArr);
    CC_SAFE_RELEASE_NULL(emptyBoxArr);
    //  CC_SAFE_RELEASE_NULL(hintArray);

    
}
