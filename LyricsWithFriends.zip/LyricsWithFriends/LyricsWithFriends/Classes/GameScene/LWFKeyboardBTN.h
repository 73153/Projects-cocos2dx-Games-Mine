//
//  LWFKeyboardBTN.h
//  LyricsWithFriends
//
//  Created by Deepthi on 20/05/13.
//
//

#ifndef LyricsWithFriends_LWFKeyboardBTN_h
#define LyricsWithFriends_LWFKeyboardBTN_h

#include "cocos2d.h"

USING_NS_CC;

class LWFKeyboardBTN:public cocos2d::CCSprite
{
public:
    LWFKeyboardBTN();
    ~ LWFKeyboardBTN();
    
    static LWFKeyboardBTN* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static LWFKeyboardBTN* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    
    std::string alphabet;
    std::string alphabetImageName;
    
    bool isHintPre;
    
    CCPoint getEmptyBoxPosition(int keyBoardNo,int xVal,int yVal,int xSpace,int ySpace,int noOfCharacters);
   
};



#endif
