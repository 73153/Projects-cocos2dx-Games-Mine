//
//  LWFRegisterScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//

#ifndef LyricsWithFriends_LWFRegisterScene_h
#define LyricsWithFriends_LWFRegisterScene_h

#include "cocos2d.h"
#include "cocos-ext.h"

#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

class LWFRegisterScene:public cocos2d::CCLayer,public cocos2d::extension::CCEditBoxDelegate
{
    
public:
    
    LWFRegisterScene();
    ~LWFRegisterScene();
    static cocos2d::CCScene* scene();
    
    //editBox variables
    CCEditBox* mailIDTextField;
    CCEditBox* passWordTextField;
    CCEditBox* reEnterPasswordTextField;
    CCEditBox* userNameTextField;
    
    //editBox  functions(overridding delegate functions)
    virtual void editBoxEditingDidBegin(CCEditBox* editBox);
    virtual void editBoxEditingDidEnd(CCEditBox* editBox);
    virtual void editBoxTextChanged(CCEditBox* editBox, const std::string& text);
    virtual void editBoxReturn(CCEditBox* editBox);
    
    //edit box 
    void mailIDTextFieldFunc();
    void passWordTextFieldFunc();
    void reenterPassWordTextFieldFunc();
    void userNameTextFieldFunc();
    
    //initialise
    void intialiseUI();
    void initialiseFunctions();
   
     void goBackToLoginScene();
    
    //response
    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);
    
    std::string enteredUserName;
    std::string enteredEmailId;
    std::string enteredPassword;
    std::string reenteredPassword;
    
    CCLabelTTF *textFieldIndicationLbl;
   
    CCLabelTTF* labelStatusCode;
    CCLabelTTF* alertLbl;
    
    //check For internet
    bool    isNetWorkPresent;
    void checkForNetWork();
    void onNetworkCheckIsFinished(cocos2d::CCNode *sender, void *data);
    //requesr,response for register
    CCMenuItemSprite *registerItem;
    
    void onClickOfRegisterButton();
    void registerButtonFunc();
    void displayAlert(rapidjson::Document & document,std::string msg);

    
    CREATE_FUNC(LWFRegisterScene);


};


#endif
