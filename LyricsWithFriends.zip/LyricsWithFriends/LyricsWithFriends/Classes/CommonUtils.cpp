//
//  Header.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 15/11/12.
//
//
#include"CommonUtils.h"
#include "support/zip_support/unzip.h"
#include"cocos2d.h"
#include "SimpleAudioEngine.h"


//USING_NS_CC_EXT;
//#include"CCPointExtension.h"
#include <unistd.h>
#include <sys/stat.h>
#pragma mark - namespace cocos2d Functions
namespace  cocos2d {
    
    
    class CCRunwayDirector:public CCDirector
    {
        
    public:
        
        static CCRunwayDirector* sharedDirector(void)
        {
            return (CCRunwayDirector*)CCDirector::sharedDirector();
        }
        
        
        
        
        CCScene * getLastButOneScene()
        {
            assert(m_pobScenesStack->count()>1);
            return (CCScene *)m_pobScenesStack->objectAtIndex((m_pobScenesStack->count()-2));
            
        }
        
        void PopSceneWithTransition(CCScene * scene)
        {
            
            m_pobScenesStack->removeLastObject();
            
            
            m_pobScenesStack->replaceObjectAtIndex(m_pobScenesStack->count()-1, scene);
            CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(1, scene, ccWHITE));
            
            m_pNextScene = scene;
        }
        
        
        
        void PurgeBehindScenes()
        {
            
            
            CCScene * running = getRunningScene();
            running->retain();
            
            m_pobScenesStack->removeAllObjects();
            m_pobScenesStack->addObject(running);
            
            
            running->release();
        }
        
        
        
        
    };
    
    
    
    //shakthi
    void CCNodePlaceAtCenter(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(0.5, 0.5));
        node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, node->getParent()->getContentSize().height /2+offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    
    
    
    void CCNodePlaceAtBottom(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(0.5, 0));
        node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    
    void CCNodePlaceAtTop(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(0.5, 1));
        node->setPosition( ccp(node->getParent()->getContentSize().width / 2+offset.x, node->getParent()->getContentSize().height+offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    
    
    void CCNodePlaceAtRight(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(1, 0.5));
        node->setPosition( ccp(node->getParent()->getContentSize().width +offset.x,node->getParent()->getContentSize().height/ 2+ offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    
    
    
    void CCNodePlaceAtLeft(CCNode * node,CCPoint offset)
    {
        node->setAnchorPoint(ccp(0, 0.5));
        node->setPosition( ccp(offset.x,node->getParent()->getContentSize().height/ 2+ offset.y) );
        node->ignoreAnchorPointForPosition(false);
        
    }
    
    void CCReplaceScene(CCScene * scene)
    {
        CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5, scene));
    }
    
    void CCReplaceSceneWithFlair(CCScene * scene)
    {
        CCDirector::sharedDirector()->replaceScene(CCTransitionZoomFlipX::create(0.25, scene));
    }
    
    void CCReplaceSceneWithOutPushTransition(CCScene * scene)
    {
        CCDirector::sharedDirector()->replaceScene(scene);
        
        
    }
    
    void CCCommonBackScene(CCScene *scene){
        CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.25, scene));
        
    }
    
    
    
    void CCPopSceneWithOutPushTransition()
    {
        CCRunwayDirector::sharedDirector()->popScene();
        
    }
    
    
    void CCDropOtherScenes()
    {
        CCRunwayDirector::sharedDirector()->PurgeBehindScenes();
        
    }
    
    
    void CCPushScene(CCScene * scene)
    {
        
        CCDirector::sharedDirector()->pushScene(CCTransitionSlideInR::create(0.25, scene));
        
    }
    
    void CCPushSceneWithFlair(CCScene * scene)
    {
        
        CCDirector::sharedDirector()->pushScene(CCTransitionZoomFlipX::create(0.25, scene));
        
    }
    
    
    
    
    
    
    
    void CCPopScene()
    {
        CCRunwayDirector::sharedDirector()->PopSceneWithTransition(CCTransitionSlideInL::create(0.25, CCRunwayDirector::sharedDirector()->getLastButOneScene()));
        
    }
    
    void CCPopSceneWithFlair()
    {
        CCRunwayDirector::sharedDirector()->PopSceneWithTransition(CCTransitionZoomFlipX::create(0.25, CCRunwayDirector::sharedDirector()->getLastButOneScene()));
        
    }
    
    
    
    namespace {
        unsigned long
        hash(unsigned char *str)
        {
            unsigned long hash = 5381;
            int c;
            
            while ((c = *str++))
                hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
            
            return hash;
        }
    }
    
    int CCTag(const  char *str)
    {
        
        return hash((unsigned char *)str);
        
        
    }
    
    
    
    
#pragma mark - CCMenuItemCommon Functions
    void CCMenuItemCommon::activate()
    {
        //
        //#if TARGET_OS_IPHONE
        //        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(CCFileUtils::sharedFileUtils()->fullPathFromRelativeFile("Button.aiff"));
        //#else
        //
        //        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Button.ogg");
        //
        //#endif
        //        if(haspressed == true)
        //        {
        //            CCMenuItemImage::activate();
        //            return;
        //        }
        //
        //
        //        if(m_bIsEnabled)
        //        {
        //            this->stopAllActions();
        //            this->setScale( m_fOriginalScale );
        //            this->setPosition(originalPoint);
        //            CCMenuItem::activate();
        //        }
    }
    
    
    void CCMenuItemCommon::selected()
    {
        
        if(haspressed == true)
        {
            
            CCMenuItemImage::selected();
            return;
        }
        
        
        // subclass to change the default action
        if(m_bEnabled)
        {
            CCMenuItem::selected();
            
            CCAction *action = getActionByTag(CCTAG(zoom));
            if (action)
            {
                this->stopAction(action);
                this->stopActionByTag(CCTAG(moveAction));
            }
            else
            {
                m_fOriginalScale = this->getScale();
                originalPoint = this->getPosition();
                
                
            }
            
            CCAction *zoomAction = CCScaleTo::create(0.1f, m_fOriginalScale * 0.99f);
            CCAction *moveAction = CCMoveBy::create(0.01f, CCPoint(0,-5));
            moveAction->setTag(CCTAG(moveAction));
            zoomAction->setTag(CCTAG(zoom));
            this->runAction(zoomAction);
            this->runAction(moveAction);
        }
    }
    
    void CCMenuItemCommon::unselected()
    {
        
        if(haspressed == true)
        {
            
            CCMenuItemImage::unselected();
            return;
            
        }
        
        
        // subclass to change the default action
        if(m_bEnabled)
        {
            CCMenuItem::unselected();
            this->stopActionByTag(CCTAG(zoom));
            this->stopActionByTag(CCTAG(moveAction));
            CCAction *zoomAction = CCScaleTo::create(0.1f, m_fOriginalScale);
            zoomAction->setTag(CCTAG(zoom));
            this->runAction(zoomAction);
            
            
            CCAction *moveAction = CCMoveTo::create(0.1f, originalPoint);
            zoomAction->setTag(CCTAG(moveAction));
            this->runAction(moveAction);
            
        }
    }
    
    
    CCMenuItemCommon * CCMenuItemCommon::create(const char *normalImage, const char *selectedImage, const char *disabledImage, CCObject* target, SEL_MenuHandler selector)
    {
        CCMenuItemCommon *pRet = new CCMenuItemCommon();
        if (pRet && pRet->initWithNormalImage(normalImage, selectedImage, disabledImage, target, selector))
        {
            pRet->autorelease();
            return pRet;
        }
        CC_SAFE_DELETE(pRet);
        return NULL;
    }
    
    
    
    CCMenuItemCommon * CCMenuItemCommon::create(const char *normalImage, const char *selectedImage,  CCObject* target, SEL_MenuHandler selector)
    {
        CCMenuItemCommon *pRet = new CCMenuItemCommon();
        if (pRet && pRet->initWithNormalImage(normalImage, selectedImage, normalImage, target, selector))
        {
            pRet->autorelease();
            return pRet;
        }
        CC_SAFE_DELETE(pRet);
        return NULL;
    }
    
    
    
    static CCMenuItemCommon * create(const char *normalImage,CCObject* target, SEL_MenuHandler selector)
    {
        CCMenuItemCommon *pRet = new CCMenuItemCommon();
        if (pRet && pRet->initWithNormalImage(normalImage, normalImage, normalImage, target, selector))
        {
            pRet->autorelease();
            return pRet;
        }
        CC_SAFE_DELETE(pRet);
        return NULL;
        
    }
    
    
    
    
    
    
    
    
    bool CCMenuItemCommon::initWithNormalImage(const char *normalImage, const char *selectedImage, const char *disabledImage, CCObject* target, SEL_MenuHandler selector)
    {
        haspressed = true;
        
        std::string selectedimagestr=selectedImage;
        if(strcmp(normalImage, selectedImage) == 0 )
        {
            
            selectedimagestr=selectedimagestr.substr(0, selectedimagestr.size()-4); //strip .png
            selectedimagestr+="_hvr.png";
            
            if(CCFileUtils_FileExistInAsset(selectedimagestr.c_str()))
            {
                
                haspressed = true;
                
                return CCMenuItemImage::initWithNormalImage(normalImage, selectedimagestr.c_str(), disabledImage, target, selector);
                
                
                
                
            }else
                haspressed = false;
            
            
            
        }
        
        
        return CCMenuItemImage::initWithNormalImage(normalImage, selectedImage, disabledImage, target, selector);
        
        
    }
    
    
    void CCMenuItemCommon::UnImplemented(CCObject* sender)
    {
        CCMessageBox("This feature is not yet implemented", "Unimplemented");
    }
    
    
    CCMenuItemCommon * CCMenuItemCommon::create(const char *normalImage)
    {
        
        
        CCMenuItemCommon *pRet = new CCMenuItemCommon();
        if (pRet && pRet->initWithNormalImage(normalImage, normalImage, normalImage, pRet, menu_selector(CCMenuItemCommon::UnImplemented)))
        {
            pRet->autorelease();
            return pRet;
        }
        CC_SAFE_DELETE(pRet);
        return NULL;
        
        
    }
    
    
    bool CCFileUtils_FileExistAtPath(const char * path)
    {
        return access(path, R_OK)==0;
    }
    
    
    
    
    double CCFileUtils_FileAge(const char * path)
    {
        
        struct stat buf;
        time_t timet_diff;
        time_t time_now = time(NULL);
        assert(stat(path, &buf)==0);
        timet_diff = time_now - buf.st_mtime;
        return (double)timet_diff;
        
        
    }
    
    
    
    bool CCFileUtils_existFileDataFromZip(const char* pszZipFilePath, const char* pszFileName)
    {
        unzFile pFile = NULL;
        bool res = false;
        do
        {
            CC_BREAK_IF(!pszZipFilePath || !pszFileName);
            CC_BREAK_IF(strlen(pszZipFilePath) == 0);
            
            pFile = unzOpen(pszZipFilePath);
            
            int nRet = unzLocateFile(pFile, pszFileName, 1);
            res = UNZ_OK == nRet;
            
        } while (0);
        
        if (pFile)
        {
            unzClose(pFile);
        }
        return res;
    }
    
    
    
    
    bool CCFileUtils_FileExistInAsset(const char* pszFileName)
    {
        
        //        if(CCFileUtils_FileExistAtPath(CCFileUtils::sharedFileUtils()->fullPathFromRelativeFile(pszFileName)))
        //            return  true;
        
        std::string fullPath(pszFileName);
        
        if ((! pszFileName))
        {
            return false;
        }
        
        if (pszFileName[0] != '/')
        {
            /// read from apk
            fullPath.insert(0, "assets/");
            //            return CCFileUtils_existFileDataFromZip(getResourceZipPath(), fullPath.c_str());
        }
        else
        {
            do
            {
                // read rrom other path than user set it
                FILE *fp = fopen(pszFileName, "rb");
                if (fp != NULL)
                {
                    fclose(fp);
                    return true;
                }
            }
            while (0);
        }
        return false;
    }
#pragma mark - MathMeScene Functions
    bool MathMeScene::isQuitDialogShown = false;
    
    bool MathMeScene::init() {
        
    	if(!CCLayer::init())
			return false;
    	isQuitDialogShown = false;
        
    	return true;
    }
    
    void MathMeScene::showDialog() {
    	if(isQuitDialogShown == true) {
    		return;
    	}
        
    	//this->addChild(Dialog::create("Awww...",  "Would you like to close Hum Along?",this,menu_selector(MathMeScene::ExitApp), menu_selector(MathMeScene::ExitCancelled)),2);
    	isQuitDialogShown = true;
    }
    
    void MathMeScene::onScreenBack()
    {
    	CCLog(" ---- MathMeScene::onScreenBack ----- ");
    	CCCallFuncSel * call = new CCCallFuncSel;
		call->initWithTarget(CCDirector::sharedDirector()->getRunningScene(),callfunc_selector(MathMeScene::showDialog));
        
		this->runAction(call);
		call->release();
        
    }
    
    void MathMeScene::ExitApp()
    {
    	CCLog(" ---- MathMeScene::ExitApp ----- ");
        CCRunwayDirector::sharedDirector()->end();
    }
    
    void MathMeScene::ExitCancelled()
	{
    	CCLog(" ---- MathMeScene::ExitCancelled ----- ");
    	isQuitDialogShown = false;
        //
	}
    
    //
    // ZoomFlipX Transition
    //
}




#pragma mark - OpponentUserTopBar Functions
bool OpponentUserTopBar::init()
{
    return true;
}


//using  cocos2d::extension::CCTableView;
//using  cocos2d::extension::CCTableViewCell;


using  namespace cocos2d;



#pragma mark - BlockingLayer Functions
bool BlockingLayer::init()
{
    
    if(!CCLayer::init())
        return false;
    
    
    setTouchEnabled(true);
    
    return true;
    
}
void BlockingLayer::registerWithTouchDispatcher()
{
    CCDirector* pDirector = CCDirector::sharedDirector();
    pDirector->getTouchDispatcher()->addTargetedDelegate(this, kCCMenuHandlerPriority, true);
}


#pragma mark - ActivtyIndicator Functions
void ActivtyIndicator::addNewNote(float dt)
{
    
}

void ActivtyIndicator::Cancel(CCObject* sender)
{
    
    
    
    CCScene  * scene =CCDirector::sharedDirector()->getRunningScene();
    
    CCPoppableScene * popscene = dynamic_cast<CCPoppableScene*>(scene);
    if(!popscene&&scene->getChildrenCount())
    {
        CCObject *obj=(CCObject*)scene->getChildren()->objectAtIndex(0);
        popscene = dynamic_cast<CCPoppableScene*>(obj);
    }
    if(popscene)
    {
        popscene->onScreenBack();
        
    }
}


bool ActivtyIndicator::init(const char *status,bool hascancel)
{
    
    if(!BlockingLayer::init())
        return false;
    
    
#if ! TARGET_OS_IPHONE
    hascancel =false;
#endif
    bg= CCLayerColor::create(ccc4(0, 0, 0, 255));
    this->addChild(bg);
    bg->setOpacity(100);
    
    
    
    CCNodePlaceAtCenter(bg);
    
    
    CCMenuItemCommon * menuitem = CCMenuItemCommon::create("cancel_btn.png", "cancel_btn.png","cancel_btn.png",this, menu_selector(ActivtyIndicator::Cancel));
    
    CCMenu * menu =CCMenu::create(menuitem,NULL);
    menu->setPosition(ccp(0, 0));
    menu->setContentSize(this->getContentSize());
    this->addChild(menu);
    
    CCNodePlaceAtCenter(menu);
    CCNodePlaceAtBottom(menuitem,ccp(0,180));
    
    
    if(!hascancel)
        menuitem->setVisible(false);
    
    
    {
        
        addNewNote(1);
        
        this->schedule(schedule_selector(ActivtyIndicator::addNewNote), 0.5);
        
        
        
    }
    
    
    
    
    
    bg->runAction(CCFadeTo::create(0.05,195));
    
    
    statusLabel = CCLabelTTF::create("", "Helvetica", 30);
    this->addChild(statusLabel);
    statusLabel->setString(status);
    
    
    if(hascancel)
        CCNodePlaceAtCenter(statusLabel,ccp(0,-150));
    else
        CCNodePlaceAtCenter(statusLabel,ccp(0,-300));
    
    
    
    return true;
    
}

void ActivtyIndicator::Pop()
{
    bg->runAction(CCFadeTo::create(0.1, 0));
    this->runAction(CCSequence::create(CCDelayTime::create(0.2),CCRemoveAction::create(),NULL));
}


void ActivtyIndicator::Pop(float time)
{
    this->runAction(CCSequence::create(CCDelayTime::create(time), CCRemoveAction::create(),NULL));
}



bool ActivtyIndicator::isActivityIndicatorOnScene()
{
    CCNode *  node= (CCDirector::sharedDirector()->getRunningScene());
    CCNode *  indicator = node->getChildByTag(CCTAG(indicator));
    return indicator !=NULL;
}



ActivtyIndicator * ActivtyIndicator::activityIndicatorOnScene(const char * status,cocos2d::MathMeScene * scene,bool hascancel)
{
    CCNode *  node= (CCDirector::sharedDirector()->getRunningScene());
    
    
    if(scene)
        node=scene;
    
    
    CCNode *  indicator = node->getChildByTag(CCTAG(indicator));
    
    if(status && indicator == NULL)
    {
        indicator = new ActivtyIndicator;
        ((ActivtyIndicator*)indicator)->init(status,hascancel);
        indicator->setTag(CCTAG(indicator));
        
        node->addChild(indicator,1000);
        indicator->release();
    }
    
    ((ActivtyIndicator*)indicator)->statusLabel->setString(status);
    
    return ((ActivtyIndicator*)indicator);
}




#pragma mark - Dialog Functions
void Dialog::SetTagFromThis()
{
    //menuitem->setTag(this->getTag());
}



void Dialog::createButtons()
{
    
    menuitem = CCMenuItemCommon::create("yes_btn.png", "yes_btn.png","yes_btn.png",this, menu_selector(Dialog::Activate));
    
    
    CCMenuItemCommon * menuitem2 = CCMenuItemCommon::create("no_btn.png", "no_btn.png","no_btn.png",this, menu_selector(Dialog::Cancel));
    
    
    
    
    CCMenu * menu =CCMenu::create(menuitem,menuitem2,NULL);
    menu->setPosition(ccp(0, 0));
    menu->setContentSize(box->getContentSize());
    box->addChild(menu);
    
    
    CCNodePlaceAtBottom(menuitem,ccp(100, 20));
    CCNodePlaceAtBottom(menuitem2,ccp(-100, 20));
    
    
    
    
}

void Dialog::setupmessage(const char * title,const char * message)
{
    
    
    {
        
        CCLabelTTF * messageLabel = CCLabelTTF::create(message, "Helvetica-Bold", 33, CCSize(box->getContentSize().width-50, box->getContentSize().height-50), kCCTextAlignmentCenter,kCCVerticalTextAlignmentCenter);
        box->addChild(messageLabel,8);
        messageLabel->setColor(ccBLACK);
        
        CCNodePlaceAtCenter(messageLabel,ccp(0,17));
        
    }
    
    {
        
        CCLabelTTF * messageLabel = CCLabelTTF::create(title, "Helvetica-Bold", 33, CCSize(box->getContentSize().width-100, 50), kCCTextAlignmentCenter,kCCVerticalTextAlignmentCenter);
        box->addChild(messageLabel);
        
        CCNodePlaceAtTop(messageLabel,ccp(0,-15));
        messageLabel->setColor(ccBLACK);
        
    }
    
}
bool Dialog::init(const char * title,const char * message, CCObject* intarget, SEL_MenuHandler inselector,SEL_MenuHandler inCancelselector)
{
    if(!BlockingLayer::init())
        return false;
    selector=inselector;
    target = intarget;
    cancelSelector = inCancelselector;
    
    
    CCLayerColor * bg = CCLayerColor::create(ccc4(0, 0, 0, 0));
    bg->ignoreAnchorPointForPosition(false);
    this->addChild(bg,5);
    bg->runAction(CCFadeTo::create(0.3, 200));
    
    
    CCNodePlaceAtCenter(bg);
    {
        
        box = CCSprite::create(dailogBg().c_str());
        this->addChild(box,30);
        CCNodePlaceAtCenter(box);
        
        this->setupmessage(title, message);
        this->createButtons();
    }
    
    this->runAction(CCCallFunc::create(this, callfunc_selector(Dialog::SetTagFromThis)));
    
    
    
    float scaletime=10;
    box->setScale(0.5);
    
    box->runAction(CCSequence::create(CCScaleTo::create(0.5/scaletime,1.2),CCScaleTo::create(0.4/scaletime,1.2),CCScaleTo::create( 1/scaletime,1),NULL));
    
    
    return true;
    
}


void Dialog::Activate(cocos2d::CCObject* sender)
{
    (target->*selector)(this);
    this->runAction(CCRemoveAction::create());
    
}

void Dialog::Cancel(CCObject* sender)
{
    if(cancelSelector)
        (target->*cancelSelector)(this);
    this->runAction(CCRemoveAction::create());
}


Dialog *  Dialog::create(const char * title,const char * message,CCObject* target, SEL_MenuHandler selector, SEL_MenuHandler cancelselector)
{
    Dialog * dilog = new Dialog;
    dilog->init(title,message, target, selector,cancelselector);
    dilog->autorelease();
    return dilog;
    
}



