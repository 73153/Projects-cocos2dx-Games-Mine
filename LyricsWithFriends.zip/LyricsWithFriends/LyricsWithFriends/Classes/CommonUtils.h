
//
//  Header.h
//  HumIt
//
//  Created by Shakthi Prasad G S on 15/11/12.
//
//

#ifndef HumIt_Header_h
#define HumIt_Header_h
#include "cocos2d.h"
#include "cocos-ext.h"
#include <stddef.h>
#include <algorithm>

#if TARGET_OS_IPHONE

#include "httpiOS.h"
#define MathMeHttpRequest  cocos2d::httpios::CCHttpRequest
#define MathMeHttpResponse cocos2d::httpios::CCHttpResponse
#define MathMeHttpClient cocos2d::httpios::CCHttpClient

#else
#include "HttpRequest.h"
#include "HttpClient.h"
#define MathMeHttpRequest  cocos2d::extension::CCHttpRequest
#define MathMeHttpResponse cocos2d::extension::CCHttpResponse
#define MathMeHttpClient cocos2d::extension::CCHttpClient


#endif




#pragma mark - namespace  cocos2d
namespace  cocos2d {
    void CCNodePlaceAtCenter(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtBottom(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtTop(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtRight(CCNode * node,CCPoint offset=CCPointZero);
    void CCNodePlaceAtLeft(CCNode * node,CCPoint offset=CCPointZero);
    void CCReplaceSceneWithOutPushTransition(CCScene * scene);
    
    void CCReplaceScene(CCScene * scene);
    void CCReplaceSceneWithFlair(CCScene * scene);
    void CCPushScene(CCScene * scene);
    void CCPushSceneWithFlair(CCScene * scene);
    void CCPopScene();
    void CCPopSceneWithFlair();
    void CCPopSceneWithOutPushTransition();
    void CCDropOtherScenes();
    
    void CCCommonBackScene(CCScene *scene);
    
    int CCTag(const  char *str);
    
    //tobe ported to android
    bool CCFileUtils_FileExistAtPath(const char * path);
    bool CCFileUtils_FileExistInAsset(const char* pszFileName);
    
    double CCFileUtils_FileAge(const char * path);
    
    void stopAllSounds();
    
    
    typedef ptrdiff_t Size;
    
    template< class Type, Size n >
    Size countOf( Type (&)[n] ) { return n; }
    
    
    
#pragma mark - CCMenuItemCommon
    class CCMenuItemCommon: public CCMenuItemImage
    {
        
        bool haspressed;
        
        float        m_fOriginalScale;
        CCPoint originalPoint;
    public:
        void activate();
        void selected();
        void unselected();
        static CCMenuItemCommon * create(const char *normalImage, const char *selectedImage, const char *disabledImage, CCObject* target=NULL, SEL_MenuHandler selector=NULL);
        
        
        void UnImplemented(CCObject* sender);
        
        static CCMenuItemCommon * create(const char *normalImage);
        bool initWithNormalImage(const char *normalImage, const char *selectedImage, const char *disabledImage, CCObject* target, SEL_MenuHandler selector);
        
        
        static CCMenuItemCommon * create(const char *normalImage, const char *selectedImage, CCObject* target, SEL_MenuHandler selector);
    };
    
    
    
    
#pragma mark - Dragabled
    
    class Dragabled:public CCLayer {
        
        
        
        CCPoint initPoint;
        CCPoint draginitPoint;
        bool hassprite;
    public:
        
        bool init(const char * path)
        {
            CCLayer::init();
            hassprite =false;
            
            if(path)
            {
                CCSprite * dragsprite = CCSprite::create(path);
                this->setContentSize(dragsprite->getContentSize());
                
                this->addChild(dragsprite);
                CCNodePlaceAtCenter(dragsprite);
                
                hassprite =true;
            }
            // m_bIsTouchEnabled=true;
            
            
            ignoreAnchorPointForPosition(false);
            setAnchorPoint(ccp(0.5,0.5));
            
            
            return true;
            
        }
        
        bool init(const char * path, const char * font,int size)
        {
            CCLayer::init();
            hassprite =false;
            
            if(path)
            {
                CCSprite * dragsprite = CCLabelTTF::create(path, font, size);
                this->setContentSize(dragsprite->getContentSize());
                
                this->addChild(dragsprite);
                CCNodePlaceAtCenter(dragsprite);
                
                hassprite =true;
            }
            // m_bIsTouchEnabled=true;
            
            
            ignoreAnchorPointForPosition(false);
            setAnchorPoint(ccp(0.5,0.5));
            
            
            return true;
            
        }
        
        
        
        void onEnter()
        {
            CCLayer::onEnter();
            if(!hassprite)
            {
                setContentSize(getParent()->getContentSize());
                m_bIgnoreAnchorPointForPosition = true;
            }
            
        }
        
        void registerWithTouchDispatcher()
        {
            CCDirector* pDirector = CCDirector::sharedDirector();
            pDirector->getTouchDispatcher()->addTargetedDelegate(this, kCCMenuHandlerPriority-100, true);
        }
        
        static Dragabled * create(const char * path)
        {
            Dragabled * d = new Dragabled;
            d->init(path);
            d->autorelease();
            return d;
            
        }
        
        
        static Dragabled * create(const char * path,const char * font,int size)
        {
            Dragabled * d = new Dragabled;
            d->init(path,font,size);
            d->autorelease();
            return d;
            
        }
        
        
        
        CCRect rect()
        {
//            return CCRectMake( m_tPosition.x - m_tContentSize.width * m_tAnchorPoint.x,
//            m_tPosition.y - m_tContentSize.height * m_tAnchorPoint.y,
//             m_tContentSize.width, m_tContentSize.height);
        }
        
        
        
        bool ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent)
        {
            
            
            CCPoint touchLocation = pTouch->getLocation();
            
            CCPoint local = this->convertToNodeSpace(touchLocation);
            CCRect r = this->rect();
            r.origin = CCPointZero;
            
            if (!r.containsPoint(local))
            {
                return false;
            }
            
            
            initPoint=getPosition();
            draginitPoint=pTouch->getLocation();
            
            
            CC_UNUSED_PARAM(pEvent);
            return true;
        }
        
        void ccTouchMoved(CCTouch *pTouch, CCEvent *pEvent)
        {
            CCPoint movepoint=pTouch->getLocation();
            setPosition(ccpAdd(initPoint,ccpSub(movepoint, draginitPoint)));
            
            
            
            
            CCPoint codeddAp = this->getAnchorPoint();
            CCPoint codeddApPAP = getParent()->getAnchorPoint();
            
            
            CCPoint originalAP = codeddAp;
            CCPoint originalPAP = codeddApPAP;
            
            {
                setAnchorPoint(ccp(0.5,0.5));
                CCPoint ap= getAnchorPointInPoints();
                setAnchorPoint(originalAP);
                
                CCAffineTransform t = this->nodeToParentTransform();
                CCPoint parentpoint=   CCPointApplyAffineTransform(ap, t);
                
                
                getParent()->setAnchorPoint(ccp(0.5,0.5));
                CCPoint papos = getParent()->getAnchorPointInPoints();
                getParent()->setAnchorPoint(originalPAP);
                
                parentpoint = ccpSub(parentpoint, papos);
                
                CCLog("CCNodePlaceAtCenter (%f,%f)",parentpoint.x,parentpoint.y);
                
                
            }
            
            
            {
                setAnchorPoint(ccp(0.5,1));
                CCPoint ap= getAnchorPointInPoints();
                setAnchorPoint(originalAP);
                
                CCAffineTransform t = this->nodeToParentTransform();
                CCPoint parentpoint=   CCPointApplyAffineTransform(ap, t);
                
                
                getParent()->setAnchorPoint(ccp(0.5,1));
                CCPoint papos = getParent()->getAnchorPointInPoints();
                getParent()->setAnchorPoint(originalPAP);
                
                parentpoint = ccpSub(parentpoint, papos);
                
                CCLog("CCNodePlaceAtTop (%f,%f)",parentpoint.x,parentpoint.y);
                
                
            }
            
            
            
            {
                setAnchorPoint(ccp(0.5,0));
                CCPoint ap= getAnchorPointInPoints();
                setAnchorPoint(originalAP);
                
                CCAffineTransform t = this->nodeToParentTransform();
                CCPoint parentpoint=   CCPointApplyAffineTransform(ap, t);
                
                
                getParent()->setAnchorPoint(ccp(0.5,0));
                CCPoint papos = getParent()->getAnchorPointInPoints();
                getParent()->setAnchorPoint(originalPAP);
                
                parentpoint = ccpSub(parentpoint, papos);
                
                CCLog("CCNodePlaceAtBottom (%d,%d)",(int)parentpoint.x,(int)parentpoint.y);
                
                
            }
            
            
            
            {
                setAnchorPoint(ccp(1,0.5));
                CCPoint ap= getAnchorPointInPoints();
                setAnchorPoint(originalAP);
                
                CCAffineTransform t = this->nodeToParentTransform();
                CCPoint parentpoint=   CCPointApplyAffineTransform(ap, t);
                
                
                getParent()->setAnchorPoint(ccp(1,0.5));
                CCPoint papos = getParent()->getAnchorPointInPoints();
                getParent()->setAnchorPoint(originalPAP);
                
                parentpoint = ccpSub(parentpoint, papos);
                
                CCLog("CCNodePlaceAtRight (%f,%f)",parentpoint.x,parentpoint.y);
                
                
            }
            
            
            {
                setAnchorPoint(ccp(0,0.5));
                CCPoint ap= getAnchorPointInPoints();
                setAnchorPoint(originalAP);
                
                CCAffineTransform t = this->nodeToParentTransform();
                CCPoint parentpoint=   CCPointApplyAffineTransform(ap, t);
                
                
                getParent()->setAnchorPoint(ccp(0,0.5));
                CCPoint papos = getParent()->getAnchorPointInPoints();
                getParent()->setAnchorPoint(originalPAP);
                
                parentpoint = ccpSub(parentpoint, papos);
                
                CCLog("CCNodePlaceAtLeft (%f,%f)",parentpoint.x,parentpoint.y);
                
                
            }
            
            
            
            this->setAnchorPoint(codeddAp);
            getParent()->setAnchorPoint(codeddApPAP);
            
            
            
            CC_UNUSED_PARAM(pEvent);
            
            
            
        }
        
        void ccTouchEnded(CCTouch *pTouch, CCEvent *pEvent)
        {
            
            CC_UNUSED_PARAM(pTouch);
            CC_UNUSED_PARAM(pEvent);
        }
        
        
        
    };
    
#pragma mark - CCResumableScene
    class CCResumableScene
    {
    public:
        
        virtual void onSceneResume()=0;
        
        
    };
    
    
#pragma mark - CCPoppableScene
    class CCPoppableScene
    {
    public:
        
        virtual void onScreenBack()=0;
        
        
    };
    
    
#pragma mark -  CCCallFuncSel
    class CCCallFuncSel:public CCCallFunc
    {
    public:
        
        bool initWithTarget(CCObject* pSelectorTarget,SEL_CallFunc selector)
        
        {
            if (CCCallFunc::initWithTarget(pSelectorTarget)) {
                m_pCallFunc = selector;
                return true;
            }
            
            return false;
        }
        
        
    };
    
    
    const char * getResourceZipPath();
    
    
    
#pragma mark -   CCMoveHereBy
    class  CCMoveHereBy:public CCMoveTo
    {
        
        CCPoint startPoint;
        
        void startWithTarget(CCNode *aTarget)
        {
            
            
            CCMoveTo::startWithTarget(aTarget);
            
            m_endPosition = aTarget->getPosition();
            m_startPosition = ccpAdd(m_endPosition, startPoint);
            //m_delta = ccpSub(m_endPosition, m_startPosition);
            aTarget->setPosition(m_startPosition);
            
        }
        
        
    public:
        
        
        bool initWithDuration(float duration, const CCPoint& position)
        {
            if (CCMoveTo::initWithDuration(duration,position))
            {
                startPoint = position;
                
                
                return true;
            }
            
            return false;
        }
        
        
        static CCMoveHereBy * create(float duration, const CCPoint& position)
        {
            
            CCMoveHereBy *pMoveTo = new CCMoveHereBy();
            pMoveTo->initWithDuration(duration, position);
            pMoveTo->autorelease();
            
            return pMoveTo;
            
        }
        
        
        
    };
    
#pragma mark -   RunWayScene
    class MathMeScene:public CCLayer,public CCPoppableScene
    {
        
    public:
        
        virtual void onScreenBack();
        
        void showDialog();
        
        bool init();
        
        void ExitApp();
        
        void ExitCancelled();
        
        static bool isQuitDialogShown;
        virtual void BackButton(CCObject* sender)
        {
            this->onScreenBack();
        }
        
        
        
        
        
    };
    
    
    //#define RUNWAY_CREATESCENE(T)\
    //    \
    //    static CCScene  * scene()\
    //    {CCScene * scene = new CCScene; scene->init(); T * layer =  new T;  layer->init();scene->addChild(layer); layer->release(); scene->autorelease(); return scene;}
    //
    //
    
    
#pragma mark - RUNWAY_CREATECOCOS2DSCENE macro
    //#define MATHME_CREATECOCOS2DSCENE(T)\
    
    #define LWF_CREATECOCOS2DSCENE(T)\
\
static cocos2d::CCScene  * scene()\
{cocos2d::CCScene * scene = new cocos2d::CCScene; scene->init(); T * layer =  new T;  layer->init();scene->addChild(layer); layer->release(); scene->autorelease(); return scene;}
 }


namespace std {
    
    namespace   {    inline string char2hex( char dec )
        {
            char dig1 = (dec&0xF0)>>4;
            char dig2 = (dec&0x0F);
            if ( 0<= dig1 && dig1<= 9) dig1+=48;    //0,48inascii
            if (10<= dig1 && dig1<=15) dig1+=97-10; //a,97inascii
            if ( 0<= dig2 && dig2<= 9) dig2+=48;
            if (10<= dig2 && dig2<=15) dig2+=97-10;
            
            string r;
            r.append( &dig1, 1);
            r.append( &dig2, 1);
            return r;
        }
        
    }
    
    
    inline string urlencode(const string &c)
    {
        
        string escaped="";
        int max = c.length();
        for(int i=0; i<max; i++)
        {
            if ( (48 <= c[i] && c[i] <= 57) ||//0-9
                (65 <= c[i] && c[i] <= 90) ||//abc...xyz
                (97 <= c[i] && c[i] <= 122) || //ABC...XYZ
                (c[i]=='~' || c[i]=='!' || c[i]=='*' || c[i]=='(' || c[i]==')' || c[i]=='\'')
                )
            {
                escaped.append( &c[i], 1);
            }
            else
            {
                escaped.append("%");
                escaped.append( char2hex(c[i]) );//converts char 255 to string "ff"
            }
        }
        return escaped;
    }
    inline string urlDecode(string &SRC) {
        string ret;
        char ch;
        int i, ii;
        for (i=0; i<SRC.length(); i++) {
            if (int(SRC[i])==37) {
                sscanf(SRC.substr(i+1,2).c_str(), "%x", &ii);
                ch=static_cast<char>(ii);
                ret+=ch;
                i=i+2;
            }else if(SRC[i]=='+')
            { ret+=' ';
            }
            else {
                ret+=SRC[i];
            }
        }
        return (ret);
    }
    
    
    inline std::string strtruncate(std::string trunk, size_t size)
    {
        if(trunk.size()>size)
        {
            trunk= trunk.substr(0,size);
            trunk+="...";
        }
        
        return trunk;
        
    }
    
    
    
}


inline std::string getFilenameFromPath(std::string path)
{
    std::string filename;
    size_t pos = path.find_last_of("/");
    if(pos != std::string::npos)
        filename.assign(path.begin() + pos + 1, path.end());
    else
        filename = path;
    
    return filename;
    
}








#define DLOG(s, ...) \
CCLOG("%s|%s:%d:: %s",getFilenameFromPath(__FILE__).c_str(),__PRETTY_FUNCTION__,__LINE__, CCString::createWithFormat(s, ##__VA_ARGS__)->getCString())


#define CCTAG(x) CCTag(#x)








#pragma mark - OpponentUserTopBar
class OpponentUserTopBar:public cocos2d::CCSprite {
    
public:
    CREATE_FUNC(OpponentUserTopBar);
    
    bool init();
    
};






#pragma mark - CCRemoveAction
class CCRemoveAction: public cocos2d::CCActionInstant {
    
    
public:
    void update(float time)
    {
        m_pTarget->removeFromParentAndCleanup(true);
    }
    
    
    
    static CCRemoveAction * create()
    {
        CCRemoveAction * action  = new CCRemoveAction;
        action->autorelease();
        return action;
        
    }
    
    
};



class CCMenuScrollable :public cocos2d::CCMenu
{
    
    cocos2d::CCPoint initialLocation;
    bool exitTracking;
    
    
    cocos2d::CCTouch* savedtouch;
    
public:
    CCMenuScrollable()
    :scrollView(0),savedtouch(0)
    {
    }
    
    ~CCMenuScrollable();
    cocos2d::extension::CCScrollView * scrollView;
    
    CREATE_FUNC(CCMenuScrollable);
    
    
    bool ccTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
    
    void ccTouchMoved(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
    void ccTouchEnded(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
    void ccTouchCancelled(cocos2d::CCTouch* touch, cocos2d::CCEvent* event);
    
    void onExit();
    cocos2d::CCRect rect();
    
    
};




#pragma mark - BlockingLayer
class  BlockingLayer: public cocos2d::CCLayer{
    
    
public:
    bool ccTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event)
    {
        return true;
    }
    void registerWithTouchDispatcher();
    bool init();
};

#pragma mark - ActivtyIndicator
class ActivtyIndicator: public BlockingLayer
{
    void addNewNote(float dt);
    bool init(const char *status,bool hascancel);
    
    void Pop();
    void Pop(float time);
    
    void Cancel(CCObject* sender);
    
public:
    
    
    cocos2d::CCLabelTTF * statusLabel;
    
    
    
    static void PopIfActive(float time=0)
    {
        using namespace cocos2d;
        CCScene *  node= (CCDirector::sharedDirector()->getRunningScene());
        
        PopIfActiveFromScene(node,time);
        
    }
    
      
    static void PopIfActiveFromScene(CCNode * node,float time=0)
    {
        
        using namespace cocos2d;
        
        ActivtyIndicator * activtyIndicator = (ActivtyIndicator *)node->getChildByTag(CCTAG(indicator));
        
        if(activtyIndicator == NULL && node->getChildrenCount())
        {
            node = (CCScene*)node->getChildren()->objectAtIndex(0);
            activtyIndicator = (ActivtyIndicator*)node->getChildByTag(CCTAG(indicator));
        }
        
        if(time==0)
        {if(activtyIndicator)
            activtyIndicator->Pop();
        }else
        {
            if(activtyIndicator)
                activtyIndicator->Pop(time);
        }
        
    }
    
    
    cocos2d::CCLayerColor * bg;
    
    static   bool isActivityIndicatorOnScene();
    
    
    static  ActivtyIndicator * activityIndicatorOnScene(const char * status,cocos2d::MathMeScene * scene=NULL,bool hascancel=false);
    
    
};

#pragma mark - Dialog
class Dialog:public BlockingLayer
{
    
protected:
    cocos2d::CCLabelTTF * text;
    cocos2d::CCMenuItemCommon * menuitem;
    
    cocos2d::CCObject * target;
    
    cocos2d::SEL_MenuHandler selector;
    cocos2d::SEL_MenuHandler cancelSelector;
    CCNode * box;
    cocos2d::CCSprite * bg;
    
public:
    
    
    virtual std::string dailogBg()
    {
        return "ResultScreen/hw_did_u_fare_popup.png";
    }
    
    void SetTagFromThis();
    virtual bool init(const char * title,const char * message, cocos2d::CCObject* target, cocos2d::SEL_MenuHandler selector, cocos2d::SEL_MenuHandler cancelselector=NULL);
    
    
    void Cancel(cocos2d::CCObject* sender);
    
    
    void Activate(cocos2d::CCObject* sender);
    
    
    
    static Dialog * create(const char * title,const char * message,cocos2d::CCObject* target, cocos2d::SEL_MenuHandler selector, cocos2d::SEL_MenuHandler cancelselector=NULL);
    
    
    virtual void createButtons();
    virtual void setupmessage(const char * title,const char * message);
    
    
    
    
};


#pragma mark - DialogOk
class DialogOk:public Dialog
{
    
public:
    static DialogOk * create(const char * title,const char * message,cocos2d::CCObject* target, cocos2d::SEL_MenuHandler selector)
    {
        DialogOk * dilog = new DialogOk;
        dilog->init(title,message, target, NULL,selector);
        dilog->autorelease();
        return dilog;
    }
    
    
    void createButtons()
    {
        
        using namespace cocos2d;
        
        menuitem = cocos2d::CCMenuItemCommon::create("yes_btn.png", "yes_btn.png","yes_btn.png",this, menu_selector(Dialog::Activate));
        menuitem->setVisible(false);
        cocos2d::CCMenuItemCommon * menuitem2 = cocos2d::CCMenuItemCommon::create("ok_btn.png", "ok_btn.png","ok_btn.png",this, menu_selector(Dialog::Cancel));
        
        cocos2d::CCMenu * menu =cocos2d::CCMenu::create(menuitem,menuitem2,NULL);
        menu->setPosition(ccp(0, 0));
        menu->setContentSize(box->getContentSize());
        box->addChild(menu);
        
        CCNodePlaceAtBottom(menuitem,ccp(100, 20));
        CCNodePlaceAtCenter(menuitem2,ccp(0, -150));
        
    }
    
    void setupmessage(const char * title,const char * message)
    {
        
        
        {
            
            cocos2d::CCLabelTTF * messageLabel = cocos2d::CCLabelTTF::create(message, "Helvetica-Bold", 28, cocos2d::CCSize(box->getContentSize().width-100, box->getContentSize().height-100), cocos2d::kCCTextAlignmentCenter,cocos2d::kCCVerticalTextAlignmentCenter);
            box->addChild(messageLabel);
            messageLabel->setColor(cocos2d::ccBLACK);
            
            CCNodePlaceAtCenter(messageLabel,ccp(0,7));
            
        }
        
        {
            
            cocos2d::CCLabelTTF * messageLabel = cocos2d::CCLabelTTF::create(title, "Helvetica-Bold", 35, cocos2d::CCSize(box->getContentSize().width-100, 50), cocos2d::kCCTextAlignmentCenter,cocos2d::kCCVerticalTextAlignmentCenter);
            box->addChild(messageLabel);
            
            CCNodePlaceAtTop(messageLabel,ccp(0,-15));
            messageLabel->setColor(cocos2d::ccBLACK);
            
        }
        
    }
    
};




#endif
