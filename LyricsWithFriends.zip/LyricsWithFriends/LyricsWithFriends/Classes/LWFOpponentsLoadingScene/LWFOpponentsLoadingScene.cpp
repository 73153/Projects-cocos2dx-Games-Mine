//
//  LWFOpponentsLoadingScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 19/06/13.
//
//

#include "LWFOpponentsLoadingScene.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFDataManager.h"
#include "LWFGameScene.h"
#include "LWFGenreListScene.h"


CCScene* LWFOpponentsLoadingScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFOpponentsLoadingScene *layer = LWFOpponentsLoadingScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFOpponentsLoadingScene::LWFOpponentsLoadingScene()
{
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    this->addChild(labelStatusCode,20);
    
    this->loadRandomOpponentFromServer();
    
    
}

#pragma mark - LoadingQuestionsFromServer
void LWFOpponentsLoadingScene::loadRandomOpponentFromServer()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToGetRandomOpponents().c_str());
    CCLOG("%s",LWFCreateURLSharedManager::sharedManager()->createURLToGetRandomOpponents().c_str());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFOpponentsLoadingScene::onLoadingRandomOpponentCompleted));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    
    labelStatusCode->setString("Waiting");
}

void LWFOpponentsLoadingScene::onLoadingRandomOpponentCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    if(message=="Success")
    {
        LWFDataManager::sharedManager()->opponentScore=0;
        LWFDataManager::sharedManager()->currentChallengeId = "9999";
        CCDirector::sharedDirector()->replaceScene(LWFGenreListScene::scene());
    }
    if(document.HasMember("user"))
    {
        
        std::string userID= document["user"]["userId"] .GetString();
        LWFDataManager::sharedManager()->opponentID = userID;
        LWFDataManager::sharedManager()->roundCount=0;
//        CCUserDefault::sharedUserDefault()->setStringForKey("userId", userID);
//        cocos2d::CCUserDefault::sharedUserDefault()->flush();
    }
    
    
}

#pragma mark - destructor
LWFOpponentsLoadingScene::~LWFOpponentsLoadingScene()
{
    
}