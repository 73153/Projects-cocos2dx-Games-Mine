//
//  LWFQuestionLoadingscene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 18/06/13.
//
//

#include "LWFQuestionLoadingscene.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFDataManager.h"
#include "LWFGameScene.h"
#include "LWFObjectiveCCalls.h"


CCScene* LWFQuestionLoadingscene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFQuestionLoadingscene *layer = LWFQuestionLoadingscene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFQuestionLoadingscene::LWFQuestionLoadingscene()
{
    CCSprite *bgSpr = CCSprite::create("LoginPage/Username-Loginre-bg.png");
    bgSpr->setPosition(ccp(160,240));
    this->addChild(bgSpr,1);

    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    this->addChild(labelStatusCode,20);
    
    this->loadSongFromServer();
    
    this->isResponseReady = false;
    this->isSongDownloaded = false;
    
    CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(LWFQuestionLoadingscene::songSuccessfullyDownloaded), "songSuccessfullyDownloaded", NULL);

    
    std::string statusMessage = "Playing the with the user "+LWFDataManager::sharedManager()->opponentID;
    
    CCLabelTTF *opponentNameLabel = CCLabelTTF::create(statusMessage.c_str(), "Arial", 20);
    opponentNameLabel->setPosition(ccp(160, 160));
    this->addChild(opponentNameLabel,3);
    opponentNameLabel->setColor(ccWHITE);


    
}

#pragma mark - LoadingQuestionsFromServer
void LWFQuestionLoadingscene::loadSongFromServer()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToGetLyrics().c_str());
    CCLOG("%s",LWFCreateURLSharedManager::sharedManager()->createURLToGetLyrics().c_str());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFQuestionLoadingscene::onLoadingSongCompleted));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    
    labelStatusCode->setString("Waiting");
}

void LWFQuestionLoadingscene::onLoadingSongCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    
    const rapidjson::Value &lyrics=document["lyrics"];
    CCLog("questionsJson size=%d",lyrics.Size());
    
    rapidjson::SizeType  j=0;
    const rapidjson::Value &lyricsDic=lyrics[j];
    
    LWFDataManager::sharedManager()->selectedSong=lyricsDic["lyricsText"].GetString();
    std::string  ans=lyricsDic["answer"].GetString();
    std::string &str =ans;
   
    
    LWFDataManager::sharedManager()->lyricsID=lyricsDic["lyricsId"].GetString();
    CCLOG("%s", LWFDataManager::sharedManager()->lyricsID.c_str());
    //converting string to upperCase
    for(short i = 0; i < str.size(); ++i)
    {
        LWFDataManager::sharedManager()->answer += toupper(str[i]);
    }
    LWFDataManager::sharedManager()->songPath=lyricsDic["songPath"].GetString();
    
    std::string url="http://juegostudio.co.in/lyricswithfriendz/";
    url=url+LWFDataManager::sharedManager()->songPath;
    LWFObjectiveCCalls::showVideo(url.c_str());
    
    if(message=="Success!!!")
    {
        this->isResponseReady = true;
        
        if (this->isResponseReady&&this->isSongDownloaded)
        {
           
            CCLOG("Go to game scene");

            CCSequence *seq =CCSequence::create(CCDelayTime::create(3), CCCallFunc::create(this, callfunc_selector(LWFQuestionLoadingscene::goToGameScene)),NULL);
            this->runAction(seq);
        }
    }
    
    //Success
    
}

void LWFQuestionLoadingscene::songSuccessfullyDownloaded(CCObject* obj)
{
    int state = (int)obj;
    if(state==0)
    {
        this->isSongDownloaded = false;
    }
    else
    {
        this->isSongDownloaded = true;
        
        if (this->isResponseReady&&this->isSongDownloaded)
        {
         
          std::string statusMessage = "Playing the with the user "+LWFDataManager::sharedManager()->opponentID;
            CCLOG("Go to game scene");
            CCSequence *seq =CCSequence::create(CCDelayTime::create(3), CCCallFunc::create(this, callfunc_selector(LWFQuestionLoadingscene::goToGameScene)),NULL);
            this->runAction(seq);            
        }
    }
}

void LWFQuestionLoadingscene::goToGameScene()
{
    CCLOG("Going to game scene");
    CCDirector::sharedDirector()->replaceScene(LWFGameScene::scene());

}

#pragma mark - destructor
LWFQuestionLoadingscene::~LWFQuestionLoadingscene()
{
        CCLOG("Dealloc in~LWFQuestionLoadingscene" );
        CCNotificationCenter::sharedNotificationCenter()->removeObserver(this, "songSuccessfullyDownloaded");
}