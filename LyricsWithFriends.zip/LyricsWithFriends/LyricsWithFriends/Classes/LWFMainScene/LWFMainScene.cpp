#include "LWFMainScene.h"
#include "SimpleAudioEngine.h"
#include "LWFLoginScene.h"
#include <string>
#include "LWFFacebookLoginScene.h"
#include "LWFFacebookFrndListScreen.h"
#include "LWFGenreListScene.h"


using namespace cocos2d;
using namespace CocosDenshion;

CCScene* LWFMainScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFMainScene *layer = LWFMainScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}


LWFMainScene::LWFMainScene()
{
           this->initialiseUI();
    
    
}

void LWFMainScene::initialiseUI()
{
        CCSize winsize=CCDirector::sharedDirector()->getWinSize();
        
        CCSprite *bgSpr = CCSprite::create("MainPage/CreateGamelogin.png");
        bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
        this->addChild(bgSpr);
    
    CCSprite *facebookButtonNormalSpr = CCSprite::create("MainPage/facebook_bt.png");
    CCSprite *facebookButtonSelectedSpr = CCSprite::create("LoginPage/facebook_bt.png");
    
    CCMenuItemSprite *faceBookMenuItem = CCMenuItemSprite::create(facebookButtonNormalSpr, facebookButtonSelectedSpr, this, menu_selector(LWFMainScene::onClickOfFB));
    faceBookMenuItem->setPosition(CCPointMake(160,256));
    
    CCSprite *twitterButtonNormalSpr = CCSprite::create("MainPage/twitter_bt.png");
    CCSprite *twitterButtonSelectedSpr = CCSprite::create("MainPage/twitter_bt.png");
    
    CCMenuItemSprite *twitterButtonMenuItem = CCMenuItemSprite::create(twitterButtonNormalSpr, twitterButtonSelectedSpr, this, menu_selector(LWFMainScene::onClickOfTwitter));
    twitterButtonMenuItem->setPosition(CCPointMake(160,206));
    
    CCSprite *gmailButtonNormalSpr = CCSprite::create("MainPage/gmail_bt.png");
    CCSprite *gmailButtonSelectedSpr = CCSprite::create("MainPage/gmail_bt.png");
    
    CCMenuItemSprite *gmailButtonMenuItem = CCMenuItemSprite::create(gmailButtonNormalSpr, gmailButtonSelectedSpr, this, menu_selector(LWFMainScene::onClickOfEmail));
    gmailButtonMenuItem->setPosition(CCPointMake(160,156));

    CCSprite *usernameNormalSpr = CCSprite::create("MainPage/username_bt.png");
    CCSprite *usernameSelectedSpr = CCSprite::create("MainPage/username_bt.png");
    
    CCMenuItemSprite *usernameButtonMenuItem = CCMenuItemSprite::create(usernameNormalSpr, usernameSelectedSpr, this, menu_selector(LWFMainScene::onClickOfUserName));
    usernameButtonMenuItem->setPosition(CCPointMake(160,106));

    
    CCMenu *menuObj = CCMenu::create (faceBookMenuItem, twitterButtonMenuItem,gmailButtonMenuItem,usernameButtonMenuItem,NULL);
    this-> addChild(menuObj,2);
    menuObj->setPosition(CCPointZero);
    //  menuObj->alignItemsVertically();
    

}

void LWFMainScene::onClickOfEmail()
{
        CCDirector::sharedDirector()->replaceScene(LWFLoginScene::scene());
}

void LWFMainScene::onClickOfFB()
{
   CCDirector::sharedDirector()->replaceScene(LWFFacebookLoginScene::scene());
   
    
    // CCPushScene(LWFFacebookFrndListScreen::scene());

}

void LWFMainScene::onClickOfUserName()
{
    CCDirector::sharedDirector()->replaceScene(LWFLoginScene::scene());

}
void LWFMainScene::onClickOfTwitter()
{
    CCDirector::sharedDirector()->replaceScene(LWFLoginScene::scene());
}
LWFMainScene::~LWFMainScene()
{
        
}