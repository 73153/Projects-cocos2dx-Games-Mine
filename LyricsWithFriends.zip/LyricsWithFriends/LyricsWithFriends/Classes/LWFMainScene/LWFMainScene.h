#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

class LWFMainScene : public cocos2d::CCLayer
{
public:
    // Method 'init' in cocos2d-x returns bool, instead of 'id' in cocos2d-iphone (an object pointer)
    LWFMainScene();
    ~ LWFMainScene();
    
    static cocos2d::CCScene* scene();
    
    
    void initialiseUI();
    
    void onClickOfEmail();
    void onClickOfFB();
    void onClickOfTwitter();
    void onClickOfUserName();
    
    CREATE_FUNC(LWFMainScene);
};

#endif // __HELLOWORLD_SCENE_H__

