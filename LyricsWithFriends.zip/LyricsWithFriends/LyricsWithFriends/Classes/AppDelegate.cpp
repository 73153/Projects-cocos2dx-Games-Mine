//
//  LyricsWithFriendsAppDelegate.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#include "AppDelegate.h"

#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "LWFMainScene.h"
#include "LWFGameProgressScreen.h"
#include "LWFGenreListScene.h"
#include "LWFDataManager.h"


USING_NS_CC;
using namespace CocosDenshion;

AppDelegate::AppDelegate()
{

}

AppDelegate::~AppDelegate()
{
}

bool AppDelegate::applicationDidFinishLaunching()
{
    // initialize director
    CCDirector *pDirector = CCDirector::sharedDirector();
    pDirector->setOpenGLView(CCEGLView::sharedOpenGLView());

    // turn on display FPS
    //  pDirector->setDisplayStats(true);

    // set FPS. the default value is 1.0/60 if you don't call this
    pDirector->setAnimationInterval(1.0 / 60);

    
    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    CCSize designSize;
    CCSize resourceSize;
    CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
    
    std::vector<std::string> searchPaths;
    
    if (screenSize.height > 480)
    {
        resourceSize = CCSizeMake(640, 960);
        searchPaths.push_back("HD");
    }
    else
    {
        resourceSize = CCSizeMake(320, 480);
    }
    pFileUtils->setSearchPaths(searchPaths);
    designSize = CCSizeMake(320, 480);
    pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
    CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
    
    std::string apiVal= CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0");
    CCLOG("%s=apiVal",apiVal.c_str());
    if(apiVal != "0")
    {
        CCScene *pScene = LWFGameProgressScreen::scene();
          pDirector->runWithScene(pScene);
    }
    else
    {
        CCScene *pScene = LWFMainScene::scene();
        pDirector->runWithScene(pScene);
    }
        return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground()
{
    LWFDataManager::sharedManager()->isAppRunning=false;
    CCDirector::sharedDirector()->stopAnimation();
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->pauseAllEffects();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground()
{
    
    CCDirector::sharedDirector()->startAnimation();
    SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->resumeAllEffects();
}
