//
//  LWFGameProgressScreen.h
//  LyricsWithFriends
//
//  Created by Deepthi on 19/06/13.
//
//

#ifndef LyricsWithFriends_LWFGameProgressScreen_h
#define LyricsWithFriends_LWFGameProgressScreen_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

class LWFGameProgressScreen :public cocos2d::CCLayer

{
public:
    LWFGameProgressScreen();
    ~LWFGameProgressScreen();
    
    static cocos2d::CCScene* scene();
    
    void initialiseUI();
    
    void onClickOfCurrentGame();
    void onClickOfRandomOpponent();
    void onClickOfFaceBookFriends();
    void onClickOfTwitter();
    void onClickOfContactList();
    void onClickOfEmail();
   
    
    void onClickOfLogout();
    void replaceSceneOnSuccessfulLogOut(std::string msg);
    
    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);
    cocos2d::CCLabelTTF* labelStatusCode;

    
    CCMenuItemSprite *logOutItem;
    
    
    
    CREATE_FUNC(LWFGameProgressScreen);
};



#endif
