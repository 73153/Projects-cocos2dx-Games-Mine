//
//  LWFGameProgressScreen.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 19/06/13.
//
//

#include "LWFGameProgressScreen.h"
#include "LWFGenreListScene.h"
#include "LWFOpponentsLoadingScene.h"
#include "LWFCurrentGamesList.h"
#include "LWFMainScene.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFOpponentSelectionScene.h"
#include "LWFFacebookFrndListScreen.h"

CCScene* LWFGameProgressScreen::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFGameProgressScreen *layer = LWFGameProgressScreen::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFGameProgressScreen::LWFGameProgressScreen()
{
    LWFDataManager::sharedManager()->isAppRunning=false;
    this->initialiseUI();
}

#pragma mark - initialiseUI
void LWFGameProgressScreen::initialiseUI()
{
    CCSize winsize= CCDirector::sharedDirector()->getWinSize();
    
    CCSprite *bgSpr = CCSprite::create("MainPage/CreateGamelogin.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    
    CCSprite *startWithSpr = CCSprite::create("GameProgressScene/start_bt.png");
    startWithSpr->setPosition(ccp(160,240));   //210
    this->addChild(startWithSpr);
    
    CCSprite *currentGameNormalSpr = CCSprite::create("GameProgressScene/games_bt.png");
    CCSprite *currentGameSelectedSpr = CCSprite::create("GameProgressScene/games_bt.png");
    
    CCMenuItemSprite *currentGameButton = CCMenuItemSprite::create(currentGameNormalSpr, currentGameSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfCurrentGame));
    currentGameButton->setPosition(CCPointMake(162,283)); //263
    
    
    
    CCSprite *randomOpponentNormalSpr = CCSprite::create("GameProgressScene/Random_bt.png");
    CCSprite *randomOpponentSelectedSpr = CCSprite::create("GameProgressScene/Random_bt.png");
    
    CCMenuItemSprite *randomOpponentButton = CCMenuItemSprite::create(randomOpponentNormalSpr, randomOpponentSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfRandomOpponent));
    randomOpponentButton->setPosition(CCPointMake(162,194)); //167
    
//    CCSprite *randomOpponentNormalSpr = CCSprite::create("GameProgressScene/Random_bt.png");
//    CCSprite *randomOpponentSelectedSpr = CCSprite::create("GameProgressScene/Random_bt.png");
//    
//    CCMenuItemSprite *randomOpponentButton = CCMenuItemSprite::create(randomOpponentNormalSpr, randomOpponentSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfRandomOpponent));
//    randomOpponentButton->setPosition(CCPointMake(162,167));
//
    
    CCSprite *contactListNormalSpr = CCSprite::create("GameProgressScene/contactlist_bt.png");
    CCSprite *contactListSelectedSpr = CCSprite::create("GameProgressScene/contactlist_bt.png");
    

    
    CCMenuItemSprite *contactListButton = CCMenuItemSprite::create(contactListNormalSpr, contactListSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfContactList));
    contactListButton->setPosition(CCPointMake(162,162)); //129
    
 
     CCSprite *faceBookFriendNormalSpr= CCSprite::create("GameProgressScene/facebook_bt.png");
     CCSprite *faceBookFriendSelectedSpr = CCSprite::create("GameProgressScene/facebook_bt.png");
     
    CCMenuItemSprite *faceBookFriendButton = CCMenuItemSprite::create(faceBookFriendNormalSpr, faceBookFriendSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfFaceBookFriends));
    faceBookFriendButton->setPosition(CCPointMake(162,131)); //91
    
     
     CCSprite *twitterNormalSpr = CCSprite::create("GameProgressScene/twitter_bt.png");
     CCSprite *twitterSelectedSpr = CCSprite::create("GameProgressScene/twitter_bt.png");
     
    CCMenuItemSprite *twitterButton = CCMenuItemSprite::create(twitterNormalSpr, twitterSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfTwitter));
    twitterButton->setPosition(CCPointMake(160,100));  //53
    
    CCSprite *emailNormalSpr = CCSprite::create("GameProgressScene/emailBtn.png");
    CCSprite *emailSelectedSpr = CCSprite::create("GameProgressScene/emailBtn.png");
    
    CCMenuItemSprite *emailButton = CCMenuItemSprite::create(emailNormalSpr, emailSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfEmail));
    emailButton->setPosition(CCPointMake(162,68));
    
     CCSprite *logOutNormalSpr = CCSprite::create("GameProgressScene/logout.png");
     CCSprite *logOutSelectedSpr = CCSprite::create("GameProgressScene/logout.png");
 
    logOutItem = CCMenuItemSprite::CCMenuItemSprite::create(logOutNormalSpr, logOutSelectedSpr, this, menu_selector(LWFGameProgressScreen::onClickOfLogout));
    logOutItem->setPosition(CCPointMake(40,25));
    logOutItem->setEnabled(true);
      

    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    addChild(labelStatusCode,20);
    
       
    CCMenu *tempMenu = CCMenu::create(currentGameButton,randomOpponentButton,contactListButton,faceBookFriendButton,twitterButton,emailButton,logOutItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);

}

#pragma mark - menu
void LWFGameProgressScreen::onClickOfCurrentGame()
{
    LWFDataManager::sharedManager()->isAppRunning=true;
     CCDirector::sharedDirector()->replaceScene(LWFCurrentGamesList::scene());
}

void LWFGameProgressScreen::onClickOfContactList()
{
   
}


void LWFGameProgressScreen::onClickOfLogout()
{
    LWFDataManager::sharedManager()->isAppRunning=true;
    //    std::string type="signin";
    LWFHttpRequest* request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createLogOutURL().c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFGameProgressScreen::onHttpRequestCompleted));
    request->setTag("GET test1");
    LWFHttpClient::getInstance()->send(request);
    request->release();
    labelStatusCode->setString("waiting...");
    logOutItem->setEnabled(false);
}

void LWFGameProgressScreen::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    
    this->replaceSceneOnSuccessfulLogOut(message);
}

void LWFGameProgressScreen::replaceSceneOnSuccessfulLogOut(std::string msg)
{
    std::string alert="Signout Successfully!!!";
    if(strcmp(msg.c_str(), alert.c_str())==0)
    {
        
        cocos2d::CCUserDefault::sharedUserDefault()->setStringForKey("APIKey", "0");
        cocos2d::CCUserDefault::sharedUserDefault()->flush();
        CCDirector::sharedDirector()->replaceScene(LWFMainScene::scene());
    }
    
    
}

void LWFGameProgressScreen::onClickOfEmail()
{
    LWFDataManager::sharedManager()->isAppRunning=true;
    CCDirector::sharedDirector()->replaceScene(LWFOpponentSelectionScene::scene());
}

void LWFGameProgressScreen::onClickOfFaceBookFriends()
{
    CCDirector::sharedDirector()->replaceScene(LWFFacebookFrndListScreen::scene());
}
void LWFGameProgressScreen::onClickOfTwitter()
{
    
}
void LWFGameProgressScreen::onClickOfRandomOpponent()
{
    LWFDataManager::sharedManager()->isAppRunning=true;
    CCDirector::sharedDirector()->replaceScene(LWFOpponentsLoadingScene::scene());
}

#pragma mark - destructor
LWFGameProgressScreen::~LWFGameProgressScreen()
{
    
}
