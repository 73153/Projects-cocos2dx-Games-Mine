//
//  httpiOS.cpp
//  HumIt
//
//  Created by Shakthi Prasad GS on 1/16/13.
//
//

#include "httpiOS.h"


@interface CustomURLConnection : NSURLConnection
{

    cocos2d::httpios::CCHttpRequest * request;
    NSMutableData * responcedata;

}

@property (assign) cocos2d::httpios::CCHttpRequest * request;
@property (retain) NSMutableData * responcedata;


@end


@implementation CustomURLConnection

@synthesize request,responcedata;


-(void)dealloc
{
    
    [responcedata release];
    [super dealloc];
}


-(oneway void)release
{
    [super release];

}

-( id)retain
{
    
    return [super retain];
    
}


@end







@interface HttpImpl : NSObject
{}
@end


@implementation HttpImpl

- (void)connection:(NSURLConnection*)connection didReceiveData:(NSData*)data
{
    
    CustomURLConnection * urlConnection = (CustomURLConnection *)connection;
    //NSLog(@"Did Receive Data %@", data);
    
    if(urlConnection.responcedata==NULL)
        urlConnection.responcedata = [NSMutableData data];
        
    
    [urlConnection.responcedata appendData:data];
}
- (void)connection:(NSURLConnection*)connection didFailWithError:(NSError*)error
{    CustomURLConnection * urlConnection = (CustomURLConnection *)connection;
    
    
    // Do something with responseData
    cocos2d::httpios::CCHttpRequest *request = urlConnection.request;
    cocos2d::CCObject *pTarget = request->getTarget();
    cocos2d::SEL_CallFuncND pSelector = request->getSelector();
    
    cocos2d::httpios::CCHttpResponse * response = new cocos2d::httpios::CCHttpResponse(request);
    response->setSucceed(false);
    
    response->setErrorBuffer([[error description] UTF8String]);
    
    
    if (pTarget && pSelector)
    {
        (pTarget->*pSelector)((cocos2d::CCNode *)NULL, response);
    }
    
    response->release();
    request->release();
    [urlConnection release];

}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"Did Finish");
    CustomURLConnection * urlConnection = (CustomURLConnection *)connection;

    
    // Do something with responseData
    cocos2d::httpios::CCHttpRequest *request = urlConnection.request;
    cocos2d::CCObject *pTarget = request->getTarget();
    cocos2d::SEL_CallFuncND pSelector = request->getSelector();
    
    cocos2d::httpios::CCHttpResponse * response = new cocos2d::httpios::CCHttpResponse(request);
    response->setSucceed(true);
//    NSString* newStr = [NSString stringWithUTF8String:(const char*)[urlConnection.responcedata bytes]];
    
    std::vector<char> chardata;
    
    for (int i=0; i< [urlConnection.responcedata length]; i++)
    {
        chardata.push_back(*((char*)[urlConnection.responcedata bytes]+i));
    }
    

    
    response->setResponseData(&chardata);
    response->setResponseCode(200);
    
    
    if (pTarget && pSelector)
    {
        (pTarget->*pSelector)((cocos2d::CCNode *)NULL, response);
    }
    
    response->release();
    request->release();
    [urlConnection release];
}
@end



namespace cocos2d {
    
    
    namespace httpios {

        
        
HttpImpl * obchttpImpl;



CCHttpClient::CCHttpClient()
{}

CCHttpClient::~CCHttpClient()
{
    requestList->release();
    responceList->release();


    [obchttpImpl release];
}

CCHttpClient * instance = NULL;

 CCHttpClient *CCHttpClient::getInstance()
{
    if(instance == NULL)
    {
        instance = new CCHttpClient;
        instance->init();
    }
    
    return instance;

}



void CCHttpClient::destroyInstance()
{
    instance->release();
    instance=NULL;
}
    
    
bool CCHttpClient::init(void)
{

    requestList = new CCArray;
    responceList= new CCArray;
    obchttpImpl =  [HttpImpl new];
    
    return true;
}

    
    
        void CCHttpClient::send(CCHttpRequest* request)
        {
            if(request->getRequestType()==CCHttpRequest::kHttpPost)
            {
                NSString * urlstring = [NSString stringWithUTF8String:request->getUrl()];
                
                             
                 char * postData =request->getRequestData();
                NSString * str = [NSString stringWithUTF8String:(const char*)postData];
                NSData* data = [str dataUsingEncoding:NSUTF8StringEncoding];
                               
                NSMutableURLRequest *nsurlrequest =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:urlstring]];
                
                [nsurlrequest setHTTPMethod:@"POST"];
                [nsurlrequest setHTTPBody:data];

            
                CustomURLConnection * connection=[[CustomURLConnection alloc] initWithRequest:nsurlrequest delegate:obchttpImpl] ;
                connection.request=request;
                request->retain();
               
                
                 [nsurlrequest release];
            }
            else{
                
                NSString * urlstring = [NSString stringWithUTF8String:request->getUrl()];
                
                if(![urlstring hasPrefix:@"http://"] && ![urlstring hasPrefix:@"https://"] &&![urlstring hasPrefix:@"ftp://"])
                    urlstring=[@"http://" stringByAppendingString:urlstring];
                
                NSURLRequest * nsurlrequest= [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:urlstring]];
                CustomURLConnection * connection=[[CustomURLConnection alloc] initWithRequest:nsurlrequest delegate:obchttpImpl] ;
                connection.request=request;
                request->retain();
                [nsurlrequest release];
            }
            
        }

    
        
}}
