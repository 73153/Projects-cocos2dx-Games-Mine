//
//  LMObjectiveCCalls.h
//  LostMonster
//
//  Created by Krithik B on 9/4/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//


//LMObjectiveCCalls.h

#include "cocos2d.h"
#include <stddef.h>

//USAGE CALL FROM C++ to LMObjectiveCCalls TO ---> LMObjectiveC 
//BASICALLY FROM C++ TO OBJECTIVE C
//This class is useful to call objective c specfic functions !!!

class LWFObjectiveCCalls
{
public:
    
    //Video
    static void showVideo(const char *videoUrl);
    static void playSong();
    static void stopSong();
};

