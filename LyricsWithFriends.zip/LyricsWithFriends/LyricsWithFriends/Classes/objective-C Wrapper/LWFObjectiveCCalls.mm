//
//  LMObjectiveCCalls.m
//  LostMonster
//
//  Created by Krithik B on 9/4/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//

//LMObjectiveCCalls.mm (.mm means its objective-c++?  Which means you can access it in c++?  This file can combine c++ and objective c?)
#include "LWFObjectiveCCalls.h" 
#include "LWFObjectiveC.h"




void LWFObjectiveCCalls::showVideo(const char *videoUrl)
{
//    [LWFObjectiveC playVideo:0 fullscreen:0 file:[NSString stringWithCString:videoUrl encoding:NSUTF8StringEncoding] fileExtension:@"mp4" withTutorialLblHeading:[NSString stringWithCString:tutorialHeading encoding:NSUTF8StringEncoding]];
    [LWFObjectiveC playVideo:0 fullscreen:0 file:[NSString stringWithCString:videoUrl encoding:NSUTF8StringEncoding]];

}

void LWFObjectiveCCalls::playSong()
{
    [LWFObjectiveC playSong];
}

void LWFObjectiveCCalls::stopSong()
{
    [LWFObjectiveC stopSong];
}

