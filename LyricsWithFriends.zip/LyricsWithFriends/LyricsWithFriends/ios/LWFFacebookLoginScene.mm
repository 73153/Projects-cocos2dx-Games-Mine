//
//  LWF.mm
//  LyricsWithFriends
//
//  Created by Deepthi on 28/06/13.
//
//
#include "LWFFacebookLoginScene.h"
#include "cocos2d.h"
#import <FacebookSDK/FacebookSDK.h>
#include "LWFFacebookFrndListScreen.h"

#include "AppController.h"

using namespace cocos2d;




void LWFFacebookLoginScene::facebookLogin(CCObject* sender)
{
    
    CCLOG("network found");
    this->retain();

    NSArray *permissions = [NSArray arrayWithObjects:@"email", nil];

//    [FBSession openActiveSessionWithReadPermissions:permissions
//                                       allowLoginUI:TRUE
//                                  completionHandler:^(FBSession *session, FBSessionState state, NSError *error)

    
    [FBSession openActiveSessionWithReadPermissions:nil
                                       allowLoginUI:TRUE
                                  completionHandler:^(FBSession *session, FBSessionState state, NSError *error)
        {
            NSLog(@"error    %@",error);
            NSLog(@"%d=state",state);
            if(error)
                this->facebookLoginDone(false);
            else if(state == FBSessionStateClosedLoginFailed)
                this->facebookLoginDone(false);
            else if(state == FBSessionStateOpen)
                this->facebookLoginDone(true);
            
            if(state != FBSessionStateClosed)
                this->release();
            
     }];
    
}


void LWFFacebookLoginScene::facebookLoginSilent(CCObject* sender)
{
    
    [FBSession openActiveSessionWithReadPermissions:nil
                                       allowLoginUI:FALSE
                                  completionHandler:^(FBSession *session, FBSessionState state, NSError *error)
     {
         
         if(error)
             this->facebookLogin(sender);//try normal login
         
         else if(state == FBSessionStateClosedLoginFailed)
             this->facebookLogin(sender);//try normal login
         else if(state == FBSessionStateOpen)
             this->loginPreviousSession();
     }];
}


void LWFFacebookLoginScene::loginPreviousSession()
{
  
      CCPushScene(LWFFacebookFrndListScreen::scene());
    
    //  this->next();
}

void LWFFacebookLoginScene::facebookProfileInfoFetch()
{
    
    //    facebookDataRetrievedCount=0;
    
    if (FBSession.activeSession.isOpen)
    {
        //fetch user detail
        
        this->retain();
        [[FBRequest requestForMe] startWithCompletionHandler:
         ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
             
             
             if (!error) {
                 
               
                 emailID =[[user objectForKey:@"email"]UTF8String];
                 CCLOG("emailID=%s",emailID.c_str());

                facebookUserName=[[user valueForKey:@"name"] UTF8String];
                 facebookUserId=[[user valueForKey:@"id"] UTF8String];
                 facebookUserGender=[[user valueForKey:@"gender"] UTF8String];
                              
                 CCLOG("%s=name",facebookUserName.c_str());
                 
                 NSString *unescaped = [user valueForKey:@"name"];
                 NSString *escapedString = (NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                               NULL,
                                                                                               (CFStringRef)unescaped,
                                                                                               NULL,
                                                                                               (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                               kCFStringEncodingUTF8);
                 
                 
                 
                 facebookNoSpaceUserName=[escapedString UTF8String];
                 [escapedString release];
                 
                 
                 [[FBRequest requestWithGraphPath:@"me/picture" parameters:[NSDictionary dictionaryWithObjectsAndKeys:@"false" ,@"redirect",@"square",@"type",Nil] HTTPMethod:@"GET"] startWithCompletionHandler:
                  ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
                      if (!error) {
                          
                          NSLog(@"%@",[user valueForKeyPath:@"data.url"]);
                          
                          
                          
                          NSString * fburl = [[ user valueForKeyPath:@"data.url"] substringFromIndex:8];//https://
                          facebookUserPictureUrl = [fburl UTF8String];
                          

                          this->loginToLyricsThroughFB();
                    
                                               // NSLog(@"%@",[user objectForKey:@"email"]);
                          //   NSLog(@"faceBookuserID=%s",facebookUserId.c_str());
                          //       this->loginRunwayServer();
                       
                          this->release();
                          
                      }
                  }];
                 
                 
             }
         }];
        
        //fetch user profileimage url
        
        this->retain();
        
    }
}

void LWFFacebookLoginScene::FacebookLoginOut(CCObject* sender)
{
    [[FBSession activeSession] closeAndClearTokenInformation];
    
}
















