//
//  RWFacebookFriendListScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "LWFFacebookFrndListScreen.h"
#import <FacebookSDK/FacebookSDK.h>


using namespace cocos2d;

static CCDictionary  * GetDictForFaceBookId(CCArray * inArray,const char * facebookid)
{
    CCObject * pObj=NULL;
    CCARRAY_FOREACH(inArray, pObj)
    {
        CCDictionary * dict=(CCDictionary *)pObj;
        if(dict->valueForKey("id")->compare(facebookid) ==0)
            return dict;
    }
    
    return NULL;
    
}


void LWFFacebookFrndListScreen::FetchFriendList(){
    this->retain(); //retain before calling objectivc
    

    if (!FBSession.activeSession.isOpen) {
        // if the session is closed, then we open it here, and establish a handler for state changes
        [FBSession openActiveSessionWithReadPermissions:nil
                                           allowLoginUI:YES
                                      completionHandler:^(FBSession *session,
                                                          FBSessionState state,
                                                          NSError *error) {
                                          if (error) {
                                              UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                                  message:error.localizedDescription
                                                                                                 delegate:nil
                                                                                        cancelButtonTitle:@"OK"
                                                                                        otherButtonTitles:nil];
                                              [alertView show];
                                          } else if (session.isOpen) {
                                              //run your user info request here
                                              
                                              [[FBRequest requestWithGraphPath:@"me/friends" parameters:[NSDictionary dictionary] HTTPMethod:@"GET"] startWithCompletionHandler:
                                               ^(FBRequestConnection *connection, NSDictionary*user, NSError *error) {
                                                   
                                                   NSLog(@"error is %@",error);
                                                   if (!error) {
                                                       
                                                       //NSLog(@"%@",user);
                                                       
                                                       
                                                       for (NSDictionary *  dict in [user valueForKey:@"data"])
                                                       {
                                                           
                                                           
                                                           CCDictionary * cdictionary =  CCDictionary::create();
                                                           
                                                           
                                                           cdictionary->setObject(CCString::create([[dict valueForKey:@"name"] UTF8String]), "name");
                                                           cdictionary->setObject(CCString::create([[dict valueForKey:@"id"] UTF8String]), "id");
                                                           
                                                           friendsList->addObject(cdictionary);
                                                       }
                                                       
                                                       
                                                       // CCLOG("%d",[[user valueForKey:@"data"] count]);
                                                       
                                                       FetchInstalledFriendList();
                                                   }
                                                   
                                                   this->release(); //release
                                               }];

                                              
                                              
                                              
                                          }
                                      }];
    }
    
    
    
   
}

void LWFFacebookFrndListScreen::FetchInstalledFriendList(){
    this->retain(); //retain before calling objectivc
    
    [[FBRequest requestWithGraphPath:@"me/friends?fields=installed" parameters:[NSDictionary dictionary] HTTPMethod:@"GET"] startWithCompletionHandler:
     ^(FBRequestConnection *connection, NSDictionary*user, NSError *error) {
         if (!error) {
             NSLog(@"error is %@",error);

             
             for (NSDictionary *  dict in [user valueForKey:@"data"])
             {
                 const char * facebookid = [[dict valueForKey:@"id"] UTF8String];
                 const char * userid = [[dict valueForKey:@"userId"] UTF8String];
                 
                 CCDictionary * frienddict =GetDictForFaceBookId(friendsList, facebookid);
                 
                 if([[dict valueForKey:@"installed"] boolValue])
                 {
                     this->friendsInstaledList->addObject(frienddict);
                     NSLog(@"friendinstalled=%d",  this->friendsInstaledList->count());
                 }else
                 {
                     this->friendsNotInstaledList->addObject(frienddict);
                 }
             }
             
             if(isRunning())
             {
                 this->sortList();
                 this->loadFriendList();
                 this->reinitlist();
             }
             
         }
         
         this->release(); //release
     }];

}




