//
//  LyricsWithFriendsAppController.h
//  LyricsWithFriends
//
//  Created by Deepthi on 19/06/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

@class RootViewController;

#import <FacebookSDK/FacebookSDK.h>

@interface AppController : NSObject <UIAccelerometerDelegate, UIAlertViewDelegate, UITextFieldDelegate,UIApplicationDelegate> {
    UIWindow *window;
    RootViewController    *viewController;
    int challengeId;
}
@property (nonatomic, assign)  int challengeId;
@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) RootViewController *viewController;

@property (strong, nonatomic) FBSession *session;

@end

