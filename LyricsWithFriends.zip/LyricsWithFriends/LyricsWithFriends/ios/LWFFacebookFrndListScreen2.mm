//
//  MMFacebookFriendListScreen.cpp
//  HumIt
//
//  Created by Shakthi Prasad G S on 18/11/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "LWFFacebookFrndListScreen.h"
#import "Facebook.h"
#import "LWFDataManager.h"

using namespace cocos2d;

@interface FacebookDialogResponder : NSObject<FBDialogDelegate>
{
    Facebook* mfacebook;
}

@end


@implementation FacebookDialogResponder


- (id)initWithFacebook:(Facebook*)facebook
{
    if (self) {
        mfacebook=facebook;
    }
    return self;
}

 //Called when the dialog succeeds and is about to be dismissed.
 
- (void)dialogDidComplete:(FBDialog *)dialog
{
    [mfacebook autorelease];
    [self autorelease];
}

void LWFFacebookFrndListScreen::postToFB(const char  *inFBPostStr){
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  [NSString stringWithFormat:@"%s",inFBPostStr],@"caption",
                                   @"The Facebook SDK for iOS makes it easier and faster to develop Facebook integrated iOS apps.", @"description",
                                   @"http://www.cocos2d-x.org//ios", @"link",
                                   @"https://raw.github.com/fbsamples/ios-3.x-howtos/master/Images/iossdk_logo.png", @"picture",
                                   nil];
    
    Facebook * facebook = [[Facebook alloc]
                           initWithAppId:FBSession.activeSession.appID
                           andDelegate:nil];
    [facebook dialog:@"feed" andParams:params andDelegate:[[FacebookDialogResponder alloc] initWithFacebook:facebook]];
}

void LWFFacebookFrndListScreen::postToFB(const char* inPost,int isHighScore, bool isLike)
{
    if (isLike) {
        
        char likeMessage[50];
        sprintf(likeMessage, "I like this game. Just give a try");
    MMFacebookFriendListScreen:;postToFB(likeMessage);
    }
    else if(isHighScore) {
        
        char higeScoreMessage[50];
        char mode[15];
        
      
        
        // sprintf(higeScoreMessage, "My highscore in %s is %d",mode,MMGameManager::sharedManager()->score);
        
        LWFFacebookFrndListScreen::postToFB(higeScoreMessage);
    }
}



bool LWFFacebookFrndListScreen::isFBLogedIn(){
    if (FBSession.activeSession.isOpen) {
        NSLog(@"isFBLogedIn 1");
        return YES;
    }
    else
    {
        NSLog(@"isFBLogedIn 0");
        return NO;
    }
    return NO;

}

 void LWFFacebookFrndListScreen::loginToFB(){
     
     [FBSession openActiveSessionWithReadPermissions:nil
                                        allowLoginUI:TRUE
                                   completionHandler:^(FBSession *session, FBSessionState state, NSError *error)
      {
          
          if(error)
             LWFFacebookFrndListScreen::facebookLoginDone(false);
          else if(state == FBSessionStateClosedLoginFailed)
             LWFFacebookFrndListScreen::facebookLoginDone(false);
          else if(state == FBSessionStateOpen)
             LWFFacebookFrndListScreen::facebookLoginDone(true);
          
//          if(state != FBSessionStateClosed)
//              this->release();
          
      }];
    
}
void LWFFacebookFrndListScreen::facebookLoginDone(bool isSuccessFull){
    if(isSuccessFull)
    {
        CCLOG("Login successfull");
        //  MMFacebookFriendListScreen:;postToFB("I have scored", MMGameManager::sharedManager()->score, false);
    }
    
    else
    {
        
    }

}
- (void)dialogDidNotComplete:(FBDialog *)dialog;
{
    [mfacebook autorelease];
    [self autorelease];
    
    
}


//  Called when dialog failed to load due to an error.
 
- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error
{
    [mfacebook autorelease];
    [self autorelease];
    
}

@end

void LWFFacebookFrndListScreen::realsendInvitation(const char * facebookid ,const char * username)
{
    Facebook * facebook = [[Facebook alloc]
                           initWithAppId:FBSession.activeSession.appID
                           andDelegate:nil];
    
    // Store the Facebook session information
    facebook.accessToken = FBSession.activeSession.accessToken;
    facebook.expirationDate = FBSession.activeSession.expirationDate;
    
    
    NSString * freindsid = [NSString stringWithUTF8String:facebookid];
    
    NSString * description = [NSString stringWithFormat:@" play Runway! Design your own model and rate them back!"];
    
//    description = [NSString stringWithFormat:@"%s %@",MMGameManager::sharedManager()->getUserName().c_str(),description,NULL];
//    
//    /*************** Change this**********
//     
//     Without link and and picture you can just post in friends wall but 'description' wont be displayed.
//     */
//    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//                                   description, @"message",
//                                   freindsid,@"to",
//                                   @"Check this out", @"notification_text",
//                                   //                                   @"http://www.mobinius.com/wp-content/uploads/2012/06/Mobinius-Tecgnologies-Pvt.-Ltd..png",@"Picture",
//                                   //                                   @"http://www.mobinius.com/iphone-application-game-development/",@"link",
//                                   nil];
//    
//     
//    // Invoke the dialog
//    [facebook dialog:@"apprequests" andParams:params andDelegate:[[FacebookDialogResponder alloc] initWithFacebook:facebook]];
    ///[facebook autorelease];

}


void LWFFacebookFrndListScreen::InvitationFailed(const char * facebookid ,const char * username)
{
    char string[500];
    sprintf(string, "Failed to invite %s ",username);
    
    CCMessageBox(string, "Unknown error");
    
}




void LWFFacebookFrndListScreen::sendInvitation(const char * facebookid ,const char * username)
{
    
                                                 
      realsendInvitation(facebookid,username);
                                                         
    
}



