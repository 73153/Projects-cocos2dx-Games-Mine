

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "CCTexture2DMutable.h"
#import "CCSpriteFloodFill.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
	CCSpriteFloodFill * sprite;
	
	ccColor4B Colors[6];
	
	NSUInteger SelectedCrayon;
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;



@end
