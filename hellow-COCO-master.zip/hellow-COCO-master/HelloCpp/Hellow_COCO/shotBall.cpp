//
//  shotBall.cpp
//  mybox2dtest
//
//  Created by apple on 13-7-24.
//
//

#include "shotBall.h"
