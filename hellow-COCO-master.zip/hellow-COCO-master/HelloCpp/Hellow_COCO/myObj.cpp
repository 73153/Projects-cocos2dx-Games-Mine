//
//  myObj.cpp
//  mybox2dtest
//
//  Created by apple on 13-7-8.
//
//

#include "myObj.h"
