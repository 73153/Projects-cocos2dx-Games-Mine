//
//  mouse.h
//  mybox2dtest
//
//  Created by apple on 13-7-16.
//
//

#ifndef __mybox2dtest__mouse__
#define __mybox2dtest__mouse__

#include <iostream>
class Cmouse{
public:
    float x;
    float y;
};
#endif /* defined(__mybox2dtest__mouse__) */
