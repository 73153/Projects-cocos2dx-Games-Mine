//
//  myfunc.h
//  mybox2dtest
//
//  Created by apple on 13-8-1.
//
//

#ifndef __mybox2dtest__myfunc__
#define __mybox2dtest__myfunc__

#include <iostream>
#include <string>
#include <vector>
using namespace std;
#include "cocos2d.h"
using namespace cocos2d;

string toString(const char* cstr);
vector<float> strToValueList(const string&str);
#endif /* defined(__mybox2dtest__myfunc__) */
