#ifndef __APPMACROS_H__
#define __APPMACROS_H__

#include "cocos2d.h"
//��Ʒֱ���
static cocos2d::CCSize designResolutionSize = cocos2d::CCSizeMake(1136, 640);
static string resourceSearchDic="iphone";

#endif /* __APPMACROS_H__ */
