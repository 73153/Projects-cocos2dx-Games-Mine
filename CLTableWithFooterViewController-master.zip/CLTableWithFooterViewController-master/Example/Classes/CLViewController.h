//
//  CLViewController.h
//  CLTableWithFooterViewController
//
//  Created by Chris Ledet on 7/5/13.
//  Copyright (c) 2013 Chris Ledet. All rights reserved.
//

#import "CLTableWithFooterViewController.h"

@interface CLViewController : CLTableWithFooterViewController

@end
