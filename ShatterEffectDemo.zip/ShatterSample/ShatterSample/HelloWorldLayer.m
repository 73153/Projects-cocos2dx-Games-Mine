//
//  HelloWorldLayer.m
//  ShatterSample
//
//  Created by Michael Burford on 8/6/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "ShatteredSprite.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}
- (void)doShowSprite {
	CCSprite	*sprite = [CCSprite spriteWithFile:@"glass.png"];
	sprite.position = ccp(160, 240);
	[self addChild:sprite z:1 tag:98];	
}

- (void)doShatter {
	//Remove any previous ones
	[self removeChildByTag:98 cleanup:YES];
	[self removeChildByTag:99 cleanup:YES];
	
	//SHATTER!
	ShatteredSprite	*shatter = [ShatteredSprite shatterWithSprite:[CCSprite spriteWithFile:@"glass.png"] piecesX:5 piecesY:7 speed:0.5 rotation:0.02];	
	shatter.position = ccp(160, 240);
	[shatter runAction:[CCEaseSineIn actionWithAction:[CCMoveBy actionWithDuration:3.0 position:ccp(0, -1000)]]];
	[self addChild:shatter z:1 tag:99];	

	//Do it again...showing the sprite for a second before destroying it.
	[self performSelector:@selector(doShowSprite) withObject:nil afterDelay:6.0];
	[self performSelector:@selector(doShatter) withObject:nil afterDelay:7.0];
}

// on "init" you need to initialize your instance
-(id) init {
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
				 
		// create and initialize a Label
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Hello World" fontName:@"Marker Felt" fontSize:64];
		CGSize size = [[CCDirector sharedDirector] winSize];
		label.position =  ccp( size.width /2 , size.height/2 );
		[self addChild: label];
		
		[self doShatter];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc {
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
