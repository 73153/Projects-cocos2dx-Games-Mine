//
//  SXGameConstants.h
//  Snake_XT
//
//  Created by i-CRG Labs Virupaksh on 6/6/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
#ifndef Snake_xt_SXGameConstants_h
#define Snake_xt_SXGameConstants_h

#define DataManager SXDataManager::sharedManager()

#define MainLayer DataManager->gameLayer
#define SnakeManager DataManager->gameLayer->snakeManager
#define BonusManager DataManager->gameLayer->bonusManager
#define ObstacleManager DataManager->gameLayer->obstacleManager

#define Snake DataManager->gameLayer->snakeManager->snake

#define SXMainLayer self.gameLayer


#define  kAlertTag 601
#define  kAlertTagForRAndomSnake 602
#define  kAlertTagForGun 603
#define  kAlertTagForMissile 604
#define  kAlertTagForBomb 605
#define  KRandomObstcaleTag 2222
#define   kAlertTagForTrap  700
#define kAlertTagForWheel 701
#define kteleport1Tag 800
#define kteleport2Tag 801
#define kFurryModeParticleTagForHead 900
#define kFurryModeParticleTagForBody 901

#define kFenceParticalTag 333





#define  kAlertTagForMovingObstacle 606

typedef enum
{
    kTop = 1,
    kBottom = 2,
    kLeft = 3,
    kRight = 4
} BoundrySide;

 enum {
    
    kMovingObstacleTimer=0,
    kRandomObstcaleTImer=1,
    kWallTimer =2,
    kLaseTimer=3,
    kRandomSnakeTimer=4,
     
    
    kMissileTimer=5,
    kBombTimer=6,
    kGunTimer=7,
    
     kwheelTimer=8,
     kTrapTimer=9,

    kLifeBonusTimer=8,
    kMagnetBonusTimer=9,
    kFuryModeBonusTimeer=10,
    kRemoveAllObstacle=11,
    kInvisibleBonusTimer=12,
    kShieldBonusTimer=13,
} ;

enum bodyType{
    
    kSnakeHead=100,
    ksnakeBody=101,
    kObstacle =102,
    kBonus=103,
    kRandomSnakeTag=104,
    kCoinTag=105,
    kScoreX2=106,
    KscoreX3=107,
    kRandomFood=108,
     kPoisonFood=109,
} ;

enum{
    
    kBomb=700,
    kMissile=701,
    kGun =702,
        
} missilesType;

enum {
    
    kLevelCompletedTrnsprtBGTag=1001,
    kLevelFailedTrnsprtBGTag =1002,
    kResumeTrnsprtBGTag=1003,
    
} transparentBGTag;

typedef enum
{
    kSingleCoin,
    kSquareCoin ,
    kLineCoin,
    kVShapeCoin,
    kCrossShapeCoin,
}CoinShape;

typedef enum{
    kTopLeft = 1,
    kTopRight = 2,
    kBottomLeft = 3,
    kBottomRight =4
}CoordinatePositon;

typedef enum{
    
    KStaticbody=1,
    kMovingBody=2,
    KDisappearBoy=3,
} BodyType;

typedef enum{
    
    kLaser=1,
    kMovingObstacle=2,
    KDisappearObstacle=3,
    KRandomWall=4,
    kRandomSnake=5,
    kWall=6,
    kWheel=7,
    kTrap=8,
} obstacleType;

typedef enum{
    kLeftDirection=1,
    kRightDirection=2,
    kStraightDirection=3
}Direction;

#pragma mark - Environment
//Tag starts from 500

#define kRainParticleTag 500
#define kSnowParticleTag 501


#define kTunnelTag 111
#define kTunnel1Tag 112
#define kUnderGrdTag 113
#define kUnderGrdEndTag 114


#define kSnakeMinimumSpeed 1.000f
#define kSnakeMinimumSpeed 1.000f

#define KBossSnakeTag   100
#define KNonBossSnakeTag 200
#define KStaticbodyTag 1000
#define kPLAYMODE "playmode"


#define KJoystickPos   @"joystickPos"
#define  kBEGINNERMODE   0  // challenge beginner mode
#define KARCADEMODE      2       //arcade  mode


#endif