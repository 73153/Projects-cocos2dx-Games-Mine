//
//  GameMode.h
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#ifndef snake_xt_New_GameMode_h
#define snake_xt_New_GameMode_h

#include <iostream>
#include "cocos2d.h"


class SXGameModeScene :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXGameModeScene();
    ~SXGameModeScene();
    void goT0ArcadeScene();
    void goToSurvivalScene();
    void goToMainScene();


    CREATE_FUNC(SXGameModeScene);
};

#endif
