//
//  GameMode.cpp
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#include "SXGameModeScene.h"
#include "SXArcadeScene.h"
#include "SXMainMenu.h"
#include "SXDataManager.h"
#include "SXGameConstants.h"
using namespace cocos2d;

CCScene* SXGameModeScene ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    SXGameModeScene *layer =SXGameModeScene::create();
    // 'layer' is an autorelease object
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

SXGameModeScene ::SXGameModeScene()
{
    CCSprite *bgSprite=CCSprite:: create("Main_bg.png");
    this->addChild(bgSprite);
    bgSprite->setPosition(ccp(240, 160));
    
    
    
    //aqdding  new game frame
    CCSprite *newGameFrame=CCSprite:: createWithSpriteFrameName("new_game_frame.png");
    this->addChild(newGameFrame);
    newGameFrame->setPosition(ccp(340, 160));
    
    
    
    
    // new  game menu item
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("arcade.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("arcade_hvr.png");
    CCMenuItemSprite *arcadeItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXGameModeScene::goT0ArcadeScene));
    arcadeItem->setPosition(ccp(345, 200));
    
    
    
    
    /// new  game menu item
    normalSprite=CCSprite::createWithSpriteFrameName ("survival.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("survival_hvr.png");
    CCMenuItemSprite *survivalItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXGameModeScene::goToSurvivalScene));
    survivalItem ->setPosition(ccp(345, 160));
    
    
    // main menu item
    
    normalSprite=CCSprite::createWithSpriteFrameName ("back.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("back_hvr.png");
    CCMenuItemSprite *mainMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXGameModeScene::goToMainScene));
    mainMenuItem ->setPosition(ccp(345, 115));
    
    CCMenu *gameModeMenu = CCMenu::create(arcadeItem,survivalItem,mainMenuItem,NULL);
    this->addChild(gameModeMenu);
    gameModeMenu->setPosition(CCPointZero);
}

void SXGameModeScene::goT0ArcadeScene()
{
    DataManager->gameMode=KARCADEMODE;
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInR::create(0.5, SXArcadeScene::scene()));
}

void SXGameModeScene::goToMainScene()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.5, SXMainMenu::scene()));
}

void SXGameModeScene::goToSurvivalScene()
{
    DataManager->gameMode=KARCADEMODE;
    DataManager->currentLevel=1;
    CCDirector::sharedDirector()->replaceScene(SXMainController::scene());
    
}

#pragma  mark- dealloc

SXGameModeScene:: ~SXGameModeScene()
{
    
}





