//
//  SXMainMenu.h
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#ifndef __snake_xt_New__SXMainMenu__
#define __snake_xt_New__SXMainMenu__

#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
#include "SXSelectBG.h"


class SXMainMenu :public cocos2d::CCLayer,public CCTextFieldDelegate,public CCIMEDelegate {
    
    
public:
    static cocos2d::CCScene* scene();
    SXMainMenu();
   virtual  ~SXMainMenu();
    void goToGameCenter();
    void goToOptionScene();
    void goToMoreAppScene();
    void goToHelpScene();
    void goToShareScene();
    void goToNewGame();
    CREATE_FUNC(SXMainMenu);
};


#endif /* defined(__snake_xt_New__SXMainMenu__) */
