//
//  SXMainMenu.cpp
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//



//
//  SXMainMenu.cpp
//  snake_project c++
//
//  Created by Deepthi on 02/01/13.
//
//


#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
#include "SXShare.h"
#include "SXHelp.h"

#include "SXDataManager.h"
#include "SXGameConstants.h"

#include "SXTimeSliderLayer.h"

using namespace cocos2d;
CCScene* SXMainMenu ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    SXMainMenu *layer =SXMainMenu::create();    // 'layer' is an autorelease object
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

SXMainMenu ::SXMainMenu(){
    
    this->setTouchEnabled(true);
    CCSpriteFrameCache *cache = CCSpriteFrameCache::sharedSpriteFrameCache();
    cache->addSpriteFramesWithFile("SXMenuImages.plist");
    cache->addSpriteFramesWithFile("SXSnakeNewImages.plist");

    CCSprite *sprite=CCSprite:: create("Main_bg.png");
    this->addChild(sprite);
    sprite->setPosition(ccp(240, 160));
    
    CCSprite *mainMenuFrame=CCSprite:: createWithSpriteFrameName("main_menu_frame.png");
    this->addChild(mainMenuFrame);
    mainMenuFrame->setPosition(ccp(340, 160));
    
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("playGame.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("playGame_hvr.png");
    CCMenuItemSprite *newGameItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToNewGame));
    newGameItem->setPosition(ccp(340, 240));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("game_centre.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("game_centre_hvr.png");
    CCMenuItemSprite *GameCenterItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToGameCenter));
    GameCenterItem->setPosition(ccp(340, 205));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("options.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("options_hvr.png");
    CCMenuItemSprite *optionItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToOptionScene));
    optionItem->setPosition(ccp(340,175 ));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("help.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("help_hvr.png");
    CCMenuItemSprite *helpItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToHelpScene));
    helpItem->setPosition(ccp(340,145 ));
    
    
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("more_apps.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("more_apps_hvr.png");
    CCMenuItemSprite *moreAppItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToMoreAppScene));
    moreAppItem->setPosition(ccp(340,115 ));
    
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("share.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("share_hvr.png");
    CCMenuItemSprite *shareItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToShareScene));
    shareItem->setPosition(ccp(340,85 ));
    
    
    CCMenu *menu = CCMenu::create(newGameItem,optionItem,NULL);//  GameCenterItem,optionItem,helpItem,moreAppItem,shareItem,NULL);
    this->addChild(menu);
    menu->setPosition(CCPointZero);
    
    //
    
    //connecting to game center
}

void SXMainMenu::goToNewGame()
{
   // CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInR::create(0.5, SXGameModeScene::scene()));
    DataManager->gameMode=KARCADEMODE;

    CCDirector::sharedDirector()->replaceScene(SXMainController::scene());
//    CCDirector::sharedDirector()->pause();
//CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInR::create(0.5, SXTimeSliderLayer::scewne()));
}

void SXMainMenu::goToGameCenter()
{
      
}

void SXMainMenu::goToOptionScene()
{
    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
    
    //    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
}

void SXMainMenu::goToMoreAppScene()
{
    
}

void SXMainMenu::goToHelpScene()
{
    CCDirector::sharedDirector()->replaceScene(SXHelp::scene());

}

void SXMainMenu::goToShareScene()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInR::create(0.5, SXShare::scene()));
}
SXMainMenu::~SXMainMenu()
{
    
}





