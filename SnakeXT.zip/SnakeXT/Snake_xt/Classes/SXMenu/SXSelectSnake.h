//
//  SXSelectSnake.h
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#ifndef snake_xt_New_SXSelectSnake_h
#define snake_xt_New_SXSelectSnake_h

#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
using namespace cocos2d;

class SXSelectSnake :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXSelectSnake();
    ~SXSelectSnake();
    void goBack();
    void setSnakeHead( CCObject *sender);
    CREATE_FUNC(SXSelectSnake);
};



#endif
