//
//  SXArcadeScene.cpp
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#include "SXArcadeScene.h"
#include "SXMainController.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXMainController.h"
#include "SXDataManager.h"
using namespace cocos2d;

CCScene* SXArcadeScene  ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    SXArcadeScene *layer =new SXArcadeScene();
    // 'layer' is an autorelease object
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}


SXArcadeScene ::SXArcadeScene(){
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("back_bt_hvr.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::goBackAction));
    backMenuItem->setPosition(ccp(60, 278));
    
    
    
    //adding bg
    CCSprite *bg = CCSprite::create("level_bg.png");
    bg->setPosition(ccp(240,160));
    this->addChild(bg);
    
    
    
    
    this->addLevelButtons();
    normalSprite=CCSprite::createWithSpriteFrameName ("reset_game.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("reset_game.png");
    CCMenuItemSprite *lockLevelItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::UnlockAllLevels));
    lockLevelItem->setPosition(ccp(60, 30));
    
    
    CCMenu *menu = CCMenu::create(backMenuItem,lockLevelItem,NULL);
    this->addChild(menu,2);
    menu->setPosition(CCPointZero);
    
    
}

void SXArcadeScene::UnlockAllLevels()
{
    CCDirector::sharedDirector()->replaceScene(SXGameModeScene::scene());
}

void SXArcadeScene::goBackAction()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.5, SXGameModeScene::scene()));
    
}
//#pragma mark- level buttons
void SXArcadeScene::addLevelButtons()
{
    float x=310;
    float y=210;
    float lockXPos=328;
    float LockYPos=195;
    
    
    
    
    CCSprite *levelsBG = CCSprite::createWithSpriteFrameName("level_sele_bg.png");
    levelsBG->setPosition(ccp(100,210));
    this->addChild(levelsBG,1);
    
    
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("level_1.png");
    CCSprite * selectedSprite=CCSprite::createWithSpriteFrameName ("level_1.png");
    CCMenuItemSprite *level1MenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::startGameWithLevel));
    level1MenuItem->setPosition(ccp(100, 210));
    level1MenuItem->setTag(1);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("level_2.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("level_2.png");
    CCMenuItemSprite *level2MenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::startGameWithLevel));
    level2MenuItem->setPosition(ccp(170, 210));
    level2MenuItem->setTag(2);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("level_3.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("level_3.png");
    CCMenuItemSprite *level3MenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::startGameWithLevel));
    level3MenuItem->setPosition(ccp(240, 210));
    level3MenuItem->setTag(3);
    
    CCMenu *levelMenu = CCMenu::create(level1MenuItem,level2MenuItem,level3MenuItem, NULL);
    this->addChild(levelMenu);
    levelMenu->setPosition(CCPointZero);
    
  levelsBG = CCSprite::createWithSpriteFrameName("level_sele_bg.png");
    levelsBG->setPosition(ccp(170, 210));
    
    CCSprite *levelsBG1 = CCSprite::createWithSpriteFrameName("level_sele_bg.png");
    levelsBG1->setPosition(ccp(240, 210));
    this->addChild(levelsBG);
    this->addChild(levelsBG1);
    
    //adding level buttons
    for(int i=4;i<=15;i++){
        //adding lock
        
        CCSprite *lockSprite = CCSprite::createWithSpriteFrameName("lock.png");
        lockSprite->setPosition(ccp(lockXPos, LockYPos));
        
        
        
        //adding leevl bg
        
        CCSprite *levelsBG = CCSprite::createWithSpriteFrameName("level_sele_bg.png");
        levelsBG->setPosition(ccp(x, y));
        
        
        // adding level umber sprite
        char normalSpriteImageName[]={};
        sprintf(normalSpriteImageName, "level_%d_hvr.png",i);
        
        normalSprite = CCSprite ::createWithSpriteFrameName(normalSpriteImageName);
        normalSprite->setPosition(ccp(x,y));
        
        
        this->addChild(lockSprite);
        this->addChild(levelsBG);
        this->addChild(normalSprite);
        if(i<16)
        {
            if(i%5==0){
                x=100;
                y=y-65;
                lockXPos=120;
                LockYPos=LockYPos-65;
            }
            else{
                x=x+70;
                lockXPos=lockXPos+70;
            }
        }
        else{
            if(i%5==0){
                x=100;
                y=y-65;
                lockXPos=120;
                LockYPos=LockYPos-65;
            }
            else{
                x=x+70;
                lockXPos=lockXPos+70;
            }
            
            if(i==15){
                x=100;
                y=210;
                lockXPos=120;
                LockYPos=195;
            }
        }
    }
    
    
    
    
    
    
}
//void SXArcadeScene::updateLevelButtons()
//{
//     float x=100;
//      float y=210;
//       float lockXPos=118;
//       float LockYPos=193;
//
//     CCSprite *normalSprite;
//     CCSprite *selectedSprite;
//       CCSprite *levelNumber;
//      int i;
//
//    normalSprite=CCSprite::createWithSpriteFrameName ("level_1.png");
//    selectedSprite=CCSprite::createWithSpriteFrameName ("level_1.png");
//    CCMenuItemSprite *level1MenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::startGameWithLevel));
//    level1MenuItem->setPosition(ccp(100, 210));
//    level1MenuItem->setTag(1);
//
//    CCMenu *levelMenu = CCMenu::create(level1MenuItem,NULL);
//    this->addChild(levelMenu);
//    levelMenu->setPosition(CCPointZero);
//
//    normalSprite=CCSprite::createWithSpriteFrameName ("level_16.png");
//    selectedSprite=CCSprite::createWithSpriteFrameName ("level_16.png");
//    CCMenuItemSprite *level16MenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXArcadeScene::startGameWithLevel));
//    level16MenuItem->setPosition(ccp(100, 210));
//    level16MenuItem->setTag(16);
//
//    CCMenu *levelMenu1 = CCMenu::create(level16MenuItem,NULL);
//    this->addChild(levelMenu1);
//    levelMenu1->setPosition(CCPointZero);
//
//    for (i = 1; i <= 28; i ++)   // for all 28 lebels
//          {
//              CCSprite *levelsBG = CCSprite::createWithSpriteFrameName("level_sele_bg.png");
//                  levelsBG->setPosition(ccp(x,y));
//
//
//
//            if(i%5==0){  // updating position to next row by decreasing y position and reseting x position
//             x=100;
//             y=y-65;
//               lockXPos=x+15;
//           }
//          else{
//               x=x+70;
//            lockXPos=lockXPos+70;
//
//         if(i<16){
//            // [layer1 addChild:levelsBG]; // adding to first layer
//         }
//
//          else{
//
//              // [layer2 addChild:levelsBG]; // addign to second layer
//            }
//
//         if(i==15){   // after addign 15 levels button reseting position first button position  to add into second layer
//               x=100;
//             y=210;
//              lockXPos=117;
//               LockYPos=195;
//          }
//       }
//   }
//
//
//    //
//}


//#pragma mark-level button action
void SXArcadeScene::startGameWithLevel( CCObject* sender)
{
    CCSprite *loadingsprite = CCSprite::createWithSpriteFrameName("loading.png");
    this->addChild(loadingsprite, 3);
    loadingsprite->setPosition(ccp(240,350));
    
    CCMenuItemSprite *item=(CCMenuItemSprite*)sender;
    SXDataManager::sharedManager()->currentLevel=item->getTag();
    CCDirector::sharedDirector()->replaceScene(SXMainController::scene());
    
}
SXArcadeScene::~SXArcadeScene( )
{
    
}
