//
//  SXArcadeScene.h
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#ifndef snake_xt_New_SXArcadeScene_h
#define snake_xt_New_SXArcadeScene_h


#include <iostream>
#include "cocos2d.h"


class SXArcadeScene :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXArcadeScene();
    ~SXArcadeScene();
    void UnlockAllLevels();
    void goBackAction();
    void addLevelButtons();
    void updateLevelButtons();
    void startGameWithLevel( CCObject *sender);
    CREATE_FUNC(SXArcadeScene);
};


#endif
