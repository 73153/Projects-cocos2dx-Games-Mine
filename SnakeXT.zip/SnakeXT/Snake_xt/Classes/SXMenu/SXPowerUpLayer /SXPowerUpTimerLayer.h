//
//  SXPowerUpTimerLayer.h
//  Snake_xt
//
//  Created by Pavithra on 2/18/13.
//
//

#ifndef __Snake_xt__SXPowerUpTimerLayer__
#define __Snake_xt__SXPowerUpTimerLayer__

#include <iostream>
#include "cocos2d.h"
#include "CCControlSlider.h"

class SXPowerUpTimerLayer :public cocos2d::CCLayer {
    
public:
    SXPowerUpTimerLayer();
    ~SXPowerUpTimerLayer();
static cocos2d::CCScene* scewne();
void update(CCObject *sender);
cocos2d::CCLabelTTF *label;
cocos2d::CCLabelTTF *secondTimerlabel;
cocos2d::CCLabelTTF *thirdTimerlabel;


cocos2d::extension::CCControlSlider *firstTimerSlider;
cocos2d::extension::CCControlSlider *secondTimerSlider;
cocos2d::extension::CCControlSlider *thirdTimerSlider;
};
#endif /* defined(__Snake_xt__SXPowerUpTimerLayer__) */
