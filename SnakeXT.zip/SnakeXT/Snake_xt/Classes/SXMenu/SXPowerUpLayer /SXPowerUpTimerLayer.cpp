//
//  SXPowerUpTimerLayer.cpp
//  Snake_xt
//
//  Created by Pavithra on 2/18/13.
//
//

#include "SXPowerUpTimerLayer.h"
#include "CCControlSlider.h"
using namespace cocos2d;
USING_NS_CC_EXT;


CCScene* SXPowerUpTimerLayer::scewne(){
    CCScene *Scene=CCScene::create();
    
    SXPowerUpTimerLayer *layer=new SXPowerUpTimerLayer();
    Scene->addChild(layer);
    return Scene;
}

SXPowerUpTimerLayer::SXPowerUpTimerLayer(){
    
    CCSprite *bg=CCSprite:: create("bg.png");
    this->addChild(bg);
    bg->setPosition(ccp(240,160));
    
    CCSprite *backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(290, 224));
    // Prepare progress for slider
    CCSprite *progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(290, 224));
    // Prepare thumb (menuItem) for slider
    CCSprite *thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(200, 224));
    
    firstTimerSlider =  cocos2d::extension::CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    firstTimerSlider->setPosition(ccp(290,203));
    firstTimerSlider->setRotation(0);
    firstTimerSlider->setValue(0.5);
    firstTimerSlider->setMinimumValue(2);
    firstTimerSlider->setMaximumValue(60);

    this->addChild(firstTimerSlider);
    firstTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXPowerUpTimerLayer::update), cocos2d::extension::CCControlEventValueChanged);

    backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(115, 31));
    // Prepare progress for slider
    progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(115,31));
    // Prepare thumb (menuItem) for slider
    thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(115,31));

    secondTimerSlider =  cocos2d::extension::CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    secondTimerSlider->setPosition(ccp(215,80 ));
    secondTimerSlider->setRotation(0);
    secondTimerSlider->setValue(0.5);
    secondTimerSlider->setMinimumValue(2);
    secondTimerSlider->setMaximumValue(30);
    secondTimerSlider->setScale(0.6);

    this->addChild(secondTimerSlider);
    
    secondTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXPowerUpTimerLayer::update), cocos2d::extension::CCControlEventValueChanged);

    backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(115, 31));
    // Prepare progress for slider
    progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(115,31));
    // Prepare thumb (menuItem) for slider
    thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(115,31));
    
    thirdTimerSlider =  cocos2d::extension::CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    thirdTimerSlider->setPosition(ccp(390,80));
    thirdTimerSlider->setRotation(0);
    thirdTimerSlider->setValue(0.7);
    thirdTimerSlider->setMinimumValue(2);
    thirdTimerSlider->setMaximumValue(30);
    thirdTimerSlider->setScale(0.6);
    this->addChild(thirdTimerSlider);
    
    thirdTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXPowerUpTimerLayer::update), cocos2d::extension::CCControlEventValueChanged);

    label =CCLabelTTF::create("00", "Arial", 15);
    label->setPosition(ccp(400, 230));
    this->addChild(label);
    
    secondTimerlabel =CCLabelTTF::create("00", "Arial", 15);
    secondTimerlabel->setPosition(ccp(250, 95));
    this->addChild(secondTimerlabel);
    
    thirdTimerlabel =CCLabelTTF::create("00", "Arial", 15);
    thirdTimerlabel->setPosition(ccp(430, 95));
    this->addChild(thirdTimerlabel);
}

void SXPowerUpTimerLayer::update( CCObject *sender){
    CCControlSlider *slider=(CCControlSlider*)sender;

    CCString *Str=CCString::createWithFormat("%f",firstTimerSlider->getValue());
    label->setString(Str->getCString());
    
    Str=CCString::createWithFormat("%f",secondTimerSlider->getValue());
    secondTimerlabel->setString(Str->getCString());

    Str=CCString::createWithFormat("%f",thirdTimerSlider->getValue());
    thirdTimerlabel->setString(Str->getCString());

    
}

SXPowerUpTimerLayer::~SXPowerUpTimerLayer(){
    
}