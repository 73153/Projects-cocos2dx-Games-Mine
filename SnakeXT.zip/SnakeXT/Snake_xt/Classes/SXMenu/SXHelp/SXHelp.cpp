//
//  SXHelp.cpp
//  snake_xt_New
//
//  Created by Deepthi on 04/01/13.
//
//

#include "SXHelp.h"
#include "SXSelectBG.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
#include "CCScrollView.h"
#include "cocos2d.h"

using namespace cocos2d;
 USING_NS_CC_EXT;

CCScene*  SXHelp ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    SXHelp *layer = new SXHelp();
    // 'layer' is an autorelease object
    
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

SXHelp ::SXHelp(){
    
    this->setTouchEnabled(true);
    
    CCSprite *sprite=CCSprite::create("help_bg.png");
    sprite->setPosition(ccp(240,160));
    this->addChild(sprite);
    
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("back_bt_hvr.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXHelp::goBack));
    backMenuItem->setPosition(ccp(60, 278));
    
    CCMenu *menu = CCMenu::create(backMenuItem,NULL);
    this->addChild(menu);
    menu->setPosition(CCPointZero);
    
    CCSprite *content=content->create("help_text.png");
    

    scrollLayer = CCLayer::create();
    
    scrollLayer->addChild(content);
    content->setPosition(CCPoint(100, 1200));
    
    scrolView = CCScrollView::create(CCSize(750,225));
    scrolView->setDirection(cocos2d::extension::kCCScrollViewDirectionVertical);
    scrolView->setBounceable(true);
    scrolView->setContainer(scrollLayer);
    
    scrolView->setContentSize(CCSize(480, 1600));
   // scrolView->setContentOffset(CCPointMake(0,-1200),false);
    scrolView->setContentOffset(CCPointMake(140,-1550),false);
    scrolView->updateInset();
    this->addChild(scrolView);
    
    scrolView->setPosition(CCPointMake(0,40));
   scrolView->updateInset();
}




void SXHelp::goBack()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.5, SXMainMenu::scene()));
    
}



SXHelp::~SXHelp()
{
    
} 
    
