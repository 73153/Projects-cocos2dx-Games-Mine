//
//  SXHelp.h
//  snake_xt_New
//
//  Created by Deepthi on 04/01/13.
//
//

#ifndef snake_xt_New_SXHelp_h
#define snake_xt_New_SXHelp_h

#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
#include "CCScrollView.h"
using namespace cocos2d;

class SXHelp :public cocos2d::CCLayer {
    
public:
    static cocos2d::CCScene* scene();
    SXHelp();
    ~SXHelp();
    void goBack();
    CCLayer *scrollLayer;
    CCLayer *layer;
    cocos2d::extension::CCScrollView *scrolView;
   
};



#endif
