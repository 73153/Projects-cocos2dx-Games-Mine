//
//  SXCustomizeJoystick.cpp
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#include "SXCustomizeJoystick.h"
#include "SXSelectBG.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
using namespace cocos2d;

CCScene* SXCustomizeJoystick ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    SXCustomizeJoystick *layer =new SXCustomizeJoystick();
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
SXCustomizeJoystick ::SXCustomizeJoystick(){
    
    this->setTouchEnabled(true);
    
    CCSprite *bg = CCSprite::create("bg.png");
    bg->setPosition(ccp(240,160));
    this->addChild(bg);
    
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCMenuItemSprite *backItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXCustomizeJoystick::goBack));
    backItem->setPosition(ccp(65,278));
    
    
    //done item
    
    normalSprite=CCSprite::createWithSpriteFrameName ("done_bt.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("done_bt_hvr.png");
    CCMenuItemSprite *doneItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXCustomizeJoystick::goToGameModeScene));
    doneItem->setPosition(ccp(415,278));
    
    
    CCMenu *menu = CCMenu::create(backItem,doneItem,NULL);
    this->addChild(menu);
    menu->setPosition(CCPointZero);
    
    CCSprite *customizeLabel = CCSprite::createWithSpriteFrameName("label_customize.png");
    customizeLabel->setPosition(ccp(240,278));
    this->addChild(customizeLabel);
    
    joystickBase =CCSprite::create("Joystick_Controller.png");
    this->addChild(joystickBase);
    
    CCSprite *joystick = CCSprite::create("movementJoystickMiddle.png");
    joystick->setPosition(ccp(joystickBase->getContentSize().width/2,joystickBase->getContentSize().height/2));
    joystickBase->addChild(joystick);
    joystickBase->setPosition(ccp(200,200));
    
}
void SXCustomizeJoystick::goBack()
{
    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
}
void SXCustomizeJoystick::goToGameModeScene()
{
    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
}

void SXCustomizeJoystick::ccTouchesBegan(CCSet *pTouch, CCEvent *pEvent)
{
    CCLOG("touhes begin");
}

void SXCustomizeJoystick:: ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event)
{
    
}
void SXCustomizeJoystick::ccTouchesMoved(CCSet *pTouches,CCEvent *pEvent)
{
    CCTouch *touch = (CCTouch*)pTouches->anyObject();
    
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    CCPoint previousPoint = touch->getPreviousLocationInView();
    previousPoint = CCDirector::sharedDirector()->convertToGL(previousPoint);
    CCPoint point=ccpSub(touchPoint, previousPoint);
    joystickBase->setPosition(ccpAdd(joystickBase->getPosition(), point));
    CCUserDefault *userdefault=CCUserDefault::sharedUserDefault();
    
    CCString *string=CCString::createWithFormat("{%f,%f}",point.x,point.y);
    
    userdefault->setStringForKey("joystickPosition", string->getCString());
    userdefault->flush();
    
    CCLog("string-=%s",string->getCString());
}

SXCustomizeJoystick::~SXCustomizeJoystick()
{
    
}



