//
//  SXTimeSliderLayer.cpp
//  Snake_xt
//
//  Created by Pavithra on 2/18/13.
//
//

#include "SXTimeSliderLayer.h"
#include "CCControlSlider.h"

#include "SXMissileManager.h"
#include "SXObstaclesManager.h"

#include "SXGameConstants.h"
#include "SXDataManager.h"

using namespace cocos2d;
USING_NS_CC_EXT;

CCScene* SXTimeSliderLayer::scewne(){
    CCScene *Scene=CCScene::create();
    
    SXTimeSliderLayer *layer=new SXTimeSliderLayer();
    Scene->addChild(layer);
    return Scene;
}

SXTimeSliderLayer::SXTimeSliderLayer(){

}

void SXTimeSliderLayer::initialize() {
//    CCLog("  initialise slider ");
    this->createLabelStringsArr();
    
    //Bg
    CCSprite *bg=CCSprite:: create("sliderBG.png");
    this->addChild(bg);
    bg->setAnchorPoint(ccp(0,0));
    bg->setPosition(ccp(0,0));
    
    //Slider to set Entry Timeb
    CCSprite *backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(290, 224));
    CCSprite *progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(290, 224));
    CCSprite *thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(200, 224));
    
    firstTimerSlider = CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    firstTimerSlider->setPosition(ccp(290,110));
    firstTimerSlider->setRotation(0);
    firstTimerSlider->setValue(01);
    firstTimerSlider->setMinimumValue(2);
    firstTimerSlider->setMaximumValue(200);
    
    bg->addChild(firstTimerSlider);
    
    firstTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXTimeSliderLayer::setFirstSlider), cocos2d::extension::CCControlEventValueChanged);
    
    //Slider to set Repeat
    
    backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(115, 31));
    
    progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(115,31));
    
    thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(115,31));
    
    secondTimerSlider = CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    secondTimerSlider->setPosition(ccp(290,70 ));
    secondTimerSlider->setRotation(0);
    secondTimerSlider->setValue(1);
   // secondTimerSlider->setScale(0.6);
    secondTimerSlider->setMinimumValue(2);
    secondTimerSlider->setMaximumValue(70);
    
    bg->addChild(secondTimerSlider);
    
    secondTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXTimeSliderLayer::setSecondTimer), cocos2d::extension::CCControlEventValueChanged);
     
     if(this->type!=kGunTimer && this->type!=kLaseTimer && this->type!=kRandomObstcaleTImer && this->type!=kwheelTimer&& this->type!=kTrapTimer ){    // adding third slider
        backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
        backgroundSprite->setPosition(ccp(115, 31));
        // Prepare progress for slider
        progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
        progressSprite->setPosition(ccp(115,31));
        // Prepare thumb (menuItem) for slider
        thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
        thumbSprite->setPosition(ccp(115,31));
        
        thirdTimerSlider =  cocos2d::extension::CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
        thirdTimerSlider->setPosition(ccp(290,30));
        thirdTimerSlider->setRotation(0);
        thirdTimerSlider->setValue(1);
        thirdTimerSlider->setMinimumValue(1);
        thirdTimerSlider->setMaximumValue(5);
        //thirdTimerSlider->setScale(0.6);
        bg->addChild(thirdTimerSlider);
        
        thirdTimerSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXTimeSliderLayer::setthirdTimer), cocos2d::extension::CCControlEventValueChanged);
        
        thirdTimerlabel =CCLabelTTF::create("1", "Arial", 15);
        thirdTimerlabel->setPosition(ccp(400, 45));
        bg->addChild(thirdTimerlabel);
        thirdTimerlabel->setColor(ccc3(0, 0, 0));
    }
    
    label =CCLabelTTF::create("1", "Arial", 15);
    label->setPosition(ccp(400, 125));
    bg->addChild(label);
    label->setColor(ccc3(0, 0, 0));
    
    secondTimerlabel =CCLabelTTF::create("1", "Arial", 15);
    secondTimerlabel->setPosition(ccp(400, 85));
    bg->addChild(secondTimerlabel);
    secondTimerlabel->setColor(ccc3(0, 0, 0));
    
    CCLabelTTF *entryTimelabel =CCLabelTTF::create("Entry Time", "Arial", 15);
    entryTimelabel->setPosition(ccp(300, 125));
    bg->addChild(entryTimelabel);
    entryTimelabel->setColor(ccc3(0, 0, 0));
    
    CCLabelTTF  *repeatLabel =CCLabelTTF::create("RepeatTime", "Arial", 15);
    repeatLabel->setPosition(ccp(300, 85));
    bg->addChild(repeatLabel);
    repeatLabel->setColor(ccc3(0, 0, 0)); 
}

#pragma mark - headingLabel

void SXTimeSliderLayer::addLabels()
{
    CCString *String=(CCString*)LabelStringsArray->objectAtIndex(this->type);
    
    headingLabel=CCLabelTTF::create(String->getCString(), "", 20);
    headingLabel->setPosition(CCPointMake(70, 65));
    this->addChild(headingLabel);
    headingLabel->setColor(ccBLACK);
    
    CCDictionary *sliderDefaultTimeArray=(CCDictionary*)AllTimerData->objectAtIndex(this->type);
    
    CCString *repeatTime=(CCString*)sliderDefaultTimeArray->valueForKey("repeatTime");
    CCString *entryTime=(CCString*)sliderDefaultTimeArray->valueForKey(" entryTime");

    firstTimerSlider->setValue(entryTime->intValue());
    secondTimerSlider->setValue(repeatTime->intValue());
    
}

void SXTimeSliderLayer::createLabelStringsArr ()
{
    LabelStringsArray=CCArray::create();
    LabelStringsArray->retain();
    
    CCString *str=CCString::create(" MovingObstacle");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Random Obstacle");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("wall");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("laser");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Random Snake");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Missilee");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Bomb");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Gun");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("Wheel");
    LabelStringsArray->addObject(str);

    str=CCString::create("Trap ");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("FuryMode");
    LabelStringsArray->addObject(str);

    str=CCString::create("RemoveObstacle");
    LabelStringsArray->addObject(str);
    
    str=CCString::create("InvisiblePowerUp");
    LabelStringsArray->addObject(str);

    str=CCString::create("Shield");
    LabelStringsArray->addObject(str);
    
    const char* path = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("SXTimerPlist.plist");
    
    //CCLog("path is %s",path);
    AllTimerData = CCArray::createWithContentsOfFile(path);
}

#pragma mark- slider methods
void SXTimeSliderLayer::setFirstSlider()
{
    CCString *Str=CCString::createWithFormat("%d",(int)firstTimerSlider->getValue());
    label->setString(Str->getCString());
    if(this->type==kMovingObstacleTimer)
    {
        ObstacleManager->movingObstacleEntryTime=(int)this->firstTimerSlider->getValue();
    }
    
    else if(this->type==kRandomObstcaleTImer) {
        ObstacleManager->randomObstacleEntryTime=(int)this->firstTimerSlider->getValue();
    }
    else if(this->type==kWallTimer) {
        ObstacleManager->wallEntryTime=(int)this->firstTimerSlider->getValue();
    }
    else if(this->type==kLaseTimer) {
        ObstacleManager->laserEntryTime=(int)this->firstTimerSlider->getValue();
    }
    else if(this->type==kRandomSnakeTimer) {
        ObstacleManager->randomSnakeEntryTime=(int)this->firstTimerSlider->getValue();
    }
    
    else if (this->type==kwheelTimer){
        ObstacleManager->wheelEntryTime=(int)this->firstTimerSlider->getValue();
    }
    else if (this->type==kTrapTimer){
        ObstacleManager->trapEntryTime=(int)this->firstTimerSlider->getValue();
    }
    
    else if(this->type==kMissileTimer) {
        MainLayer->missileManager->missileEntryTime=(int)this->firstTimerSlider->getValue();
    }
    
    else if(this->type==kBombTimer) {
        MainLayer->missileManager->BombEntryTime=(int)this->firstTimerSlider->getValue();
    }
    else if(this->type==kGunTimer) {
        MainLayer->missileManager->gunEntryTime=(int)this->firstTimerSlider->getValue();
    }
//    Str=CCString::createWithFormat("%f",thirdTimerSlider->getValue());
//    thirdTimerlabel->setString(Str->getCString());
}

void SXTimeSliderLayer::setSecondTimer(){

   CCString *Str=CCString::createWithFormat("%d",(int)secondTimerSlider->getValue());
    secondTimerlabel->setString(Str->getCString());
    if(this->type==kMovingObstacleTimer)
    {
        ObstacleManager->movingObstcaleRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    
    else if(this->type==kRandomObstcaleTImer) {
        ObstacleManager->randomObstacleRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if(this->type==kWallTimer) {
        ObstacleManager->wallRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if(this->type==kLaseTimer) {
        ObstacleManager->laserrepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if(this->type==kRandomSnakeTimer) {
        ObstacleManager->randomSnakeRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if (this->type==kwheelTimer){
        ObstacleManager->wheelrepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if (this->type==kTrapTimer){
        ObstacleManager->traprepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if(this->type==kMissileTimer) {
        MainLayer->missileManager->missileRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    
    else if(this->type==kBombTimer) {
        MainLayer->missileManager->bombRepeatTime=(int)this->secondTimerSlider->getValue();
    }
    else if(this->type==kGunTimer) {
        MainLayer->missileManager->gunRepeatTime=(int)this->secondTimerSlider->getValue();
    }
}


void SXTimeSliderLayer::setthirdTimer(){
    
    CCString *Str=CCString::createWithFormat("%d",(int)thirdTimerSlider->getValue());
    thirdTimerlabel->setString(Str->getCString());
    if(this->type==kRandomSnakeTimer){
        ObstacleManager->noOfRandomSnake=(int)thirdTimerSlider->getValue();
    }
    else if (this->type==kBombTimer) {
        
        MainLayer->missileManager->noOfBombToCreate=(int)thirdTimerSlider->getValue();
    }
    
    else if (this->type==kMissileTimer){
        MainLayer->missileManager->noOfMissileToCreate=(int)thirdTimerSlider->getValue();
    }
    else if (this->type==kMovingObstacleTimer){
        ObstacleManager->noOfMovableObstacleCount=(int)thirdTimerSlider->getValue();
    }
   
    else{
        ObstacleManager->noOfWall=(int)thirdTimerSlider->getValue();
    }
    
}
#pragma mark - Dealloc

SXTimeSliderLayer::~SXTimeSliderLayer() {
    CC_SAFE_RELEASE(LabelStringsArray);

}