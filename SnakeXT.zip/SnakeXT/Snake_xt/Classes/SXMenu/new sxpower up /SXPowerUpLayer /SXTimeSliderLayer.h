//
//  SXTimeSliderLayer.h
//  Snake_xt
//
//  Created by Pavithra on 2/18/13.
//
//

#ifndef __Snake_xt__SXTimeSliderLayer__
#define __Snake_xt__SXTimeSliderLayer__

#include <iostream>
#include "cocos2d.h"
#include "CCControlSlider.h"

using namespace cocos2d;


class SXTimeSliderLayer :public cocos2d::CCLayer {
    
public:
    SXTimeSliderLayer();
    ~SXTimeSliderLayer();
    static cocos2d::CCScene* scewne();
    CREATE_FUNC(SXTimeSliderLayer);
    
    void setFirstSlider();
    void setSecondTimer();
    void setthirdTimer();
    
    void initialize();
    void addLabels();
    
    int type;
    
    CCLabelTTF *label;
    CCLabelTTF *secondTimerlabel;
    CCLabelTTF *thirdTimerlabel;
    
    cocos2d::extension::CCControlSlider *firstTimerSlider;
    cocos2d::extension::CCControlSlider *secondTimerSlider;
    cocos2d::extension::CCControlSlider *thirdTimerSlider;
    
    //Label
    CCLabelTTF *headingLabel;
    CCArray *LabelStringsArray;
    void createLabelStringsArr();
    
    // default value from plist
    
    CCArray *AllTimerData;
};
#endif /* defined(__Snake_xt__SXTimeSliderLayer__) */
