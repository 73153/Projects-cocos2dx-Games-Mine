//
//  SXSelectBG.cpp
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#include "SXSelectBG.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
#include "SXGameConstants.h"
#include "SXDataManager.h"
using namespace cocos2d;

CCScene* SXSelectBG ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    SXSelectBG *layer =SXSelectBG::create();
    
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
SXSelectBG ::SXSelectBG(){
    
    CCSprite *bg=CCSprite:: create("bg.png");
    this->addChild(bg);
    bg->setPosition(ccp(240, 160));
    
    CCLabelTTF *label =CCLabelTTF::create("Select BG","Arial",25);
    this->addChild(label);
    label->setPosition(ccp(240,280));
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("playGame.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("playGame_hvr.png");
    CCMenuItemSprite *newGameItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXMainMenu::goToNewGame));
    newGameItem->setPosition(ccp(340, 240));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("back.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("back_hvr.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXSelectBG::goBack));
    backMenuItem->setPosition(ccp(60,275));
    
    CCMenu *menu = CCMenu::create(backMenuItem,NULL);
    this->addChild(menu);
    menu->setPosition(CCPointZero);
    
    float xpos=80;
    float ypos=220;
    
    for(int i=1;i<=18;i++){
        
        char normalSpriteImageName[10]={};
        sprintf(normalSpriteImageName, "BG%d.jpg",i);
        char SelectedSpriteImageName[10]={};
        sprintf(SelectedSpriteImageName, "BG%d.jpg",i);
        
        CCLog("%s",normalSpriteImageName);
        
        CCSprite *normalSprite=CCSprite::createWithSpriteFrameName (normalSpriteImageName);
        CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName (SelectedSpriteImageName);
        CCMenuItemSprite *BGMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXSelectBG::setBG));
        BGMenuItem->setPosition(ccp(60,275));
        BGMenuItem->setTag(i);
        BGMenuItem->setPosition(ccp(xpos,ypos));
        menu->addChild(BGMenuItem);
        
        xpos=xpos+80;
        
        if(i%5==0){
            xpos=80;
            ypos-=50;
        }
    }
}


void SXSelectBG::setBG(CCObject* sender)
{
    CCMenuItemSprite *item=(CCMenuItemSprite*)sender;
    
    DataManager->BGNo=item->getTag();
    CCLog(" DataManager->BGNo=%d", DataManager->BGNo);
    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
}
void SXSelectBG::goBack()
{
    CCDirector::sharedDirector()->replaceScene(SXOptionScene::scene());
}
SXSelectBG ::~SXSelectBG()
{
    
}




