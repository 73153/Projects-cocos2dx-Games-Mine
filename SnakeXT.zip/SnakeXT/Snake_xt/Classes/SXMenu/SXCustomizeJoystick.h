//
//  SXCustomizeJoystick.h
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#ifndef snake_xt_New_SXCustomizeJoystick_h
#define snake_xt_New_SXCustomizeJoystick_h
#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
using namespace cocos2d;

class SXCustomizeJoystick :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXCustomizeJoystick();
    ~SXCustomizeJoystick();
    CCSprite *joystickBase;
    void goBack();
    void goToGameModeScene();
    virtual void ccTouchesBegan (CCSet* touches, CCEvent* event);
    
    virtual void ccTouchesEnded(CCSet* touches, CCEvent* event);
    void ccTouchesMoved(CCSet* touches, CCEvent* event);
    CREATE_FUNC(SXCustomizeJoystick);
};



#endif
