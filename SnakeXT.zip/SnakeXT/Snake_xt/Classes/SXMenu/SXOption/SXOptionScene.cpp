//
//  SXOptionScene.cpp
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#include "SXOptionScene.h"
#include "SXMainController.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "CCControlSlider.h"
#include "SXSelectSnake.h"
#include "SXCustomizeJoystick.h"
#include "SXDataManager.h"
#include "SXGameConstants.h"


using namespace cocos2d;
USING_NS_CC_EXT;

CCScene* SXOptionScene  ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    SXOptionScene *layer =new SXOptionScene();
    // 'layer' is an autorelease object
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
SXOptionScene ::SXOptionScene(){
    
    count=0;
    
    
       
    
        
    //adding aprite
    CCSprite *bg=CCSprite:: create("bg.png");
    this->addChild(bg);
    bg->setPosition(ccp(240,160));
    
    
    
    CCSprite *optionBG =CCSprite ::create("options.png");
    this->addChild(optionBG);
    optionBG->setPosition(ccp(240,160));
    
    //addign menu....
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("back_bt_hvr.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXOptionScene::gotoMainMenu));
    backMenuItem->setPosition(ccp(60, 278));
    
    
    
    
    // option label
    
    CCSprite *optionLabelSprite =CCSprite::createWithSpriteFrameName("label_options.png");
    this->addChild(optionLabelSprite);
    optionLabelSprite->setPosition(ccp(240,278));
    
    
    CCSprite *backgroundSprite      = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSprite->setPosition(ccp(290, 224));
    // Prepare progress for slider
    CCSprite *progressSprite       = CCSprite::createWithSpriteFrameName("slide.png");
    progressSprite->setPosition(ccp(290, 224));
    // Prepare thumb (menuItem) for slider
    CCSprite *thumbSprite           = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSprite->setPosition(ccp(200, 224));
    
    CCControlSlider  *musicSlider =  CCControlSlider::create(backgroundSprite,progressSprite,thumbSprite);
    musicSlider->setPosition(ccp(315,203));
    musicSlider->setRotation(0);
    musicSlider->setValue(0.5);
    musicSlider->setMinimumValue(2);
    musicSlider->setMaximumValue(6);
    optionBG->addChild(musicSlider);
    
    CCSprite *backgroundSpriteOne  =  CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSpriteOne->setPosition(ccp(290, 224));
    CCSprite *progressSpriteOne   = CCSprite::createWithSpriteFrameName("slide.png");
    progressSpriteOne->setPosition(ccp(290, 224));
    CCSprite *thumbSpriteOne     = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSpriteOne->setPosition(ccp(188, 224));
    
    CCControlSlider  *soundSlider = CCControlSlider::create(backgroundSpriteOne,progressSpriteOne,thumbSpriteOne);
    soundSlider->setPosition(ccp(315,168));
    soundSlider->setRotation(0);
    soundSlider->setValue(0.5);
    soundSlider->setMaximumValue(0.88);
    optionBG->addChild(soundSlider);
    
    CCSprite *backgroundSpriteTwo = CCSprite::createWithSpriteFrameName("slider_bg.png");
    backgroundSpriteTwo->setPosition(ccp(311,147));
    CCSprite *progressSpriteTwo  = CCSprite::createWithSpriteFrameName("slide.png");
    progressSpriteTwo->setPosition(ccp(311,147));
    CCSprite *thumbSpriteTwo = CCSprite::createWithSpriteFrameName("slider.png");
    thumbSpriteTwo->setPosition(ccp(240,160));
    

    cocos2d::extension::CCControlSlider  *snakeSpeedSlider =   cocos2d::extension::CCControlSlider::create(backgroundSpriteTwo,progressSpriteTwo,thumbSpriteTwo);
    snakeSpeedSlider->setValue((float)DataManager->snakeSpeed);

    snakeSpeedSlider->setPosition(ccp(315,239));
    
    snakeSpeedSlider->setRotation(0);
    snakeSpeedSlider->setMinimumValue(2);
    snakeSpeedSlider->setMaximumValue(6);
     snakeSpeedSlider->setValue(DataManager->snakeSpeed) ;
    optionBG->addChild(snakeSpeedSlider);
    DataManager->snakeSpeed=(int) snakeSpeedSlider->getValue();
    snakeSpeedSlider->addTargetWithActionForControlEvents(this, cccontrol_selector(SXOptionScene::update), CCControlEventValueChanged);

    
   SnakeSpeedLabel =CCLabelTTF::create("00", "Arial", 15);
    SnakeSpeedLabel->setPosition(ccp(400, 252));
    optionBG->addChild(SnakeSpeedLabel);
    
   bool isTouch=CCUserDefault::sharedUserDefault()->getBoolForKey(kPLAYMODE);
    
    if(!isTouch)
    {
        CCLog(" paly mode is joystick");
        normalSprite=CCSprite::createWithSpriteFrameName ("joystick_hvr.png");
    }
    
    else {
        normalSprite=CCSprite::createWithSpriteFrameName ("joystick.png");
    }
    selectedSprite = CCSprite::createWithSpriteFrameName("joystick_hvr.png");
    joystickMenuItem=CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXOptionScene::goToJoystickScene));
    joystickMenuItem->setPosition(ccp(250,115));
    
    if(isTouch)
    {
        touchSprite =CCSprite::createWithSpriteFrameName ("touch_hvr.png");
    }
    else
    {
        touchSprite =CCSprite::createWithSpriteFrameName ("touch.png");
    }
    this->addChild(touchSprite);
    touchSprite->setPosition(ccp(360,115));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("reset_game.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("reset_game.png");
    CCMenuItemSprite *resetMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXOptionScene::resetGame));
    resetMenuItem->setPosition(ccp(65,60));
    
    
    CCLabelTTF *label =CCLabelTTF::create("Select Snake", "Arial", 20);
    
    CCMenuItemLabel *selectSnake = CCMenuItemLabel::create(label,this, menu_selector(SXOptionScene::goToSelectSnakeScene));
    selectSnake->setPosition(ccp(240,60));
    
    label =CCLabelTTF::create("Select BG", "Arial", 20);
    CCMenuItemLabel *selectBG = CCMenuItemLabel::create(label,this, menu_selector(SXOptionScene::goToSelectBG));
    selectBG->setPosition(ccp(370,60));
    
    
    CCMenu *menu = CCMenu::create(backMenuItem,joystickMenuItem,resetMenuItem,selectSnake,selectBG, NULL);
    this->addChild(menu);
    menu->setPosition(CCPointZero);
    
    setTouchEnabled(true);
    this->setTouchEnabled(true);
}
#pragma mark-update
void SXOptionScene::update(CCObject *sender,CCControlEvent controlEvent){
    
    CCControlSlider *slider=(CCControlSlider*)sender;
    
    DataManager->snakeSpeed=(int) slider->getValue();
    CCLog(" data manager snake speed=%f",DataManager->snakeSpeed);
}

#pragma mark-Touches
void SXOptionScene::ccTouchesBegan(CCSet *touches, CCEvent *pEvent){
    
    CCLog("touches begin");
    CCTouch *touch = (CCTouch*)touches->anyObject();
    
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    if(touchSprite->boundingBox().containsPoint(touchPoint)){
        touchSprite->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("touch_hvr.png"));
        CCUserDefault *userDefault=CCUserDefault::sharedUserDefault();
        userDefault->setBoolForKey(kPLAYMODE, true);
          userDefault->flush();
        joystickMenuItem->setNormalImage(CCSprite::createWithSpriteFrameName("joystick.png"));
    }
}

#pragma mark-Call back actions

void SXOptionScene::goToSelectSnakeScene()
{
    CCDirector::sharedDirector()->replaceScene(SXSelectSnake::scene());
}

void SXOptionScene::goToSelectBG()
{
    CCDirector::sharedDirector()->replaceScene(SXSelectBG::scene());
}


void SXOptionScene::resetGame()
{
    transparentBG =CCSprite ::create("trsprnt_bg.png");
    this->addChild(transparentBG);
    transparentBG->setPosition(ccp(240,160));
    CCSprite *resetBg =CCSprite ::create("reset_bg.png");
    transparentBG ->addChild(resetBg);
    resetBg->setPosition(ccp(240,160));
    CCSprite *normalSprite=CCSprite::create("ok_bt.png");
    CCSprite  *selectedSprite=CCSprite::create ("ok_bt.png");
    CCMenuItemSprite *okMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXOptionScene::resetAction));
    okMenuItem->setPosition(ccp(180,120));
    normalSprite=CCSprite::create("cancel_bt.png");
    selectedSprite=CCSprite::create ("cancel_bt.png");
    CCMenuItemSprite *CancelItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXOptionScene::cancelAction));
    CancelItem->setPosition(ccp(320,120));
    CCMenu *menu = CCMenu::create(okMenuItem,CancelItem, NULL);
    transparentBG->addChild(menu);
    menu->setPosition(CCPointZero);
    scheduleUpdate();
}

void SXOptionScene::cancelAction()
{
    this->removeChild(transparentBG,true);
}

void SXOptionScene::resetAction()
{
    
}

void SXOptionScene::goToJoystickScene()
{
    CCUserDefault *userDefault=CCUserDefault::sharedUserDefault();
    userDefault->setBoolForKey(kPLAYMODE,false);
    userDefault->flush();
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInR::create(0.5, SXCustomizeJoystick::scene()));
}


void SXOptionScene::gotoMainMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.5, SXMainMenu::scene()));
}

#pragma  mark- dealloc
SXOptionScene::~SXOptionScene()
{
    
}
