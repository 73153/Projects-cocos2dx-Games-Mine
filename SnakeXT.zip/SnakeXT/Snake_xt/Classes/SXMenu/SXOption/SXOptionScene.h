//
//  SXOptionScene.h
//  snake_xt_New
//
//  Created by Deepthi on 02/01/13.
//
//

#ifndef snake_xt_New_SXOptionScene_h
#define snake_xt_New_SXOptionScene_h
#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;
USING_NS_CC_EXT;

class SXOptionScene :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXOptionScene();
    ~SXOptionScene();
    void goToSelectSnakeScene();
    void goToSelectBG();
    void resetGame();
    void cancelAction();
    void resetAction();
    void goToJoystickScene();
    void update(CCObject *sender,CCControlEvent controlEvent);
    void gotoMainMenu();
    
  virtual  void ccTouchesBegan (CCSet* touches, CCEvent* event);
    
    CCSprite *transparentBG;
    CCSprite *touchSprite;
    CCMenuItemSprite  *joystickMenuItem;
    
    CCLabelTTF * SnakeSpeedLabel;
    cocos2d::extension::CCControlSlider  *snakeSpeedSlider;
    CREATE_FUNC(SXOptionScene);
    
    int count;
    
    
};



#endif
