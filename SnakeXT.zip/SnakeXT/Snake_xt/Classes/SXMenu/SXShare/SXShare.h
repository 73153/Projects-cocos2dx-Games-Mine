//
//  SXShare.h
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#ifndef snake_xt_New_SXShare_h
#define snake_xt_New_SXShare_h
#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
using namespace cocos2d;

class SXShare :public cocos2d::CCLayer {
    
    
public:
    static cocos2d::CCScene* scene();
    SXShare();
    ~SXShare();
    void goBackAction();
    void goToFacebook();
    CREATE_FUNC(SXShare);
};



#endif
