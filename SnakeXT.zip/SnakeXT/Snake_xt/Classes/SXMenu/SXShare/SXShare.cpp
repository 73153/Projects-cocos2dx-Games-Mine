//
//  SXShare.cpp
//  snake_xt_New
//
//  Created by Deepthi on 03/01/13.
//
//

#include "SXShare.h"
#include "SXSelectBG.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
using namespace cocos2d;

CCScene*  SXShare ::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    SXShare *layer = SXShare::create();
    // 'layer' is an autorelease object
    
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
SXShare ::SXShare(){
    
    CCSprite *bg=CCSprite:: create("bg.png");
    this->addChild(bg);
    bg->setPosition(ccp(240, 160));
    
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("back_bt.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("back_bt_hvr.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXShare::goBackAction));
    backMenuItem->setPosition(ccp(60, 278));
    
    
    //share label
    CCSprite *shareLabelSprite=CCSprite:: createWithSpriteFrameName("label_share.png");
    this->addChild(shareLabelSprite);
    shareLabelSprite->setPosition(ccp(240, 278));
    
    
    //share message bg
    CCSprite *shareMessageBG=CCSprite:: createWithSpriteFrameName("share_bg.png");
    this->addChild(shareMessageBG);
    shareMessageBG->setPosition(ccp(240, 160));
    
    normalSprite=CCSprite::createWithSpriteFrameName ("facebook.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("facebook_hvr.png");
    CCMenuItemSprite *facebookMenuitem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXShare::goToFacebook));
    facebookMenuitem->setPosition(ccp(310,190));
    
    normalSprite=CCSprite::createWithSpriteFrameName ("twitter.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("twitter_hvr.png");
    CCMenuItemSprite *twitterMenuitem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXShare::goToFacebook));
    twitterMenuitem->setPosition(ccp(350,190));
    
    
    normalSprite=CCSprite::createWithSpriteFrameName ("msg_icon.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("msg_icon_hvr.png");
    CCMenuItemSprite *sendMessageMenuitem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXShare::goToFacebook));
    sendMessageMenuitem->setPosition(ccp(310,135));
    
    CCMenu *menu = CCMenu::create(backMenuItem,facebookMenuitem,twitterMenuitem,sendMessageMenuitem,NULL);
    this->addChild(menu,2);
    menu->setPosition(CCPointZero);
}

void SXShare::goBackAction()

{
    CCDirector::sharedDirector()->replaceScene(CCTransitionSlideInL::create(0.5, SXMainMenu::scene()));
}
void SXShare::goToFacebook()
{
    
}
SXShare::~SXShare()
{
    
}



