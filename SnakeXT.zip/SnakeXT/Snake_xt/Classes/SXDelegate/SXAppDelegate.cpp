//
//  Snake_xtSXAppDelegate.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#include "SXAppDelegate.h"

#include "cocos2d.h"
#include "SXMainController.h"
#include "SXMainMenu.h"

USING_NS_CC;

SXAppDelegate::SXAppDelegate()
{
    
}

SXAppDelegate::~SXAppDelegate()
{
    
}

bool SXAppDelegate::applicationDidFinishLaunching()
{
    // initialize director
    CCDirector *pDirector = CCDirector::sharedDirector();
    pDirector->setOpenGLView(CCEGLView::sharedOpenGLView());

    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    //CCSize designSize = CCSizeMake(480, 320);
    
    //CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);

    CCSize designSize;
    CCSize resourceSize;
    CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
    
    if (screenSize.height > 320)
    {
        resourceSize = CCSizeMake(960, 640);
        designSize = CCSizeMake(960, 640);

        pFileUtils->setResourceDirectory("hd");
    }
    
    else
    {
          resourceSize = CCSizeMake(480, 320);
          CCFileUtils::sharedFileUtils()->setResourceDirectory("sd");
          designSize =CCSizeMake(480, 320);
    }
    designSize =CCSizeMake(480, 320);

   // pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
    CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
    
    // create a scene. it's an autorelease object
    CCScene *pScene = SXMainMenu::scene();

    // run
    pDirector->runWithScene(pScene);
    
    return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void SXAppDelegate::applicationDidEnterBackground()
{
    CCDirector::sharedDirector()->stopAnimation();

    // if you use SimpleAudioEngine, it must be paused
    // SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
}

// this function will be called when the app is active again
void SXAppDelegate::applicationWillEnterForeground()
{
    CCDirector::sharedDirector()->startAnimation();
    
    // if you use SimpleAudioEngine, it must resume here
    // SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
}
