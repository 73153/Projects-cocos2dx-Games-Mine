//
//  SXUIManager.h
//  Snake_xt
//
//  Created by Pavitra on 03/01/13.
//
//

#ifndef __Snake_xt__SXUIManager__
#define __Snake_xt__SXUIManager__

#include <iostream>
#include "cocos2d.h"

#include "SXGameManager.h"

using namespace cocos2d;
class SXUIManager :public SXGameManager
 {
public:
    CCLabelTTF *scoreLabel;
    CCLabelTTF *levelLabel;
    CCLabelTTF *partsLabel;
    CCLabelTTF *totalScoreLabel;
    CCLabelTTF *mBodyPartCounter;
    
    CCSprite *transparentBG;
     
     CCMenuItemToggle*  pauseButton;
     CCMenuItemSprite *optionButtonItem;
     
    int score;
    int noOfParts;
    
    
    SXUIManager();
   virtual ~SXUIManager();

    void setUIForGame();
    
    CCArray *lifeFullArray;
    
    void optionButtonAction();
    void addLifes();
     
    void menuCallbacks(cocos2d::CCObject *sender);
     
    void updateLabels();
    void updateLifeArray();
    void updateLifeBonus();
    void updateNOfsnakeParts();
     void updateScore(int inScore);
     
    void optionButonAction();
    void levelCompletedUI();
    void  setUPYouFailedUI();
    void showYouFailedUI();
     
    };
#endif /* defined(__Snake_xt__SXUIManager__) */
