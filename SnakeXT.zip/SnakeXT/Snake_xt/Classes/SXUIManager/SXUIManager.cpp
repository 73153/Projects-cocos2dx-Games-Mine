//
//  SXUIManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 03/01/13.
//
//

#include "SXUIManager.h"
#include "SXGameConstants.h"
#include "SXDataManager.h"
#include "SXMainController.h"
#include "SXCustomSprite.h"
#include "SXMainMenu.h"
#include "SXArcadeScene.h"
#include "SXTimeSliderLayer.h"



SXUIManager::SXUIManager () {
    
    this->gameLayer=DataManager->gameLayer;
    
    this->lifeFullArray=CCArray::create();
    this->lifeFullArray->retain();
    score=0;

    noOfParts=DataManager->MaxNoOfBodiesInLevel ;

    this->setUIForGame();
   
    //this->levelCompletedUI();
    this->optionButonAction();
     this->setUPYouFailedUI();
    
    
}




#pragma mark-update methods
void SXUIManager::updateLabels() {
    
    char str[5];
    sprintf(str, "%d",score);
    scoreLabel->setString(str);
    
    sprintf(str, "%d",noOfParts);
    mBodyPartCounter->setString(str);
//    if(this->lifeFullArray->count()==0) {
//        this->showYouFailedUI();
//       
//    }
//    else
        if( this->noOfParts==0 &&DataManager->gameMode==KARCADEMODE) {
       
        char str[5];
        sprintf(str, "%d",this->score);
        totalScoreLabel->setString(str);
    }
}

void SXUIManager::updateNOfsnakeParts(){
    
    if(DataManager->gameMode==KARCADEMODE){
        noOfParts--;
    }
    else{
        noOfParts++;
       }
}
void SXUIManager::updateScore(int inScore){
    
    this->score+=inScore;
}

#pragma  mark- lifes updates 
void SXUIManager::updateLifeBonus()
{
    CCSprite *sprite=(CCSprite *)this->lifeFullArray->lastObject();
    if(this->lifeFullArray->count() <5)
    {
        CCSprite *lifeEmpltySprite=CCSprite::createWithSpriteFrameName("life_full.png");
        lifeEmpltySprite->setPosition(ccp(sprite->getPosition().x+15,sprite->getPosition().y));
        this->lifeFullArray->addObject(lifeEmpltySprite);
        this->gameLayer->addChild(lifeEmpltySprite,7);
    }
}

void SXUIManager::updateLifeArray() {
   
    CCSprite *sprite=(CCSprite *)this->lifeFullArray->lastObject();
    CCSprite *lifeEmpltySprite=CCSprite::createWithSpriteFrameName("life_empty.png");
    lifeEmpltySprite->setPosition(sprite->getPosition());
    this->gameLayer->addChild(lifeEmpltySprite,7);
    this->gameLayer->removeChild(sprite, true);
    this->lifeFullArray->removeObject(sprite);
    if(this->lifeFullArray->count()==0) {
        this->showYouFailedUI();
    }
    
}

void SXUIManager::addLifes()
{
    
    int x=350;
    int y=305;
    
    //this->lifeFullArray->removeAllObjects();
    
    for (int i=0; i<5; i++) {
        CCSprite *lifeEmpltySprite=CCSprite::createWithSpriteFrameName("life_full.png");
        this->gameLayer->addChild(lifeEmpltySprite,7);
        
        lifeEmpltySprite->setPosition(ccp(x, y));
        this->lifeFullArray->addObject(lifeEmpltySprite);
        x=x+15;
    }
    
    int noOfEmptyLife=5-this->lifeFullArray->count();
    
    // adding empty lifes
    for(int i=0;i<noOfEmptyLife;i++){
        CCSprite *lifeEmpltySprite=CCSprite::createWithSpriteFrameName("life_empty.png");
        this->gameLayer->addChild(lifeEmpltySprite,7);
        
        lifeEmpltySprite->setPosition(ccp(x, y));
        x=x+15;
    }
}

#pragma mark-Set Up Game UI
void SXUIManager::setUIForGame() {
    
    CCSprite *topMenu;
    topMenu=CCSprite  ::createWithSpriteFrameName("top_menu_02.png");
    this->gameLayer->addChild(topMenu,7);
    topMenu->setPosition(ccp(240, 305));
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName("option_Button_01.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName("option_Button_02.png");
    
    optionButtonItem=CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(SXUIManager::menuCallbacks));
    optionButtonItem->setPosition(19, 305);
    optionButtonItem->setTag(101);
    optionButtonItem->setEnabled(false);
    
    
    normalSprite=CCSprite::createWithSpriteFrameName("Pause_01.png");
    selectedSprite=CCSprite::createWithSpriteFrameName("Play_01.png");
    
     pauseButton = CCMenuItemToggle::createWithTarget(this, menu_selector(SXUIManager::menuCallbacks),CCMenuItemSprite::create(normalSprite, normalSprite),CCMenuItemSprite::create(selectedSprite, selectedSprite),NULL);
    pauseButton->setPosition(ccp(460,305));
    pauseButton->setTag(21);
    pauseButton->setEnabled(false);
    
        
    CCMenu *menu=CCMenu::create(optionButtonItem,pauseButton,NULL);
    this->gameLayer->addChild(menu,7);
    menu->setPosition(CCPointZero);
    
    CCSprite *Scorebg=CCSprite::createWithSpriteFrameName("scoreBG.png");
    this->gameLayer->addChild(Scorebg,7) ;
    Scorebg->setPosition(CCPointMake(100, 307));
    
    // scoreLabel ...................
    scoreLabel=CCLabelTTF::create("00", "Arial", 15);
    this->gameLayer->addChild(scoreLabel,7) ;
    scoreLabel ->setColor(ccc3(255, 255, 255));
    scoreLabel->setPosition(ccp(90, 305));
    
    // leve; label
    levelLabel=CCLabelTTF::create("00", "Arial", 15);
    //this->gameLayer->addChild(levelLabel,7) ;
    levelLabel ->setColor(ccc3(255, 255, 255));
    levelLabel->setPosition(ccp(212, 300));
    char str[5];
    sprintf(str, "%d",DataManager->currentLevel);
    
    levelLabel->setString(str);
    noOfParts=0;
    mBodyPartCounter=CCLabelTTF::create("00", "Arial", 15);
    this->gameLayer->addChild(mBodyPartCounter,7) ;
    mBodyPartCounter ->setColor(ccc3(255, 255, 255));
    mBodyPartCounter->setPosition(ccp(245, 300));
    
    //adding lifes  bg................
    CCSprite *lifeBG=CCSprite::createWithSpriteFrameName("lifeBG.png");
    this->gameLayer->addChild(lifeBG,7);
    lifeBG->setPosition(CCPointMake(380, 305));
    
    this->addLifes();
}

void SXUIManager::setUPYouFailedUI()
{
   CCSprite *transparentBG =CCSprite ::create("trsprnt_bg.png");
    this->gameLayer->addChild(transparentBG,7,kLevelFailedTrnsprtBGTag);
    transparentBG->setPosition(ccp(240,160));
    CCSprite *levelLoseBg =CCSprite ::create("level_failed_bg.png");
    transparentBG->addChild(levelLoseBg);
    levelLoseBg->setPosition(ccp(240,160));
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("replay.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("replay_hvr.png");
    CCMenuItemSprite *restatMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    restatMenuItem->setTag(1);
    restatMenuItem->setPosition(ccp(320,80));
    normalSprite=CCSprite::createWithSpriteFrameName ("levelMenu.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("levelMenu_hvr.png");
    CCMenuItemSprite *levelMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    levelMenuItem->setPosition(ccp(380,80));
    levelMenuItem->setTag(2);
    
    totalScoreLabel=CCLabelTTF::create("0000", "Arial", 20);
    transparentBG->addChild(totalScoreLabel);
    char str[5];
    sprintf(str, "%d",this->score);
    scoreLabel->setString(str);
    
    totalScoreLabel->setPosition(ccp(323, 138)); // total label
    
    transparentBG->setVisible(false);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("menu_bt.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("menu_bt_hvr.png");
    CCMenuItemSprite *mainMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    mainMenuItem->setTag(10);
    mainMenuItem->setPosition(ccp(90,260));
    CCMenu *menu=CCMenu:: create(restatMenuItem,levelMenuItem,mainMenuItem, NULL);
    transparentBG->addChild(menu ,10);
    menu->setPosition(CCPointZero);
}
void SXUIManager::optionButonAction()
{
     // transparent bg
    CCSprite *transparentBG =CCSprite ::create("trsprnt_bg.png");
    this->gameLayer->addChild(transparentBG,8,kResumeTrnsprtBGTag);
    transparentBG->setPosition(ccp(240,160));
    
    // resume bg
    
    CCSprite *resumeBg =CCSprite ::create("Resume_game.png");
    transparentBG->addChild(resumeBg);
    resumeBg->setPosition(ccp(240,160));
    
    // resume label
    CCSprite *resumeLabelSprite =CCSprite ::createWithSpriteFrameName("label_resume.png");
    transparentBG->addChild(resumeLabelSprite,8);
    resumeLabelSprite->setPosition(ccp(240,230));
    
    //main menu item
  CCSprite * normalSprite=CCSprite::createWithSpriteFrameName ("menu_bt.png");
   CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("menu_bt_hvr.png");
    CCMenuItemSprite *mainMebnuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    mainMebnuItem->setPosition(ccp(90, 228));
    mainMebnuItem->setTag(6);
    
        //play meni item
    normalSprite=CCSprite::createWithSpriteFrameName ("play.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("play_hvr.png");
    CCMenuItemSprite *playMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    playMenuItem->setPosition(ccp(150,150));
    playMenuItem->setTag(7);
    
    // replay menu item
    normalSprite=CCSprite::createWithSpriteFrameName ("replay.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("replay_hvr.png");
    CCMenuItemSprite *restartMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    restartMenuItem->setPosition(ccp(210,150));
    restartMenuItem->setTag(1);
    
    // level menu item
       normalSprite=CCSprite::createWithSpriteFrameName ("levelMenu.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("levelMenu_hvr.png");
    CCMenuItemSprite *levelMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    levelMenuItem->setPosition(ccp(270,150));
    levelMenuItem->setTag(2);
    
    // volume menu item
    
    normalSprite=CCSprite::createWithSpriteFrameName ("volume.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("volume_hvr.png");
    CCMenuItemSprite *volumeMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    volumeMenuItem->setPosition(ccp(330,150));
    volumeMenuItem->setTag(8);
    
    CCMenu *menu;
    if (DataManager->gameMode==KARCADEMODE)
    {
        menu=CCMenu::create(mainMebnuItem,playMenuItem,restartMenuItem,levelMenuItem,volumeMenuItem, NULL);
    }
    else
    {
        menu=CCMenu::create(mainMebnuItem,playMenuItem,restartMenuItem,volumeMenuItem, NULL);
        playMenuItem->setPosition(ccp(180,150));
        restartMenuItem->setPosition(ccp(240,150));
        volumeMenuItem->setPosition(ccp(300,150));
    }
    transparentBG->addChild(menu,9);
    menu->setPosition(CCPointZero);
    transparentBG->setVisible(false);
}


void SXUIManager::levelCompletedUI()
{
    
  CCSprite  *transparentBG =CCSprite ::create("trsprnt_bg.png");
    this->gameLayer->addChild(transparentBG,7,kLevelCompletedTrnsprtBGTag);
    transparentBG->setPosition(ccp(240,160));
    
    CCSprite *levelCompletedSprite =CCSprite ::create("level_completed_bg.png");
    transparentBG->addChild(levelCompletedSprite);
    levelCompletedSprite->setPosition(ccp(240,160));
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName ("facebook.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName ("facebook_hvr.png");
    CCMenuItemSprite *facebookMenuitem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    facebookMenuitem ->setPosition(ccp(380,227));
    facebookMenuitem->setTag(3);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("twitter.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("twitter_hvr.png");
    CCMenuItemSprite *twitterMenuitem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    twitterMenuitem->setPosition(ccp(410, 227));
    twitterMenuitem->setTag(4);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("nxt.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("nxt_hvr.png");
    CCMenuItemSprite *nextMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    nextMenuItem->setPosition(ccp(190, 65));
    nextMenuItem->setTag(5);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("replay.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("replay_hvr.png");
    CCMenuItemSprite *restatMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    nextMenuItem->setPosition(ccp(250, 65));
    restatMenuItem->setTag(1);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("levelMenu.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("levelMenu_hvr.png");
    CCMenuItemSprite *levelMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    levelMenuItem->setPosition(ccp(310, 65));
    levelMenuItem->setTag(2);
    
    normalSprite=CCSprite::createWithSpriteFrameName ("menu_bt.png");
    selectedSprite=CCSprite::createWithSpriteFrameName ("menu_bt_hvr.png");
    CCMenuItemSprite *mainMenuItem = CCMenuItemSprite::create(normalSprite,selectedSprite,this,menu_selector(SXUIManager::menuCallbacks));
    mainMenuItem->setTag(10);
    mainMenuItem->setPosition(ccp(90,226));
    
    CCMenu *menu = CCMenu::create(nextMenuItem,restatMenuItem,levelMenuItem,facebookMenuitem,twitterMenuitem,mainMenuItem, NULL);
    transparentBG->addChild(menu,2);
    menu->setPosition(CCPointZero);
    
    totalScoreLabel=CCLabelTTF::create("0000", "Arial", 20);
    transparentBG->addChild(totalScoreLabel);
    
       totalScoreLabel->setPosition(ccp(260, 120));
    transparentBG->setVisible(false);
}

#pragma mark-Show You Failed 
void SXUIManager::showYouFailedUI()
{
    char str[10]={};
    sprintf(str, "%d",this->score);
    this-> totalScoreLabel->setString(str);
    CCSprite *sprite=(CCSprite*)MainLayer->getChildByTag(kLevelFailedTrnsprtBGTag);
    sprite->setVisible(true);
    CCDirector::sharedDirector()->pause();
    //MainLayer->unscheduleAllSelectors();
}

#pragma mark-menuCallbacks

void SXUIManager::menuCallbacks(CCObject *Sender)
{
    CCMenuItemSprite *sprite=(CCMenuItemSprite *) Sender;
    switch (sprite->getTag()) {

            break;
            case 1: //replay
            
            DataManager->firstTap=false;
            DataManager->secondTick=1;
            CCDirector::sharedDirector()->resume();
            CCDirector::sharedDirector()->replaceScene(SXMainController::scene());
            break;
            
            case 2: // arcade mode
                   CCDirector::sharedDirector()->replaceScene(SXArcadeScene::scene()) ;
            break;
            
            case 3:
                  break;
            
            
            case 5: // next menu item
            DataManager->currentLevel++;
            CCDirector::sharedDirector()->replaceScene(SXMainController::scene());
            break;
            
            case 21: //pause
            if(CCDirector::sharedDirector()->isPaused()){
                CCDirector::sharedDirector()->resume();
            }
            else{
                CCDirector::sharedDirector()->pause();
            }
            
            break;
            
            case 10: // main menu
            CCDirector::sharedDirector()->replaceScene(SXMainMenu::scene());
            
            break;

        case 101:
            {
                  
            CCSprite  *sprite= (CCSprite*) DataManager->gameLayer->getChildByTag(kResumeTrnsprtBGTag);
            sprite->setVisible(true);
            }
                 
          // main menu
           
            break;
        default:  CCDirector::sharedDirector()->replaceScene(SXMainMenu::scene());

            break;
    }
}
SXUIManager::~SXUIManager(){
    
    CCLog(" uimanager dealloc");
    CC_SAFE_RELEASE_NULL(this->lifeFullArray);

}