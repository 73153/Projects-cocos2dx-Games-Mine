//
//  SXGameManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXGameManager.h"


SXGameManager::SXGameManager(){
    
}


SXGameManager::~SXGameManager(){
    
}