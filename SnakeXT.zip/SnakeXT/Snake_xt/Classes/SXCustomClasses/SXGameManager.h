//
//  SXGameManager.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXGameManager__
#define __Snake_xt__SXGameManager__

#include <iostream>
#include "cocos2d.h"
#import "SXMainController.h"

class SXMainController;
class SXGameManager :public cocos2d::CCObject {
public:
    
    SXGameManager();
    ~SXGameManager();
    
    SXMainController *gameLayer;
};

#endif 
