//
//  SXCustomSprite.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXCustomSprite__
#define __Snake_xt__SXCustomSprite__

#include <iostream>

#include "cocos2d.h"
class SXCustomSprite :public cocos2d::CCSprite{
    
public:
    SXCustomSprite();
    virtual   ~SXCustomSprite();
    
    int type;
    int side;
};

#endif /* defined(__Snake_xt__SXCustomSprite__) */
