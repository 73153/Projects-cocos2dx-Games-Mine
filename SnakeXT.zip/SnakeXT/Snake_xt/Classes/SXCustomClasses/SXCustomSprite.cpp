//
//  SXCustomSprite.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXCustomSprite.h"

SXCustomSprite::SXCustomSprite(){
    
}

SXCustomSprite::~SXCustomSprite(){
    
}