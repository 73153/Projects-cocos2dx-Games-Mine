//
//  SXDataManager.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXDataManager__
#define __Snake_xt__SXDataManager__

#include <iostream>

#include "cocos2d.h"


#include "SXMainController.h"

class SXDataManager {
    
    SXDataManager(void);
    virtual ~SXDataManager(void);

public:
    
    bool init(void);
    static SXDataManager* sharedManager(void);
    
    // var
    SXMainController *gameLayer;
    b2World *world;
    
    
    int currentLevel;
    int gameMode;
    int MaxNoOfBodiesInLevel;
    
    int BGNo;
    int snakeNumber;
    float snakeSpeed;
    bool firstTap;
    int secondTick;
    
};
#endif /* defined(__Snake_xt__SXDataManager__) */
