//
//  SXDataManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXDataManager.h"
static SXDataManager *gSharedManager = NULL;

SXDataManager::SXDataManager(void){}

SXDataManager::~SXDataManager(void){}

SXDataManager* SXDataManager::sharedManager(void) {
    
	SXDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new SXDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
        }
	}
    
	return pRet;
}

bool SXDataManager::init(void) {
    currentLevel=1;
    snakeNumber=4;
    snakeSpeed=2;
    BGNo=1;
    MaxNoOfBodiesInLevel=0;
    firstTap=false;
    secondTick=1;
	return true;
}


