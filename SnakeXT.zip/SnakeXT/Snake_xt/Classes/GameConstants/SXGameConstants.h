//
//  SXGameConstants.h
//  Snake_XT
//
//  Created by i-CRG Labs Virupaksh on 6/6/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include "cocos2d.h"

#define DataManager SXDataManager::sharedManager()

#define SXMainLayer self.gameLayer


typedef enum{
    
    ksnakeMinimumSpeed,
}snakePartType ;

//typedef enum{
//    kSnakeHead ,
//    ksnakeBody ,
//    kObstacle,
//    kBonus,
//}snakePartType;


#define kPLAYMODE "playmode"
#define kLevelCompletedTrnsprtBGTag 1001
#define kLevelFailedTrnsprtBGTag 1002
#define kResumeTrnsprtBGTag 1003

#define kSnakeHead   100
#define ksnakeBody   200
#define kObstacle   300
#define kBonusTag   400
#define kRandomSnakeTag   500
#define kCoinTag 600

#define KBossSnakeTag   100
#define KNonBossSnakeTag 200
#define KStaticbodyTag 1000

#define KJoystickPos   @"joystickPos"
#define KTotalLevelsCompleted @"total level completed "
#define  kBEGINNERMODE   0  // challenge beginner mode
#define KARCADEMODE      2       //arcade  mode


#define kLifeAvailable		@"lifesavailable"

#define kSavePointScore			@"pointscore"





