//
//  SXUtility.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXUtility__
#define __Snake_xt__SXUtility__

#include <iostream>
#include "cocos2d.h"
#include "SXGameConstants.h"
using namespace cocos2d;

class  SXUtility: public cocos2d::CCObject {
    
    
    
public:
    
    static void addGameAnimationsToAnimationCache(const char *pszFileName);
    static CCPoint getRandomPoint();
    static CCPoint  getStraightPointWithRadius(float radius, float inAngle ,CCPoint startPoint);
    static CCPoint  getRotatedPointForPoint(CCPoint inPoint, float inAngle ,CCSize inContentSize, CoordinatePositon inCorner);
    
    static  float getRandomAngle( int min ,int max);
    static float checkTheAngleLimitAngle(float currentAngle);
    static float  getAngleFromVelocity(CCPoint velocity);
    static  float getAngleFromCurrentPoint( CCPoint fromPoint,CCPoint toPoint);
    static  float  getCurrentJoystickAngleForDegree(float inAngle);

    static float getParticalAngleFronAngle(float inAngle);
    static int getRandomNumberBetween(int min, int max);

    static CoordinatePositon getCoordinateForPosition(CCPoint inPosition);

    static BoundrySide getBoundarySide();
    static  CCPoint normalizeVector(CCPoint vector); 
    
    //static void addBoxToSprite(CCSprite *sprite);
};
#endif /* defined(__Snake_xt__SXUtility__) */
