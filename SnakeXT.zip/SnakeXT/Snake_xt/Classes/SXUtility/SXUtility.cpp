//
//  SXUtility.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXUtility.h"
#include "Box2D.h"
#include "SXDataManager.h"
#include "SXObstacle.h"
#include "SXMainController.h"
#include "SXObstaclesManager.h"

#include "CCNumber.h"

#define PTM_RATIO 32

#define SJ_PI 3.14159265359f
#define SJ_PI_X_2 6.28318530718f
#define SJ_PI_X_2 6.28318530718f
#define SJ_RAD2DEG 180.0f/SJ_PI
#define SJ_DEG2RAD SJ_PI/180.0f

void SXUtility::addGameAnimationsToAnimationCache(const char *pszFileName) {
    
    CCAssert( pszFileName, "Invalid texture file name");
    
    const char* path = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath(pszFileName);
    
    //CCLog("path is %s",path);
    CCDictionary *dictAnimationData = CCDictionary::createWithContentsOfFile(path);
    //CCDictionary *dictAnimationData = CCDictionary::create(path);
    
    CCAssert( dictAnimationData, "CCAnimationCache: File could not be found");
    
    // Looping through the items n adding them into cache...
    CCDictElement* pElement = NULL;
   
    CCArray *allkeys=dictAnimationData->allKeys();
    CCObject *obj;
    
    CCARRAY_FOREACH(allkeys, obj) {
        
        CCString *key=(CCString*)obj;
        
        CCDictionary *aAnimationDict=(CCDictionary*)dictAnimationData->valueForKey(key->getCString());
        
        
        CCArray *animFrames = CCArray::create();
        
        int numOfFrames = aAnimationDict->valueForKey("num_of_frames")->intValue();
        const char* prefixName = aAnimationDict->valueForKey("prefix")->getCString();
        
        for (int i = 1; i <= numOfFrames; i++)
        {
            char name[30];
            sprintf(name, "%s%d.png",prefixName,i);
//            CCLog("namei s %s",name);
            
            CCSpriteFrame *frame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name);
            animFrames->addObject(frame);
        }
        
//        const char* key = aAnimationDict->valueForKey("Key")->getCString();
        //CCLog("animations are %s",key);
        
        float animationDelay = aAnimationDict->valueForKey("delay")->floatValue();
        
        CCAnimation *animation = CCAnimation::createWithSpriteFrames(animFrames,animationDelay);
        //CCAnimation *animation = CCAnimation::create(animFrames,animationDelay);
        animFrames->release();
        
        CCAnimationCache::sharedAnimationCache()->addAnimation(animation, key->getCString());
    }
}





CCPoint SXUtility:: getRandomPoint()
{
	CCPoint _point;
	
    int high = 280;  int low = 30;
	
	int xVal = rand() % (high - low + 1) + low;
	
	high = 440;  low = 40;
	
	int yVal = rand() % (high - low + 1) + low;
	
	_point = CCPointMake((float)yVal, (float)xVal);
    
	return _point;
}


float SXUtility::getAngleFromCurrentPoint(CCPoint inCurrentPoint, CCPoint inToPoint) {
    
    CCPoint difference = ccpSub(inToPoint,inCurrentPoint);
    double angle = -1 * (atan2(difference.y, difference.x) * 180 / M_PI + 90) + 180;
    
    if (angle < 0) {
        angle = 360 + angle;
    }
    return abs(angle);
}


float SXUtility:: getCurrentJoystickAngleForDegree(float inAngle){
    float angleDegrees = inAngle-90;
    float cocosAngle = -1 * angleDegrees;
    return cocosAngle;
}

float SXUtility::getAngleFromVelocity(CCPoint velocity){
    
	float dx = velocity.x;
	float dy =velocity.y;
	
	float angle = atan2f(dy, dx); // in radians
	if(angle < 0)
	{
		angle+= SJ_PI_X_2;
	}
	float degrees = angle * SJ_RAD2DEG;
	float angleDegrees = degrees-90;
	float cocosAngle = -1 * angleDegrees;
    return cocosAngle;
}

float SXUtility::getRandomAngle( int min ,int max) {
    
    int high = max;  int low = min;
	
	int xVal = arc4random() % (high - low + 1) + low;
    
	return  xVal;
}

float SXUtility:: getParticalAngleFronAngle( float inAngle){
    

    float angle;
    
    if(inAngle>=45 && inAngle<=90){
        angle=inAngle+10;
        
        if(inAngle<66){
            float diff=66-inAngle;
            angle=angle+diff;
        }
    }
    return angle;
}


#pragma mark - get Posiiton

CCPoint SXUtility::getStraightPointWithRadius(float radius, float inAngle ,CCPoint startPoint)
{
    
    float X = (startPoint.x) - sin(CC_DEGREES_TO_RADIANS(inAngle+180))*radius;
    float Y = (startPoint.y) - cos(CC_DEGREES_TO_RADIANS(inAngle+180))*radius;
    return ccp(X, Y);
}


CCPoint SXUtility:: getRotatedPointForPoint(CCPoint inPoint, float inAngle ,CCSize inContentSize, CoordinatePositon inCorner)
{
    double rad = inAngle*M_PI/180;
    
    if (inCorner == kTopLeft)
    {
        float tX = -(inContentSize.width * cosf(rad) + inContentSize.height * sinf(rad) ) + inPoint.x;
        float tY = -(inContentSize.width * sinf(rad) - inContentSize.height * cosf(rad) ) + inPoint.y;
        return ccp(tX, tY);
    }
    else if (inCorner == kTopRight) {
        float tX = (inContentSize.width * cosf(rad) - inContentSize.height * sinf(rad) ) + inPoint.x;
        float tY = (inContentSize.width * sinf(rad) + inContentSize.height * cosf(rad) ) + inPoint.y;
        return ccp(tX, tY);
    }
    else if (inCorner == kBottomLeft) {
        float tX = -(inContentSize.width * cosf(rad) - inContentSize.height * sinf(rad) ) + inPoint.x;
        float tY = -(inContentSize.width * sinf(rad) + inContentSize.height * cosf(rad) ) + inPoint.y;
        return ccp(tX, tY);
    }
    else if (inCorner == kBottomRight) {
        float tX = (inContentSize.width * cosf(rad) + inContentSize.height * sinf(rad) ) + inPoint.x;
        float tY = (inContentSize.width * sinf(rad) - inContentSize.height * cosf(rad) ) + inPoint.y;
        return ccp(tX, tY);
    }
    return CCPointZero;
}

float SXUtility::  checkTheAngleLimitAngle(float currentAngle)
{
    float finalAngle;
    float angleNew= currentAngle+90;
    if (angleNew<0) {
        angleNew = 360 + angleNew;
    }
    angleNew = (int)angleNew % 360;
    
    finalAngle =360 - ((int)angleNew + 180);
    
    
    return finalAngle;
}


CoordinatePositon SXUtility::getCoordinateForPosition(CCPoint inPosition)
{
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    
    if (inPosition.x<=winSize.width/2&&inPosition.y>winSize.height/2) {
        return kTopLeft;
    }
    else if (inPosition.x>=winSize.width/2&&inPosition.y>winSize.height/2)
    {
        return kTopRight;
    }
    else if (inPosition.x>=winSize.width/2&&inPosition.y<winSize.height/2)
    {
        return kBottomRight;
    }
    else if (inPosition.x<=winSize.width/2&&inPosition.y<winSize.height/2)
    {
        return kBottomLeft;
    }
    return kTopLeft;
}



BoundrySide SXUtility::getBoundarySide() {
    
        int rand = arc4random()%4+1;
        return  BoundrySide(rand);
}

int SXUtility::getRandomNumberBetween(int min, int max)
{
    int toNumber = max + 1;
    int fromNumber = min;
    
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    
    return randomNumber;
}

CCPoint SXUtility::normalizeVector(CCPoint vector) {
        float length=sqrtf(vector.x*vector.x+vector.y*vector.y);
        if (length<0.000001) return ccp(0,1);
        return ccpMult(vector, 1/length);
}
