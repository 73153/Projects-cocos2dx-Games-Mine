//
//  SXEnvironment.cpp
//  Snake_xt
//  
//  Created by Deepthi on 01/02/13.
//
//

#include "SXEnvironmentManager.h"
#include "SXMainController.h"
#include "SXDataManager.h"
#include "SXGameConstants.h"
#include "SXObstaclesManager.h"
#include "SXMainController.h"
#include "SXGameConstants.h"

SXEnvironmentManager::SXEnvironmentManager()
{
    tickCount=1;
}

SXEnvironmentManager::~SXEnvironmentManager()
{
    CCLog(" env manager dealloc");

}

#pragma  mark -update

void SXEnvironmentManager::update()
{
//    CCLog("tickCount=%d ",tickCount);
    tickCount++;
    if(tickCount>0){
        if(tickCount%33==0)
        {
       //     this->addRainParticle();
        }
        if(tickCount%61==0)
        {
          //  this->addSnow();
            
            tickCount=-11;
        }
    }
}

#pragma  mark -Rain particle
//different effects
void SXEnvironmentManager::addRainParticle()
{
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
   
    CCSprite *darkImage = CCSprite::create("darkBg.png");
    darkImage->setPosition(ccp(winsize.width/2,winsize.height/2));
    DataManager->gameLayer->addChild(darkImage,1);
    darkImage->setScaleX(winsize.width/darkImage->getContentSize().width);
    darkImage->setScaleY(winsize.height/darkImage->getContentSize().height);
    
    ccBlendFunc bf = {GL_DST_COLOR,GL_SRC_COLOR};
    darkImage->setBlendFunc(bf);
    darkImage->setColor(ccWHITE);
    
    CCParticleSystemQuad *particle = CCParticleSystemQuad::create("newrain2.plist");
    DataManager->gameLayer->addChild(particle,1,kRainParticleTag);
    particle->setPosition(ccp(winsize.width/2,winsize.height-50));
//    particle->setAngle(-300);
    
    darkImage->runAction(CCSequence::create(CCDelayTime::create(10),CCCallFuncN::create(this, callfuncN_selector(SXEnvironmentManager::removeRainEffect)),NULL));
}

void SXEnvironmentManager::removeRainEffect(CCSprite *inRainDarkSpr){
    DataManager->gameLayer->removeChildByTag(kRainParticleTag, true);
    DataManager->gameLayer->removeChild(inRainDarkSpr, true);
}

#pragma  mark -Snow particle
void SXEnvironmentManager::addSnow()
{
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
    CCParticleSystemQuad *particle = CCParticleSystemQuad::create("SXSnow.plist");
    DataManager->gameLayer->addChild(particle,1,kSnowParticleTag);
    particle->setPosition(ccp(winsize.width/2,winsize.height));
    particle->setOpacityModifyRGB(true);
    particle->runAction(CCSequence::create(CCDelayTime::create(10),CCCallFuncN::create(this, callfuncN_selector(SXEnvironmentManager::removeSnowEffect)),NULL));
}

void SXEnvironmentManager::removeSnowEffect(){
    DataManager->gameLayer->removeChildByTag(kSnowParticleTag, true);
}




