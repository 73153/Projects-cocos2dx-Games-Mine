//
//  SXEnvironmentManager.h
//  Snake_xt
//
//  Created by Deepthi on 01/02/13.
//
//

#ifndef Snake_xt_SXEnvironmentManager_h
#define Snake_xt_SXEnvironmentManager_h

#include <iostream>
#include "SXCustomSprite.h"
#include "cocos2d.h"

using namespace cocos2d;

class SXEnvironmentManager :public cocos2d::CCLayer {
    
public:
    
    SXEnvironmentManager();
    ~SXEnvironmentManager();
    
    void update();
    int tickCount;
    
    void addRainParticle();
    void addSnow();
    
    void removeRainEffect(CCSprite *inRainDarkSpr);
    void removeSnowEffect();

};
#endif
