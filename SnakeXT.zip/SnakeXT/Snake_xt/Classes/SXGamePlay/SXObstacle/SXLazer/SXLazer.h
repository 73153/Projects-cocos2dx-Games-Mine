//
//  SXLazer.h
//  Snake_xt
//
//  Created by Deepthi on 24/01/13.
//
//

#ifndef Snake_xt_SXLazer_h
#define Snake_xt_SXLazer_h

#include <iostream>
#include "cocos2d.h"
#include "SXCustomSprite.h"

using namespace cocos2d;

class SXLazer  :public SXCustomSprite
{

public:
    
    SXLazer();
   ~SXLazer();
        
    SXLazer* spriteWithFrame(const char *pszFileName);
    SXLazer* create(CCSpriteFrame *pSpriteFrame);
    SXLazer* create(const char *pszFileName);
    
    void addLazer();
    void removeLazer(CCObject *obj);

   CCPoint startPoint;
   CCPoint endPoint;
    
    CCSprite *startSprite;
    CCSprite  *endSprite;
};
#endif
