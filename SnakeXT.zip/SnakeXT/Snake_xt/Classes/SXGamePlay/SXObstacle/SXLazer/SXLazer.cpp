//
//  SXLazer.cpp
//  Snake_xt
//
//  Created by Deepthi on 24/01/13.
//
//

#include "SXLazer.h"
#include "SXObstaclesManager.h"
#include "SXDataManager.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"
#include "SXMainController.h"
#include "SXBonusManager.h"
#include "SXUtility.h"
#include "SXGameConstants.h"

#define PTM_RATIO 32
using namespace cocos2d;

SXLazer::SXLazer()
{
    this->startPoint=CCPointZero;
    this->endPoint=CCPointZero;
}

SXLazer::~SXLazer()
{
}

SXLazer* SXLazer ::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    SXLazer *tempSpr = SXLazer::create(pFrame);
    return tempSpr;
}

SXLazer* SXLazer::create(CCSpriteFrame *pSpriteFrame)
{
   SXLazer *pobSprite = new SXLazer();
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

SXLazer* SXLazer::create(const char *pszFileName)
{
    SXLazer *pobSprite = new SXLazer();
    if (pobSprite && pobSprite->initWithSpriteFrameName(pszFileName))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

#pragma  mark - AddingLazer
void SXLazer::addLazer()
{
        this->type=kLaser;
        
        SXSnake *snakeHead =(SXSnake *)DataManager->gameLayer->snakeManager->snake->movableObjects->objectAtIndex(0);
        
        CCPoint possibleLaserPosition;
        float snakeHeadPosition = snakeHead->getPositionX();
        
        if(snakeHeadPosition  >=240)
        {
                possibleLaserPosition.x = DataManager->gameLayer->bonusManager->getRandomNumberBetween(50,240);
                possibleLaserPosition.y = DataManager->gameLayer->bonusManager->getRandomNumberBetween(50,270);
        }
        else if(snakeHeadPosition <=240)
        {
                possibleLaserPosition.x = DataManager->gameLayer->bonusManager->getRandomNumberBetween(250,400);
                possibleLaserPosition.y = DataManager->gameLayer->bonusManager->getRandomNumberBetween(50,270);
        }
        
        DataManager->gameLayer->obstacleManager->isLaserPresent=true;
        
        CCPoint endPoint = CCPointMake(DataManager->gameLayer->bonusManager->getRandomNumberBetween(20, 400),DataManager->gameLayer->bonusManager->getRandomNumberBetween(20, 300));
        
        
        this->startSprite = CCSprite::createWithSpriteFrameName("laserindicator.png");
        DataManager->gameLayer->addChild(this->startSprite,1);
        this->startSprite->setPosition(possibleLaserPosition);
        
        this->endSprite = CCSprite::createWithSpriteFrameName("laserindicator1.png");
        DataManager->gameLayer->addChild(this->endSprite,1);
        
        DataManager->gameLayer->addChild(this,1,kLaser);
        this->setScaleX(0);
        this->setScaleY(0.5);
        this->setAnchorPoint(ccp(0.0,0.5));
        this->setPosition(possibleLaserPosition);
        
        this->startPoint=possibleLaserPosition;
        
        float angle = SXUtility::getAngleFromCurrentPoint(possibleLaserPosition, endPoint)-90;
        this->setRotation(angle);
        
        float end=DataManager->secondTick+50;
        CCPoint currentLaserEndPoint = SXUtility::getStraightPointWithRadius(end, this->getRotation()+90, possibleLaserPosition);
        
        CCRect _mainframe = CCRectMake(5, 05, 480, 320);
        
        if(!_mainframe.containsPoint(currentLaserEndPoint)){
                currentLaserEndPoint=endPoint;
        }
    
        this->endPoint=currentLaserEndPoint;
        
        this->endSprite->setPosition(currentLaserEndPoint);
        
        float distance = ccpDistance(possibleLaserPosition,currentLaserEndPoint);
        
        CCActionInterval *action = CCScaleTo::create(3, distance/this->getContentSize().width,0.5);
        this->runAction(action);
        
        this->runAction(CCSequence::create(CCDelayTime::create(5), CCCallFuncN::create(this, callfuncN_selector(SXLazer::removeLazer)),NULL) );
}

#pragma  mark - Removing laser
void SXLazer::removeLazer(CCObject *obj)
{
    ObstacleManager->isLaserPresent=false;
    MainLayer->removeChild(startSprite, true);
    MainLayer->removeChild(endSprite, true);
    ObstacleManager->toDeleteArray->addObject(this);
 }