//
//  SXWall.h
//  Snake_xt
//
//  Created by Deepthi on 30/01/13.
//
//

#ifndef Snake_xt_SXWall_h
#define Snake_xt_SXWall_h

#include <iostream>
#include "cocos2d.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"


using namespace cocos2d;

class SXWall :public SXCustomSprite
{
public:
    
    SXWall();
    virtual  ~SXWall();
        
    SXWall* spriteWithFrame(const char *pszFileName);

    CCPoint startPoint;
    CCPoint endPoint;
    
    float distance;
    float wallAngle;
    
    CCSprite *startParticle;
    CCSprite *endParticle;
     BoundrySide inBoundry;
    
    BoundrySide getSideForWall();
    void initialiseWall();
    BoundrySide getSide();
    void remove();
    int positionBasedOnTime(BoundrySide inBoundry);
    void removeParticle();
};


#endif
