//
//  SXWall.cpp
//  Snake_xt
//
//  Created by Deepthi on 30/01/13.
//
//

#include "SXWall.h"
#include "SXLazer.h"
#include "SXObstaclesManager.h"
#include "SXDataManager.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"
#include "SXMainController.h"
#include "SXBonusManager.h"
#include "SXUtility.h"
#include "SXGameConstants.h"

#define PTM_RATIO 32
using namespace cocos2d;

SXWall ::SXWall()
{
   this->wallAngle=0;
}

SXWall ::~SXWall()
{
    
}

SXWall* SXWall ::spriteWithFrame(const char *pszFileName )
{
  SXWall *tempSpr =  new SXWall();
  tempSpr->initWithSpriteFrameName(pszFileName);
  tempSpr->type=kWall;
    
  return tempSpr;
}


#pragma mark  - Wall
void SXWall::initialiseWall()
{
    BoundrySide inBoundry= ObstacleManager->getFreeSide(kWall);
    
    this->side=inBoundry;
    DataManager->gameLayer->addChild(this,1,kWall);
    ObstacleManager->obstaclesArray->addObject(this);
    
    int rand = arc4random()%2+1;
    if(inBoundry==kTop)
    {
        if(rand==1)
        {
            startPoint = CCPointMake(5,315);
        }
        else if(rand==2)
        {
            startPoint = CCPointMake(475,315);
            this->wallAngle=180;
        }
    }
    else if(inBoundry==kBottom)
    {
        if(rand==1)
        {
            startPoint = CCPointMake(5,5);
        }
        else if(rand==2)
        {
            startPoint = CCPointMake(475,5);
            this->wallAngle=180;
        }
    }
    else if(inBoundry ==kLeft)
    {
        if(rand==1)
        {
            startPoint = CCPointMake(5,5);
            this->wallAngle=-90;
        }
        else if(rand==2)
        {
            startPoint = CCPointMake(5,315);
            this->wallAngle=90;
        }
    }
    else
    {
        if(rand==1)
        {
            startPoint = CCPointMake(475,5);
            this->wallAngle=-90;
        }
        else if(rand==2)
        {
            startPoint = CCPointMake(475,315);
            this->wallAngle=90;
        }
    }
    
    int wallDistance = this->positionBasedOnTime(inBoundry);
    endPoint=SXUtility::getStraightPointWithRadius(wallDistance,this->wallAngle+90,this->startPoint);

    CCActionInterval *action = CCScaleTo::create(0, wallDistance/this->getContentSize().width,0.7);
    this->runAction(action);
    this->setAnchorPoint(ccp(0,0.5));
    this->setPosition(startPoint);
    this->setRotation(this->wallAngle);
    
  
//    this-> startParticle = CCSprite::createWithSpriteFrameName("laserIndicatorImage.png");
//
//    DataManager->gameLayer->addChild(this->startParticle,1);
//    this-> startParticle->setPosition(startPoint);
//    
//    endParticle = CCSprite::createWithSpriteFrameName("laserIndicator1Image.png");
//    DataManager->gameLayer->addChild(this->endParticle ,1);
//    this->endParticle ->setPosition(endPoint);
    this->runAction(CCSequence::createWithTwoActions(CCDelayTime::create(5), CCCallFuncN::create(this, callfuncN_selector(SXWall::remove))) );
}

#pragma mark - positionBasedOnTimeb
int SXWall::positionBasedOnTime(BoundrySide inBoundry)
{
    float radius;
    if(DataManager->secondTick <=30)
    {
         radius=100;
    }
    else if(DataManager->secondTick>30 && DataManager->secondTick<=60)
    {
        radius=250;
    }
    else
    {
    if(inBoundry==kTop || inBoundry==kBottom)
        
        radius=470;
    else
        
        radius=310;
        
    }
    return radius;
}


#pragma mark - removeWall
void SXWall::remove()
{
 //  this->startParticle ->removeFromParentAndCleanup(true);
  // this->endParticle ->removeFromParentAndCleanup(true);
   
  //  this->stopAllActions();
    this->removeFromParentAndCleanup(true);
       
    ObstacleManager->toDeleteArray->addObject(this);
}


