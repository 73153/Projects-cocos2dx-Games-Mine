//
//  SXObstacle.h
//  Snake_xt
//
//  Created by Pavitra on 03/01/13.
//
//

#ifndef __Snake_xt__SXObstacle__
#define __Snake_xt__SXObstacle__

#include <iostream>
#include "cocos2d.h"
#include "SXGameConstants.h"
#include "SXCustomSprite.h"

using namespace cocos2d;
class SXObstacle  :public SXCustomSprite
{
public:
    SXObstacle();
    virtual  ~SXObstacle();
        
    SXObstacle* spriteWithFrame(const char *pszFileName ,CCPoint position);
    SXObstacle* create(CCSpriteFrame *pSpriteFrame,CCPoint position);
    void addBoxToSprite(SXObstacle *obstcle ,const char  *pSpriteFrame);
        
    void runAnimation();
    bool isRunningAnimation;
};

class SXMovingObstacles :public SXObstacle
{
    
public:
    CCPoint moveToPoint;
    BoundrySide side;
    int currentAngle;
    CCRect mainFrame;
    
    SXMovingObstacles();
    virtual  ~SXMovingObstacles();
        
    SXMovingObstacles* spriteWithFrame(const char *pszFileName ,CCPoint position);
    SXMovingObstacles* create(CCSpriteFrame *pSpriteFrame,CCPoint position);
    void addBoxToSprite(SXMovingObstacles *obstcle ,const char  *pSpriteFrame);
    
    void update();
    void getRandomAngle();
    void callUpdate();
    
    void addMovingObstacles();
    void initialiseMovingObstcale();
    void remove();
    void removeAlert();
};

class SXRandomObstacles :public SXObstacle
{
    
public:
    SXRandomObstacles();
    virtual  ~SXRandomObstacles();
        
    CCPoint moveToPoint;
        
    SXRandomObstacles* spriteWithFrame(const char *pszFileName);
    void addBoxToSprite(SXRandomObstacles *obstcle ,const char  *pSpriteFrame);
};


#endif /* defined(__Snake_xt__SXObstacle__) */

