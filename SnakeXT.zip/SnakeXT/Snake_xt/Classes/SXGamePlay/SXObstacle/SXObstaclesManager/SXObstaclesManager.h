//
//  SXObstaclesManager.h
//  Snake_xt
//
//  Created by Pavitra on 07/01/13.
//
//

#ifndef __Snake_xt__SXObstaclesManager__
#define __Snake_xt__SXObstaclesManager__

#include <iostream>
#include "SXGameManager.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXWheel.h"


class  SXGameManager;
class  SXWheel;
class  SXTrap;

class SXObstaclesManager :public SXGameManager{
    public:
    SXObstaclesManager();
    ~SXObstaclesManager();
        
        SXWheel *wheel;
        SXTrap  *trap;
    
    void createObstacle();
    
    void  checkCollision ( SXCustomSprite *spriteA,SXCustomSprite*spriteB);
    void checkCollision();
    void checkCollisionIthLaser();
    void checkCollisionWithRandonSnake();
    void checkCollisionWithWall();

    // get free side
    BoundrySide  getFreeSide(int type);
    
    void clear();

    void runCollisionEffect(SXCustomSprite *sprite);
    void removeObstacle(CCObject *obj);
    void removeAllObstacle();
    
    // fence
    void removeFence(CCObject *Sender);
    
    CCArray *toDeleteArray;
    CCArray *obstaclesArray;
    
    bool isLaserPresent;
    bool isRandomSnakePresent;
    bool isWallPresent;
    
    //  entry timers
    // movable obstacle
    
    int movingObstacleEntryTime;
    int movingObstcaleRepeatTime;
    int movableObstacleCount;
    int noOfMovableObstacleCount;
    void createMovingObstcale();
    
    //wall
    int wallEntryTime;
    int wallRepeatTime;
    int noOfWall;
    int wallCount;
    void createWall();

    // random snake
    int randomSnakeEntryTime;
    int randomSnakeRepeatTime;
    int randomSnakeCount;
    int noOfRandomSnake;
    void createRandomSnake();
        
        char a[20];
        int rand;
    
    int randomObstacleEntryTime;
    int randomObstacleRepeatTime;
    
    int laserEntryTime;
    int laserrepeatTime;
    
    
    int wheelEntryTime;
    int wheelrepeatTime;
    
    int trapEntryTime;
    int traprepeatTime;
    
    
};

#endif /* defined(__Snake_xt__SXObstaclesManager__) */
