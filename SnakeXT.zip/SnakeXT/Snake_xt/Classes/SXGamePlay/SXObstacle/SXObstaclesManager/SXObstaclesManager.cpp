
//
//  SXObstaclesManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 07/01/13.
//
//
#include "SimpleAudioEngine.h"

#include "SXObstaclesManager.h"
#include "SXSnakeManager.h"
#include "SXBonusManager.h"
#include "SXCollisionManager.h"
#include "SXBackgroundManager.h"

#include "SXDataManager.h"
#include "SXGameConstants.h"
#include "SXUtility.h"
#include "CCNumber.h"

#include "SXObstacle.h"
#include "SXTunnel.h"
#include "SXLazer.h"
#include "SXMissile.h"
#include "SXBomb.h"
#include "SXRandomSnake.h"
#include "SXWall.h"
#include "SXWheel.h"

#include "SXBonus.h"

#include "SXSnakeBody.h"
#include "SXSnakeEffects.h"

SXObstaclesManager::SXObstaclesManager(){
    
    const char* path = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("SXTimerPlist.plist");
    
    //CCLog("path is %s",path);
    CCArray *AllTimerData = CCArray::createWithContentsOfFile(path);
    
    for (int i=0; i<5; i++) {
        CCDictionary *sliderDefaultTimeArray=(CCDictionary*)AllTimerData->objectAtIndex(i);
        
        CCString *entryTime=(CCString*)sliderDefaultTimeArray->valueForKey(" entryTime");
        CCString *repeatTime=(CCString*)sliderDefaultTimeArray->valueForKey("repeatTime");
        
        if(i==0){
            this->movingObstacleEntryTime=entryTime->intValue();
            this->movingObstcaleRepeatTime=repeatTime->intValue();
        }
        else if(i==1){
            this->randomObstacleEntryTime=entryTime->intValue();;
            this->randomObstacleRepeatTime=repeatTime->intValue();
        }
        else if(i==2){
            this->wallEntryTime=entryTime->intValue();;
            this->wallRepeatTime=repeatTime->intValue();
        }
        else if(i==3){
            this->laserEntryTime=entryTime->intValue();;
            this->laserrepeatTime=repeatTime->intValue();
        }
        else if(i==4){
            this->randomSnakeEntryTime=entryTime->intValue();;
            this->randomSnakeRepeatTime=repeatTime->intValue();
        }
    }
    
    this->randomSnakeCount=0;
    this->noOfRandomSnake=0;
    this->movableObstacleCount=0;
    this->noOfWall=0;
    this->wallCount=0;
    
    this->wheelEntryTime=13;
    this->wheelrepeatTime=20;
    
    this->trapEntryTime=43;
    this->traprepeatTime=0;
    
    this->toDeleteArray=CCArray::create();
    this->toDeleteArray->retain();
    
    this->obstaclesArray=CCArray::create();
    this->obstaclesArray->retain();
    
    this->gameLayer=DataManager->gameLayer;
    this->isLaserPresent=false;
    this->isRandomSnakePresent=false;
    this->isWallPresent=false;
}

#pragma mark- Creating obstacle
void SXObstaclesManager::createObstacle()
{
    if(DataManager->secondTick%43==0)
    {
        
        CCSprite *sprite=CCSprite::createWithSpriteFrameName("fence_1.png");
        MainLayer->addChild(sprite,0,1111);
        sprite->setPosition(SXUtility::getRandomPoint());
        
        CCParticleSystemQuad *fencePartical=CCParticleSystemQuad::create("SXFencePartical.plist");
        MainLayer->addChild(fencePartical,1,kFenceParticalTag);
        fencePartical->setPosition(sprite->getPosition());
        
        
        CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation = animCache->animationByName("Fence");
        CCAnimate *animN = CCAnimate::create(animation);
        sprite->runAction(animN);
        
         sprite->runAction(CCSequence::createWithTwoActions(CCDelayTime::create(5), CCCallFuncN::create(this, callfuncN_selector(SXObstaclesManager::removeFence))) );
    }
    
    if(DataManager->secondTick==trapEntryTime)
    {
        trapEntryTime=trapEntryTime+traprepeatTime;
        SXTrap *wheel = wheel->spriteWithFrame("wheelObstacle.png");
        wheel->type=kTrap;
    }
    
    if(DataManager->secondTick==this->wheelEntryTime)
    {
        wheelEntryTime=wheelEntryTime+wheelrepeatTime;
        SXWheel *wheel = wheel->spriteWithFrame("SawWheel.png");
        DataManager->gameLayer->addChild(wheel);
    }
    
    if(DataManager->secondTick==this->movingObstacleEntryTime) {     // moving obstacle
        this->movingObstacleEntryTime=this->movingObstacleEntryTime+this->movingObstcaleRepeatTime;
        
      //  this->createMovingObstcale();
        
        if(this->noOfMovableObstacleCount!=0) {
            int limit=this->movableObstacleCount/this->noOfMovableObstacleCount;
            if(limit>=4){
                limit=3;
            }
            for(int i=0;i<limit;i++){
               // this->createMovingObstcale();
            }
             this->movableObstacleCount++;
        }
    }
    
    if(DataManager->secondTick==this->randomObstacleEntryTime) {     // random  obstacle
        this->randomObstacleEntryTime=this->randomObstacleEntryTime+this->randomObstacleRepeatTime;
        SXRandomObstacles *obstacle=obstacle->spriteWithFrame("Piedra2.png");
        obstacle->type=kObstacle;
        DataManager->gameLayer->addChild(obstacle,1);
        CCScaleTo *action2=CCScaleTo::create(7, 1);
        this->obstaclesArray->addObject(obstacle);
        
        CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXObstaclesManager::removeObstacle));
        obstacle->runAction(CCSequence::createWithTwoActions(action2,callback));
    }
    
    if(DataManager->secondTick==this->wallEntryTime) {   // adding wall
        this->wallEntryTime=this->wallEntryTime+this->wallRepeatTime;
        this->createWall();
        
        
        if(this->noOfWall!=0)
        {
            
            int limit=this->wallCount/this->noOfWall;
            if(limit>4){
                limit=4;
            }
            for(int i=0;i<limit;i++){
                this->createWall();
            }
            
            this->wallCount++;
        }
    }
    
    if(DataManager->secondTick==this->laserEntryTime) {  //  adding  laser
        this->laserEntryTime=this->laserEntryTime+this->laserrepeatTime;
        SXLazer *laser=laser->spriteWithFrame("laser.png");
        laser->addLazer();
        this->obstaclesArray->addObject(laser);
    }
    
    if(DataManager->secondTick==this->randomSnakeEntryTime) {   // adding random snake
        this->randomSnakeEntryTime=this->randomSnakeEntryTime+this->randomSnakeRepeatTime;
          this->createRandomSnake();
        if(this->noOfRandomSnake!=0) {
            int limit=this->randomSnakeCount/this->noOfRandomSnake;
            if(limit>=4){
                limit=3;
            }
            for(int i=0;i<limit;i++){
                this->createRandomSnake();
            }
            
            this->randomSnakeCount++;
        }
    }
}

void SXObstaclesManager::createMovingObstcale(){
    SXMovingObstacles *obstacle=obstacle->spriteWithFrame("Piedra2", ccp(-20, 160));
    obstacle->initialiseMovingObstcale();
    obstacle->type=kObstacle;
}

void SXObstaclesManager:: createWall(){
    SXWall *Wall=Wall->spriteWithFrame("Wall.png");
    Wall->initialiseWall();
}

void SXObstaclesManager::createRandomSnake()
{
    rand = SXUtility::getRandomNumberBetween(1,3);
    SXRandomSnake *randonSnake=randonSnake->createWithSpriteFrameName();
     this->gameLayer->addChild(randonSnake,1,kRandomSnake);
    randonSnake->initialiseRandomSnake();
   
        for (int i=0; i<13; i++)
    {
         char a[20]={};
        sprintf(a,"Body%d.png",rand);
        SXSnakeBody *body=body->spriteWithFrame(a);
        randonSnake->movableObjects->addObject(body);
        randonSnake->addChild(body);
    }
    randonSnake->schedule(schedule_selector(SXRandomSnake::update));
}

#pragma mark- checkCollision
void SXObstaclesManager::runCollisionEffect(SXCustomSprite *sprite) {
    
    SXObstacle  *obstacle=(SXObstacle*)sprite;
    if(obstacle->getTag()==2222) {
        if(obstacle->getScale()<=0.6)
        {
            return;
        }
    }

    if(SnakeManager->snake->isFuryModeEnabled)
    {
        obstacle->runAnimation();

        CCDelayTime *delay=CCDelayTime::create(0.5);
        obstacle->runAction(CCSequence::createWithTwoActions(delay, CCCallFuncN::create(this, callfuncN_selector(SXObstaclesManager::removeObstacle))));
    }
    
    else if(Snake->snakeEffects->isSheildOn){
        
        ObstacleManager->toDeleteArray->addObject(obstacle);
        CCSprite *sprite=(CCSprite*)Snake->getChildByTag(1);
        Snake->snakeEffects->removeShieldEffect(sprite);
    }
    
    else {
        SnakeManager->snake->snakeEffects->runHitEffect();
    }
}

#pragma mark - Fence
void SXObstaclesManager::removeFence( CCObject *Sender){
    
    CCSprite *fence=(CCSprite*)Sender;
    MainLayer->removeChild(fence);
    
    MainLayer->removeChildByTag(kFenceParticalTag);
    
    
}

#pragma mark- RemoveObstacle

void SXObstaclesManager::removeObstacle(CCObject *obj)  {
    SXObstacle *obst=(SXObstacle*)obj;
    this->toDeleteArray->addObject(obst);
}

void SXObstaclesManager::removeAllObstacle()  // when snake take remove all obstacle bonus 
{
    CCObject *obj;
    CCARRAY_FOREACH(this->obstaclesArray, obj)
    {
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        
        if(sprite->type==kWall)
        {
            SXWall *Wall=(SXWall*)sprite;
            Wall->remove();
        }
        else if (sprite->type==kLaser) {
            SXLazer *laser=(SXLazer*)sprite;
            laser->removeLazer(laser);
        }
        
        else  if(sprite->type==kRandomSnake) {
            MainLayer->removeChildByTag(kAlertTagForRAndomSnake);
            MainLayer->removeChild(sprite);
        }
        
        else
            this->toDeleteArray->addObject(sprite);
    }
}

#pragma mark- get Free Side

BoundrySide SXObstaclesManager::getFreeSide(int type) {  
    
    cocos2d_extensions::CCNumber<int> *intOne = cocos2d_extensions::CCNumber<int>::numberWithValue(1);
    cocos2d_extensions::CCNumber<int> *intTwo = cocos2d_extensions::CCNumber<int>::numberWithValue(2);
    cocos2d_extensions::CCNumber<int> *intThree = cocos2d_extensions::CCNumber<int>::numberWithValue(3);
    cocos2d_extensions::CCNumber<int> *intFour = cocos2d_extensions::CCNumber<int>::numberWithValue(4);
    CCArray *freeSidesArr = CCArray::create();
    freeSidesArr->retain();
    
    freeSidesArr->addObject(intOne);
    freeSidesArr->addObject(intTwo);
    freeSidesArr->addObject(intThree);
    freeSidesArr->addObject(intFour);
    
    CCObject *obj;
    
    CCARRAY_FOREACH(this->obstaclesArray, obj)
    {
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
       
        
        if(sprite->type==type)
        {
            switch (type) {
                case kWall:{
                    SXWall    *sprite=(SXWall*)obj;
                    
                    if(sprite->side==kTop) {
                        freeSidesArr->removeObject(intOne);
                    }
                    else if(sprite->side==kBottom){
                        freeSidesArr->removeObject(intTwo);
                    }
                    else if(sprite->side==kLeft){
                        freeSidesArr->removeObject(intThree);
                    }
                    else if(sprite->side==kRight){
                        freeSidesArr->removeObject(intFour);
                    }
                }
                    break;
                    
                case kRandomSnake:
                {
                    SXRandomSnake    *sprite=(SXRandomSnake*)obj;
                    if(sprite->side==kTop){
                        freeSidesArr->removeObject(intOne);
                    }
                    else if(sprite->side==kBottom){
                        freeSidesArr->removeObject(intTwo);
                    }
                    else if(sprite->side==kLeft){
                        freeSidesArr->removeObject(intThree);
                    }
                    else if(sprite->side==kRight){
                        freeSidesArr->removeObject(intFour);
                    }
                }
                    
                    break;
                case kObstacle:
                {
                    SXMovingObstacles  *sprite=(SXMovingObstacles*)obj;
                    if(sprite->side==kTop){
                        freeSidesArr->removeObject(intOne);
                    }
                    else if(sprite->side==kBottom){
                        freeSidesArr->removeObject(intTwo);
                    }
                    else if(sprite->side==kLeft){
                        freeSidesArr->removeObject(intThree);
                    }
                    else if(sprite->side==kRight){
                        freeSidesArr->removeObject(intFour);
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
    }
    
    if(freeSidesArr->count()!=0){
    cocos2d_extensions::CCNumber<int > * rand1=(cocos2d_extensions::CCNumber<int> *)freeSidesArr->objectAtIndex(arc4random()% freeSidesArr->count());
        return BoundrySide(rand1->getValue());
    }
    CC_SAFE_RELEASE(freeSidesArr);
    
    return BoundrySide(1);
}

#pragma mark- Clear

void SXObstaclesManager::clear() {
    CCObject *obj;
    CCARRAY_FOREACH(this->toDeleteArray, obj){
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        this->obstaclesArray->removeObject(sprite);
        if(sprite->type==kObstacle){
            DataManager->gameLayer->removeBody(sprite);
        }
        DataManager->gameLayer->removeChild(sprite);
    }
    toDeleteArray->removeAllObjects();
}

SXObstaclesManager::~SXObstaclesManager(){
    CC_SAFE_RELEASE(this->toDeleteArray);
    CC_SAFE_RELEASE(this->obstaclesArray);
}
