//
//  SXWheel.cpp
//  Snake_xt
//
//  Created by Deepthi on 04/03/13.
//
//

#include "SXWheel.h"
#include "SXGameConstants.h"
#include "SXDataManager.h"
#include "SXObstaclesManager.h"
#include "SXUtility.h"
#include "SXBonusManager.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"

SXWheel* SXWheel ::spriteWithFrame(const char *pszFileName) {
        
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
        CCAssert(pFrame != NULL, msg);
        SXWheel *tempSpr = SXWheel::create(pFrame);
        return tempSpr;
}

SXWheel* SXWheel::create(CCSpriteFrame *pSpriteFrame)
{
        SXWheel *pobSprite = new SXWheel();
        if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

SXWheel* SXWheel::create(const char *pszFileName)
{
        SXWheel *pobSprite = new SXWheel();
        if (pobSprite && pobSprite->initWithSpriteFrameName(pszFileName))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

SXWheel::SXWheel()
{
        this->type=kWheel;
        this->setTag(kWheel);
        BoundrySide inBoundry=SXUtility::getBoundarySide();
        this->side=inBoundry;
        
        CCSprite *alertImage=CCSprite::createWithSpriteFrameName("alertImage.png");
        MainLayer->addChild(alertImage,1,kAlertTagForWheel);
      //  alertImage->setPosition(SXUtility::getRandomPoint());
        
        CCBlink *blink=CCBlink::create(2, 5);
        alertImage->runAction(blink);
        
        CCLabelTTF *Label=CCLabelTTF::create(" Wheel ", "Arial", 15);
        alertImage->addChild(Label);
        Label->setPosition(ccp(alertImage->getContentSize().width/2,alertImage->getContentSize().height+10));
        
        if(side==kTop)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, 350));
                mainFrame = CCRectMake(0,0, 480, 360);
                alertImage->setPosition(CCPoint(this->getPosition().x, 280));
        }
        
        else if(side==kBottom)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, -20));
                mainFrame = CCRectMake(0, -30,480, 360);
                   alertImage->setPosition(CCPoint(this->getPosition().x, 20));
        }
        
        else if(side ==kLeft)
        {
                this->setPosition(ccp(-20,SXUtility::getRandomPoint().y ));
               mainFrame = CCRectMake(-20, 0, 520, 320);
                 alertImage->setPosition(CCPoint(20, this->getPosition().y));
          }
        
        else  // right
        {
                this->setPosition(ccp(500,SXUtility::getRandomPoint().y ));
                mainFrame = CCRectMake(-10, -10, 530, 320);
                  alertImage->setPosition(CCPoint(460, this->getPosition().y));
               
       }
 
        CCCallFuncN *callback = CCCallFuncN::create(this,callfuncN_selector(SXWheel::removeAlert));
        CCCallFuncN *rotate = CCCallFuncN::create(this,callfuncN_selector(SXWheel::rotateWheel));
        CCCallFuncN *remove = CCCallFuncN::create(this,callfuncN_selector(SXWheel::callUpdate));
        //CCFiniteTimeAction *action = CCSpawn::create(move,rotate);
        CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(2),callback,remove,rotate,NULL);
        alertImage->runAction(seq);
}
void SXWheel::removeAlert()
{
        MainLayer->removeChildByTag(kAlertTagForWheel);
}

void SXWheel::rotateWheel()
{
        CCRotateBy *rotate = CCRotateBy::create(0.1, 180);
        CCRepeatForever *rotate1=CCRepeatForever::create(rotate);
        this->runAction( rotate1);
}

void SXWheel::update()
{
    if(!Snake->isFreezewrEnabled) {
        
        float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*3;
        float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*3;
        this->setPosition(CCPointMake(X, Y));
        if(!mainFrame.containsPoint(this->getPosition()))
        {
            this->removeWheel();
        }
    }
}

void SXWheel::getRandomAngle()
{
        if(this->side==kBottom)
        {
                if(this->getPosition().x<=240)
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(0, 45);
                }
                else
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(270, 360);
                        
                }
        }
        
        else if(this->side==kTop)
        {
                
                if(this->getPosition().x<=240)
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(125, 180);
                }
                else
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(180, 235);
                        
                }
        }
        
        else  if(this->side==kLeft)
        {
                
                if(this->getPosition().y<=160)
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(45, 90);
                }
                else{
                        this->currentAngle=BonusManager->getRandomNumberBetween(90, 140);
                }
        }
        
        else  if(this->side==kRight)
        {
                
                if(this->getPosition().y<=160)
                {
                        this->currentAngle=BonusManager->getRandomNumberBetween(270, 315);
                }
                else{
                        this->currentAngle=BonusManager->getRandomNumberBetween(225, 260);
                        
                }
        }
}

void SXWheel::callUpdate()
{
        this->getRandomAngle();
        this->schedule(schedule_selector(SXWheel::update));
}

void SXWheel::removeWheel()
{
        MainLayer->removeChildByTag(kWheel);
}

SXWheel::~SXWheel()
{
        
}

SXTrap::SXTrap()
{
        CCSprite *alertImage=CCSprite::createWithSpriteFrameName("alertImage.png");
        MainLayer->addChild(alertImage,1,kAlertTagForTrap);
         alertImage->setPosition(SXUtility::getRandomPoint());
      
        CCBlink *blink=CCBlink::create(2, 5);
        alertImage->runAction(blink);
        
        CCLabelTTF *Label=CCLabelTTF::create(" Trap ", "Arial", 15);
        alertImage->addChild(Label);
        Label->setPosition(ccp(alertImage->getContentSize().width/2,alertImage->getContentSize().height+10));
        
        
        this->setPosition(alertImage->getPosition());
        this->setTag(kTrap);
        this->setScale(0);

        
        CCFiniteTimeAction *callBack = CCCallFuncN::create(this,callfuncN_selector(SXTrap::removeAlert));
         DataManager->gameLayer->addChild(this);
        CCFiniteTimeAction *callBackOne = CCCallFuncN::create(this,callfuncN_selector(SXTrap::remove));
        this->runAction(CCSequence::create(CCDelayTime::create(2),callBack,CCDelayTime::create(10),callBackOne,NULL));

}
void SXTrap::runAnimation()
{

        CCAnimationCache *animCache2 = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation2 = animCache2->animationByName("Trap");
        //animation2->setRestoreOriginalFrame(1);
        CCAnimate *animN2 = CCAnimate::create(animation2);
        //animN2->setTag(1);
        this->runAction((animN2));

}

SXTrap* SXTrap::create(const char *pszFileName)
{
        SXTrap *pobSprite = new SXTrap();
        if (pobSprite && pobSprite->initWithSpriteFrameName(pszFileName))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

SXTrap* SXTrap ::spriteWithFrame(const char *pszFileName)
{
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
        CCAssert(pFrame != NULL, msg);
        SXTrap *tempSpr = SXTrap::create(pFrame);
        return tempSpr;
}
SXTrap* SXTrap::create(CCSpriteFrame *pSpriteFrame)
{
        SXTrap *pobSprite = new SXTrap();
        if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

void SXTrap::removeAlert()
{
        MainLayer->removeChildByTag(kAlertTagForTrap);
        CCScaleTo *action = CCScaleTo::create(4,1 );
        this->runAction(action);
      
       
}
void SXTrap::remove()
{
     MainLayer->removeChildByTag(kTrap);
}

SXTrap::~SXTrap()
{
        
}