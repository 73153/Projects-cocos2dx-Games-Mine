//
//  SXWheel.h
//  Snake_xt
//
//  Created by Deepthi on 04/03/13.
//
//

#ifndef Snake_xt_SXWheel_h
#define Snake_xt_SXWheel_h

#include <iostream>
#include "cocos2d.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXObstaclesManager.h"


using namespace cocos2d;

class SXWheel :public SXCustomSprite
{
public:
        
        SXWheel();
      ~SXWheel();
  
        SXWheel* spriteWithFrame(const char *pszFileName);
        SXWheel* create(CCSpriteFrame *pSpriteFrame);
        SXWheel* create(const char *pszFileName);
        CCRect mainFrame;
        CCPoint moveToPoint;
        
        void rotateWheel();
        void removeWheel();
        void update();
        void callUpdate();
        void getRandomAngle();
        void removeAlert();
        
        float currentAngle;
};

class SXTrap:public SXCustomSprite{
public:
        SXTrap();
        ~SXTrap();
        SXTrap* spriteWithFrame(const char *pszFileName);
         SXTrap* create(const char *pszFileName);
              SXTrap* create(CCSpriteFrame *pSpriteFrame);
        void remove();
        void removeAlert();
        void runAnimation();
        bool isrunningAnimation;
        
};
#endif
