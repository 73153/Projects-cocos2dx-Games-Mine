//
//  SXObstacle.cpp
//  Snake_xt
//
//  Created by Pavitra on 03/01/13.
//
//

#include "SimpleAudioEngine.h"
#include "SXObstacle.h"

#include "Box2D.h"
#include "GB2ShapeCache.h"

#include "SXDataManager.h"
#include "SXObstaclesManager.h"
#include "SXDataManager.h"
#include "SXBonusManager.h"
#include "SXSnakeManager.h"

#include "SXSnake.h"

#include "SXGameConstants.h"
#include "SXUtility.h"

using namespace cocos2d;

#pragma mark - sxobstacle
SXObstacle::SXObstacle()
{
    isRunningAnimation=false;
}

SXObstacle::~SXObstacle()
{
    
}

SXObstacle* SXObstacle ::spriteWithFrame(const char *pszFileName, CCPoint position )
{
        char str[20]={};
        sprintf(str, "%s.png",pszFileName);
        
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(str);
        
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s.png", pszFileName);
        
        CCAssert(pFrame != NULL, msg);
        
        SXObstacle *tempSpr = SXObstacle::create(pFrame,position);
        return tempSpr;
}

void SXObstacle::addBoxToSprite(SXObstacle *obstacle,const char  *pSpriteFrame )
{
    b2BodyDef spriteBodyDef;
    spriteBodyDef.type = b2_dynamicBody;
    spriteBodyDef.position.Set(obstacle->getPosition().x,
                               obstacle->getPosition().y);
    spriteBodyDef.userData = obstacle;
    b2Body *spriteBody = DataManager-> gameLayer->world->CreateBody(&spriteBodyDef);
    gbox2d::GB2ShapeCache::sharedGB2ShapeCache()->addFixturesToBody(spriteBody, pSpriteFrame);
}

SXObstacle* SXObstacle::create(CCSpriteFrame *pSpriteFrame ,CCPoint position )
{
    SXObstacle *pobSprite = new SXObstacle();
    pobSprite->type=kObstacle;
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

#pragma mark- Animation
void SXObstacle::runAnimation()      //when snake with furry mode hits obstacle
{
        CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation = animCache->animationByName("Obstacle");
        CCAnimate *animN = CCAnimate::create(animation);
        if(!isRunningAnimation)
        {
                isRunningAnimation=true;
                this->runAction(animN);
       // CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("clay-rock.caf");
        }
}

#pragma mark - sxmoving obstacle
SXMovingObstacles* SXMovingObstacles ::spriteWithFrame(const char *pszFileName, CCPoint position )
{
        char str[20]={};
        sprintf(str, "%s.png",pszFileName);
        
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(str);
        
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s.png", pszFileName);
        
        CCAssert(pFrame != NULL, msg);
        
        SXMovingObstacles *tempSpr = SXMovingObstacles::create(pFrame,position);
        return tempSpr;
}

void SXMovingObstacles::addBoxToSprite(SXMovingObstacles *obstacle,const char  *pSpriteFrame )
{
        b2BodyDef spriteBodyDef;
        spriteBodyDef.type = b2_dynamicBody;
        spriteBodyDef.position.Set(obstacle->getPosition().x,
                                   obstacle->getPosition().y);
        spriteBodyDef.userData = obstacle;
        b2Body *spriteBody = DataManager-> gameLayer->world->CreateBody(&spriteBodyDef);
        gbox2d::GB2ShapeCache::sharedGB2ShapeCache()->addFixturesToBody(spriteBody, pSpriteFrame);
}

SXMovingObstacles* SXMovingObstacles::create(CCSpriteFrame *pSpriteFrame ,CCPoint position )
{
        SXMovingObstacles *pobSprite = new SXMovingObstacles();
        pobSprite->type=kObstacle;
        if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

SXMovingObstacles::SXMovingObstacles()
{
    this->currentAngle=0;
   // DataManager->gameLayer->addChild(this,1);
    ObstacleManager->obstaclesArray->addObject(this);
    this->addBoxToSprite(this,"Piedra2");
}
SXMovingObstacles::~SXMovingObstacles()
{
        
}
void  SXMovingObstacles::initialiseMovingObstcale()
{
     CCSprite *alertImage=CCSprite::createWithSpriteFrameName("stone_icon.png");
     MainLayer->addChild(alertImage,1,kAlertTagForMovingObstacle);

     CCBlink *blink=CCBlink::create(2, 5);
     alertImage->runAction(blink);
        
    CCCallFuncN *callbackOne=CCCallFuncN::create(this, callfuncN_selector(SXMovingObstacles::removeAlert));
    CCCallFuncN *callbackTwo=CCCallFuncN::create(this, callfuncN_selector(SXMovingObstacles::callUpdate));
    alertImage->runAction(CCSequence::create(CCDelayTime::create(3),callbackOne,callbackTwo,NULL));
        
    BoundrySide inBoundry=SXUtility::getBoundarySide();
    this->side=inBoundry;
     if(side==kTop)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, 350));
                this->currentAngle=180;
                mainFrame = CCRectMake(0,0, 480, 360);
                alertImage->setPosition(CCPoint(this->getPosition().x, 280));
        }
        
        else if(side==kBottom)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, -20));
                this->currentAngle=0;
                mainFrame = CCRectMake(0, -30,480, 360);
                alertImage->setPosition(CCPoint(this->getPosition().x, 20));
        }
        
        else if(side ==kLeft)
        {
                this->setPosition(ccp(-20,SXUtility::getRandomPoint().y ));
                this->currentAngle=90;
                mainFrame = CCRectMake(-20, 0, 520, 320);
                alertImage->setPosition(CCPoint(20, this->getPosition().y));
        }
        
        else  // right
        {
                this->setPosition(ccp(500,SXUtility::getRandomPoint().y ));
                this->currentAngle=270;
                mainFrame = CCRectMake(-10, -10, 530, 320);
                alertImage->setPosition(CCPoint(460, this->getPosition().y));
        }
    }

void SXMovingObstacles::update()
{
    if(!Snake->isFreezewrEnabled){
        float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*.5;
        float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*.5;
        this->setPosition(CCPointMake(X, Y));
        if(!mainFrame.containsPoint(this->getPosition()))
        {
            this->remove();
        }
    }
}

void SXMovingObstacles::getRandomAngle()
{
    if(this->side==kBottom)
    {
        if(this->getPosition().x<=240)
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(0, 45);
        }
        else
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(270, 360);

        }
    }
    
    else if(this->side==kTop)
    {
        
        if(this->getPosition().x<=240)
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(125, 180);
        }
        else
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(180, 235);
            
        }
    }

   else  if(this->side==kLeft)
   {
        
        if(this->getPosition().y<=160)
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(45, 90);
        }
        else{
            this->currentAngle=BonusManager->getRandomNumberBetween(90, 140);
        }
    }

   else  if(this->side==kRight)
   {
        
        if(this->getPosition().y<=160)
        {
            this->currentAngle=BonusManager->getRandomNumberBetween(270, 315);
        }
        else{
            this->currentAngle=BonusManager->getRandomNumberBetween(225, 260);
            
        }
    }
}

void SXMovingObstacles::callUpdate()
{
        this->getRandomAngle();
        this->schedule(schedule_selector(SXMovingObstacles::update));
}

#pragma  mark - remove
void SXMovingObstacles::remove()
{
        ObstacleManager->toDeleteArray->addObject(this);
}

void SXMovingObstacles::removeAlert()
{
        MainLayer->removeChildByTag(kAlertTagForMovingObstacle);
}

#pragma mark- Random obstacle
SXRandomObstacles::SXRandomObstacles()
{
    this->setScale(0);
}

SXRandomObstacles::~SXRandomObstacles()
{
    
}

SXRandomObstacles*  SXRandomObstacles::spriteWithFrame(const char *pszFileName)
{
    SXRandomObstacles *pobSprite = new SXRandomObstacles();
    pobSprite->initWithSpriteFrameName(pszFileName);
    pobSprite->type=kObstacle;
    pobSprite->setTag(KRandomObstcaleTag);
    pobSprite->setPosition(SXUtility::getRandomPoint());
    pobSprite->addBoxToSprite(pobSprite, "Piedra2");
    return pobSprite;
}

void SXRandomObstacles::addBoxToSprite(SXRandomObstacles *obstacle,const char  *pSpriteFrame )
{
    b2BodyDef spriteBodyDef;
    spriteBodyDef.type = b2_dynamicBody;
    spriteBodyDef.position.Set(obstacle->getPosition().x,
                               obstacle->getPosition().y);
     spriteBodyDef.userData = obstacle;
    b2Body *spriteBody = MainLayer->world->CreateBody(&spriteBodyDef);
    gbox2d::GB2ShapeCache::sharedGB2ShapeCache()->addFixturesToBody(spriteBody, pSpriteFrame);
}


