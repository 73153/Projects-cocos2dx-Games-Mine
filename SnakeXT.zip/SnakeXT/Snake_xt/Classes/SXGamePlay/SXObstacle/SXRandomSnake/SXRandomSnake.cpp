//
//  SXRandomSnake.cpp
//  Snake_xt
//
//  Created by Pavitra on 11/01/13.
//
//

#include "SXRandomSnake.h"
#include "SXSnakeBody.h"
#include "SXDataManager.h"
#include "SXBonusManager.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"

#include "SXGameConstants.h"
#include "SXObstaclesManager.h"


#include "SXUtility.h"
using namespace cocos2d;

SXRandomSnake::SXRandomSnake(){
    this->movableObjects=CCArray::create();
    this->movableObjects->retain();
    
    this->pathArray=CCPointArray::create(1000);
    this->pathArray->retain();
    
    snakeLength=this->getSnakeLength();
    this->type=kRandomSnake;
    this->canChangeDirection=false;
    
//
//    CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXRandomSnake::addAlert));
//    CCCallFuncN *callBackOne = CCCallFuncN::create(this,callfuncN_selector(SXRandomSnake::removeAlert));
//    
//    this->runAction(CCSequence::create(callBack,CCDelayTime::create(4),CCDelayTime::create(4), callBackOne,NULL));
//
    
}

void  SXRandomSnake::initialiseRandomSnake()
{
    this->side=ObstacleManager->getFreeSide(kRandomSnake);
  
    ObstacleManager->obstaclesArray->addObject(this);

    CCSprite *alertImage=CCSprite::create("icon_bg-1.png");
    MainLayer->addChild(alertImage,1,kAlertTagForRAndomSnake);
    
  CCBlink *blink=CCBlink::create(1, 2);
    alertImage->runAction(blink);
  CCActionInterval *act = CCFadeIn::create(2);
   alertImage->runAction(act);
    
//    CCLabelTTF *Label=CCLabelTTF::create(" Random Snake ", "Arial", 15);
//    alertImage->addChild(Label);
//    Label->setPosition(ccp(alertImage->getContentSize().width/2,alertImage->getContentSize().height+10));

  
        
    if(side==kTop)
    {
     this->setPosition(ccp(SXUtility::getRandomPoint().x, 500));
        this->currentAngle=180;
        mainFrame = CCRectMake(-100,-100, 600, 600);
        alertImage->setPosition(CCPoint(this->getPosition().x, 280));
          //this->setPositionX(BonusManager->getRandomNumberBetween(100, 240));
    }
    
    else if(side==kBottom)
    {
        this->setPosition(ccp(SXUtility::getRandomPoint().x, -200));
        this->currentAngle=0;
        mainFrame = CCRectMake(-100, -200,600, 600);
       alertImage->setPosition(CCPoint(this->getPosition().x, 20));
    }
    
   else if(side ==kLeft)
   {
       this->setPosition(ccp(-200,SXUtility::getRandomPoint().y ));
       this->currentAngle=90;
      mainFrame = CCRectMake(-200, -100, 760, 500);
       alertImage->setPosition(CCPoint(20, this->getPosition().y));
   }
   
   else  // right
   {
      this->setPosition(ccp(600,SXUtility::getRandomPoint().y ));
       this->currentAngle=270;
        mainFrame = CCRectMake(-100, -100, 700, 600);
       alertImage->setPosition(CCPoint(420, this->getPosition().y));
  }
    
    //CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXRandomSnake::addAlert));
    CCCallFuncN *callBackOne = CCCallFuncN::create(this,callfuncN_selector(SXRandomSnake::removeAlert));
    
    alertImage->runAction(CCSequence::create(CCDelayTime::create(2), callBackOne,NULL));
}

SXRandomSnake* SXRandomSnake::createWithSpriteFrameName() {
    SXRandomSnake *pobSprite=new SXRandomSnake();
        char a[20]={};
        sprintf(a,"snakeHead%d.png",ObstacleManager->rand);
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(a);
    
    pobSprite->type=kRandomSnake ;
    if (pobSprite && pobSprite->initWithSpriteFrame(pFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

#pragma mark - alertImage
//void SXRandomSnake::addAlert(){
//   alertImage=CCSprite::create("icon_bg-1.png");
//    MainLayer->addChild(alertImage,1,kAlertTagForRAndomSnake);
//    
//    initialiseRandomSnake();
//    
//    CCBlink *blink=CCBlink::create(1, 2);
//    alertImage->runAction(blink);
//    CCActionInterval *act = CCFadeIn::create(2);
//    alertImage->runAction(act);
//
//}

void SXRandomSnake::removeAlert() {
    MainLayer->removeChildByTag(kAlertTagForRAndomSnake);

     ObstacleManager->isRandomSnakePresent=true;
    this->schedule(schedule_selector(SXRandomSnake::getRandomDirection),.5);
}

#pragma mark-update

void SXRandomSnake::update()
{
    if(!Snake->isFreezewrEnabled){
        speed=2;
        int  speedFactor=(this->getContentSize().width/2)/speed;
        
        float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*speed;
        float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*speed;
        this->setPosition(CCPointMake(X, Y));
        this->setRotation(currentAngle);
        this->pathArray->addControlPoint(this->getPosition());
        
        for (int i=0; i<13; i++)
        {
            SXSnakeBody *body=(SXSnakeBody *) this->movableObjects->objectAtIndex(i);
            
            if(DataManager->gameMode==KARCADEMODE)
            {
                if(DataManager->snakeNumber<6)
                {
                    if(speed>=4 && speed<6)
                    {
                        CCPoint point=this->convertToNodeSpace(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i)));
                        body->setPosition(point);
                        // body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i)));
                        
                    }
                    else if(speed==6){
                        // body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i+3)));
                        CCPoint point=this->convertToNodeSpace(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i+3)));
                        body->setPosition(point);
                    }
                    else
                    {
                        //body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor-1)*i+8)));
                        CCPoint point=this->convertToNodeSpace(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor-1)*i+8)));
                        body->setPosition(point);
                    }
                }
                
                else
                {
                    if(DataManager->snakeSpeed<7)
                    {
                        body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i+3)));
                    }
                    else{
                        body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i+2)));
                    }
                }
            }
            
            else {
                body->setPosition(this->pathArray->getControlPointAtIndex( this->pathArray->count()-((speedFactor)*i)));
            }
        }
        if(DataManager->secondTick%5==0)
        {
            
        }
        
        
        CCRect rect=CCRectMake(0, 0, 480, 320);
        if(rect.containsPoint(this->getPosition()))
        {
            //            MainLayer->removeChildByTag(kAlertTagForRAndomSnake);
            //            ObstacleManager->isRandomSnakePresent=true;
            this->getRandomAngle();
            //this->schedule(schedule_selector(SXRandomSnake::getRandomDirection),.5);
        }
        
        this->checkCollisipn();

        
    }
}


void SXRandomSnake::checkCollisipn() {
    
    
    if(!mainFrame.containsPoint(this->getPosition()))
    {
        ObstacleManager->isRandomSnakePresent=false;
        this->movableObjects->removeAllObjects();
//        DataManager->gameLayer->removeChild(this);
        ObstacleManager->toDeleteArray->addObject(this);
        
    }
}

#pragma mark-GetRandomLenght
int SXRandomSnake::getSnakeLength() {
    
    speed=arc4random()%(6-2)+2;
    return arc4random()%(14-5)+5;
}
void SXRandomSnake::getRandomDirection()
{
        canChangeDirection=true;
        int rand = arc4random()%2;
        if(rand==0)
        {
                snakeDirection=kLeftDirection;
        }
        if(rand==1)
        {
                snakeDirection=kRightDirection;
        }
        if(rand==2)
        {
                snakeDirection=kStraightDirection;
        }
        
     
}
void SXRandomSnake::getRandomAngle() {
        
        
        if(canChangeDirection) {
                
                        if(this->snakeDirection==kLeftDirection){
                                currentAngle++;
                        }
                        
                        else if(this->snakeDirection==kRightDirection){
                                currentAngle--;
                        }
                }
   

}


CCPoint SXRandomSnake::getRandomPoint(){
    CCPoint _point;
	
    int high = 280;  int low = 30;
	
	int xVal = rand() % (high - low + 1) + low;
	
	high = 440;  low = -20;
	
	int yVal = rand() % (high - low + 1) + low;
	
	_point = CCPointMake((float)yVal, (float)xVal);
    
	return _point;
}

#pragma mark=Dealloc
SXRandomSnake::~SXRandomSnake() {
    CC_SAFE_RELEASE(this->movableObjects);
    CC_SAFE_RELEASE(this-> pathArray);
}
