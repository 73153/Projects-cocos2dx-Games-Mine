//
//  SXRandomSnake.h
//  Snake_xt
//
//  Created by Pavitra on 11/01/13.
//
//

#ifndef __Snake_xt__SXRandomSnake__
#define __Snake_xt__SXRandomSnake__

#include <iostream>
#include "cocos2d.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"

using namespace cocos2d;
class SXCustomSprite;

class SXRandomSnake :public SXCustomSprite{
    
public:
    
    SXRandomSnake();
    ~SXRandomSnake();
    SXRandomSnake* createWithSpriteFrameName();
    
    
    int speed;
    int snakeLength;
    float currentAngle;
    BoundrySide side;
  Direction snakeDirection;
     

    
    void update();
    int getSnakeLength();
    CCPoint getRandomPoint();
     void getRandomAngle( );
     
        void getRandomDirection();
    
    CCArray *movableObjects;
    CCPointArray *pathArray;
    
    void checkCollisipn();
    void initialiseRandomSnake();
    CCRect mainFrame;
        bool canChangeDirection;
    
  //  void addAlert();
    void removeAlert();
    CCSprite *alertImage;
    
};
#endif /* defined(__Snake_xt__SXRandomSnake__) */
