


//
//  SXBomb.cpp
//  Snake_xt
//
//  Created by Pavithra on 13/02/13.
//
//

#include "SXBomb.h"

#include "SXUtility.h"
#include "SXSnake.h"
#include "SXMainController.h"
#include "SXDataManager.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"
#include "SXMissileManager.h"

#pragma  mark - Bomb
 SXBomb::SXBomb()
{
    mAngleChanged=false;
    this->canRemove=false;
    this->setRotation(270);
    this->target=Snake;
    this->type=kBomb;
 
    this->side=MainLayer->missileManager->getFreeSide(kBomb);
  
    CCCallFuncN *Callback=CCCallFuncN::create(this, callfuncN_selector(SXBomb::removeBomb));
    CCCallFuncN *Callback1=CCCallFuncN::create(this, callfuncN_selector(SXBomb::removeBomb));

       CCFiniteTimeAction *seq=CCSequence::create(CCDelayTime::create(10),Callback,CCDelayTime::create(7),Callback1, NULL);
    this->runAction(seq);
}

SXBomb::~SXBomb()
{
        
}

SXBomb* SXBomb::spriteWithFile(const char *pszFileName)
{
        SXBomb *tempSpr =  new SXBomb();
        tempSpr->initWithFile(pszFileName);
        return tempSpr;
}
SXBomb* SXBomb::spriteWithFrame(const char *pszFileName)
{
    SXBomb *tempSpr =  new SXBomb();
    tempSpr->initWithSpriteFrameName(pszFileName);
    return tempSpr;
}

#pragma mark - Update
void SXBomb::update()
{
//        CCPoint desiredDirection = this->normalizeVector(ccpSub(Snake->getPosition(), this->getPosition()));
//        CCPoint velocity=ccpMult(desiredDirection, 1.5);
//        float X = shadow->getPosition().x + sin(CC_DEGREES_TO_RADIANS(shadowAngle))*1.5;
//        float Y = shadow->getPosition().y + cos(CC_DEGREES_TO_RADIANS(shadowAngle))*1.5;
//        shadow->setPosition(CCPointMake(X, Y));
//        shadow->setRotation(shadowAngle);
//        shadowAngle=shadowAngle-0.001;
    if(!Snake->isFreezewrEnabled)
    {
        if(!canRemove)
        {
            
            CCPoint desiredDirection = this->normalizeVector(ccpSub(Snake->getPosition(), this->getPosition()));
            CCPoint velocity=ccpMult(desiredDirection, 1.5);//1.5
            this->setPosition(ccpAdd(this->getPosition(), velocity));
            this->setRotation(SXUtility::getAngleFromCurrentPoint(this->getPosition(),Snake->getPosition()));
        }
        else
        {
            
            if(mAngleChanged)
            {
                
                if(mRotatingAngle<currentAngle)
                {
                    currentAngle=currentAngle-2;
                }
                else
                {
                    currentAngle=currentAngle+2;
                }
                
                if(this->currentAngle==mRotatingAngle)
                {
                    mAngleChanged=false;
                }
            }
            
            float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*1.5;
            float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*1.5;
            this->setPosition(CCPointMake(X, Y));
            this->setRotation(currentAngle);
            CCRect mainFrame=CCRect(0, 0, 480, 320);
            
            if(!mainFrame.containsPoint(this->getPosition()))
            {
                MainLayer->missileManager->toDeleteArray->addObject(this);
                MainLayer->missileManager->toDeleteArray->addObject(shadow);
            }
        }
    }
    
    else{
        this->stopAllActions();
        this->canRemove=true;
    }
}


CCPoint SXBomb:: normalizeVector(CCPoint vector)
{
    float length=sqrtf(vector.x*vector.x+vector.y*vector.y);
    if (length<0.000001) return ccp(0,1);
    return ccpMult(vector, 1/length);
}

void SXBomb::runAnimation()
{

        CCAnimationCache *animCache2 = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation2 = animCache2->animationByName("Eagle");
        animation2->setRestoreOriginalFrame(1);
        CCAnimate *animN2 = CCAnimate::create(animation2);
        animN2->setTag(1);
        this->runAction(CCRepeatForever::create(animN2));
}

#pragma  mark - Creating Bomb
void SXBomb::launchBomb()
{
        isBirdShadowMoved=false;
    
        shadow = CCSprite::create("FlyingEagleShadow.png");
        MainLayer->addChild(shadow,-1);
        shadow->setPosition(ccp(-10,-10));

        alertImage=CCSprite::createWithSpriteFrameName("eagle_icon.png");
        MainLayer->addChild(alertImage,1,kAlertTagForBomb);
        
               
        CCBlink *blink=CCBlink::create(3, 4);
        alertImage->runAction(blink);
        
        CCLabelTTF *Label=CCLabelTTF::create(" Eagle ", "Arial", 15);
        alertImage->addChild(Label);
        Label->setPosition(ccp(alertImage->getContentSize().width/2,alertImage->getContentSize().height+10));
      
        if(this->side==kRight)
        {
                alertImage->setPosition( ccp(450,this->target->getPosition().y));
                             
                shadowval=CCPoint(480,this->target->getPosition().y);
                moveToPoint=CCPoint(-10,shadowval.y);
                shadowAngle=270;
                this->setPosition(CCPoint(600, this->target->getPosition().y));
                
        }
        
        else if(this->side==kLeft)
        {
                alertImage->setPosition( ccp(25,this->target->getPosition().y));
                this->setPosition(ccp(-30, this->target->getPosition().y));
                
                shadowval=CCPoint(0,this->target->getPosition().y);
                moveToPoint=CCPoint(500,shadowval.y);
                shadowAngle=90;
           
        }
        
        else if(this->side==kTop)
        {
                alertImage->setPosition( ccp(this->target->getPosition().x,300));
                this->setPosition(ccp(this->target->getPosition().x, 400));
               
                shadowval=CCPoint(this->target->getPosition().x,300);
                moveToPoint=CCPoint(shadowval.x,-10);
                shadowAngle=180;

        }
        
        else
        {
                alertImage->setPosition( ccp(this->target->getPosition().x,20));
                this->setPosition(ccp(this->target->getPosition().x, -40));
                
                shadowval=CCPoint(this->target->getPosition().x,0);
                moveToPoint=CCPoint(shadowval.x,350);
                shadowAngle=0;

        }
        
        
       

        CCCallFuncN *callBack=CCCallFuncN::create(this, callfuncN_selector(SXBomb::removeAlert));
        //CCCallFuncN *CallbackOne=CCCallFuncN::create(this, callfuncN_selector(SXBomb::callUpdate));
        CCFiniteTimeAction *seq=CCSequence::create(CCDelayTime::create(3),callBack,NULL);
        this->runAction(seq);
}

#pragma  mark - removeAlert
void SXBomb::removeAlert()
{
        MainLayer->removeChildByTag(kAlertTagForBomb);
        
        shadow->setPosition(shadowval);
        CCMoveTo *move = CCMoveTo::create(3, moveToPoint);
        CCCallFuncN *CallbackOne=CCCallFuncN::create(this, callfuncN_selector(SXBomb::callUpdate));
        CCFiniteTimeAction *seq=CCSequence::create(move, CallbackOne,NULL);

        CCLOG("%f=value",moveToPoint.y);
        shadow->runAction(seq);
        shadow->setRotation(shadowAngle);
}

#pragma mark - callUpdate
void SXBomb::callUpdate()
{
     this->schedule(schedule_selector(SXBomb::update));
}

#pragma mark - removeBomb
void SXBomb::removeBomb(CCObject *obj)
{
    if(canRemove){
        SXBomb *bomb=(SXBomb*)obj;
       
        MainLayer->missileManager->toDeleteArray->addObject(bomb);
    }
    
    else{
        canRemove=true;
        mAngleChanged=true;
        currentAngle=this->getRotation();
        mRotatingAngle=(SXUtility::getRandomAngle(20, 315));
    }
}


