//
//  SXBomb.h
//  Snake_xt
//
//  Created by Pavithra on 13/02/13.
//
//

#ifndef __Snake_xt__SXBomb__
#define __Snake_xt__SXBomb__

#include <iostream>
#include "SXCustomSprite.h"
#include "SXGameConstants.h"

using namespace cocos2d;

class SXBomb : public SXCustomSprite
{
public:
    SXBomb();
    ~SXBomb();
    SXBomb* spriteWithFile(const char *pszFileName);
    SXBomb* spriteWithFrame(const char *pszFileName);
    
    void removeBomb(CCObject *sender);
    void launchBomb();
    void update();
    void removeAlert();
    void callUpdate();
        
        void runAnimation();

    CCPoint normalizeVector(CCPoint vector) ;
    
     int tickCount;
    
    CCSprite *alertImage;
    CCPoint moveToPoint;
    CCSprite *target;
        
        CCSprite *shadow;
    
    BoundrySide getBoundarySide();
    BoundrySide side;
    bool canRemove;
    int currentAngle;
    int mRotatingAngle;
    bool mAngleChanged;
    bool canRunAnimation;
     CCAnimate *animN2 ;
        int shadowAngle;
        
        CCPoint shadowval;
      //  CCPoint moveToPoint;
       
        
bool isBirdShadowMoved;
        
};


#endif /* defined(__Snake_xt__SXBomb__) */
