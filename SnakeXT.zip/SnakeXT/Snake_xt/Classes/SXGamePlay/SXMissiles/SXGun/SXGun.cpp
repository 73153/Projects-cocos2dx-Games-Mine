//
//  SXGun.cpp
//  Snake_xt
//
//  Created by Deepthi on 13/02/13.
//
//

#include "SimpleAudioEngine.h"
#include "SXGun.h"
#include "cocos2d.h"

#include "SXMissile.h"
#include "SXSnake.h"

#include "SXDataManager.h"
#include "SXMainController.h"
#include "SXSnakeManager.h"
#include "SXObstaclesManager.h"
#include "SXMissileManager.h"
#include "SXBonusManager.h"

#include "SXGameConstants.h"
#include "SXUtility.h"
#include "SXLazer.h"

using namespace cocos2d;

#pragma  mark - SXGun

SXGun* SXGun::spriteWithFile(const char *pszFileName){
        
        SXGun *tempSpr =  new SXGun();
        tempSpr->initWithFile(pszFileName);
        return tempSpr;
}
SXGun* SXGun::spriteWithFrame(const char *pszFileName){
    
    SXGun *tempSpr =  new SXGun();
    tempSpr->initWithSpriteFrameName(pszFileName);
    return tempSpr;
}

SXGun::SXGun()
{
        this->setVisible(false);
        this->isRunningAnimation=false;
        this->target=Snake;
        this->type=kGun;
        this->side=SXUtility::getBoundarySide();
        this->setPosition(ccp(470, this->target->getPosition().y));
        
        CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXGun::addAlert));
        CCCallFuncN *callBackOne = CCCallFuncN::create(this,callfuncN_selector(SXGun::removeAlert));
        CCCallFuncN *callBackThree  = CCCallFuncN::create(this,callfuncN_selector(SXGun::removeGun));
        CCCallFuncN *callBackTwo = CCCallFuncN::create(this,callfuncN_selector(SXGun::addGun));
        CCFiniteTimeAction *seq = CCSequence::create(callBack,CCDelayTime::create(3),callBackOne,callBackTwo,CCDelayTime::create(6),callBackThree,NULL);
        this->runAction(seq);
        
        this->schedule(schedule_selector(SXGun::update));
}

SXGun::~SXGun()
{
        
}

#pragma mark - Animation
void SXGun::  runAnimation ()   //When snake with furry mode hits gun 
{
        CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation = animCache->animationByName("Gun");
        CCAnimate *animN = CCAnimate::create(animation);
        if(!this->isAlertFound && !this->isRunningAnimation)
        {
                this->isRunningAnimation=true;
                this->runAction(animN);
        }
}

#pragma  mark - update
void SXGun::update()
{
    if(!Snake->isFreezewrEnabled){
        CCPoint point;
        this->side=kLeft;
        if(this->side==kRight)
        {
            point =CCPoint(470, this->getPositionY());
            this->gunAngle=270;
            this->setFlipX(true);
        }
        else if(this->side==kLeft)
        {
            point=CCPoint(5, this->getPositionY());
            this->gunAngle=90;
            
        }
        else if(this->side==kTop)
        {
            point=CCPoint(this->getPositionX(), 315);
            this->gunAngle=180;
        }
        else
        {
            point=CCPoint(this->getPositionX(), 10);
            this->gunAngle=0;
        }
        
        this->setGunPosition(point);
        this->setRotation(gunAngle);

    }
}

#pragma mark - UpdatedPositio
void SXGun::setGunPosition(CCPoint point)     //To normalize the gun speed
{
        CCPoint desiredDirection = SXUtility::normalizeVector(ccpSub(Snake->getPosition(), point));
        CCPoint velocity=ccpMult(desiredDirection,10);
        if(velocity.y >2.0)
        {
                velocity.y=2.0;
        }
        else if (velocity.y<-2.0)
        {
                velocity.y=-2.0;
        }
        
        this->setPosition(ccpAdd(point, velocity));

        if(isAlertFound==true)
        {
                alertImage->setPosition(ccpAdd(point, velocity));
        }
}

void SXGun::shakeGun()
{
       // CCLog("gun position=%f",this->getPosition().x);
        //CCLog("gun position Y =%f",this->getPositionY());
        if(this->side==kLeft || this->side==kRight)
        {
                moveToPoint=CCPoint(this->getPosition().x-10,this->getPosition().y);
                moveBack=CCPoint(this->getPosition().x,this->getPosition().y);
        }
        else if(this->side==kTop || this->side == kBottom)
        {
                moveToPoint=CCPoint(this->getPosition().x+10,this->getPosition().y);
                moveBack=CCPoint(this->getPosition().x,this->getPosition().y);
        }
        CCMoveTo *moveTheGunBack = CCMoveTo::create(0.03, CCPoint(moveToPoint));
        CCMoveTo *moveTheGunFront = CCMoveTo::create(0.04, CCPoint(moveBack));
        this->runAction(CCSequence::create(moveTheGunBack,moveTheGunFront,NULL));
      //  id moveTheGunFront = [CCMoveTo actionWithDuration:0.04 position:ccp(17,28)];
        
       // [self runAction:[CCSequence actionOne:moveTheGunBack two:moveTheGunFront]];
}
#pragma mark - Alert
void SXGun::addAlert()
{
        this->isAlertFound=true;
        alertImage=CCSprite::createWithSpriteFrameName("gun_icon.png");
        MainLayer->addChild(alertImage,1,kAlertTagForGun);
        alertImage->setPosition(alertPos);
        
        CCBlink *blink=CCBlink::create(1, 2);
        alertImage->runAction(blink);
        CCActionInterval *colorAction = CCRepeatForever::create((CCActionInterval *)CCSequence::create(
                                                                                                   CCTintTo::create(0.2f, 255, 0, 0),
                                                                                                   CCTintTo::create(0.2f, 0, 255, 0),
                                                                                                   CCTintTo::create(0.2f, 0, 0, 255),
                                                                                                   CCTintTo::create(0.2f, 0, 255, 255),
                                                                                                   CCTintTo::create(0.2f, 255, 255, 0),
                                                                                                   CCTintTo::create(0.2f, 255, 0, 255),
                                                                                                   CCTintTo::create(0.2f, 255, 255, 255),
                                                                                                   NULL));
    alertImage->runAction(colorAction);
        
}

#pragma  mark - RemoveAlert
void SXGun::removeAlert()
{
        this->isAlertFound=false;
        this->setVisible(true);
        MainLayer->removeChildByTag(kAlertTagForGun);
}


#pragma mark - AddGun
void SXGun::addGun()
{
        
        if(MainLayer->missileManager->rand==2)
        {
                this->schedule(schedule_selector(SXGun::fireBulletFromPosition),0.25);
                
                bulletposition=CCPoint(this->getContentSize().width-22,this->getContentSize().height);
                if(this->side==kRight)
                {
                        bulletposition=CCPoint(this->getContentSize().width-15,this->getContentSize().height);
                }
                
        }
        else {
                this->schedule(schedule_selector(SXGun::fireBulletFromPosition),1);
                
                bulletposition=CCPoint(this->getContentSize().width-21,this->getContentSize().height-20);
                if(this->side==kRight)
                {
                        bulletposition=CCPoint(this->getContentSize().width-12,this->getContentSize().height-20);
                }
        }
  
}


#pragma mark - RemoveGun
void SXGun::removeGun(CCObject *sender)
{
    SXGun *gun=(SXGun*)sender;         
    MainLayer->missileManager->toDeleteArray->addObject(gun);
    MainLayer->missileManager->bulletsArray ->removeAllObjects();
}

#pragma  mark - Bullets
void SXGun::fireBulletFromPosition()
{
       // this->shakeGun();
    if(!Snake->isFreezewrEnabled){
        CCSprite *bulletSpr = CCSprite::createWithSpriteFrameName("Bullet.png");
        this->addChild(bulletSpr,-1);
        bulletSpr->setPosition(bulletposition);
        
        MainLayer->missileManager->bulletsArray->addObject(bulletSpr);
        // CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("0017_mgun_f_01_single_shot.mp3");
        
        CCPoint endPoint = SXUtility::getStraightPointWithRadius(500, this->getRotation(), this->getPosition());
        endPoint=this->convertToNodeSpace(endPoint);
        float duration = ccpDistance(bulletSpr->getPosition(),endPoint)/500;
        bulletSpr->runAction(CCSequence::create(CCMoveTo::create(duration,endPoint),CCCallFuncN::create(this, callfuncN_selector(SXGun::removeBullet)),NULL));
    }
}

void SXGun::removeBullet(CCObject *sender)
{
        CCSprite *bullet=(CCSprite*)sender;
        this->removeChild(bullet, true);
        MainLayer->missileManager->bulletsArray ->removeObject(bullet);
}