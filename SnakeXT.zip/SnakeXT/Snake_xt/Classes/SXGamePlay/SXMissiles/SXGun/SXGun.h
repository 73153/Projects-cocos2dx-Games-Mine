//
//  SXGun.h
//  Snake_xt
//
//  Created by Deepthi on 13/02/13.
//
//

#ifndef Snake_xt_SXGun_h
#define Snake_xt_SXGun_h

#include <iostream>
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
using namespace cocos2d;
class SXCustomSprite;
class SXGun : public SXCustomSprite
{
public:
         SXGun();
        ~SXGun();
        
        SXGun* spriteWithFile(const char *pszFileName);
       SXGun* spriteWithFrame(const char *pszFileName);

    
        void update();
       
        void fireBulletFromPosition();
        void removeBullet(CCObject *sender);
        
        void addAlert();
        void removeAlert();
        
        void setGunPosition(CCPoint pnt);
        void addGun();
        void removeGun(CCObject *sender);
        void runAnimation();
        void shakeGun();
        
        CCSprite *target;
        CCSprite *alertImage;

        CCPoint alertPos;
        CCPoint bulletposition;
        
        float gunAngle;
        
        int alertxVal;
        int alertyVal;
        
        bool isAlertFound;
        bool isRunningAnimation;
        
        BoundrySide side;
        
        CCPoint moveToPoint;
        CCPoint moveBack;


};
#endif /* defined(__Snake_xt__SXBomb__) */
