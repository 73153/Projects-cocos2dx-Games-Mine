//
//  SXMissileManager.cpp
//  Snake_xt
//
//  Created by Pavithra on 13/02/13.
//
//

#include "SXMissileManager.h"

#include "SXDataManager.h"
#include "SXUtility.h"

#include "SXMissile.h"
#include "SXBomb.h"
#include "SXGun.h"

#include "SXSnake.h"
#include "SXSnakeEffects.h"
#include "SXSnakeManager.h"

#include "CCNumber.h"

#pragma mark - MissileManager
SXMissileManager:: SXMissileManager(){
    
    this->missileEntryTime=13;
    this->missileRepeatTime=13;
    
    this->BombEntryTime=5;
    this->bombRepeatTime=7;
    
    this->gunEntryTime=37;
    this->gunRepeatTime=37;
    const char* path = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("SXTimerPlist.plist");
    
    CCArray *AllTimerData = CCArray::createWithContentsOfFile(path);
    
    for (int i=5; i<8; i++) {
        CCDictionary *sliderDefaultTimeArray=(CCDictionary*)AllTimerData->objectAtIndex(i);
        
        CCString *entryTime=(CCString*)sliderDefaultTimeArray->valueForKey(" entryTime");
        CCString *repeatTime=(CCString*)sliderDefaultTimeArray->valueForKey("repeatTime");
        
        if(i==5){
            this->missileEntryTime=entryTime->intValue();;
            this->missileRepeatTime=repeatTime->intValue();
            
        }
        else if(i==6){
            this->BombEntryTime=entryTime->intValue();;
            this->bombRepeatTime=repeatTime->intValue();
            
        }
        else if(i==7){
            this->gunEntryTime=entryTime->intValue();;
            this->gunRepeatTime=repeatTime->intValue();
            
        }
    }
    
    this->missileCount=0;
    this->noOfMissileToCreate=0;
    
    this->bombCount=0;
    this->noOfBombToCreate=0;
    
    this->missilesArray=CCArray::create();
    this->missilesArray->retain();
    
    this->bulletsArray=CCArray::create();
    this->bulletsArray->retain();
    
    this->toDeleteArray=CCArray::create();
    this->toDeleteArray->retain();
}

SXMissileManager::~SXMissileManager(){
    
    
    CC_SAFE_RELEASE(this->missilesArray);
    CC_SAFE_RELEASE(this->bulletsArray);
    CC_SAFE_RELEASE(this->toDeleteArray);
}

#pragma mark - AddingMisile
void SXMissileManager::addMissile() {
    
      if(DataManager->secondTick==this->missileEntryTime) {   // adding missile
        
        this->missileEntryTime=this->missileEntryTime+this->missileRepeatTime;
        this->createMissile();
          
        if(this->noOfMissileToCreate!=0) {
            int limit=this->missileCount/this->noOfMissileToCreate;
            if(limit>4){
                limit=4;
            }
            for(int i=0;i<limit;i++){
                this->createMissile();
            }
            
           /* if(this->missileCount/this->noOfMissileToCreate==1 ){
                this->createMissile();
            }
            
            else if(this->missileCount/this->noOfMissileToCreate>=2){
                this->createMissile();
                this->createMissile();
            }*/
            
            this->missileCount++;
        }
    }
    
    if (DataManager->secondTick==BombEntryTime) {     // adding bomb
        BombEntryTime=BombEntryTime+bombRepeatTime;
        this->createBomb();
        if(this->noOfBombToCreate!=0) {
            if(this->bombCount/this->noOfBombToCreate==1 ){
                this->createBomb();
            }
            
            else if(this->bombCount/this->noOfBombToCreate>=2){
                this->createBomb();
                this->createBomb();
            }
            this->bombCount++;
        }
    }
    
    if (DataManager->secondTick==gunEntryTime) {  //adding bomb
        gunEntryTime=gunEntryTime+gunRepeatTime;
        rand = arc4random()%2+1;
        char str[10];
        sprintf(str,"gun%d.png", rand);
        
        SXGun *gun=gun->spriteWithFrame(str);
        MainLayer->addChild(gun);
        this->missilesArray->addObject(gun);
    }
}

void SXMissileManager::createBomb() {
  SXBomb *bomd=bomd->spriteWithFrame("Flying _Eagle_1.png");
 
   bomd->launchBomb();
        bomd->runAnimation();
        

    MainLayer->addChild(bomd,7);
  this->missilesArray->addObject(bomd);
}

void SXMissileManager::createMissile(){
    SXMissile *missile=missile->spriteWithFrame("FireMissiles.png");
    MainLayer->addChild(missile);
    this->missilesArray->addObject(missile);
    missile->launchMissile();
}

#pragma mark - RemovingAllMissiles
void SXMissileManager::RemoveAllMissiles() {    // remove all missile bomb and gun when snake take remove alsxsna
    
    CCObject *obj;
    CCARRAY_FOREACH(this->missilesArray, obj) {
        SXCustomSprite *missil=(SXCustomSprite*)obj;
        if(missil->type==kMissile){
            MainLayer->removeChildByTag(kAlertTagForMissile);
        }
        else if(missil->type==kGun){
            missil->unscheduleAllSelectors();
            
            MainLayer->removeChildByTag(kAlertTagForGun);
        }
        else if(missil->type==kBomb){
            MainLayer->removeChildByTag(kAlertTagForBomb);
        }
        this->toDeleteArray->addObject(missil);
    }
    
    CCARRAY_FOREACH(this->bulletsArray, obj) {
        CCSprite *missil=(CCSprite*)obj;
        this->toDeleteArray->addObject(missil);
        bulletsArray->removeAllObjects();
    }
}

#pragma  mark - Animation
void SXMissileManager::runAnimatiion(SXCustomSprite *sprite){
    
        
                if(sprite->type==kGun)
                {
                        SXGun *gun=(SXGun*)sprite;
                        
                        if (  !gun->isAlertFound) {
                                
                                gun->unscheduleAllSelectors();
                                gun->runAnimation();
                                CCDelayTime *delay=CCDelayTime::create(1);
                                gun->runAction(CCSequence::createWithTwoActions(delay, CCCallFuncN::create(this, callfuncN_selector(SXGun::removeGun))));
                        }
                }
                
                else if(sprite->type==kMissile )
                        {
                                SXMissile *missile=(SXMissile*)sprite;
                                missile->runAnimation();
                                this->toDeleteArray->addObject(missile);
                        }

}
    

#pragma mark - get Free Side
BoundrySide SXMissileManager::getFreeSide(int type){
    cocos2d_extensions::CCNumber<int> *intOne = cocos2d_extensions::CCNumber<int>::numberWithValue(1);
    cocos2d_extensions::CCNumber<int> *intTwo = cocos2d_extensions::CCNumber<int>::numberWithValue(2);
    cocos2d_extensions::CCNumber<int> *intThree = cocos2d_extensions::CCNumber<int>::numberWithValue(3);
    cocos2d_extensions::CCNumber<int> *intFour = cocos2d_extensions::CCNumber<int>::numberWithValue(4);
    CCArray *freeSidesArr = CCArray::create();
    freeSidesArr->retain();
    
    freeSidesArr->addObject(intOne);
    freeSidesArr->addObject(intTwo);
    freeSidesArr->addObject(intThree);
    freeSidesArr->addObject(intFour);
    
    CCObject *obj;
    int  rand=SXUtility::getRandomNumberBetween(1, 4);
    
    CCARRAY_FOREACH(this->missilesArray, obj)
    {
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        
        
        if(sprite->type==type)
        {
            switch (type) {
                case kMissile:{
                    SXMissile    *sprite=(SXMissile*)obj;
                    
                    if(sprite->side==kTop)
                    {
                        //CCLog("deleted random value from free side array=%d",rand);
                        freeSidesArr->removeObject(intOne);
                    }
                    else if(sprite->side==kBottom){
                        freeSidesArr->removeObject(intTwo);
                        
                    }
                    else if(sprite->side==kLeft){
                        
                        freeSidesArr->removeObject(intThree);
                        
                    }
                    else if(sprite->side==kRight){
                        //CCLog("deleted random value from free side array=%d",rand);
                        freeSidesArr->removeObject(intFour);
                    }
                }
                    break;
                    
                case kBomb:
                {
                    SXBomb    *sprite=(SXBomb*)obj;
                    CCLog("wall side=%d",sprite->side);
                    
                    if(sprite->side==kTop)
                    {
                        //CCLog("deleted random value from free side array=%d",rand);
                        freeSidesArr->removeObject(intOne);
                    }
                    else if(sprite->side==kBottom){
                        //CCLog("deleted random value from free side array=%d",rand);
                        
                        freeSidesArr->removeObject(intTwo);
                        
                    }
                    else if(sprite->side==kLeft){
                        //CCLog("deleted random value from free side array=%d",rand);
                        
                        freeSidesArr->removeObject(intThree);
                        
                    }
                    else if(sprite->side==kRight){
                        //CCLog("deleted random value from free side array=%d",rand);
                        freeSidesArr->removeObject(intFour);
                    }
                }
                    
                    break;
                    
                default:
                    break;
            }
        }
    }
    
    if(freeSidesArr->count()!=0)
    {
        cocos2d_extensions::CCNumber<int > * rand1=(cocos2d_extensions::CCNumber<int> *)freeSidesArr->objectAtIndex(arc4random()% freeSidesArr->count());
        return BoundrySide(rand1->getValue());
    }
    
    return BoundrySide(1);
}

#pragma mark - Clear
void SXMissileManager::clear()
{
    CCObject *obj;
    CCARRAY_FOREACH(this->toDeleteArray, obj)
    {
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
            if(sprite->type==kBomb){
                    SXBomb *bomb=(SXBomb*)sprite;
                    CCSprite *shadow=(CCSprite*)bomb->shadow;
                    MainLayer->removeChild(shadow);
            }
        MainLayer->removeChild(sprite);
            
        this->missilesArray->removeObject(sprite);
    }
    
    this->toDeleteArray->removeAllObjects();
}

