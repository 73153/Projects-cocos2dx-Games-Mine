//
//  SXMissileManager.h
//  Snake_xt
//
//  Created by Pavithra on 13/02/13.
//
//

#ifndef __Snake_xt__SXMissileManager__
#define __Snake_xt__SXMissileManager__

#include <iostream>
#include "SXGameManager.h"
#include "SXTimeSliderLayer.h"
class SXGameManager;

class SXBomb;
class SXMissileManager :public SXGameManager {
    
public:
    SXMissileManager();
    ~SXMissileManager();
    
    CCArray *missilesArray;
    CCArray *bulletsArray;
    CCArray *toDeleteArray;

    int rand;
    //missile
    int missileEntryTime;
    int missileRepeatTime;
    int missileCount;
    int noOfMissileToCreate;
    void createMissile();
        
 SXBomb *bomd;

    
    //bomb 
    int BombEntryTime;
    int bombRepeatTime;
    int noOfBombToCreate;
    int bombCount;
    void createBomb();

    int gunEntryTime;
    int gunRepeatTime;

    
    void addMissile();
    void RemoveAllMissiles();
    void clear();
    void runAnimatiion(SXCustomSprite *sprite );
    
    BoundrySide getFreeSide(int type);
};

#endif /* defined(__Snake_xt__SXMissileManager__) */
