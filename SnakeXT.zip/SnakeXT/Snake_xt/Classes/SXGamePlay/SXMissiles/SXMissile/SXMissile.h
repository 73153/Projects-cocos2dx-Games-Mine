//
//  SXMissile.h
//  Snake_xt
//
//  Created by Pavithra on 12/02/13.
//
//

#ifndef __Snake_xt__SXMissile__
#define __Snake_xt__SXMissile__

#include <iostream>
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
using namespace cocos2d;

class SXCustomSprite;
class SXMissile : public SXCustomSprite
{
public:
        SXMissile();
        ~SXMissile();
        
        SXMissile* spriteWithFrame(const char *pszFileName);
        
        BoundrySide getBoundarySide();
        BoundrySide side;
        
        void launchMissile();
        void removeAlert();
        void runAnimation();
        void removeMissile(CCObject *sender);
        
        void update();
        
        CCSprite *target;
        CCPoint MoveToPoint;
        CCParticleSystemQuad *missilePartical;
        
        float missileAngle;
};
#endif /* defined(__Snake_xt__SXMissile__) */
