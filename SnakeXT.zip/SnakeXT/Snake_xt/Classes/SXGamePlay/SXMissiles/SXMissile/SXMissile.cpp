//
//  SXMissile.cpp
//  Snake_xt
//
//  Created by Pavithra on 12/02/13.
//
//
#include "SimpleAudioEngine.h"
#include "cocos2d.h"

#include "SXMissile.h"
#include "SXSnake.h"

#include "SXDataManager.h"
#include "SXMainController.h"
#include "SXSnakeManager.h"
#include "SXMissileManager.h"

#include "SXGameConstants.h"
#include "SXUtility.h"

using namespace cocos2d;

#pragma mark - Missile
SXMissile::SXMissile()
{
        this->setScale(0.8);
        this->target=Snake;
        this->type=kMissile;
        this->side=MainLayer->missileManager->getFreeSide(kMissile);
}

SXMissile::~SXMissile()
{
        
}

SXMissile* SXMissile::spriteWithFrame(const char *pszFileName)
{
        SXMissile *tempSpr =  new SXMissile();
        tempSpr->initWithSpriteFrameName(pszFileName);
        return tempSpr;
}


#pragma  mark - Animation
void SXMissile::  runAnimation()    //wken snake with furry mode hits missile
{
        CCAnimationCache *animCache = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation = animCache->animationByName("Gun");
        CCAnimate *animN = CCAnimate::create(animation);
        this->runAction(animN);
}

#pragma mark - LaunchMissile
void SXMissile::launchMissile()
{
        CCSprite *alertImage=CCSprite::createWithSpriteFrameName("missile_icon.png");
        MainLayer->addChild(alertImage,1,kAlertTagForMissile);
        
        CCBlink *blink=CCBlink::create(1, 2);
        alertImage->runAction(blink);
        
        if(this->side==kRight)
        {
                alertImage->setPosition( ccp(450,this->target->getPosition().y));
                this->setPosition(ccp(600, this->target->getPosition().y));
                this->MoveToPoint=CCPoint(0, Snake->getPosition().y);
                this->missileAngle=270;
        }
        
        else if(this->side==kLeft)
        {
                alertImage->setPosition( ccp(25,this->target->getPosition().y));
                this->setPosition(ccp(-30, this->target->getPosition().y));
                this->MoveToPoint=CCPoint(500, Snake->getPosition().y);
                this->missileAngle=90;
        }
    
        else if(this->side==kTop)
        {
                alertImage->setPosition( ccp(this->target->getPosition().x,300));
                this->setPosition(ccp(this->target->getPosition().x, 400));
                this->MoveToPoint=CCPoint(Snake->getPosition().x, 0);
                this->missileAngle=180;
        }
    
        else
        {
                alertImage->setPosition( ccp(this->target->getPosition().x,20));
                this->setPosition(ccp(this->target->getPosition().x, -30));
                this->MoveToPoint=CCPoint(Snake->getPosition().x, 300);
                this->missileAngle=0;
        }
        
        this->setRotation(missileAngle);
        alertImage->setRotation(missileAngle);
       
        CCCallFuncN *callBackActionOne=CCCallFuncN::create(this, callfuncN_selector(SXMissile::removeAlert));
        CCMoveTo *moveAction=CCMoveTo::create(1,this->MoveToPoint);

        CCCallFuncN *callBackActionTwo=CCCallFuncN::create(this, callfuncN_selector(SXMissile::removeMissile));
        CCFiniteTimeAction *seq=CCSequence::create(CCDelayTime::create(2),callBackActionOne,moveAction,callBackActionTwo,NULL);
        this->runAction(seq);
}

#pragma mark -  RemoveAlert
void SXMissile::removeAlert()
{
   MainLayer->removeChildByTag(kAlertTagForMissile);
// CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Missle_Launch-Kibblesbob-2118796725.mp3");

}

#pragma mark - Remove Missile
void SXMissile::removeMissile(CCObject *obj)
{
    SXMissile *missile=(SXMissile*)obj;
    MainLayer->missileManager->toDeleteArray->addObject(missile);  
}


