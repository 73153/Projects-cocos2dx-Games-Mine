//
//  SXBonusManager.h
//  Snake_xt
//
//  Created by Deepthi on 08/01/13.
//
//
#ifndef __Snake_xt__SXBonusManager__
#define __Snake_xt__SXBonusManager__

#include <iostream>

#include "cocos2d.h"
#include "SXGameManager.h"

#include "SXGameConstants.h"

typedef enum {
    kSnakeHeadBonus = 1 ,
    kSnakeSpeedIncreaseBonus = 2,
    kSnakeSpeedDecreaseBonus = 3,
    kMagnetBonus = 4,
    kLifeBOnus = 5,
    kFuryModeBonus = 6,
    kRemoveObstacleBonus = 7,
    kInvisiblePowerup=8,
    kSuperMagnet=9,
    kFullBodySheild=10,
    kLeftThroneShiel=11,
    kRightThroneShield=12,
    kBothSideThrone=13,
    kSpike=14,
    kFreezer=15,
    kdoubleScore=16,
    kTripleScore=17,
} BonusType;

class SXBonus;
class SXCustomSprite;
class SXCoinManager;

class SXBonusManager :SXGameManager
{
    
public:
    
    SXBonusManager();
    ~SXBonusManager();

    SXCoinManager *coinManager;
 
   //Tick
    void update();
    
    //Bonus
    bool canAddBonus();
    BonusType getBonusTypeToAdd();
    void addBonusOfType(BonusType inBonus);
    void checkForBonusType(int tag );
    void removeBonus(CCObject *obj);
    
    void addSheildPowerUp();
    void removePowerUp(CCObject *Sender);
    void addSpikePowerUp();
    
    bool canAddCoins();

    bool isCoinPresent;
    bool isBonusPresent;
    bool isHavingMagnet;
    bool isPowerUpAdded;
    bool isDoubleScoreActivate;
    bool isTripleScoreActivete;
    
    //Coins
    CoinShape getCoinTypeToAdd();
    void addCoinToScene(CoinShape inShape);
  
    int coinsCount;
    int PowerUpCount;
    
    CCPoint getPositionInCoordinate(CoordinatePositon getPosition);
    CCPoint freePos;
    CoordinatePositon getFreeCoordinate();
    bool isHavingFreeCoordinates();
    
     void clear();
   
    //Utility
    CoordinatePositon getCoordinateForPosition(CCPoint inPosition);
    int getRandomNumberBetween(int min,int max);
    
    
                                               
    CCArray *toDeleteArray;
    CCArray *coinsArray;
    CCArray *bonusArray;
    CCArray *bonusLabelStringsArray;
    
    int lifeBonusEntryTime;
    int lifeBonusRepeatTime;
    
    int magnetBonusEntryTime;
    int magnetBonusRepeatTime;
    
    int furyModeBonusEntryTime;
    int furyBonusRepeatTime;

    int removeObstacleBonusEntryTime;
    int removeObstacleBonusRepeatTime;

    int invisibleBonusEntryTime;
    int invisibleBonusRepeatTime;

    int shieldBonusEntryTime;
    int shieldBonusRepeatTime;

    int randValue;
    
};
#endif /* defined(__Snake_xt__SXBonusManager__) */
