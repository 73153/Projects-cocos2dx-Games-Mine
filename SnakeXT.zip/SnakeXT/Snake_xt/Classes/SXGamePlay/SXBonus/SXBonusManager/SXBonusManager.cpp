//
//  SXBonusManager.cpp
//  Snake_xt
//
//  Created by Deepthi on 08/01/13.
//
//

#include "SimpleAudioEngine.h"

#include "SXBonusManager.h"
#include "SXDataManager.h"
#include "SXSnakeManager.h"
#include "SXUIManager.h"
#include "SXObstaclesManager.h"
#include "SXCoinManager.h"
#include "SXMissileManager.h"

#include "SXBonus.h"
#include "SXObstacle.h"
#include "SXGameConstants.h"
#include "SXUtility.h"
#include "SXSnake.h"

#include "SXSnakeEffects.h"

#include "CCNumber.h"
#include "CCValue.h"

#include "SXCoin.h"
#include "SXRandomFood.h"

#define PTM_RATIO 32

using namespace cocos2d;
using namespace cocos2d_extensions;

SXBonusManager ::SXBonusManager()
{
    coinsCount=0;
    this->PowerUpCount=0;
    
    this->gameLayer=DataManager->gameLayer;
    
    this->isCoinPresent=false;
    this->isBonusPresent=false;
    this->isHavingMagnet=false;
    this-> isPowerUpAdded=false;
    this->isDoubleScoreActivate=false;
    this->isTripleScoreActivete=false;
    
    this->toDeleteArray=CCArray::create();
    this->toDeleteArray->retain();
    
    this->coinsArray=CCArray::create();
    this->coinsArray->retain();
    
    this->coinManager=new SXCoinManager();

    this->bonusArray=CCArray::create();
    this->bonusArray->retain();
    
    this->bonusLabelStringsArray=CCArray::create();
    bonusLabelStringsArray->retain();
    
    CCString *str=CCString::create(" Shield");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Increase Speed");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Decrease Speed");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Magnet");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Life Bonus");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("FuryMode Bonus");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Rewmove obstacle ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("invisible PowerUp ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Super Magnet ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Full Body Sheild ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("leftThrone ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("rightThrone ");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Both side Throne");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("spike");
    bonusLabelStringsArray->addObject(str);
    
    str=CCString::create("Freezer");
    bonusLabelStringsArray->addObject(str);
    
}

SXBonusManager::~SXBonusManager()
{
    CC_SAFE_RELEASE(this->toDeleteArray);
    CC_SAFE_RELEASE(this->coinsArray);
    CC_SAFE_RELEASE(this->bonusArray);
    CC_SAFE_RELEASE(this->bonusLabelStringsArray);
     delete this->coinManager;
}

#pragma mark - Tick
void SXBonusManager::update()
{
      
        if( DataManager->secondTick%113==0)
        {
            SXBonus *bonus=bonus->spriteWithFrame("Score Bonus X2.png");
            bonus->bonusType=kdoubleScore;
            bonusArray->addObject(bonus);
            MainLayer->addChild(bonus);
            bonus->setPosition(SXUtility::getRandomPoint());
        }
        
        if( DataManager->secondTick%131==0)
        {
            SXBonus *bonus=bonus->spriteWithFrame("Score Bonus X3.png");
            bonus->bonusType=kTripleScore;
            bonusArray->addObject(bonus);
            MainLayer->addChild(bonus);
            bonus->setPosition(SXUtility::getRandomPoint());
        }
        
    if( DataManager->secondTick%7==0&& this->canAddBonus())
    {
        this->addBonusOfType(this->getBonusTypeToAdd());
    }
        
    if(DataManager->secondTick%5==0 &&this->canAddCoins())//7
    {
        this->coinManager-> addCoinToScene(this->coinManager->getCoinTypeToAdd());
    }
        
    if(DataManager->secondTick%6==0)
    {
        int rand = this->getRandomNumberBetween(1, 4);
        this->randValue=rand;
        char a[20]={};
        sprintf(a, "RandomFood%d.png",rand);
        SXRandomFood *randomFood =randomFood->spriteWithFrame(a);
            if(rand==4||rand==1){
                    randomFood->type=kPoisonFood;
            }
        
        DataManager->gameLayer->addChild(randomFood,1);
        bonusArray->addObject(randomFood);
    }
}

#pragma mark - Bonus
bool SXBonusManager::canAddBonus()
{
    if(this->isBonusPresent==false && this->isHavingFreeCoordinates())
    {
        return true;
    }
    else
        return false;
}

BonusType SXBonusManager::getBonusTypeToAdd()
{
    isBonusPresent=true;
    int rand = this->getRandomNumberBetween(1, 15);
//    rand=15;
     return (BonusType)rand;
}

void SXBonusManager::addBonusOfType(BonusType inBonus)
{
    freePos=this->getPositionInCoordinate(this->getFreeCoordinate());
    
    char a[20]={};
    sprintf(a,"bonus%d.png",inBonus);
    
    CCLog("bonus image %s",a);
    SXBonus *bonus =bonus->spriteWithFrame(a);
    DataManager->gameLayer->addChild(bonus,1);
    bonusArray->addObject(bonus);
    bonus->setPosition(ccp(freePos.x,freePos.y));
    
    bonus->bonusType=inBonus;
//    bonus->setTag(kBonusTag);
    bonus->type=kBonus;
   
    sprintf(a, "bonus%d_Glow.png",inBonus);
    bonus ->glowEffect(CCSprite::createWithSpriteFrameName(a));
    bonus->runAction(CCSequence::createWithTwoActions(CCDelayTime::create(9), CCCallFuncN::create(this, callfuncN_selector(SXBonusManager::  removeBonus))) );
    
    CCString *labelStr=(CCString*) bonusLabelStringsArray->objectAtIndex(inBonus-1);
    CCLabelTTF *bonusLabel=CCLabelTTF::create(labelStr->getCString(), "", 15);
    bonus->addChild(bonusLabel);
    bonusLabel->setPosition(ccp(20, 40));
}

# pragma mark - Power Up 
void SXBonusManager::addSheildPowerUp()
{
    this->PowerUpCount++;
        
    CCSprite *sprite=CCSprite::createWithSpriteFrameName("bonus1.png");
    MainLayer->addChild(sprite);
    sprite->setPosition(ccp(440, 280));
    
    CCBlink *blink=CCBlink::create(1, 1);
    CCRepeatForever *repeat=CCRepeatForever::create(blink);
    sprite->runAction(repeat);
        
    isPowerUpAdded=true;
    
    CCSequence *seq=CCSequence::createWithTwoActions(CCDelayTime::create(5),CCCallFuncN::create(this, callfuncN_selector(SXBonusManager::removePowerUp)));
    sprite->runAction(seq);
}

void SXBonusManager::addSpikePowerUp()
{
    SXBonus *sprite=sprite->spriteWithFrame("spike.png");
    MainLayer->addChild(sprite);
    sprite->setPosition(SXUtility::getRandomPoint());
    sprite->type=kBonus;
    sprite->bonusType=kSpike;
    this->bonusArray->addObject(sprite);
    CCBlink *blink=CCBlink::create(1, 1);
    CCRepeatForever *repeat=CCRepeatForever::create(blink);
    sprite->runAction(repeat);
    
    CCSequence *seq=CCSequence::createWithTwoActions(CCDelayTime::create(5),CCCallFuncN::create(this, callfuncN_selector(SXBonusManager::removePowerUp)));
    sprite->runAction(seq);
}

void SXBonusManager::removePowerUp( CCObject *Sender )
{
    CCSprite *Sprirte=(CCSprite*)Sender;
    this->toDeleteArray->addObject(Sprirte);
    this->isPowerUpAdded=false;
}

void SXBonusManager::removeBonus(CCObject *obj)
{
    isBonusPresent=false;
    SXBonus  *bonus=(SXBonus*)obj;
    this->toDeleteArray->addObject(bonus);
}

void SXBonusManager::checkForBonusType ( int tag)
{
    switch (tag)
    {
        case kdoubleScore:this->isDoubleScoreActivate=true;
            break;
        case kTripleScore: this->isTripleScoreActivete=true;
            break;
            
            case kSpike:
            Snake->snakeEffects->setSpikePowerUpEffect();
                  break;
        case kSnakeHeadBonus:
              //CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("shield.caf");

                SnakeManager->snake->snakeEffects->setShieldEffect();
                break;
                    
        case kSnakeSpeedIncreaseBonus:  //speed down
            
            this->gameLayer->snakeManager->snake->setSpeed(DataManager->snakeSpeed+2);
            break;
            
        case kSnakeSpeedDecreaseBonus:
            {//speed up
                   // CCLog("%f=snakespeed",DataManager->snakeSpeed);
                    float snakeSpeed=DataManager->snakeSpeed-1;
                    //CCLog("%f=snakespeed",snakeSpeed);
            this->gameLayer->snakeManager->snake->setSpeed(snakeSpeed);
            }
            break;
            
        case kMagnetBonus:  // magnet
            
            Snake->isHavingMagnet =true;
            Snake->scheduleOnce(schedule_selector(SXSnake::resetIsHavingMagnet),7);
            break;
              
        case kLifeBOnus:  //lifw
        //  CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("26 Life Purchase Button Sound.mp3");

             MainLayer->uiManager->updateLifeBonus();
            break;
            
        case kRemoveObstacleBonus:  // remove all obstacle
            ObstacleManager->removeAllObstacle();
            MainLayer->missileManager->RemoveAllMissiles();
            break;
            
        case kFuryModeBonus:  // fury mode
            Snake->scheduleOnce(schedule_selector(SXSnakeEffects::resetFuryBonusMode),10);
            Snake-> snakeEffects-> runFuryModeEffect();
            break;
            
           case kInvisiblePowerup:
            Snake ->setInvisiblePowrUpMode();
            Snake->scheduleOnce(schedule_selector(SXSnake::resetInvisiblePowerUpMode),10);
            break;
            
            case kLeftThroneShiel:
            Snake->snakeEffects->setShieldEffect(1);
            break;
            
        case kRightThroneShield:
            Snake->snakeEffects->setShieldEffect(2);
            break;
        case kBothSideThrone:
            Snake->snakeEffects->setShieldEffect(32);
            break;

        case kSuperMagnet:
            Snake->isHavingSuperMagnet =true;
            Snake->scheduleOnce(schedule_selector(SXSnake::resetIsHavingMagnet),10);
            break;
        case kFullBodySheild:
            Snake->isFullBodySheild=true;
            SnakeManager->snake->snakeEffects->fullBodySheildEffect();
            break;
            case kFreezer:
        {
            Snake->isFreezewrEnabled=true;
            CCDelayTime *delay=CCDelayTime::create(5);
            CCCallFunc *callback=CCCallFunc::create(Snake, callfunc_selector(SXSnake::resetFreezer));
            
            CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
            Snake->runAction(seq);
            Snake->setFrezMode();
        }
            
            break;
        default:
            break;
    }
}



#pragma mark - Coins
bool SXBonusManager::canAddCoins()
{
    if(this->isCoinPresent==false &&this->isHavingFreeCoordinates())
    {
        return true;
    }
    else
        return false;
}


#pragma mark - Free CoordinatePositon
CCPoint SXBonusManager::getPositionInCoordinate(CoordinatePositon selectedCoordinate)
{
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    CCPoint freePosition;
    
    if(selectedCoordinate ==kTopLeft)
    {
        freePosition.x = this->getRandomNumberBetween(20, winSize.width/2);
        freePosition.y =this->getRandomNumberBetween(winSize.height/2,winSize.height-100);
    }
    else if (selectedCoordinate==kTopRight)
    {
        freePosition.x = this->getRandomNumberBetween(winSize.width/2, winSize.width-100);
        freePosition.y =this->getRandomNumberBetween(winSize.height/2,winSize.height-100);
    }
    else if (selectedCoordinate==kBottomLeft)
    {
        freePosition.x = this->getRandomNumberBetween(20, winSize.width/2);
        freePosition.y =this->getRandomNumberBetween(20,winSize.height/2);
    }
    
    else if (selectedCoordinate==kBottomRight)
    {
        freePosition.x = this->getRandomNumberBetween(winSize.width/2, winSize.width-100);
        freePosition.y =this->getRandomNumberBetween(20,winSize.height/2);
    }
    return freePosition;
}

CoordinatePositon SXBonusManager:: getFreeCoordinate()
{
    CCArray *freeSidesArr = CCArray::create();
    freeSidesArr->retain();
    
    CCRect t1;
    
    CCNumber<int> *intOne = CCNumber<int>::numberWithValue(1);
    CCNumber<int> *intTwo = CCNumber<int>::numberWithValue(2);
    CCNumber<int> *intThree = CCNumber<int>::numberWithValue(3);
    CCNumber<int> *intFour = CCNumber<int>::numberWithValue(4);
    
    freeSidesArr->addObject(intOne);
    freeSidesArr->addObject(intTwo);
    freeSidesArr->addObject(intThree);
    freeSidesArr->addObject(intFour);
    
    //Check for Snake
    SXSnake *snakeHead=Snake;
    CoordinatePositon aCoordinate = SXUtility::getCoordinateForPosition(snakeHead->getPosition());

    if (aCoordinate == kTopLeft)
        freeSidesArr->removeObject(intOne);
    else if (aCoordinate == kTopRight)
        freeSidesArr->removeObject(intTwo);
    else if (aCoordinate == kBottomRight)
        freeSidesArr->removeObject(intThree);
    else if (aCoordinate == kBottomLeft)
        freeSidesArr->removeObject(intFour);
    
    CCObject *obj;
    CCARRAY_FOREACH(this->gameLayer->obstacleManager->obstaclesArray , obj)
    {
        SXObstacle *obstacle=(SXObstacle*)obj;
        CoordinatePositon obstacleCoordinate = SXUtility::getCoordinateForPosition(obstacle->getPosition());

        if (aCoordinate || obstacleCoordinate == kTopLeft)
            freeSidesArr->removeObject(intOne);
        else if (aCoordinate || obstacleCoordinate  == kTopRight)
            freeSidesArr->removeObject(intTwo);
        else if (aCoordinate || obstacleCoordinate == kBottomRight)
            freeSidesArr->removeObject(intThree);
        else if (aCoordinate ||obstacleCoordinate  == kBottomLeft)
            freeSidesArr->removeObject(intFour);
    }
       //Get the free side from Array
    CCNumber<int> * selectedCoordinateInt = (CCNumber<int> *)freeSidesArr->objectAtIndex(arc4random()%freeSidesArr->count());
    CC_SAFE_RELEASE(freeSidesArr);
    
    CoordinatePositon selectedCoordinate = (CoordinatePositon)selectedCoordinateInt->getValue();
    return selectedCoordinate;
}

bool SXBonusManager::isHavingFreeCoordinates()
{
    CCArray *freeSidesArr = CCArray::create();
    freeSidesArr->retain();
    
    CCRect t1;
    
    CCNumber<int> *intOne = CCNumber<int>::numberWithValue(1);
    CCNumber<int> *intTwo = CCNumber<int>::numberWithValue(2);
    CCNumber<int> *intThree = CCNumber<int>::numberWithValue(3);
    CCNumber<int> *intFour = CCNumber<int>::numberWithValue(4);
    
    freeSidesArr->addObject(intOne);
    freeSidesArr->addObject(intTwo);
    freeSidesArr->addObject(intThree);
    freeSidesArr->addObject(intFour);
    
    //Check for Snake
    
    SXSnake *snakeHead=Snake;
    CoordinatePositon aCoordinate = SXUtility::getCoordinateForPosition(snakeHead->getPosition());
    
    if (aCoordinate == kTopLeft)
        freeSidesArr->removeObject(intOne);
    else if (aCoordinate == kTopRight)
        freeSidesArr->removeObject(intTwo);
    else if (aCoordinate == kBottomRight)
        freeSidesArr->removeObject(intThree);
    else if (aCoordinate == kBottomLeft)
        freeSidesArr->removeObject(intFour);
    
    CCObject *obj;
    CCARRAY_FOREACH(ObstacleManager->obstaclesArray , obj)
    {
        SXObstacle *obstacle=(SXObstacle*)obj;
        CoordinatePositon obstacleCoordinate = SXUtility::getCoordinateForPosition(obstacle->getPosition());
        
        if ( obstacleCoordinate == kTopLeft)
            freeSidesArr->removeObject(intOne);
        else if (obstacleCoordinate  == kTopRight)
            freeSidesArr->removeObject(intTwo);
        else if ( obstacleCoordinate == kBottomRight)
            freeSidesArr->removeObject(intThree);
        else if (obstacleCoordinate  == kBottomLeft)
            freeSidesArr->removeObject(intFour);
    }
    
    CCARRAY_FOREACH(bonusArray , obj)
    {
        SXBonus *bonus=(SXBonus*)obj;
        CoordinatePositon bonusPosition = SXUtility::getCoordinateForPosition(bonus->getPosition());
        
        if (bonusPosition == kTopLeft)
            freeSidesArr->removeObject(intOne);
        else if (bonusPosition  == kTopRight)
            freeSidesArr->removeObject(intTwo);
        else if (bonusPosition == kBottomRight)
            freeSidesArr->removeObject(intThree);
        else if (bonusPosition  == kBottomLeft)
            freeSidesArr->removeObject(intFour);
    }
    CCARRAY_FOREACH(coinsArray , obj)
    {
        
        SXCoin *coin=(SXCoin*)obj;
        CoordinatePositon coinPosition = SXUtility::getCoordinateForPosition(coin->getPosition());
        
        if (coinPosition == kTopLeft)
            freeSidesArr->removeObject(intOne);
        else if (coinPosition  == kTopRight)
            freeSidesArr->removeObject(intTwo);
        else if (coinPosition == kBottomRight)
            freeSidesArr->removeObject(intThree);
        else if (coinPosition  == kBottomLeft)
            freeSidesArr->removeObject(intFour);
    }
    
    //Get the free side from Array
    if(freeSidesArr->count()>0)
    {
        CC_SAFE_RELEASE(freeSidesArr);
        return  true;
    }
    else
    {
        CC_SAFE_RELEASE(freeSidesArr);
        return false;
    }
}

#pragma mark - Clear
void SXBonusManager::clear()
{
        CCObject *obj;
        CCARRAY_FOREACH(this->toDeleteArray, obj)
        {
                SXCustomSprite *sprite=(SXCustomSprite*)obj;
                DataManager->gameLayer->removeChild(sprite);
                if(sprite->type==kBonus || sprite->type==kRandomFood || sprite->type==kPoisonFood )
                {
                        this->bonusArray->removeObject(sprite);
                }
                else if(sprite->type==kCoinTag  )
                {
                        this->coinsArray->removeObject(sprite);
                }
        }
        this->toDeleteArray->removeAllObjects();
}

#pragma mark - Utility
int SXBonusManager::getRandomNumberBetween(int min, int max)
{
    int toNumber = max + 1;
    int fromNumber = min;
    
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    
    return randomNumber;
}

CoordinatePositon SXBonusManager::getCoordinateForPosition(CCPoint inPosition)
{
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    
    if (inPosition.x<=winSize.width/2&&inPosition.y>winSize.height/2) {
        return kTopLeft;
    }
    else if (inPosition.x>=winSize.width/2&&inPosition.y>winSize.height/2)
    {
        return kTopRight;
    }
    else if (inPosition.x>=winSize.width/2&&inPosition.y<winSize.height/2)
    {
        return kBottomRight;
    }
    else if (inPosition.x<=winSize.width/2&&inPosition.y<winSize.height/2)
    {
        return kBottomLeft;
    }
    return kTopLeft;
}
