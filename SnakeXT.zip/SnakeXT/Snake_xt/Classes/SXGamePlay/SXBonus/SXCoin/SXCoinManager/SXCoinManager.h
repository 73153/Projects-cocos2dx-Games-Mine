//
//  SXCoinManager.h
//  Snake_xt
//
//  Created by Pavitra on 06/02/13.
//
//

#ifndef __Snake_xt__SXCoinManager__
#define __Snake_xt__SXCoinManager__

#include <iostream>
#include "SXGameManager.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"

class SXCoin;

class SXCoinManager :public SXGameManager
{
public:
        
        SXCoinManager();
        ~SXCoinManager();
        
        CoinShape getCoinTypeToAdd();
        void addCoinToScene(CoinShape inShape);
        
        void addSingleCoin();
        void addSquare(int xPos,int yPos,int length,int noOfItems);
        void addLine(int x,int y);
        void addVShape(int x,int y,int length);
        void addcrossShape(int x,int y,int length);
        
      //  void rotateCoin(CCSprite *spr);
        void afterCoinCollision(SXCustomSprite *sprite);
        void checkCollisionForCoins();
        void removeCoin( CCObject *sender);
       // void runAnimation();
        SXCoin   *coinSpr;
        
        int coinsCount;         
};
#endif /* defined(__Snake_xt__SXCoinManager__) */
