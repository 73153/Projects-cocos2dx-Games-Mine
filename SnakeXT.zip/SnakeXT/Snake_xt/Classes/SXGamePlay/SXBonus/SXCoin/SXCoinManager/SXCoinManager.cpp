//
//  SXCoinManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 06/02/13.
//
//

#include "SXCoinManager.h"
#include "SXMainController.h"
#include "SXDataManager.h"
#include "SXCoin.h"
#include "SXGameConstants.h"
#include "SXBonusManager.h"

SXCoinManager ::SXCoinManager()
{
    this->coinsCount=0;
      
}

SXCoinManager ::~SXCoinManager()
{
        
}

#pragma mark - Adding Coin
void SXCoinManager:: addCoinToScene(CoinShape inShape)
{
    //Get Free Position
    CCPoint   freePos=DataManager->gameLayer->bonusManager->getPositionInCoordinate(DataManager->gameLayer->bonusManager->getFreeCoordinate());
    
    DataManager->gameLayer->bonusManager->isCoinPresent = true;
    
    if(inShape==kSingleCoin)
    {
        this->addSingleCoin();
    }
    
    else if(inShape==kSquareCoin)
    {
        int length=DataManager->gameLayer->bonusManager->getRandomNumberBetween(2, 4);

        if(length==2)
        {
            this->addSquare(freePos.x,freePos.y,2,3);
        }
        else if(length==3)
        {
            this->addSquare(freePos.x,freePos.y,3,7);
        }
        else if(length==4)
        {
            this->addSquare(freePos.x,freePos.y,4,11);
        }
    }
    else if(inShape==kLineCoin)
    {
        this->coinsCount=0;
        this->addLine(freePos.x,freePos.y);
    }
    
    else if(inShape==kCrossShapeCoin)
    {
        int length=DataManager->gameLayer->bonusManager->getRandomNumberBetween(4, 6);
        this->addcrossShape(freePos.x, freePos.y,length);
    }
        
    if(inShape==kVShapeCoin)
    {
           int length=DataManager->gameLayer->bonusManager->getRandomNumberBetween(4, 6);
        
            this->addVShape(freePos.x ,freePos.y,length);
            
        }
   }

CoinShape SXCoinManager::getCoinTypeToAdd()
{
        int rand = BonusManager->getRandomNumberBetween(0,4);
      
        if(rand==0)
        {
                return kSingleCoin;
        }
        else if(rand==1)
        {
                return kSquareCoin;
        }
        else if(rand ==2)
        {
                return  kCrossShapeCoin;
        }
        else if(rand ==3)
        {
                return kVShapeCoin;
        }
        else if(rand==4)
        {
                
        return kLineCoin;
                
        }
         return kLineCoin;
}

#pragma mark Coin Shape
void SXCoinManager::addSquare(int xPos,int yPos,int length,int noOfItems)
{
        for(int i=0;i<=noOfItems;i++)
        {
                DataManager->gameLayer->bonusManager->coinsCount++;
                SXCoin   *coinSpr = coinSpr->spriteWithFrame("Coin_1.png");
                coinSpr->setOpacity(0);
                coinSpr->runAnimation();
                
                if(i>=0&&i<=length-1)
                {
                        xPos=xPos+20;
                        yPos=yPos;
                }
                if(i>=length&&i<=length*2-2)
                {
                        xPos=xPos;
                        yPos=yPos-20;
                        
                }
                else if(i>=length*2-1&&i<=length*3-3)
                {
                        xPos=xPos-20;
                        yPos=yPos;
                }
                if(i>=length*3-2 && i<=length*4-5)
                {
                        xPos=xPos;
                        yPos=yPos+20;
                }
                if(xPos>470||xPos<10 ||yPos>300||yPos<5)
                        
                {
                        coinSpr->setVisible(false);
                }
                
                coinSpr->setPosition(ccp(xPos,yPos));
               
               // this->rotateCoin(coinSpr);
                DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
        }
      
}
void SXCoinManager:: addVShape(int xPos,int yPos,int length)
{
        SXCoin   *coinSpr;
        DataManager->gameLayer->bonusManager->coinsCount++;
        
        for(int i=0;i<=length;i++)
        {
                coinSpr = coinSpr->spriteWithFrame("SXCoin1.png");
                 coinSpr->setOpacity(0);
              
                 coinSpr->runAnimation();
                xPos=xPos+15;
                yPos=yPos+10;
                
                coinSpr->setPosition(ccp(xPos,yPos));
           //     this->rotateCoin(coinSpr);
                
                if(xPos>=470||xPos<10 ||yPos>310||yPos<10)
                {
                        coinSpr->setVisible(false);
                }
                
                DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
        }
    
        for( int i=length+1;i<=length*2;i++)
        {
                coinSpr = coinSpr->spriteWithFrame("SXCoin1.png");
                coinSpr->setOpacity(0);
                 coinSpr->runAnimation();
                xPos=xPos+15;
                yPos=yPos-10;
                
                coinSpr->setPosition(ccp(xPos,yPos));
              //  this->rotateCoin(coinSpr);
                
                if(xPos>=470||xPos<10 ||yPos>310||yPos<10)
                {
                        coinSpr->setVisible(false);
                }
                
                DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
                
        }
}

void SXCoinManager::addcrossShape(int xpos,int ypos,int length)
{
        SXCoin   *coinSpr;
        DataManager->gameLayer->bonusManager->coinsCount++;
        for(int i=0;i<=length;i++)
        {
                coinSpr = coinSpr->spriteWithFrame("SXCoin1.png");
                coinSpr->setOpacity(0);
                  coinSpr->runAnimation();
                xpos=xpos+15;
                ypos=ypos+10;
                
                coinSpr->setPosition(ccp(xpos,ypos));
             //   this->rotateCoin(coinSpr);
                
                if(xpos>=470||xpos<10 ||ypos>310||ypos<10)
                {
                        coinSpr->setVisible(false);
                }
                DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
                
        }
        
        xpos=xpos-90;
        ypos=ypos+10;
        for( int i=length+1;i<=length*2+1;i++)
        {
                coinSpr = coinSpr->spriteWithFrame("SXCoin1.png");
                coinSpr->setOpacity(0);
                  coinSpr->runAnimation();
                xpos=xpos+15;
                ypos=ypos-10;
                
                coinSpr->setPosition(ccp(xpos,ypos));
             //   this->rotateCoin(coinSpr);
                
                if(xpos>=470||xpos<10 ||ypos>310||ypos<10)
                {
                        coinSpr->setVisible(false);
                }
                DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
        }
}

void SXCoinManager::addLine(int x,int y)
{
    for(int i=1;i<=5;i++)
    {
       SXCoin *coinSpr = coinSpr->spriteWithFrame("SXCoin1.png");
        coinSpr->setOpacity(0);
          coinSpr->runAnimation();
        x=x+20;
        y=y;
        
        if(x>=470|| y>=310 ||x<=10 ||y<=10)
        {
            coinSpr->setVisible(false);
        }
            
       DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
       coinSpr->setPosition(ccp(x,y));
     //  this->rotateCoin(coinSpr);
    }
}

void SXCoinManager::addSingleCoin()
{
        CCPoint   freePos=BonusManager->getPositionInCoordinate(DataManager->gameLayer->bonusManager->getFreeCoordinate());
        
        DataManager->gameLayer->bonusManager->coinsCount++;
        
        SXCoin * coinSpr   = coinSpr->spriteWithFrame("SXCoin1.png");
        coinSpr->setOpacity(0);
          coinSpr->runAnimation();
        coinSpr->setPosition(freePos);
        if(coinSpr->getPosition().x>480 || coinSpr->getPosition().y>320)
        {
                coinSpr->setVisible(false);
        }
        DataManager->gameLayer->bonusManager->coinsArray->addObject(coinSpr);
      //  this->rotateCoin(coinSpr);
}

#pragma mark - Other
//void SXCoinManager::rotateCoin(CCSprite *spr)
//{
//    CCActionInterval*  rotate = CCRotateTo::create( 3, 180);
//    CCActionInterval*  rotate1 = CCRotateTo::create( 2, -45);
//    CCActionInterval*  rotate2 = CCRotateTo::create(2 , 0);
//    spr->runAction( CCSequence::create(rotate, rotate1,rotate2, NULL));
//}

void SXCoinManager:: removeCoin( CCObject *sender)
{
    SXCoin *coin=(SXCoin*)sender;
    MainLayer->removeChild(coin);
    BonusManager->coinsArray->removeObject(coin);
    BonusManager->isCoinPresent=false;
}

