//
//  SXCoin.cpp
//  Snake_xt
//
//  Created by Deepthi on 18/01/13.
//
//

#include "SXCoin.h"
#include "SXBonus.h"

#include "SXGameConstants.h"
#include "SXDataManager.h"

#include "SXBonusManager.h"
#include "SXSnakeManager.h"
#include "SXUtility.h"
#include "SXCoinManager.h"

#define PTM_RATIO 32

using namespace cocos2d;


SXCoin::SXCoin()
{
        this->type=kCoinTag;
        CCActionInterval *fadeAction=CCFadeIn::create(2);
        this->runAction(fadeAction);
        CCActionInterval *fadeOut=CCFadeOut::create(2);
        CCBlink *blink = CCBlink::create(2, 5);
        this->moveToPoint=Snake->getPosition();
        this->runAction(CCSequence::create(CCDelayTime::create(8),blink, fadeOut,CCCallFuncN::create(this, callfuncN_selector(SXCoinManager::removeCoin)),NULL));
        MainLayer->addChild(this);
        //CCLog("%d=arrycount",t)
}

//void SXCoin::removeAnimation()
//{
//       // this->stopActionByTag(2);
//}
void SXCoin::runAnimation()
{
   
        CCAnimationCache *animCache2 = CCAnimationCache::sharedAnimationCache();
        CCAnimation *animation2 = animCache2->animationByName("Coin");
      //  animation2->setRestoreOriginalFrame(1);
        CCAnimate *animN2 = CCAnimate::create(animation2);
         animN2->setTag(2);
        //this->runAction(animN2);
        //this ->runAction(CCRepeatForever::create(animN2));
       this ->runAction(CCRepeat::create(animN2,9));
}

SXCoin::~SXCoin()
{
    
}

void SXCoin::update()
{
        CCPoint desiredDirection = SXUtility::normalizeVector(ccpSub(Snake->getPosition(), this->getPosition()));
        int distance=1;
        CCPoint velocity=ccpMult(desiredDirection, 2);
        this->setPosition(ccpAdd(this->getPosition(), velocity));
        this->setRotation(SXUtility::getAngleFromCurrentPoint(this->getPosition(),Snake->getPosition()));
        if((ccpDistance(Snake->getPosition(),this->getPosition())>=distance && ccpDistance(Snake->getPosition(),this->getPosition())<=15) )
                //|| ccpDistance(Snake->getPosition(), this->getPosition())>80 )
                    {
                               MainLayer->removeChild(this);
//                            if(ccpDistance(Snake->getPosition(), this->getPosition())<=25)
//                            {
//                                    
//                                    this->cocos2d::CCNode::setVisible(false);
//                            }
                 
                  BonusManager->isCoinPresent=false;
                   }

    // int distace=10;//5
//      CCPoint velocity=ccpMult(desiredDirection, 0.5);//1.5
//      this->setPosition(ccpAdd(this->getPosition(), velocity));
//      this->setRotation(SXUtility::getAngleFromCurrentPoint(this->getPosition(),Snake->getPosition()));
//        this->setPosition(target->getPosition());
//        CCMoveTo * move = CCMoveTo::create(0.1, CCPoint(200,200))
//        ;
//        this->runAction(move);
//         this->setRotation(SXUtility::getAngleFromCurrentPoint(this->getPosition(),Snake->getPosition()));
//        float point =ccpDistance(Snake->getPosition(), this->getPosition() );
//        CCLog("%f =val",point);
//    if((ccpDistance(Snake->getPosition(),this->getPosition())>=distace && ccpDistance(Snake->getPosition(),this->getPosition())<=15 ) || ccpDistance(Snake->getPosition(), this->getPosition())>30 )
//    {
//        MainLayer->removeChild(this);
//        BonusManager->isCoinPresent=false;
//    }
}

SXCoin* SXCoin ::spriteWithFrame(const char *pszFileName)
{
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    SXCoin *tempSpr = SXCoin::create(pFrame);
    return tempSpr;
}

SXCoin* SXCoin::create(CCSpriteFrame *pSpriteFrame) {
    
    SXCoin *pobSprite = new SXCoin();
    
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }

    
    CC_SAFE_DELETE(pobSprite);
    
    return NULL;
}


