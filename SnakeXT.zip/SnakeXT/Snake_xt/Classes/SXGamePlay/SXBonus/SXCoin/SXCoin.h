//
//  SXCoin.h
//  Snake_xt
//
//  Created by Deepthi on 18/01/13.
//
//

#ifndef Snake_xt_SXCoin_h
#define Snake_xt_SXCoin_h

#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXBonusManager.h"

using namespace cocos2d;

class SXCoin :public SXCustomSprite
{
public:
     SXCoin();
    ~SXCoin();
    SXCoin *coinSpr;
    
    CCPoint moveToPoint;
    void update();
    
    CCSprite *target;
    
    SXCoin* spriteWithFrame(const char *pszFileName);
    SXCoin* create(CCSpriteFrame *pSpriteFrame);
    void   runAnimation();
        void removeAnimation();
};


#endif
