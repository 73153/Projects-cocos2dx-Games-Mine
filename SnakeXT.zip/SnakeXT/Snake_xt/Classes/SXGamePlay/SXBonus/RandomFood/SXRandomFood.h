//
//  SXRandomFood.h
//  Snake_xt
//
//  Created by Deepthi on 27/02/13.
//
//

#ifndef Snake_xt_SXRandomFood_h
#define Snake_xt_SXRandomFood_h
#include <iostream>
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXObstacle.h"
#include "SXObstaclesManager.h"
using namespace cocos2d;
class SXCustomSprite;

class SXRandomFood : public SXCustomSprite
{
public:
        SXRandomFood();
        ~SXRandomFood();
        
        SXRandomFood* spriteWithFrame(const char *pszFileName );
        SXRandomFood* create(CCSpriteFrame *pSpriteFrame);
        
        void update();
        void remove();

         BoundrySide side;
        CCRect mainFrame;
        float currentAngle;
        
        void selectPositionForRandomFood();
        void getRandomDirection();
        void getRandomAngle();
        
      Direction randomFoodDirection;
};

#endif
