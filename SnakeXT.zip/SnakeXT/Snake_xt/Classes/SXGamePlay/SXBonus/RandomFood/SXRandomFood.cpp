//
//  SXRandomFood.cpp
//  Snake_xt
//
//  Created by Deepthi on 27/02/13.
//
//

#include "SXRandomFood.h"
#include <iostream>
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXObstacle.h"
#include "SXSnake.h"

#include "SXMainController.h"

#include "SXObstaclesManager.h"
#include "SXSnakeManager.h"
#include "SXBonusManager.h"
#include "SXDataManager.h"
#include "SXUtility.h"


using namespace cocos2d;

SXRandomFood::SXRandomFood()
{
       this->type=kRandomFood;
        this->selectPositionForRandomFood();
        this->schedule(schedule_selector(SXRandomFood::update));
        this->schedule(schedule_selector(SXRandomFood::getRandomDirection));
}

SXRandomFood::~SXRandomFood()
{
        
}
SXRandomFood* SXRandomFood :: spriteWithFrame(const char *pszFileName)
{
        char str[20]={};
        sprintf(str, "%s",pszFileName);
        
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(str);
        
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
        
        // CCAssert(pFrame != NULL, msg);
        
        SXRandomFood *tempSpr = new SXRandomFood();
        tempSpr->initWithSpriteFrame(pFrame);
        return tempSpr;
}
SXRandomFood* SXRandomFood::create(CCSpriteFrame *pSpriteFrame )
{
        SXRandomFood *pobSprite = new SXRandomFood();
        pobSprite->type=kRandomFood;
        if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}

/*void SXRandomFood::selectPositionForRandomFood()
{
        BoundrySide inBoundry=SXUtility::getBoundarySide();
        this->side=inBoundry;
        if(side==kTop)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, 350)); //500
                this->currentAngle=180;
                mainFrame = CCRectMake(-100,-100, 600, 600);
                
        }
        
        else if(side==kBottom)
        {
                this->setPosition(ccp(SXUtility::getRandomPoint().x, -200));
                this->currentAngle=0;
                mainFrame = CCRectMake(-100, -200,600, 600);
        }
        
        else if(side ==kLeft)
        {
                this->setPosition(ccp(-200,SXUtility::getRandomPoint().y ));
                this->currentAngle=90;
                mainFrame = CCRectMake(-200, -100, 760, 500);
                
        }
        
        else  // right
        {
                this->setPosition(ccp(600,SXUtility::getRandomPoint().y ));
                this->currentAngle=270;
                mainFrame = CCRectMake(-100, -100, 700, 600);
                
        }
}*/
void SXRandomFood::selectPositionForRandomFood()
{
    BoundrySide inBoundry=SXUtility::getBoundarySide();
    this->side=inBoundry;
    
    if(side==kTop)
    {
        this->setPosition(ccp(SXUtility::getRandomPoint().x, 300)); //500
        this->currentAngle=180;
        mainFrame = CCRectMake(-100,-100, 600, 600);
        if(BonusManager->randValue==4)
        {
            this->setRotation(180);
            CCActionInterval*  actionTo = CCJumpTo::create(5, CCPoint(this->getPositionX(),-10), 20, 11);
            CCCallFunc *callFunc = CCCallFunc::create(this, callfunc_selector(SXRandomFood::remove));
            this->runAction(CCSequence::create(actionTo,callFunc,NULL));
        }
    }
    
    else if(side==kBottom)
    {
        this->setPosition(ccp(SXUtility::getRandomPoint().x, -200));
        this->currentAngle=0;
        mainFrame = CCRectMake(-100, -200,600, 600);
        if(BonusManager->randValue==4)
        {
            this->setRotation(0);
            CCActionInterval*  actionTo = CCJumpTo::create(5, CCPoint(this->getPositionX(),350), 20, 11);
            CCCallFunc *callFunc = CCCallFunc::create(this, callfunc_selector(SXRandomFood::remove));
            this->runAction(CCSequence::create(actionTo,callFunc,NULL));
        }
        
    }
    
    else if(side ==kLeft)
    {
        this->setPosition(ccp(-200,SXUtility::getRandomPoint().y ));
        this->currentAngle=90;
        mainFrame = CCRectMake(-200, -100, 760, 500);
        if(BonusManager->randValue==4)
        {
            this->setRotation(90);
            CCActionInterval*  actionTo = CCJumpTo::create(5, CCPoint(500,this->getPositionY()), 20, 11);
            CCCallFunc *callFunc = CCCallFunc::create(this, callfunc_selector(SXRandomFood::remove));
            this->runAction(CCSequence::create(actionTo,callFunc,NULL));
            
        }
        
        
    }
    
    else  // right
    {
        this->setPosition(ccp(600,SXUtility::getRandomPoint().y ));
        this->currentAngle=270;
        mainFrame = CCRectMake(-100, -100, 700, 600);
        if(BonusManager->randValue==4)
        {
            this->setRotation(270);
            CCActionInterval*  actionTo = CCJumpTo::create(5, CCPoint(-20,this->getPositionY()), 20,10);
            CCCallFunc *callFunc = CCCallFunc::create(this, callfunc_selector(SXRandomFood::remove));
            this->runAction(CCSequence::create(actionTo,callFunc,NULL));
        }
        
        
    }
    
}
void SXRandomFood::update()
{
    if(!Snake->isFreezewrEnabled){
        float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*.8;
        float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*.8;
        this->setPosition(CCPointMake(X, Y));
        this->setRotation(currentAngle);
        this->getRandomAngle();
        if(!mainFrame.containsPoint(this->getPosition()))
        {
            this->remove();
        }
    }
}
void SXRandomFood::remove()
{
        BonusManager->toDeleteArray->addObject(this);
}

void SXRandomFood::getRandomDirection()
{
        
        int rand = arc4random()%2;
        if(rand==0)
        {
                randomFoodDirection=kLeftDirection;
        }
        if(rand==1)
        {
                randomFoodDirection=kRightDirection;
        }
        if(rand==2)
        {
                randomFoodDirection=kStraightDirection;
        }
        
        
}
void SXRandomFood::getRandomAngle()
{
        if(this->randomFoodDirection==kLeftDirection)
        {
                //  currentAngle++;
                currentAngle=currentAngle+0.6;
        }
        else if(this->randomFoodDirection==kRightDirection)
        {
                //currentAngle--;
                currentAngle=currentAngle-0.6;
        }
}



