//
//  SXBonus.cpp
//  Snake_xt
//
//  Created by Deepthi on 08/01/13.
//
//

#include "SXBonus.h"
#include "SXSelectBG.h"
#include "SXMainMenu.h"
#include "SXGameModeScene.h"
#include "SXOptionScene.h"
#include "SXGameConstants.h"
#include "SXDataManager.h"
#include "SXUtility.h"

#define PTM_RATIO 32

using namespace cocos2d;

SXBonus::SXBonus()
{

}

SXBonus* SXBonus ::spriteWithFrame(const char *pszFileName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    SXBonus *tempSpr = SXBonus::create(pFrame);
    return tempSpr;
}

SXBonus* SXBonus::create(CCSpriteFrame *pSpriteFrame)
{
   SXBonus *pobSprite = new SXBonus();
    pobSprite->type=kBonus;
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
   CC_SAFE_DELETE(pobSprite);
    return NULL;
}

void SXBonus::glowEffect(CCSprite *spr)
{
    spr->setPosition(ccp(this->getContentSize().width/2,this->getContentSize().height/2));
    this->addChild(spr,-4);
        
    CCFiniteTimeAction *actionScale1 = CCScaleTo::create(0.5, 1);
    CCFiniteTimeAction *actionScale2 = CCScaleTo::create(0.5, 0.5);
    
    CCFiniteTimeAction *Sequence=CCSequence::create(actionScale1,actionScale2,NULL);
    CCRepeat *repeat=CCRepeat::create(Sequence, 5);
    spr->runAction(repeat);
}

#pragma mark - Dealloc
SXBonus::~SXBonus()
{

}

