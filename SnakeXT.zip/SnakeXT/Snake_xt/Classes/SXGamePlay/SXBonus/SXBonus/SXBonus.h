//
//  SXBonus.h
//  Snake_xt
//
//  Created by Deepthi on 08/01/13.
//
//

#ifndef Snake_xt_SXBonus_h
#define Snake_xt_SXBonus_h

#include <iostream>
#include "cocos2d.h"
#include "SXGameModeScene.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
#include "SXBonusManager.h"

using namespace cocos2d;

class SXBonus :public SXCustomSprite
{
    public:
    SXBonus();
    ~SXBonus();

    SXBonus* spriteWithFrame(const char *pszFileName);
    SXBonus* create(CCSpriteFrame *pSpriteFrame);

   void glowEffect(CCSprite *spr);
        
     BonusType bonusType;        
        
  };
#endif
