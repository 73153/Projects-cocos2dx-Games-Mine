//
//  SXCollisionManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 01/02/13.
//
//

#include "SXCollisionManager.h"
#include "SXObstaclesManager.h"
#include "SXSnakeManager.h"
#include "SXMainController.h"
#include "SXBonusManager.h"
#include "SXUIManager.h"
#include "SXMissileManager.h"

#include "SXObstacle.h"
#include "SXLazer.h"
#include "SXRandomSnake.h"
#include "SXWall.h"
#include "SXWheel.h"

#include "SXGun.h"

#include "SXCoin.h"
#include "SXBonus.h"
#include "SXRandomFood.h"

#include "SXSnake.h"
#include "SXSnakeBody.h"
#include "SXSnakeEffects.h"
#include "SXSnakeManager.h"
#include "SXBackgroundManager.h"

#include "SXMissile.h"
#include "SXBomb.h"


#include "SXGameConstants.h"
#include "SXUtility.h"
#include "SXDataManager.h"

SXCollisionManager::SXCollisionManager() {
        
}

SXCollisionManager::~SXCollisionManager(){
        
}

void SXCollisionManager::checkCollision() {
        this->checkCollisionForrandomFood();
        this->checkCollisionForBonus();
        this->checkCollisionForCoins();
        this->checkCollisionIthLaser();
        this->checkCollisionWithWall();
        this->checkCollisionWithRandonSnake();
        this->collisionForCoinWithObstacles();
        this->checkCollisionForMissile();
        this->checkCollisionWithWheel();
        this->checkCollisionWithTrap();
        this->checkCollisionForUnderGround();
        this->checkCollisionWithFence();
       this->checkCollisionForShieldThrone();
}

#pragma mark- collision for  missiles
void SXCollisionManager::checkCollisionForMissile()
{
        
        CCObject *obj;
        CCARRAY_FOREACH(MainLayer->missileManager->missilesArray, obj)
        {
                SXCustomSprite *sprite=(SXCustomSprite*)obj;
                if(ccpDistance(Snake->getPosition(), sprite->getPosition())<=30 ) { // for both eagle and missile
                        
                        if(Snake->isFuryModeEnabled)
                        {
                                if(sprite->type!=kBomb)
                                {
                                        MainLayer->missileManager->runAnimatiion(sprite);
                                        
                                }
                                else{
                                        SXBomb *bomb=(SXBomb*)sprite;
                                        MainLayer->missileManager->toDeleteArray->addObject(bomb);
                        }
                }
                
                else if(!Snake->isHeadInsideUnderGrd) {
                        if(sprite->type==kBomb && !Snake->isCollideWithEagle) {
                                Snake->isCollideWithEagle=true;
                                 SXBomb *bomb=(SXBomb*)sprite;
                                bomb->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Hunting-Eagle.png"));
                                bomb->stopActionByTag(1);
                                
                               Snake->setSpeed(1);
                                //Snake->currentspeed=1.5;
                               // CCCallFunc *calback=CCCallFunc::create(Snake, callfunc_selector(SXSnake::setNormalSpeed));
                                //MainLayer->runAction(CCSequence::create(CCDelayTime::create(4),calback,NULL));
                        }
                        
                        Snake->snakeEffects->runHitEffect();
                }
                
                
                // MainLayer->missileManager->toDeleteArray->addObject(sprite);
        }
                else if (sprite->type==kBomb){
                        SXBomb *bomb=(SXBomb*)sprite;
                        //bomb->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Flying _Eagle_1.png"));

                }
   }
    
        CCARRAY_FOREACH(MainLayer->missileManager->bulletsArray, obj)  // collision with bulletes
        {
                SXCustomSprite *sprite=(SXCustomSprite*)obj;
                CCPoint point=sprite->convertToWorldSpace(sprite->getPosition());
                
                if(ccpDistance(Snake->getPosition(),point)<=10 )
                {
                        Snake->snakeEffects->runHitEffect();
                }
        }
/*  if(sprite->type==kMissile)
 {
 if(Snake->boundingBox().containsPoint(sprite->getPosition())) {
 
 }
 }
 
 else if((sprite->type==kGun  && ccpDistance(Snake->getPosition(), sprite->getPosition())<=10 ) ){
 SXGun *gun=(SXGun*)sprite;
 
 if(Snake->isFuryModeEnabled && !gun->isAlertFound) {
 gun->runAnimation();
 }
 
 else {
 Snake->snakeEffects->runHitEffect();
 }
 }
 
 else  if(ccpDistance(Snake->getPosition(), sprite->getPosition())<=10)
 {
 Snake->snakeEffects->runHitEffect();
 }
 } */

}

#pragma mark- collision for bonus
void SXCollisionManager::checkCollisionForrandomFood() {
        
        CCObject *obj;
        CCARRAY_FOREACH(BonusManager->bonusArray, obj)
        {
                SXCustomSprite *sprite=(SXCustomSprite*)obj;
                if(sprite->type==kRandomFood || sprite->type==kPoisonFood){
                        SXRandomFood *bonus=(SXRandomFood*)obj;
                        
                        if((ccpDistance(Snake->getPosition(),bonus->getPosition())<25  && !Snake->isEnteredUnderGround)) {
                                
                                BonusManager->toDeleteArray->addObject(bonus);
                                if(sprite->type==kRandomFood){
                                        MainLayer->uiManager->score+=100;
                                }
                            
                                else if(!Snake->isFuryModeEnabled&&!Snake->isinvisiblePowerupEnabled &&!Snake->snakeEffects->isHavingSpikePowerUp &&!Snake->isFullBodySheild){
                                        MainLayer->uiManager->updateLifeArray();
                                }
                        }
                }
        }
}

void SXCollisionManager::checkCollisionForBonus(){
        
        CCObject *obj;
        CCARRAY_FOREACH(BonusManager->bonusArray, obj)
        {
                SXCustomSprite *sprite=(SXCustomSprite*)obj;
                if(sprite->type==kBonus){
                        SXBonus *bonus=(SXBonus*)obj;
                        
                        if((ccpDistance(Snake->getPosition(),bonus->getPosition())<25  && !Snake->isEnteredUnderGround)) {
                                BonusManager->isBonusPresent=false;
                                BonusManager->toDeleteArray->addObject(bonus);
                                BonusManager->checkForBonusType(bonus->bonusType);
                        }
                }
        }
}

//void SXCollisionManager::checkCollisionForCoins()
//{
//        for(int i=0;i<BonusManager->coinsArray->count();i++)
//        {
//                SXCoin *coin= (SXCoin*)  BonusManager->coinsArray->objectAtIndex(i);
//                
//                //Snake->isHavingMagnet=true;
//                bool value1= (ccpDistance(Snake->getPosition(),coin->getPosition())<20 && !Snake->isHavingMagnet  && !Snake->isEnteredUnderGround);
//                bool value2= (ccpDistance(Snake->getPosition(),coin->getPosition())<50 && Snake->isHavingMagnet  && !Snake->isEnteredUnderGround);
//                
//                if(value1) {
//                        this->afterCoinCollision(coin);
//                }
//                
//                else if(value2) {
//                        //if(coin->numberOfRunningActions()>=2)
//                        // {
//                        coin->target=SnakeManager->snake;
//                        coin->schedule(schedule_selector(SXCoin::update));
//                        //  }
//                        this->afterCoinCollision(coin);
//                }
//        }
//}
void SXCollisionManager::checkCollisionForCoins()
{
    for(int i=0;i<BonusManager->coinsArray->count();i++)
    {
        SXCoin *coin= (SXCoin*)  BonusManager->coinsArray->objectAtIndex(i);
        
        //Snake->isHavingMagnet=true;
        bool value1= (ccpDistance(Snake->getPosition(),coin->getPosition())<20 && !Snake->isHavingMagnet  && !Snake->isEnteredUnderGround);
        bool value2= (ccpDistance(Snake->getPosition(),coin->getPosition())<40 && Snake->isHavingMagnet  && !Snake->isEnteredUnderGround);
        bool value3= (ccpDistance(Snake->getPosition(),coin->getPosition())<80 && Snake->isHavingSuperMagnet  && !Snake->isEnteredUnderGround);
        if(value1) {
            this->afterCoinCollision(coin);
        }
        
        else if(value2) {
            //if(coin->numberOfRunningActions()>=2)
            // {
            coin->target=SnakeManager->snake;
            coin->schedule(schedule_selector(SXCoin::update));
            //  }
            this->afterCoinCollision(coin);
        }
        else if(value3)
        {
            coin->target=SnakeManager->snake;
            coin->schedule(schedule_selector(SXCoin::update));
            this->afterCoinCollision(coin);
            
        }
    }
}

void SXCollisionManager::afterCoinCollision(CCObject  *sender)
{
        SXCoin *coin=(SXCoin*)sender;
    
        if(coin->type==kCoinTag)
        {
                BonusManager->coinsArray->removeObject(coin);
                if(!Snake->isHavingMagnet &&!Snake->isHavingSuperMagnet) {
                        MainLayer->removeChild(coin);
                }
            if(BonusManager->isTripleScoreActivete){
                MainLayer->uiManager->score=MainLayer->uiManager->score+30;
            }
            else if(BonusManager->isDoubleScoreActivate){
                MainLayer->uiManager->score=MainLayer->uiManager->score+20;

            }
            else
                MainLayer->uiManager->score=MainLayer->uiManager->score+10;
                BonusManager->coinsCount--;
                if(BonusManager->coinsArray->count()==0)
                {
                        BonusManager->isCoinPresent=false;
                }
        }
        
      /*  else  if(coin->type==kScoreX2) {  // double the score
                MainLayer->removeChild(coin);
                BonusManager->coinsArray->removeObject(coin);
                MainLayer->uiManager->score=MainLayer->uiManager->score*2;
        }
        else  {           // triple the score
                MainLayer->removeChild(coin);
                BonusManager->coinsArray->removeObject(coin);
                MainLayer->uiManager->score=MainLayer->uiManager->score*3;
        }*/
}

void SXCollisionManager::collisionForCoinWithObstacles() {
        CCObject *obj;
        CCARRAY_FOREACH(BonusManager->coinsArray, obj) {
                
                SXCoin *coin=(SXCoin*)(obj);
                SXObstacle *obstcle=(SXObstacle*)MainLayer->getChildByTag(kObstacle);
                
                if(MainLayer->getChildByTag(kObstacle)){
                        if(ccpDistance(coin->getPosition(), obstcle->getPosition())<20 && !Snake->isEnteredUnderGround){
                                
                                coin->setOpacity(100);
                        }
                }
        }
}

#pragma mark- collision for All Obstacles
void SXCollisionManager::checkCollision(SXCustomSprite *spriteA, SXCustomSprite *spriteB){
        
        if(spriteA->type==kSnakeHead && spriteB->type==kObstacle){
                ObstacleManager->runCollisionEffect(spriteB);
        }
        
        if(spriteA->type==kObstacle && spriteB->type==kSnakeHead){
                ObstacleManager->runCollisionEffect(spriteA);
        }
}

void SXCollisionManager::checkCollisionIthLaser() {
        
        if(DataManager->gameLayer->getChildByTag(kLaser)) {
                
                SXLazer *laser=(SXLazer*)MainLayer->getChildByTag(kLaser);
                if( !Snake->isEnteredUnderGround)
                {
                        float currentLaserDistance = laser->getScaleX()*laser->getContentSize().width;
                        
                        CCPoint currentLaserEndPoint = SXUtility::getStraightPointWithRadius(currentLaserDistance, laser->getRotation()+90, laser->getPosition());
                        CCPoint  snakelongStraightLine=SXUtility::getStraightPointWithRadius(30, Snake->getRotation(), Snake->getPosition());
                        
                        CCPoint  snakeStraightLine=SXUtility::getStraightPointWithRadius(20, Snake->getRotation()+90, Snake->getPosition());
                        
                        //  SnakeManager->cuttingLineNode->startPoint=Snake->getPosition();
                        // SnakeManager->cuttingLineNode->endPoint=snakeStraightLine;
                        
                        if(ccpSegmentIntersect(Snake->getPosition(),snakelongStraightLine, laser->startPoint,currentLaserEndPoint)){
                                Snake->snakeEffects->runHitEffect();
                        }
                        else if(ccpSegmentIntersect(Snake->getPosition(),snakeStraightLine, laser->startPoint,currentLaserEndPoint)){
                                Snake->snakeEffects->runHitEffect();
                        }
                }
        }
}

void SXCollisionManager::checkCollisionWithRandonSnake()
{
        if(MainLayer->getChildByTag(kRandomSnake))
        {
                SXRandomSnake *randomSnake=(SXRandomSnake*) MainLayer->getChildByTag(kRandomSnake);
                if(SnakeManager->snake->boundingBox().containsPoint(randomSnake->getPosition())  && !Snake->isEnteredUnderGround)  //  snake head with random snake head
                {
                        Snake->snakeEffects->runHitEffect();
                }
                
                else  if(ObstacleManager->isRandomSnakePresent)
                {
                        for(int i=0;i<randomSnake->movableObjects->count();i++)
                        {
                                SXSnakeBody *randomSnakeBody=(SXSnakeBody*)randomSnake->movableObjects->objectAtIndex(i);
                                CCPoint point=randomSnake->convertToWorldSpace(randomSnakeBody->getPosition());
                                if(Snake->boundingBox().containsPoint(point)){ //  snake head with random snake head
                                        Snake->snakeEffects->runHitEffect();
                                }
                        }
                        randomSnake->checkCollisipn();
                }
        }
}

void SXCollisionManager::checkCollisionWithWall()
{
        CCObject *obj;
        CCARRAY_FOREACH(ObstacleManager->obstaclesArray, obj){
                SXCustomSprite  *sprite=(SXCustomSprite*)obj;
                
                if(sprite->type==kWall){
                        SXWall *wall=(SXWall*)sprite;
                        //            if(wall->numberOfRunningActions()==1 && ObstacleManager->isWallPresent)
                        //            {
                        if(wall->boundingBox().containsPoint(Snake->getPosition()))
                        {
                                Snake->snakeEffects->runHitEffect();
                        }
                }
                
        }
}

void SXCollisionManager::checkCollisionWithWheel()
{
        if(DataManager->gameLayer->getChildByTag(kWheel))
        {
                SXWheel *wheel = (SXWheel*)MainLayer->getChildByTag(kWheel);
                if((ccpDistance(Snake->getPosition(), wheel->getPosition())<5) &&  !Snake->isEnteredUnderGround&&!Snake->isinvisiblePowerupEnabled)
                {
                        if(!Snake->isFuryModeEnabled)
                        {
                                SnakeManager->snake->snakeEffects->runWheelEffect(1);
                        }
                        else{
                                ObstacleManager->wheel->removeWheel();
                        }
                        
                }
                else{
                        for (int i=1; i<SnakeManager->snake->movableObjects->count(); i++)
                        {
                                SXSnakeBody *body =(SXSnakeBody*)SnakeManager->snake->movableObjects->objectAtIndex(i);
                                if((ccpDistance(body->getPosition(), wheel->getPosition())<5) &&  !Snake->isEnteredUnderGround&&!Snake->isinvisiblePowerupEnabled)
                                {
                                        if(!Snake->isFuryModeEnabled)
                                        {
                                                SnakeManager->snake->snakeEffects->runWheelEffect(i);
                                        }
                                        else{
                                                ObstacleManager->wheel->removeWheel();
                                                break;
                                        }
                                        
                                        
                                }
                        }
                }
        }
}

void SXCollisionManager::checkCollisionWithTrap()
{
        if(DataManager->gameLayer->getChildByTag(kTrap))
        {
                SXTrap *trap=( SXTrap*)MainLayer->getChildByTag(kTrap);
                if(trap->getScale()==1)
                {
                        if(ccpDistance(Snake->getPosition(), trap->getPosition())<5&&! Snake->isCollidedWithMovingBody &&!Snake->isinvisiblePowerupEnabled&&!Snake->isEnteredUnderGround )
                        {
                                if( !Snake->isFuryModeEnabled)
                                {
                                        Snake->isCollidedWithMovingBody=true;
                                        CCDelayTime*delay=CCDelayTime::create(2);
                                        CCCallFunc *CallbackOne = CCCallFunc::create(trap, callfunc_selector(SXTrap::runAnimation));
                                        CCCallFuncN *Callback=CCCallFuncN::create(MainLayer->uiManager,callfuncN_selector(SXUIManager::showYouFailedUI));
                                        MainLayer->runAction(CCSequence::create(CallbackOne,delay,Callback,NULL));
                                }
                                else{
                                        ObstacleManager->trap->remove();
                                }
                                
                                //SnakeManager->snake->isCollidedWithMovingBody=true;
                                
                        }
                        else
                        {
                                for (int i=1; i<SnakeManager->snake->movableObjects->count(); i++)
                                {
                                        
                                        SXSnakeBody *body =(SXSnakeBody*)SnakeManager->snake->movableObjects->objectAtIndex(i);
                                        if((ccpDistance(body->getPosition(),trap->getPosition()) <=5)&&! Snake->isCollidedWithMovingBody&&!Snake->isinvisiblePowerupEnabled&&!Snake->isEnteredUnderGround)
                                        {
                                                if(!Snake->isFuryModeEnabled)
                                                {
                                                        Snake->isCollidedWithMovingBody=true;
                                                        CCDelayTime*delay=CCDelayTime::create(3);
                                                        CCCallFuncN *Callback=CCCallFuncN::create(MainLayer->uiManager,callfuncN_selector(SXUIManager::showYouFailedUI));
                                                        MainLayer->runAction(CCSequence::create(delay,Callback,NULL));
                                                }
                                                else{
                                                        ObstacleManager->trap->remove();
                                                        break;
                                                }
                                                
                                                
                                        }
                                }
                        }
                }
        }
}

#pragma mark- collision for BackGround Obstacles

void SXCollisionManager::checkCollisionForUnderGround() {
        CCSprite *underGrdStart=(CCSprite*)MainLayer->getChildByTag(kUnderGrdTag);
        CCSprite *underGrdEnd=(CCSprite*)MainLayer->getChildByTag(kUnderGrdEndTag);
        
        if(MainLayer->BackgroundMgr->isUndergrdPresent && !Snake->isEnteredUnderGround){
                if(underGrdStart->boundingBox().containsPoint(Snake->getPosition())  )
               // if(ccpDistance(underGrdStart->getPosition(), Snake->getPosition())<=15)
                {
                       Snake->isEnteredUnderGround=true;
                       Snake->isHeadInsideUnderGrd=true;
                        Snake->snakeEffects->setUnderGroundEffect(underGrdEnd->getPosition());
                        Snake->tunnelNO=1;
                }
            
               else  if (underGrdEnd->boundingBox().containsPoint(Snake->getPosition()))
               // if(ccpDistance(underGrdEnd->getPosition(), Snake->getPosition())<=15)
                {
                    Snake->isEnteredUnderGround=true;
                    Snake->isHeadInsideUnderGrd=true;

                    Snake->snakeEffects->setUnderGroundEffect(underGrdStart->getPosition());
                    Snake->tunnelNO=2;
                }
        }
}

#pragma mark- collision for Fence
void SXCollisionManager::checkCollisionWithFence() {
    
    CCSprite *fence=(CCSprite*)MainLayer->getChildByTag(1111);
    if(fence!=NULL){
        if (fence->boundingBox().containsPoint(Snake->getPosition())) {
            Snake->snakeEffects->runHitEffect();
        }
    }
}

#pragma mark- collision for Throne
void SXCollisionManager:: checkCollisionForShieldThrone(){
    if (Snake->snakeEffects->isHavingLeftThrone) {
        
        CCObject *obj;
        CCARRAY_FOREACH(BonusManager->bonusArray, obj){
            
            SXCustomSprite *sprite=(SXCustomSprite*)obj;
            if(sprite->type==kRandomFood) {
                if(Snake->snakeEffects->leftThrone->boundingBox().intersectsRect(sprite->boundingBox())){
                    BonusManager->toDeleteArray->addObject(sprite);
                }
            }
        }
    }
    
    if (Snake->snakeEffects->isHavingRightThrone) {
        CCObject *obj;
        CCARRAY_FOREACH(BonusManager->bonusArray, obj){
            
            SXCustomSprite *sprite=(SXCustomSprite*)obj;
            if(sprite->type==kRandomFood) {
                if(Snake->snakeEffects->rightThrone->boundingBox().intersectsRect(sprite->boundingBox())){
                    BonusManager->toDeleteArray->addObject(sprite);
                }
            }
        }
    }
}

void SXCollisionManager::checkCollisionWithSpike(){
    CCObject *obj;
    CCARRAY_FOREACH(Snake->movableObjects, obj){
        SXSnakeBody *body=(SXSnakeBody*)obj;
    }
}
