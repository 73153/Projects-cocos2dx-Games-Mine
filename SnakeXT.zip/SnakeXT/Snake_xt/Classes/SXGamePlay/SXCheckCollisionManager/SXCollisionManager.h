//
//  SXCollisionManager.h
//  Snake_xt
//
//  Created by Pavitra on 01/02/13.
//
//

#ifndef __Snake_xt__SXCollisionManager__
#define __Snake_xt__SXCollisionManager__

#include <iostream>
#include "SXGameManager.h"
#include "SXCustomSprite.h"

class SXCollisionManager :public SXGameManager {
    
public:
    SXCollisionManager();
   virtual ~SXCollisionManager();

    void checkCollisionIthLaser();
    void checkCollisionWithRandonSnake();
    void checkCollisionWithWall();
    void  checkCollision (SXCustomSprite *spriteA,SXCustomSprite*spriteB);


    void checkCollisionForrandomFood();
    void checkCollisionForBonus();
    void checkCollisionForCoins();
    void collisionForCoinWithObstacles();
    void afterCoinCollision(CCObject  *sender);
    
    //missile
    void checkCollisionForMissile();
    
    //wheel
    void checkCollisionWithWheel();
    void checkCollisionWithTrap();

    //under4ground
    void checkCollisionForUnderGround();
    
    // fence
    void checkCollisionWithFence();
    
    
    // throne
    void checkCollisionForShieldThrone();
   void checkCollision();
    
    //spike
    void checkCollisionWithSpike();

};
#endif /* defined(__Snake_xt__SXCollisionManager__) */
