//
//  SXLevelManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXLevelManager.h"
#include "SXSnakeManager.h"
#include "SXObstaclesManager.h"
#include "SXDataManager.h"
#include "SXGameConstants.h"

SXLevelManager::SXLevelManager(){
    
}

SXLevelManager::~SXLevelManager(){

}

#pragma mark- SetupForLevel
void SXLevelManager::setUPLevelForTheGame(int level,int gameMode) {
    
    const char *basePath = CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("SnakeXTLevelDetails.plist");
    CCDictionary *gameDict = CCDictionary::createWithContentsOfFileThreadSafe(basePath);
    char str[10]={ };

    if(gameMode==KARCADEMODE){
        sprintf(str, "Level%d",level);
        
        CCDictionary *levelDict=(CCDictionary*)gameDict->valueForKey(str);
        
        CCString* maxNoOfbodiesInLevel  =(CCString *) levelDict->valueForKey("NumberOfBodies");
        DataManager->MaxNoOfBodiesInLevel=maxNoOfbodiesInLevel->intValue();

        
        CCArray *obsrtaclesArray=(CCArray*)levelDict->valueForKey("obstacles");
        for (int i=0; i<obsrtaclesArray->count();i++)
        {
            CCArray *obstacleArray=(CCArray*)obsrtaclesArray->objectAtIndex(i);
            CCString *obstacleName=(CCString*) obstacleArray->objectAtIndex(0);
            CCString *obstaclePosition=(CCString*) obstacleArray->objectAtIndex(1);
            
            //DataManager->gameLayer->obstacleManager->createObstacle(obstacleName->getCString(), CCPointFromString(obstaclePosition->getCString()));
        }
    }
    
    else {
        
        CCArray *levelDict=(CCArray*)gameDict->valueForKey("SurvivalModeLevelDetails");
    }
    
    //obstacles
    
    CCDictionary *AllSnakeDict=(CCDictionary*)gameDict->valueForKey("snake");

    sprintf(str, "snake%d",DataManager->snakeNumber);
    
    CCDictionary *SnakeDict=(CCDictionary*)AllSnakeDict->valueForKey(str);
    

    DataManager->gameLayer->snakeManager->createSnakeHead( );
    
    
   // CCString *shieldImage=(CCString*)SnakeDict->valueForKey("Shield");
    
    
   // CCString *dullImage=(CCString*)SnakeDict->valueForKey("dullImage");
//    
//    CCArray *arrayOfSnakeBody=(CCArray*)SnakeDict->valueForKey("SnakeBody");
    
    for (int i =0; i<3; i++)
    {
        MainLayer->snakeManager->creatBody(kMovingBody);
//        CCDictionary *bodyDict=(CCDictionary*)arrayOfSnakeBody->objectAtIndex(i);
//        CCString *bodyName=(CCString*)bodyDict->valueForKey("SnakeBodyImage"); 
//        CCString *bodyPosition=(CCString*)bodyDict->valueForKey("Position");        
//
//        DataManager->gameLayer->snakeManager->createSnakeParts(bodyName->getCString(), CCPointFromString(bodyPosition->getCString()));
    }
    
}