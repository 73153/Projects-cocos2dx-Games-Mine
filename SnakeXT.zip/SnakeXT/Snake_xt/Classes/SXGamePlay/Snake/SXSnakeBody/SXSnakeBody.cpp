//
//  SXSnakeBody.cpp
//  Snake_xt
//
//  Created by Pavitra on 02/01/13.
//
//

#include "SXSnakeBody.h"
#include "Box2D.h"
#include "SXDataManager.h"
#include "SXSnakeManager.h"
#include "SXUtility.h"
#define PTM_RATIO 32
using namespace cocos2d;

SXSnakeBody::SXSnakeBody(){

//    this->schedule(schedule_selector(SXSnakeBody::update));
//    this->isAttached=false;
    isenteredUnderGround=false;
}

SXSnakeBody::~SXSnakeBody(){
    
}

void SXSnakeBody::update() {
    if(isAttached)
    {
        CCPoint vecDiff = ccpSub(this->targetPosition, this->getPosition());
        vecDiff = ccpMult(vecDiff, 0.3f);
        this->setPosition(ccpAdd(this->getPosition(), vecDiff));
        this->setRotation(SXUtility::getAngleFromCurrentPoint(this->getPosition(), vecDiff));
        

    }
  }

CCPoint SXSnakeBody::tailAnchor()
{
    CCSize s = this->getContentSize();
    
    float x = this->getRotation();
    x=fmodf(x,360.f);
    if (x < 0.f) x+=360.f;
    
    //return CCPoint(this->getPositionX() + (s.width/2) * cos(x * (M_PI / 180)), this->getPositionY() + (s.width/2) * sin(-x * (M_PI / 180)));
    CCSize topRightCornerSize = CCSizeMake(this->getContentSize().width/2-40,this->getContentSize().height-40);
    
    CCPoint tailpos=SXUtility::getRotatedPointForPoint(this->getPosition(), SXUtility::checkTheAngleLimitAngle(this->getRotation()),topRightCornerSize , kBottomRight);
    
    return tailpos;
}


// To create sprite from sprite sheet!
SXSnakeBody* SXSnakeBody ::spriteWithFrame(const char *pszFileName) {
    
    //CCLog("name is %s",pszFileName);
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    SXSnakeBody *tempSpr = SXSnakeBody::create(pFrame);
    
    return tempSpr;
}

SXSnakeBody* SXSnakeBody::create(CCSpriteFrame *pSpriteFrame) {
    
    SXSnakeBody *pobSprite = new SXSnakeBody();
    pobSprite->type=ksnakeBody;

    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

#pragma mark- moving body 
SXMovingBody::SXMovingBody() {
    
    bodyOutsideBoundaryCount=0;
    this->setPosition(SXUtility::getRandomPoint());

}

SXMovingBody::~SXMovingBody(){
    
}

// To create sprite from sprite sheet!
SXMovingBody* SXMovingBody ::spriteWithFrame(const char *pszFileName) {
    
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    SXMovingBody *tempSpr = SXMovingBody::create(pFrame);
    
    return tempSpr;
}

SXMovingBody* SXMovingBody::create(CCSpriteFrame *pSpriteFrame) {
    
    SXMovingBody *pobSprite = new SXMovingBody();
    pobSprite->type=ksnakeBody;
    pobSprite->xvalur = arc4random()%45+20;
    pobSprite->yvalue = arc4random()%45+20;
   pobSprite ->xvalur=this->getRandomValue();
    pobSprite->yvalue=this->getRandomValue();

    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

int SXMovingBody::getRandomValue() {
    
    int low=-10;
    int high=45;
    
    int value=arc4random()%(high-low)-low;
    return value;
}



#pragma mark - DisApper  body
SXDisapperBody::SXDisapperBody(){
    
    this->setPosition(SXUtility::getRandomPoint());
    
    CCFadeOut *action=CCFadeOut::create(10);
    CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXDisapperBody::removeBody));
    this->runAction(CCSequence::create(action,callback,NULL));
}

void SXDisapperBody::removeBody(CCObject *obj){
    
    SXDisapperBody *body=(SXDisapperBody*)obj;
    DataManager->gameLayer->snakeManager->toDeleteArray->addObject(body);
}

SXDisapperBody::~SXDisapperBody(){
    
}

// To create sprite from sprite sheet!
SXDisapperBody* SXDisapperBody ::spriteWithFrame(const char *pszFileName) {
    
    //CCLog("name is %s",pszFileName);
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    SXDisapperBody *tempSpr = new SXDisapperBody();
    tempSpr->type=ksnakeBody;

    tempSpr->initWithSpriteFrame(pFrame);

    return tempSpr;
}

SXDisapperBody* SXDisapperBody::create(CCSpriteFrame *pSpriteFrame) {
    
    SXDisapperBody *pobSprite = new SXDisapperBody();
    pobSprite->type=ksnakeBody;
       
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}


