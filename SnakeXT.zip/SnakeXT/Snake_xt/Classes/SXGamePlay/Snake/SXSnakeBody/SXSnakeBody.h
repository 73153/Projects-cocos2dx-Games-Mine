//
//  SXSnakeBody.h
//  Snake_xt
//
//  Created by Pavitra on 02/01/13.
//
//

#ifndef __Snake_xt__SXSnakeBody__
#define __Snake_xt__SXSnakeBody__

#include <iostream>

#include "cocos2d.h"
#include "SXCustomSprite.h"
#include "SXGameConstants.h"
using namespace cocos2d;

class SXSnakeBody :public SXCustomSprite {
public:
    
    SXSnakeBody();
     virtual ~SXSnakeBody();
    SXSnakeBody* spriteWithFrame(const char *pszFileName);
    SXSnakeBody* create(cocos2d::CCSpriteFrame *pSpriteFrame);
    SXSnakeBody *parent;
    void update();
    CCPoint tailAnchor();
    CCPoint targetPosition;
    bool isAttached;
    bool isenteredUnderGround;
    
};



class SXMovingBody :public SXCustomSprite {
    public:
    SXMovingBody();
    ~SXMovingBody();
    SXMovingBody* spriteWithFrame(const char *pszFileName);
    SXMovingBody* create(cocos2d::CCSpriteFrame *pSpriteFrame);
    
    int getRandomValue();
    int xvalur;
    int yvalue;
    int bodyOutsideBoundaryCount;
    bool IsMoving;
};

class SXDisapperBody :public SXCustomSprite {
    
    
public:
    SXDisapperBody();
    ~SXDisapperBody();
    SXDisapperBody* spriteWithFrame(const char *pszFileName);
    SXDisapperBody* create(cocos2d::CCSpriteFrame *pSpriteFrame);

    void removeBody(CCObject *obj);
    
};

#endif /* defined(__Snake_xt__SXSnakeBody__) */
