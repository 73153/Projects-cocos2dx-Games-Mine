//
//  SXSnakeEffects.cpp
//  Snake_xt
//
//  Created by Pavitra on 28/01/13.
//
//
#include "SXSnakeManager.h"
#include "SXDataManager.h"
#include "SXUIManager.h"
#include "SXBonusManager.h"
#include "SXBackgroundManager.h"

#include "SXGameConstants.h"
#include "SXUtility.h"

#include "SXSnakeEffects.h"
#include "SXSnake.h"
#include "SXSnakeBody.h"

SXSnakeEffects:: SXSnakeEffects(){
        this->snake=Snake;
        this->isRunningAnimation=false;
        this->isSheildOn=false;
    this->isHavingRightThrone=false;
    this->isHavingLeftThrone=false;
    this->isHavingSpikePowerUp=false;
}

SXSnakeEffects::~SXSnakeEffects() {
    
}

#pragma mark - UnderGrd EWffect
void SXSnakeEffects::setUnderGroundEffect( CCPoint endPoint)
{
       Snake->setOpacity(100);

        Snake->unschedule(schedule_selector(SXSnakeEffects::resetUndergroundEffect));
        Snake->schedule(schedule_selector(SXSnakeEffects::setBodyUnderGrdEffect));
        Snake->schedule(schedule_selector(SXSnakeEffects::resetUndergroundEffect));

        Snake->IsjoystickRegain=false;
        CCDelayTime *Delay=CCDelayTime::create(1);
        CCCallFunc *Callback=CCCallFunc::create(this, callfunc_selector(SXSnakeEffects::scheduleResetUnderGround));
        //Snake->runAction(CCSequence::createWithTwoActions(Delay, Callback));
        Snake-> currentAngle= (SXUtility::getAngleFromCurrentPoint(Snake->getPosition(),endPoint));
        Snake->setRotation(Snake->currentAngle);
}

void SXSnakeEffects::setBodyUnderGrdEffect() {
    
    if(MainLayer->BackgroundMgr->isUndergrdPresent)
    {
        CCObject *obj;
        CCSprite *underGrdEnd=(CCSprite*)MainLayer->getChildByTag(kUnderGrdEndTag);
        CCSprite *underGrdStart=(CCSprite*)MainLayer->getChildByTag(kUnderGrdTag);
        
        for (int i=1; i<Snake->movableObjects->count(); i++)
        {
            
            SXSnakeBody *body=(SXSnakeBody*)Snake->movableObjects->objectAtIndex(i);
            if(Snake->tunnelNO==2)
            {
                if(ccpDistance(underGrdEnd->getPosition(), body->getPosition())<=25)
                {
                    if(!body->isenteredUnderGround) {
                        body->setOpacity(100);
                        body->isenteredUnderGround=true;
                    }
                }
            }
            else if(Snake->tunnelNO==1){
                if(ccpDistance(underGrdStart->getPosition(), body->getPosition())<=25)
                {
                    if(!body->isenteredUnderGround){
                        body->setOpacity(100);
                        body->isenteredUnderGround=true;
                    }
                }
            }
    }
        
        SXSnakeBody *lastBody=(SXSnakeBody*)Snake->movableObjects->lastObject();
        if(lastBody->isenteredUnderGround){
            Snake->unschedule(schedule_selector(SXSnakeEffects::setBodyUnderGrdEffect));
        }
    }
}

void SXSnakeEffects::resetUndergroundEffect()
{
        CCSprite *underGrdEnd=(CCSprite*)MainLayer->getChildByTag(kUnderGrdEndTag);
        CCSprite *underGrdStart=(CCSprite*)MainLayer->getChildByTag(kUnderGrdTag);
        
        if(MainLayer->BackgroundMgr->isUndergrdPresent && Snake->isEnteredUnderGround)
        {
            if(Snake->tunnelNO==1)
            {
                if(underGrdEnd->boundingBox().intersectsRect(Snake->boundingBox()))
                {
                    if(Snake->isHeadInsideUnderGrd==true){
                        Snake->schedule(schedule_selector(SXSnakeEffects::resetBodyUnderGrdEffect));
                    }
                    
                    Snake->isHeadInsideUnderGrd=false;
                    CCDelayTime *Delay=CCDelayTime::create(2);
                    CCCallFunc *Callback=CCCallFunc::create(this, callfunc_selector(SXSnake::resetUnderGroundMode));
                    Snake->runAction(CCSequence::createWithTwoActions(Delay, Callback));
                    
                    if(!Snake->isinvisiblePowerupEnabled){
                        Snake->setOpacity(255);
                    }
                }
            }
            else if (Snake->tunnelNO==2){
                if(underGrdStart->boundingBox().containsPoint(Snake->getPosition()))
                {
                    Snake->schedule(schedule_selector(SXSnakeEffects::resetBodyUnderGrdEffect));
                    
                    Snake->isHeadInsideUnderGrd=false;
                    CCDelayTime *Delay=CCDelayTime::create(2);
                    CCCallFunc *Callback=CCCallFunc::create(this, callfunc_selector(SXSnake::resetUnderGroundMode));
                    Snake->runAction(CCSequence::createWithTwoActions(Delay, Callback));
                    
                    
                    if(!Snake->isinvisiblePowerupEnabled){
                        Snake->setOpacity(255);
                    }
                }
            }
               
        }
}

void SXSnakeEffects::resetBodyUnderGrdEffect() {
    CCSprite *underGrdEnd=(CCSprite*)MainLayer->getChildByTag(kUnderGrdEndTag);
    CCSprite *underGrdStart=(CCSprite*)MainLayer->getChildByTag(kUnderGrdTag);

    CCObject *obj;
    for (int i=1; i<Snake->movableObjects->count(); i++){
    {
        SXSnakeBody *body=(SXSnakeBody*)Snake->movableObjects->objectAtIndex(i);
        if(MainLayer->BackgroundMgr->isUndergrdPresent ){
            if(Snake->tunnelNO==1){
                if(underGrdEnd->boundingBox().intersectsRect(body->boundingBox()))
                {
                    if(body->isenteredUnderGround){
                        body->setOpacity(255);
                        body->isenteredUnderGround=false;
                    }
                }
            }
            
            else if(Snake->tunnelNO==2){
                if( underGrdStart->boundingBox().containsPoint(body->getPosition()) )
                {
                    if(body->isenteredUnderGround){
                        body->setOpacity(255);
                        body->isenteredUnderGround=false;
                    }
                }
            }
//            if(underGrdEnd->boundingBox().intersectsRect(body->boundingBox())|| underGrdStart->boundingBox().containsPoint(body->getPosition()) )
//            {
//                if(body->isenteredUnderGround){
//                    body->setOpacity(255);
//                    body->isenteredUnderGround=false;
//                }
//            }
        }
    }
        
        SXSnakeBody *lastBody=(SXSnakeBody*)Snake->movableObjects->lastObject();
        if(lastBody->isenteredUnderGround==false){
            Snake->unschedule(schedule_selector(SXSnakeEffects::resetBodyUnderGrdEffect));
        }
    }
}

void SXSnakeEffects::scheduleResetUnderGround(){
        Snake->schedule(schedule_selector(SXSnakeEffects::resetUndergroundEffect));
}
//void SXSnakeEffects::runFuryModeEffect() {
//    this->snake->isFuryModeEnabled=true;
//
//    this->snake->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("furyHead.png"));
//       
//    for (int i=1; i<this->snake->movableObjects->count(); i++) {
//        SXSnakeBody *body=(SXSnakeBody*)this->snake->movableObjects->objectAtIndex(i);
//        body->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("furyBody.png"));
//    }
//       
//    BonusManager->isBonusPresent=true;
//}

#pragma mark -  Fury Mode methods
 void SXSnakeEffects::runFuryModeEffect() {
        if ( this->snake->isFuryModeEnabled==true)
        {
                this->snake->removeChild(furyModePartical, true);
                CCObject *obj;
                CCARRAY_FOREACH(Snake-> movableObjects, obj)
                {
                        SXSnakeBody *body=(SXSnakeBody*)obj;
                        body->removeChild(furyModePartical, true);
                }
        }
    
       Snake->isFuryModeEnabled=true;
        furyModePartical=CCParticleSystemQuad::create("FurryBodyParticle .plist");
        furyModePartical->setPositionType(kCCPositionTypeRelative);
        furyModePartical->setPosition(CCPoint(10,10)); //Position Adjust
        furyModePartical->setRotation(-205);  //Angle Adjust
        
        //  furyModePartical->setRotation(360);
        Snake-> addChild(furyModePartical,1,kFurryModeParticleTagForHead);
        Snake-> setSpeed(DataManager->snakeSpeed+2);
        BonusManager->isBonusPresent=true;
        CCObject *obj;
        CCARRAY_FOREACH(Snake-> movableObjects, obj)
        {
                SXSnakeBody *body=(SXSnakeBody*)obj;
                furyModeBodyPartical=CCParticleSystemQuad::create("FurryBodyParticle .plist");
                furyModeBodyPartical->setPositionType(kCCPositionTypeRelative);
                furyModeBodyPartical->setPosition(CCPoint(10,10)); //Position Adjust
                furyModeBodyPartical->setRotation(-205);  //Angle Adjust
                body-> addChild(furyModeBodyPartical ,1,kFurryModeParticleTagForBody);
        }
}


void SXSnakeEffects::resetFuryBonusMode()
{
//       Snake->removeChild(furyModePartical, true);
        Snake->removeChildByTag(kFurryModeParticleTagForHead);

//        Snake->removeChild(furyModePartical, true);
        Snake-> isFuryModeEnabled=false;
        Snake->setNormalSpeed();
        BonusManager->isBonusPresent=false;
        CCObject *obj;
        CCARRAY_FOREACH(Snake-> movableObjects, obj)
        {
                SXSnakeBody *body=(SXSnakeBody*)obj;
                CCParticleSystemQuad *partical=(CCParticleSystemQuad*)body->getChildByTag(kFurryModeParticleTagForBody);
                //partical->stopAllActions();
                body->removeChild(partical, true);
        }
}

void SXSnakeEffects::showTongue()
{
        // tongue action
        CCPoint  preTonguePos=this->snake->tongue->getPosition();
        
        CCPoint tonguePos=SXUtility::getStraightPointWithRadius(15, this->snake-> tongue->getRotation(), this->snake-> tongue-> getPosition());
        
        CCMoveTo *moveAction=CCMoveTo::create(0.5, tonguePos);
        if(this->snake-> tongue->numberOfRunningActions()==0){
                this->snake-> tongue->runAction(CCSequence::create(moveAction,CCMoveTo::create(0.5,preTonguePos),NULL));
        }
}

#pragma mark - Hit Effect   
void SXSnakeEffects::runHitEffect()
{
        if(!this ->isRunningAnimation && !this->isSheildOn &&! this->snake->isFuryModeEnabled && !this->snake->isinvisiblePowerupEnabled && !this->snake->isEnteredUnderGround )
        {
                this-> setHitEffect();
                this-> isRunningAnimation=true;
        }
}

void SXSnakeEffects::setHitEffect() {
        char str[15];
        sprintf(str, "snakeDull%d.png",3);
        Snake->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(str));
        CCSprite *snakeHit=CCSprite::createWithSpriteFrameName("level1_hit_.png");
        Snake ->addChild(snakeHit,0,1);
        snakeHit->setPosition(ccp(this->snake-> getContentSize().width/2, this->snake-> getContentSize().height/2));
        
        CCRotateTo  *rotate1=CCRotateTo::create(0.5, snakeHit->getRotation()+180);
        CCRotateTo  *rotate2=CCRotateTo::create(0.5, snakeHit->getRotation()+360);
        CCSequence *actionSeq=CCSequence::createWithTwoActions(rotate1, rotate2);
        CCRepeatForever *Repeat=CCRepeatForever::create(actionSeq);
        snakeHit->runAction(Repeat);
        
        CCDelayTime *delay=CCDelayTime::create(3);
        CCCallFunc *callback=CCCallFunc::create(this, callfunc_selector(SXSnakeEffects::removeHitEfffect));
        
        CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
        snakeHit->runAction(seq);
        MainLayer->uiManager->updateLifeArray();
}

void SXSnakeEffects::removeHitEfffect()
{
        char str[15];
        sprintf(str, "snakeHead%d.png",DataManager->snakeNumber);
        
        CCSprite *snakeHit=(CCSprite *) this->snake-> getChildByTag(1);
        snakeHit->removeFromParent();
        this->snake-> setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(str));
        this->isRunningAnimation=false;
}
          
void SXSnakeEffects::setShieldEffect()
{
        isSheildOn=true;
        CCSprite *snakeHit = CCSprite::createWithSpriteFrameName("Shield5.png");
        snakeHit->setPosition(ccp(this->snake-> getContentSize().width/2,this-> snake-> getContentSize().height/2));
        this-> snake->addChild(snakeHit,0,1);
        
        CCRect shieldRect =CCRectMake(snakeHit->getPosition().x-snakeHit->getContentSize().width/2,snakeHit->getPosition().y-snakeHit->getContentSize().height/2,snakeHit->getContentSize().width/2,snakeHit->getContentSize().height/2);
        
        CCDelayTime *delay=CCDelayTime::create(6);
        CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXSnakeEffects::removeShieldEffect));
        
        CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
        snakeHit->runAction(seq);
        BonusManager->isBonusPresent=true;
//         CCSprite *leftThrone=CCSprite::createWithSpriteFrameName("throne1.png");
//        snakeHit->addChild(leftThrone);
//       leftThrone->setPosition(ccp(10, 20));
//    
//    CCSprite *rightThrone=CCSprite::createWithSpriteFrameName("throne2.png");
//    snakeHit->addChild(rightThrone);
//    rightThrone->setPosition(ccp(30, 20));
    
}

void SXSnakeEffects :: setShieldEffect(int type){
    isSheildOn=true;
    CCSprite *snakeHit = CCSprite::createWithSpriteFrameName("Shield5.png");
    snakeHit->setPosition(ccp(this->snake-> getContentSize().width/2,this-> snake-> getContentSize().height/2));
    this-> snake->addChild(snakeHit,0,1);
    
    CCRect shieldRect =CCRectMake(snakeHit->getPosition().x-snakeHit->getContentSize().width/2,snakeHit->getPosition().y-snakeHit->getContentSize().height/2,snakeHit->getContentSize().width/2,snakeHit->getContentSize().height/2);
    
    CCDelayTime *delay=CCDelayTime::create(10);
    CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXSnakeEffects::removeShieldEffect));
    
    CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
    snakeHit->runAction(seq);
    BonusManager->isBonusPresent=true;
    if(type==1){
        this->isHavingLeftThrone=true;
        leftThrone=CCSprite::createWithSpriteFrameName("throne1.png");
        snakeHit->addChild(leftThrone);
        leftThrone->setPosition(ccp(10, 20));
    }
    
    else if(type==2)  {
        this->isHavingRightThrone=true;
        rightThrone=CCSprite::createWithSpriteFrameName("throne2.png");
        snakeHit->addChild(rightThrone);
        rightThrone->setPosition(ccp(30, 30));
    }
    
    else{
        this->isHavingRightThrone=true;
        this->isHavingLeftThrone=true;

        //full  body shield
       leftThrone=CCSprite::createWithSpriteFrameName("throne1.png");
        snakeHit->addChild(leftThrone);
        leftThrone->setPosition(ccp(10, 20));
        
        rightThrone=CCSprite::createWithSpriteFrameName("throne2.png");
        snakeHit->addChild(rightThrone);
        rightThrone->setPosition(ccp(30, 20));
    }
        
}

void SXSnakeEffects::removeShieldEffect(CCSprite *spr)
{
        //CCSprite *snakeHit=(CCSprite *) this->snake->getChildByTag(1);
    this->isHavingLeftThrone=false;
    this->isHavingRightThrone=false;

        this->snake->removeChild(spr, true);
        this->isSheildOn=false;
        BonusManager->isBonusPresent=false;
}

void SXSnakeEffects::fullBodySheildEffect()
{
    CCSprite *snakeHit = CCSprite::createWithSpriteFrameName("Shield5.png");
    snakeHit->setPosition(ccp(this->snake-> getContentSize().width/2,this-> snake-> getContentSize().height/2));
    this-> snake->addChild(snakeHit,0,1);
    CCObject *obj;
    CCARRAY_FOREACH(Snake-> movableObjects, obj)
    {
        bonus = CCSprite::createWithSpriteFrameName("bonus10.png");
        SXSnakeBody *body=(SXSnakeBody*)obj;
        bonus->setPosition(ccp(10, 15));
        // snakeHit->setRotation(body->getRotation());
        body->addChild(bonus,1,2);
    }
    
    CCDelayTime *delay=CCDelayTime::create(6);
    CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXSnakeEffects::removeSheild));
    
    CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
    snakeHit->runAction(seq);
    BonusManager->isBonusPresent=true;
    
}
void SXSnakeEffects::removeSheild()
{
    this->snake->removeChildByTag(1);
    CCObject *obj;
    CCARRAY_FOREACH(Snake-> movableObjects, obj)
    {
        SXSnakeBody *body=(SXSnakeBody*)obj;
        CCSprite *spr=( CCSprite*)body->getChildByTag(2);
        //partical->stopAllActions();
        body->removeChild(spr, true);
        BonusManager->isBonusPresent=false;
    }
    Snake->isFullBodySheild=false;
}

void SXSnakeEffects::runWheelEffect( int bodyIndex )
{
      //  CCLOG("Snake->movableObjects->count()=%d",Snake->movableObjects->count());
        int j=Snake->movableObjects->count()-bodyIndex;
        MainLayer->uiManager->noOfParts-=j;
        MainLayer->uiManager->updateScore(-(j*100));
        for(int i=bodyIndex;i<=snake->movableObjects->count()-1;i++)
    {
        
        SXSnakeBody *body = (SXSnakeBody*)SnakeManager->snake->movableObjects->objectAtIndex(i);
        MainLayer->snakeManager->toDeleteArray->addObject(body);
        //SnakeManager->snake->movableObjects->removeLastObject();
        
    }
}

#pragma mark - spike
void SXSnakeEffects::setSpikePowerUpEffect() {
    isHavingSpikePowerUp=true;
    for (int i=1; i<snake->movableObjects->count(); i++) {
        SXSnakeBody *body=(SXSnakeBody*)Snake->movableObjects->objectAtIndex(i);
        CCSprite *spike = CCSprite::createWithSpriteFrameName("bonus14.png");
        spike->setPosition(ccp(10, 15));
        body->addChild(spike,1,2);
    }
    
    CCDelayTime *delay=CCDelayTime::create(6);
    CCCallFuncN *callback=CCCallFuncN::create(this, callfuncN_selector(SXSnakeEffects::removeSpike));
    
    CCSequence *seq=CCSequence::createWithTwoActions(delay, callback);
    Snake->runAction(seq);
    
}
void SXSnakeEffects::removeSpike() {
    isHavingSpikePowerUp=false;
    for (int i=1; i<snake->movableObjects->count(); i++) {
        SXSnakeBody *body=(SXSnakeBody*)Snake->movableObjects->objectAtIndex(i);
        CCSprite *spr=( CCSprite*)body->getChildByTag(2);
        body->removeChild(spr, true);
    }

}
