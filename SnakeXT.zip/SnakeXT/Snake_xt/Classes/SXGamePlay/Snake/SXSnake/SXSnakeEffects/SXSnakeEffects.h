//
//  SXSnakeEffects.h
//  Snake_xt
//
//  Created by Pavitra on 28/01/13.
//
//

#ifndef __Snake_xt__SXSnakeEffects__
#define __Snake_xt__SXSnakeEffects__

#include <iostream>
#include "cocos2d.h"

#include "SXSnake.h"
using namespace cocos2d;

class SXSnakeEffects :public CCObject
{
public:
    SXSnakeEffects();
    ~SXSnakeEffects();
    
    SXSnake *snake;
    
    void runFuryModeEffect();
    void showTongue();
    void runHitEffect();
    void setHitEffect();
    void removeHitEfffect();
    void resetFuryBonusMode();
    
    //underGrd
    void  setUnderGroundEffect( CCPoint endPoint);
    void  resetUndergroundEffect();
    void scheduleResetUnderGround();
    void setBodyUnderGrdEffect();
    void resetBodyUnderGrdEffect();
    
    //sheild
    CCSprite *leftThrone;
    CCSprite *rightThrone;
    CCSprite *bonus;
    void setShieldEffect();
    void setShieldEffect(int type);
    void removeShieldEffect(CCSprite *spr);
    void fullBodySheildEffect();
    void removeSheild();
    
    //spike power up
    bool isHavingSpikePowerUp;
    void setSpikePowerUpEffect();
    void removeSpike();
    
    void runWheelEffect( int bodyIndex );
    
    bool isRunningAnimation;
    bool isSheildOn;
    bool isHavingLeftThrone;
    bool isHavingRightThrone;
    
    CCParticleSystemQuad *furyModePartical;
    CCParticleSystemQuad  *furyModeBodyPartical;
    
};
#endif /* defined(__Snake_xt__SXSnakeEffects__) */
