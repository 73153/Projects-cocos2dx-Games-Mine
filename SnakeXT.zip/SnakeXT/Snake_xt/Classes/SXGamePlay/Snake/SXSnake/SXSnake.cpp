//
//  SXSnake.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#include "SXSnake.h"
#include "SXSnakeBody.h"
#include "SXTunnel.h"
#include "SXWheel.h"
#include "SXCoin.h"

#include "SXDataManager.h"
#include "SXSnakeManager.h"
#include "SXUIManager.h"
#include "SXBackgroundManager.h"
#include "SXBonusManager.h"
#include "SXMissile.h"
#include "SXMissileManager.h"

#include "SXGameConstants.h"
#include "SXUtility.h"

#include "SXSnakeEffects.h"
#define PTM_RATIO 32

using namespace cocos2d;

SXSnake::SXSnake() {
    
    this->isEnteredTunnel=false;
    this->isCollidedWithMovingBody=false;
    this->isFuryModeEnabled=false;
    this->isHavingMagnet=false;
    this->isinvisiblePowerupEnabled=false;
    this->isEnteredUnderGround=false;
    this->isHeadInsideUnderGrd=false;
    this->isLastBodyInsideUnderGrd=false;
    this->isCollideWithEagle=false;
    this->IsjoystickRegain=true;
    this->isFreezewrEnabled=false;
    
    this->isHavingSuperMagnet=false;
    this->isHavingMegaMagnet=false;
    this->isFullBodySheild=false;
    
    this->movableObjects=CCArray::create();
    this->movableObjects->retain();
    this->movableObjects->retain();

    this->pointsArray= CCPointArray::create(100000);
    this->pointsArray->retain();
    
    this->snakeEffects=new SXSnakeEffects();
    
    speedToSet=1;
    NormalSpeed=DataManager->snakeSpeed;;
    currentspeed=DataManager->snakeSpeed;
  // currentspeed=3;

    minimunSpeed=2;
    
    CCMenuItemLabel *item1=CCMenuItemLabel::create(CCLabelTTF::create("Decrease speed", "", 12), this, menu_selector(SXSnake::menuCallBack));
    CCMenuItemLabel *item2=CCMenuItemLabel::create(CCLabelTTF::create("Increase speed", "", 12), this, menu_selector(SXSnake::menuCallBack));
    item1->setTag(101);
    item2->setTag(102);
    CCMenu *menu=CCMenu::create(item1,item2,NULL);
    
    menu->alignItemsVertically();
    menu->setPosition(ccp(50,50));
}

#pragma mark- menuCallBack
void SXSnake::menuCallBack(CCObject *Sender) {
  
    CCMenuItemLabel *item=(CCMenuItemLabel*)Sender;
    switch (item->getTag()) {
        case 101: // decrease
            this->setSpeed(currentspeed-1);
            break;
            
        default:  //increase 
            this->setSpeed(4);
            break;
    }
}

# pragma mark -  update methods

void SXSnake::update()
{
    if(!isCollidedWithMovingBody){
        if(!SnakeManager->isToucMode)
        {
            this->headMovement();
        }
        
        else{
            SXSnake *snakeHead=this;
            
            currentAngle = snakeHead->getRotation();
            float angleDiff;
            if(mRotateAngle > currentAngle)
                angleDiff = (int)mRotateAngle - (int)currentAngle;
            else
                angleDiff = (int)currentAngle - (int)mRotateAngle;
            if(mAngleChanged) // if angle is  changed
            {
                if((int)currentAngle != (int)mRotateAngle)
                {
                    if(isLeftTurn) // left turn
                    {
                        if(angleDiff < kRotatingFactor)  // if angle diff  is less than
                        {
                            currentAngle = currentAngle - angleDiff; //  subtracting cureent angle with angle diff to make snake  left rotation smoothly
                            // NSLog(@" currentAngle in left turn after subtracting diff=%f",currentAngle);
                        }
                        else  if( angleDiff>330){
                            currentAngle=mRotateAngle;
                        }
                        
                        else{
                            currentAngle = currentAngle - kRotatingFactor;    // subtractin current angle with kFactor(minimum decrement in curerent angle)
                        }
                        
                        if(currentAngle <= 0) {
                            currentAngle = 360 + currentAngle;    //adding 360 to current angle if it  is 0
                        }
                        
                        if (((currentAngle > 340 && currentAngle < 360) || (currentAngle >= 0 && currentAngle < kRotatingFactor)) && (mRotateAngle >= 340 && mRotateAngle < 360))
                        {
                            
                            if (currentAngle + kRotatingFactor > mRotateAngle) {
                                currentAngle = (mRotateAngle - currentAngle) + currentAngle;
                            }
                        }
                        
                        if((int)currentAngle == (int)mRotateAngle){
                            mAngleChanged = false;
                            currentAngle = (int)mRotateAngle;
                        }
                    }
                    
                    else
                    { // right turn
                        
                        if(angleDiff < kRotatingFactor) {
                            currentAngle = currentAngle + angleDiff; // adding angleDiff to currentAngle to make snake  right  rotation smoothly
                        }
                        
                        else{
                            currentAngle = currentAngle + kRotatingFactor; // adding  kRotatingFactor
                        }
                        
                        currentAngle = (int)currentAngle % 360;
                        
                        if (((currentAngle > 340 && currentAngle < 360) || (currentAngle >= 0 && currentAngle < kRotatingFactor)) && (mRotateAngle >= 0 && mRotateAngle < kRotatingFactor))
                        {
                            
                            if (currentAngle - kRotatingFactor < mRotateAngle)
                            {
                                
                                if (mRotateAngle == 0)
                                {
                                    currentAngle = 0;
                                }
                                else
                                    currentAngle = currentAngle - (currentAngle - mRotateAngle);
                            }
                        }
                        
                        if((int)currentAngle == (int)mRotateAngle)
                        {
                            mAngleChanged = false;
                            currentAngle = (int)mRotateAngle;
                        }
                    }
                }
            }
        }
        
        this->headMovement();
        this->checkForHeadOutsideTehBounds();
    }
}

void SXSnake::headMovement()
{
    CCSprite *snakeHead=this;// (CCSprite *)this->movableObjects->objectAtIndex(0);
    
        if(!SnakeManager->isToucMode)
        {
            CCPoint scaledVelocity;
            
            CCPoint velocity= this->joystickSkin->getJoystick()->getVelocity();
            
            if(! velocity.equals(CCPointZero)  && !isHeadInsideUnderGrd)
            {
                IsjoystickRegain=true;
                
                joyStickVelocity=this->joystickSkin->getJoystick()->getVelocity();
                //CCLog("joystick velocity=%f %f",joyStickVelocity.x,joyStickVelocity.y);
                snakeHead->setRotation(SXUtility::getCurrentJoystickAngleForDegree(joystickSkin->getJoystick()->getDegrees()) );
                //CCLog("snake rotation=%f",this->getRotation());
                scaledVelocity=ccpMult(ccpNormalize(joyStickVelocity), 50);
                lastJoystickVelocity=scaledVelocity;
                scaledVelocity=ccpMult(scaledVelocity, currentspeed);
                float  x=snakeHead->getPosition().x +scaledVelocity.x*0.01;
                float  y=snakeHead ->getPosition().y+scaledVelocity.y*0.01;
                snakeHead->setPosition(ccp(x, y));
                
                lastJoystickRotation=snakeHead->getRotation();
                this->pointsArray->addControlPoint(snakeHead->getPosition());
            }
            
            else if(IsjoystickRegain)
            {
                scaledVelocity=lastJoystickVelocity;
                
               // CCLog("joystick velocity=%f %f",joyStickVelocity.x,joyStickVelocity.y);
                //CCLog("snake rotation=%f",this->getRotation());
                scaledVelocity=ccpMult(scaledVelocity, currentspeed);
                float  x=snakeHead->getPosition().x +scaledVelocity.x*0.01;
                float  y=snakeHead ->getPosition().y+scaledVelocity.y*0.01;
                snakeHead->setPosition(ccp(x, y));
                
                lastJoystickRotation=snakeHead->getRotation();
                this->pointsArray->addControlPoint(snakeHead->getPosition());
            }
            
            else{
                int speed=currentspeed-1;
                if(speed==0){
                    speed=1;
                }
                
                float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*speed;
                float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*speed;
                this->setPosition(CCPoint(X, Y));
                this->setRotation(currentAngle);
                this->pointsArray->addControlPoint(snakeHead->getPosition());
            }
            
//            scaledVelocity=ccpMult(scaledVelocity, currentspeed);
//            float  x=snakeHead->getPosition().x +scaledVelocity.x*0.01;
//            float  y=snakeHead ->getPosition().y+scaledVelocity.y*0.01;
//            snakeHead->setPosition(ccp(x, y));
//            
//            lastJoystickRotation=snakeHead->getRotation();
//            this->pointsArray->addControlPoint(snakeHead->getPosition());
        }
    
        else   // movement using tap  
        {
            //currentAngle=50;
            float X = this->getPosition().x + sin(CC_DEGREES_TO_RADIANS(currentAngle))*currentspeed;
            float Y = this->getPosition().y + cos(CC_DEGREES_TO_RADIANS(currentAngle))*currentspeed;
            this->setPosition(CCPoint(X, Y));
            this->setRotation(currentAngle);
            this->pointsArray->addControlPoint(snakeHead->getPosition());
        }
        
        this->bodyMovement();
        //this->checkCollisionWithMovingbody();
        this->checkCollisionWithTunnel();
     //   if(MainLayer->BackgroundMgr->isUndergrdPresent)
      //  {
        
       // this->snakeEffects->setUnderGroundEffect();
       // this->snakeEffects->resetUndergroundEffect();
      //  }
}

void SXSnake::bodyMovement()
{
    int speedFactor;
    
    SXSnake *snakeHead=this; // (SXSnake *)this->movableObjects->objectAtIndex(0);
    speedFactor=(snakeHead->getContentSize().width/2)/currentspeed;

    for (int i=1; i<this->movableObjects->count(); i++)
    {
        SXSnakeBody *body=(SXSnakeBody *) this->movableObjects->objectAtIndex(i);
            CCPoint bodyPos;

            if(!SnakeManager->isToucMode){
                    bodyPos=this->pointsArray->getControlPointAtIndex(this->pointsArray->count()-((speedFactor+1)*i+5));
 
            }
        else
                    //bodyPos=this->pointsArray->getControlPointAtIndex(this->pointsArray->count()-((speedFactor)*i));

        bodyPos=this->pointsArray->getControlPointAtIndex(this->pointsArray->count()-((speedFactor)*i-1));

                body->setPosition(bodyPos);
                body->setRotation(currentAngle);
    }
    
       SXSnakeBody *body=(SXSnakeBody *) this->movableObjects->lastObject();
        CCPoint position = body->getPosition();
        snakeTrailParticle->setPosition(position);
        
    while (pointsArray->count()>(this->movableObjects->count()*this->getContentSize().width/2*round(currentspeed))) {
        pointsArray->removeControlPointAtIndex(0);
            
    }
}

void SXSnake:: handleWithTap(CCTouch *touch, CCEvent *event) {
    DataManager->firstTap=true;
    CCSprite *snakeHead=this;
    
    //CCTouch *touch= (CCTouch *)touches->anyObject();
    
    CCPoint position=touch->getLocationInView();
    
    position=CCDirector::sharedDirector()->convertToGL(position);
//    mTappedPoint=position;
//    
//    mRotateAngle= (SXUtility::getAngleFromCurrentPoint(snakeHead->getPosition(), position));
    
    if(snakeHead->boundingBox().containsPoint(position) || isEnteredUnderGround )
    {
        mAngleChanged=false;
    }
    
    else {
        CCPoint position=touch->getLocationInView();
        
        position=CCDirector::sharedDirector()->convertToGL(position);
        mTappedPoint=position;
        
        mRotateAngle= (SXUtility::getAngleFromCurrentPoint(snakeHead->getPosition(), position));
        mAngleChanged=true;
    }
    
    this->checkRotation();
    this->snakeEffects->showTongue();
}

void SXSnake::checkCollisionWithMovingbody()
{
    for (int i=25;i<this->movableObjects->count(); i++)
    {
        SXSnakeBody *body=(SXSnakeBody*)this->movableObjects->objectAtIndex(i);
        if(ccpDistance(this->getPosition(), body->getPosition())<=20 &&  !isEnteredUnderGround &&  !isFuryModeEnabled &&!snakeEffects->isSheildOn && !this->isinvisiblePowerupEnabled){
            this->isCollidedWithMovingBody=true;
            CCDelayTime*delay=CCDelayTime::create(2);
            CCCallFuncN *Callback=CCCallFuncN::create(MainLayer->uiManager,callfuncN_selector(SXUIManager::showYouFailedUI));
            this->runAction(CCSequence::create(delay,Callback,NULL));
        }
    }
}

void SXSnake::ShowYouFailedBg(){
    
    MainLayer->uiManager->showYouFailedUI();
}

#pragma mark- Tunnel

void SXSnake::checkCollisionWithTunnel()
{
    CCObject *obj;
    CCARRAY_FOREACH(MainLayer->BackgroundMgr->tunnelArray, obj){
        SXTunnel *tunnel=(SXTunnel*)obj;
            if(tunnel->getScale()==1)
            {
        if(!isEnteredTunnel)
        {
            if(tunnel->tunnelRect.containsPoint(this->getPosition()))
            {
                isEnteredTunnel=true;
                
                this->setPosition(tunnel->endPoint);
                //this->setRotation(this->getRedirectAngle(this->getRotation()));
                //lastJoystickRotation=this->getRotation();
                
                if(!SnakeManager->isToucMode)
                {
                    CCLog(" reseting joystick ");
                    //this->setRotation(this->getRedirectAngle(this->getRotation()+90));

                    //joystickSkin->getJoystick()->resetJoystick();
                    this->redirectSnakeWithJoystick();
                }
                CCDelayTime *Delay=CCDelayTime::create(.3);
                CCCallFunc *Callback=CCCallFunc::create(this, callfunc_selector(SXSnake::setIsEnteredTunnel));
                this->runAction(CCSequence::create(Delay,Callback,NULL));
            }
        }
    }
}
}
void SXSnake::setIsEnteredTunnel() {
    isEnteredTunnel=false;
}

#pragma mark - Set Speed
void SXSnake::setSpeed(float inSpeed)
{
         speedToSet = inSpeed;

   // this->schedule(schedule_selector(SXSnake::changeSpeed),0.01f);
        this->schedule(schedule_selector(SXSnake::changeSpeed));

    if (speedToSet !=round(2))
    {
        this->scheduleOnce(schedule_selector(SXSnake::setNormalSpeed), 10);
    }
}

void SXSnake::changeSpeed()
{

           if( (roundf( this->currentspeed))==(speedToSet))
    {
            
        this->unschedule(schedule_selector(SXSnake::changeSpeed));
        return;
    }
    
//   else if ((this->currentspeed)>(speedToSet)&& (roundf(this->currentspeed)>2.00f))
          
         else if ((this->currentspeed)>(speedToSet))
                  //&& (roundf(this->currentspeed)>=2.00f))
    {
          
      this->currentspeed = this->currentspeed-0.005f;
           // this->currentspeed = this->currentspeed-1;
        
    }
    
    else if ( (this->currentspeed)<(speedToSet)  && (roundf(this->currentspeed)<5))
    {
      
            this->currentspeed= (this->currentspeed+0.01f);
        //this->currentspeed= (this->currentspeed+1);
    }
}

void SXSnake::setNormalSpeed()
{
     
        this->isCollideWithEagle=false;
    this->setSpeed(NormalSpeed);
}

# pragma mark - redirect methods

void  SXSnake::checkForHeadOutsideTehBounds()
{
    CCRect _mainframe = CCRectMake(0, 0, 480, 320);
    
    SXSnake *snake=this;// (SXSnake *)this->movableObjects->objectAtIndex(0);
    if(!_mainframe.containsPoint(snake->getPosition()))
    {
        this->redirectSnakeWithTap();

//        if(isJoystick) {
//            this->redirectSnakeWithTap();
//            //joystickSkin->getJoystick()->resetJoystick();
//        }
//        
//        else
//        {
//            this->redirectSnakeWithTap();
//        }
    }
}

void SXSnake::redirectSnakeWithTap()
{
    
//    float angle;
//    
//    if(isJoystick){
//        angle=this->lastJoystickRotation;
//        
//    }
//    
//    else{
//        
//        angle=this->getRotation();
//    }
    if(this->getPositionX()>=480 ||this->getPositionX()<=0) {
        int oppositeBoundryDistance = this->getOppositeBoundryDistance( this->getPosition(),this->getRedirectAngle(this->getRotation()));
        
        CCPoint redirectPoint=SXUtility::getStraightPointWithRadius(oppositeBoundryDistance, this->getRedirectAngle(this->getRotation()), this->getPosition());
      
        this->setPosition(redirectPoint);
    }
    
    else  if(this->getPositionY()>=320 ||this->getPositionY()<=0)
    {
        int oppositeBoundryDistance = this->getOppositeBoundryDistance( this->getPosition(),this->getRedirectAngle(this->getRotation()));
        
        CCPoint redirectPoint=SXUtility::getStraightPointWithRadius(oppositeBoundryDistance, this->getRedirectAngle(this->getRotation()), this->getPosition());
        this->setPosition(redirectPoint);
    }
    
    // redirct to the center 
    //    mTappedPoint=this->getPosition();
    //    mAngleChanged=true;
    //this->setRotation(this->getRotation());
    // this->currentAngle=-this->getRotation();
    
    /*  CCPoint currentLocation = redirectPoint;
     SXSnake *SnakeHead=(SXSnake*)this->movableObjects->objectAtIndex(0);
     
     CCPoint point=SnakeHead->getPosition();
     mTappedPoint = currentLocation;
     float angle = SXUtility:: getAngleFromCurrentPoint(point, currentLocation) ; // get angle towards center
     mRotateAngle = angle;
     mAngleChanged = true;
     this->checkRotation();*/
}

int SXSnake::getOppositeBoundryDistance(CCPoint currentPoint,float oppositeAngle)
{
    CCPoint intersectedPoint;
    CCPoint longStraightLine = SXUtility::getStraightPointWithRadius(1000, oppositeAngle, currentPoint);
    BoundrySide aSide = this->getBoundrySide();
    
//    SnakeManager->cuttingLineNode->startPoint=currentPoint;
//    SnakeManager->cuttingLineNode->endPoint=longStraightLine;

    if (aSide!=kRight && ccpSegmentIntersect(this->getPosition(),longStraightLine, CCPointMake(480,0),CCPointMake(480,320))) //Right
    {
        intersectedPoint = ccpIntersectPoint(currentPoint, longStraightLine,CCPointMake(480,0),CCPointMake(480,320));
    }
    else if (aSide!=kLeft&&ccpSegmentIntersect(this->getPosition(),longStraightLine, CCPointMake(0,0),CCPointMake(0,320)))//left
    {
        intersectedPoint = ccpIntersectPoint(currentPoint, longStraightLine,CCPointMake(0,0),CCPointMake(0,320));
    }
    else if (aSide!=kTop&&ccpSegmentIntersect(this->getPosition(),longStraightLine, CCPointMake(0,320),CCPointMake(480,320)))//Top
    {
        intersectedPoint = ccpIntersectPoint(currentPoint, longStraightLine,CCPointMake(0,320),CCPointMake(480,320));
    }
    else if(aSide!=kBottom&&ccpSegmentIntersect(this->getPosition(),longStraightLine, CCPointMake(0,0),CCPointMake(480,0))) //Bottom
    {
        intersectedPoint = ccpIntersectPoint(currentPoint, longStraightLine,CCPointMake(0,0),CCPointMake(480,0));
    }
    return ccpDistance(currentPoint, intersectedPoint);
}

//Get the side
BoundrySide SXSnake::getBoundrySide()
{
    if(this->getPosition().x>480 && (this->getPositionY()<320 || this->getPositionY()>0) ){
        return kRight;
    }
    else if((this->getPositionX()>=0 && this->getPositionX()<=480 )  && this->getPositionY()>=320){
        return kTop;
    }
    else if((this->getPositionX()>=0 && this->getPositionX()<=480 )  && this->getPositionY()<=0){
        return kBottom;
    }
    else if(this->getPosition().x<=0 && (this->getPositionY()<=320 || this->getPositionY()>=0) ) {
        return kLeft;
    }
    return kLeft;
}

float SXSnake::getRedirectAngle( float angle){
    int redirectAngle=(int)angle;
    int redirectangle=redirectAngle+180;
    if(redirectangle>=360) {
        redirectangle=redirectangle%360;
    }
    return redirectangle;
}

void SXSnake::redirectSnakeWithJoystick() {
    
    //joystickSkin->getJoystick()->resetJoystick();
    
   /* if(this->getPositionX()>480 ||this->getPositionX()<10)
    {
        CCPoint redirectPoint=SXUtility::getStraightPointWithRadius(480, this->getRedirectAngle(this->getRotation()), this->getPosition());
        this->setPosition(redirectPoint);
    }
    
    else   if(this->getPositionY()>320 ||this->getPositionY()<0){
        CCPoint redirectPoint=SXUtility::getStraightPointWithRadius(350, this->getRedirectAngle(this->getRotation()), this->getPosition());
        this->setPosition(redirectPoint);
    }*/
    
     SXSnake *snakeHead=(SXSnake *)this->movableObjects->objectAtIndex(0);
     
     CCPoint velocity=lastJoystickVelocity;
     //bottom
     if( snakeHead->getPosition().y<15){
     velocity=ccp(-velocity.x,-velocity.y);
     }
     
     //top
     if(snakeHead->getPosition().y>=300){
     velocity=ccp(-velocity.x,-velocity.y);
     }
     
     //left
     if(snakeHead->getPosition().x<=20){
     velocity=ccp(-velocity.x,-velocity.y);
     }
     
     //right
     if(snakeHead->getPosition().x>=470 ){
     velocity=ccp(-velocity.x,-velocity.y);
     }
     
     //joyStickVelocity=velocity;
    velocity=ccp(-velocity.x,-velocity.y);

     snakeHead->setRotation(SXUtility::getAngleFromVelocity(velocity));
     
     //velocity=ccpMult(ccpNormalize(velocity), 100);
     lastJoystickVelocity=velocity;
//    lastJoystickRotation=45;
     velocity=ccpMult(velocity, DataManager->snakeSpeed);
     float x=snakeHead->getPosition().x+velocity.x*0.01;
     float y=snakeHead->getPosition().y+velocity.y*0.01;
     snakeHead->setPosition(ccp(x,y));
     this->pointsArray->addControlPoint(snakeHead->getPosition());
     CCDelayTime *delay=CCDelayTime::create(2);
     DataManager ->gameLayer->runAction(delay);
}

void SXSnake::checkRotation()
{
    CCSprite *snake=this;
    
    float  angleDiff;
    if(currentAngle>mRotateAngle)
        angleDiff=currentAngle-mRotateAngle;
    else
        angleDiff=mRotateAngle-currentAngle;
    
    float frontAngle = (360-this->getRotation())+mRotateAngle;
    frontAngle = (int)frontAngle % 360;
    float reverseAngle=360-frontAngle;
    
    if(frontAngle<reverseAngle)                                          // checking whether to turn snake left or right
    {
        isLeftTurn=false;
    }
    else{
        isLeftTurn=true;
    }
    float distance1=ccpDistance(snake->getPosition(), mTappedPoint);             // for minimum distance
    
    if(distance1<35)
    {
        kRotatingFactor=40;                          //kFactor in minimum  decrement/increment in rotation angle   depend on left  right rotatiom
    }
    else if(DataManager->snakeSpeed>2)
    {
        kRotatingFactor=20;
    }
    else{
        kRotatingFactor=10;
    }
}

#pragma mark- Other
void SXSnake::setInvisiblePowrUpMode()
{
    this->isinvisiblePowerupEnabled=true;
    this->setOpacity(150);
    this->tongue->setOpacity(0);
    
    CCObject *obj;
    CCARRAY_FOREACH(this->movableObjects, obj){
        SXSnakeBody *body=(SXSnakeBody*)obj;
        body->setOpacity(100);
    }
}

void SXSnake::resetUnderGroundMode(){
    this->isEnteredUnderGround=false;
}

void SXSnake::resetInvisiblePowerUpMode(){
    this->isinvisiblePowerupEnabled=false;
    this->setOpacity(255);
    this->tongue->setOpacity(255);
    CCObject *obj;
    CCARRAY_FOREACH(this->movableObjects, obj){
        SXSnakeBody *body=(SXSnakeBody*)obj;
        body->setOpacity(255);
    }
}

void SXSnake::resetIsHavingMagnet() {
    this->isHavingMagnet=false;
    this->isHavingSuperMagnet=false;
    this->isHavingMegaMagnet=false;
    this->isFullBodySheild=false;
}

void SXSnake::resetFreezer(){
    this->isFreezewrEnabled=false;
    CCObject *obj;
    CCARRAY_FOREACH(ObstacleManager->obstaclesArray, obj){
        
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        if(sprite->type==kObstacle || sprite->type==kLaser|| sprite->type==kWall){
            sprite->resumeSchedulerAndActions();
        }
       
    }

    CCARRAY_FOREACH(MainLayer->missileManager->missilesArray, obj){
        
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        if(sprite->type==kMissile){
            sprite->resumeSchedulerAndActions();
        }
    }
    for(int i=0;i<BonusManager->coinsArray->count();i++)
    {
        SXCoin *coin= (SXCoin*)  BonusManager->coinsArray->objectAtIndex(i);
        coin->resumeSchedulerAndActions();
    }
    
    if(DataManager->gameLayer->getChildByTag(kWheel))
    {
        SXWheel *wheel = (SXWheel*)MainLayer->getChildByTag(kWheel);
        wheel->resumeSchedulerAndActions();
    }
    if(DataManager->gameLayer->getChildByTag(kTrap))
    {
        SXTrap *trap=( SXTrap*)MainLayer->getChildByTag(kTrap);
        trap->resumeSchedulerAndActions();
    }
}

void SXSnake::setFrezMode() {
    
    CCObject *obj;
    
    CCARRAY_FOREACH(ObstacleManager->obstaclesArray, obj){
        
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        if(sprite->type==kObstacle || sprite->type==kLaser || sprite->type==kWall){
            sprite->pauseSchedulerAndActions();
        }
    }
    CCARRAY_FOREACH(MainLayer->missileManager->missilesArray, obj){
        
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        if(sprite->type==kMissile){
            sprite->pauseSchedulerAndActions();
        }
    }
    for(int i=0;i<BonusManager->coinsArray->count();i++)
    {
        SXCoin *coin= (SXCoin*)  BonusManager->coinsArray->objectAtIndex(i);
        coin->pauseSchedulerAndActions();

    }
    if(DataManager->gameLayer->getChildByTag(kWheel))
    {
        SXWheel *wheel = (SXWheel*)MainLayer->getChildByTag(kWheel);
        wheel->pauseSchedulerAndActions();
    }
    if(DataManager->gameLayer->getChildByTag(kTrap))
    {
        SXTrap *trap=( SXTrap*)MainLayer->getChildByTag(kTrap);
        trap->pauseSchedulerAndActions();
    }
    
    
}

void SXSnake::addingToSnakeHead() {
    char str[10];
    sprintf(str, "Body%d.png",4);
    
    SXSnakeBody *body3=body3->spriteWithFrame(str);
    MainLayer->addChild(body3,5);
      
        SXSnakeBody *lastBody=(SXSnakeBody*)this->movableObjects->lastObject();
        body3->setPosition(lastBody->getPosition());
   
    this->movableObjects->addObject(body3);
    
    if(this->isFuryModeEnabled){
       // body3->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("furyBody.png"));
       CCParticleSystemQuad     *furyModePartical=CCParticleSystemQuad::create("FurryBodyParticle .plist");
            furyModePartical->setPositionType(kCCPositionTypeRelative);
            furyModePartical->setPosition(CCPoint(10,10)); //Position Adjust
            furyModePartical->setRotation(-205);  //Angle Adjust
            body3-> addChild(furyModePartical,1,kFurryModeParticleTagForBody);
        }
    else if(this->isinvisiblePowerupEnabled)
    {
        body3->setOpacity(100);
    }
    
    else if(this->isFullBodySheild)
    {
                CCSprite *snakeHit = CCSprite::createWithSpriteFrameName("bonus10.png");
                snakeHit->setPosition(ccp(10, 10));
                body3->addChild(snakeHit,1,2);
    }
    else if(this->snakeEffects->isHavingSpikePowerUp) {
        CCSprite *spike = CCSprite::createWithSpriteFrameName("bonus14.png");
        spike->setPosition(ccp(10, 15));
        body3->addChild(spike,1,2);
    }
}

#pragma mark- initialisze
void SXSnake::initialisze() {
    
    this->setPosition(ccp(200, 20));
    this->addBoxToSprite(this);
    this-> tongue=CCSprite::createWithSpriteFrameName("tongue.png");
    tongue->setPosition(ccp(10, 15));
    this->addChild(tongue,-2);
    this->snakeEffects=new SXSnakeEffects();
    this->movableObjects->addObject(this);
}

// To create sprite from sprite sheet!
SXSnake* SXSnake ::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    SXSnake *tempSpr = SXSnake::create(pFrame);
    return tempSpr;
}

SXSnake* SXSnake::create(CCSpriteFrame *pSpriteFrame) {
    
    SXSnake *pobSprite = new SXSnake();
    pobSprite->type=kSnakeHead ;
   
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

void SXSnake::addBoxToSprite(SXSnake *sprite)
{
    b2BodyDef spriteBodyDef;
    spriteBodyDef.type = b2_dynamicBody;
    spriteBodyDef.position.Set(sprite->getPosition().x,
                               sprite->getPosition().y);
    
    spriteBodyDef.userData = sprite;
    b2Body *spriteBody = SXDataManager::sharedManager()->gameLayer-> world->CreateBody(&spriteBodyDef);
    
//    b2PolygonShape spriteShape;
//    spriteShape.SetAsBox(sprite->getContentSize().width/PTM_RATIO/2,
//                         sprite->getContentSize().height/PTM_RATIO/2);
    b2CircleShape circleShape;
    circleShape.m_radius=.4;
    b2FixtureDef spriteShapeDef;
    spriteShapeDef.shape = &circleShape;
    spriteShapeDef.density = 10.0;
    spriteShapeDef.isSensor = true;
    spriteBody->CreateFixture(&spriteShapeDef);
}

#pragma mark - Dealloc
SXSnake::~SXSnake()
{

    CC_SAFE_RELEASE_NULL(this->pointsArray);
    CC_SAFE_RELEASE_NULL(this->movableObjects);
}

