//
//  SXSnake.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXSnake__
#define __Snake_xt__SXSnake__

#include <iostream>
#include "cocos2d.h"
#include "SXGameConstants.h"

#include "SXCustomSprite.h"
#include "SXTunnel.h"

#include "SneakyJoystick.h"
#include "SneakyJoystickSkinnedBase.h"

#include "Box2D.h"
using namespace cocos2d;
class SXSnakeEffects;


class SXSnake : public SXCustomSprite {
    
public:
    
    SXSnake();
    virtual  ~SXSnake();
    
    SXSnakeEffects *snakeEffects;
        
     CCParticleSystemQuad *snakeTrailParticle;
    
    CCSprite *tongue;
    //temp speed
    float NormalSpeed;
    //  rotation
    float currentAngle;
    float mRotateAngle;
    int mRotateFactor;
    int kRotatingFactor;
    bool mAngleChanged;
    bool isLeftTurn;
    CCPoint mTappedPoint;
    
    //joystick
    SneakyJoystickSkinnedBase *joystickSkin;
    CCPoint joyStickVelocity;
    CCPoint lastJoystickVelocity;
    float  lastJoystickRotation;
    bool isCollidedWithMovingBody;
    
    //snake Movement
    float currentspeed;
    CCArray *movableObjects;
    CCPointArray *pointsArray;
    
    
    //initialize
    void initialisze();
    SXSnake* spriteWithFrame(const char *pszFileName);
    SXSnake* create(CCSpriteFrame *pSpriteFrame);
    void addBoxToSprite(SXSnake *sprite);
    
  // update methods
    void update();
    void bodyMovement();
    void headMovement();
    void checkForHeadOutsideTehBounds();
    void checkCollisionWithMovingbody();
    
    //you failed 
    void ShowYouFailedBg();
    
    //redirect
    float getRedirectAngle( float angle);
    BoundrySide getBoundrySide();
    int getOppositeBoundryDistance(CCPoint currentPoint,float oppositeAngle);
    
    void redirectSnakeWithJoystick();
    void redirectSnakeWithTap();
    
    //rotation
    void checkRotation();
    void handleWithTap(CCTouch *touch, CCEvent *event);
    
    //other methods
    void addingToSnakeHead();
    
    // set speed
    int minimunSpeed;
    
    float speedToSet;
    void setSpeed(float inSpeed);
    void setNormalSpeed();
    void changeSpeed();
    
    ///tunnel
    bool isEnteredTunnel;
    void checkCollisionWithTunnel();
    void setIsEnteredTunnel();
    
    void menuCallBack(CCObject *Senser);
    
    bool isFuryModeEnabled;
    void resetFuryBonusMode();
    
    // magnet
    bool isHavingMagnet;
    void resetIsHavingMagnet();

    bool isinvisiblePowerupEnabled;
    bool isEnteredUnderGround;
    void setInvisiblePowrUpMode();
    void resetInvisiblePowerUpMode();
    
   void setUnderGroundMode();
        void setUnderGroundEffect();
    void resetUnderGroundMode();
    
    //freezer
    void resetFreezer();
    void setFrezMode();
        // eagle
  bool isCollideWithEagle;
    
    
    //tunnel variables 
    int tunnelNO;
    bool isHeadInsideUnderGrd;
    bool isLastBodyInsideUnderGrd;
    bool IsjoystickRegain;;
    bool  isFullBodySheild;
    bool isHavingSuperMagnet;
    bool isHavingMegaMagnet;
    bool isFreezewrEnabled;
    
};
#endif /* defined(__Snake_xt__SXSnake__) */
