//
//  SXSnakeManager.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef __Snake_xt__SXSnakeManager__
#define __Snake_xt__SXSnakeManager__

#include <iostream>
#include "cocos2d.h"
#include "SXGameManager.h"
#include "SXGameConstants.h"

//#include "SneakyButtonSkinnedBase.h"
#include "SneakyJoystick.h"
#include "SneakyJoystickSkinnedBase.h"

#include "SXSnake.h"
#include "LMLine.h"


using namespace cocos2d;
class SXSnakeManager: public SXGameManager {
    
public:

    int bodyCount;
    SXSnakeManager();
    ~ SXSnakeManager();

    //Joystick
    SneakyJoystickSkinnedBase *joystickSkin;
    bool isToucMode;

    //Snake
    SXSnake *snake;
    int snakeLength;
    
    // todeleteArray
    CCArray *toDeleteArray;
    CCArray *staticObjects;
    CCArray *movingStaticObjects;
    
    CCArray *allStaticObjects;
    
    LMLine *cuttingLineNode;

    //Snake Functions
    void handleWithTap(CCTouch *touch, CCEvent *event);
    void snakeUpdate();
    void staticBodyTick();
    
    void addingToSnakeHead();
    void createSnakeHead();
    void createSnakeStaticBody();
    void creatBody(BodyType type);
    void createSnakeBody();
    
    BoundrySide side;
    CCPoint getFreePositionForbody();

   //call back methods
    void deleteBodyAfterFadeIn( CCObject* sender);
    
    //check collision 
    void  checkCollision ( SXCustomSprite *spriteA,SXCustomSprite*spriteB);
    void checkCollision();
    // clare todeleteArray
    void clear();
    
    void collisionWithBodyWhenHavingMagnet();

};
#endif /* defined(__Snake_xt__SXSnakeManager__) */
