//
//  SXSnakeManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//
#include "SimpleAudioEngine.h"
#include "SXSnakeManager.h"
#include "SXDataManager.h"
#include "SXUIManager.h"
#include "SXBackgroundManager.h"

#include "SXUtility.h"
#include "SXGameConstants.h"

#include "SXSnakeBody.h"
#include "SXObstacle.h"
#include "SXBonus.h"
using namespace cocos2d;

#pragma mark - Implementation

SXSnakeManager::SXSnakeManager(){
    
   // to delete array
    this->toDeleteArray=CCArray::create();
    this->toDeleteArray->retain();
    
    this->staticObjects=CCArray::create();
    this->staticObjects->retain();
    
    this->movingStaticObjects =CCArray::create();
    this->movingStaticObjects->retain();
    
    this->allStaticObjects =CCArray::create();
    this->allStaticObjects->retain();
    bodyCount=0;
  
    //Joystick
    CCUserDefault *userDefault=CCUserDefault::sharedUserDefault();
    isToucMode=userDefault->getBoolForKey(kPLAYMODE);
    
    if(!isToucMode){
        float joystickRadius=50;
        SneakyJoystick *joystick=new SneakyJoystick();
        joystick->autorelease();
        joystick->initWithRect(CCRectZero);
        joystick->setAutoCenter(true);
        joystick->setHasDeadzone(true);
        joystick->setDeadRadius(10);
        
        joystickSkin=new SneakyJoystickSkinnedBase();
        joystickSkin->autorelease();
        joystickSkin->init();
        joystickSkin->setBackgroundSprite(CCSprite::create("Joystick_Controller.png"));
        joystickSkin->setThumbSprite(CCSprite::create("movementJoystickMiddle.png"));
        joystickSkin->setPosition(ccp(joystickRadius,joystickRadius));
        joystickSkin->setJoystick(joystick);
        DataManager->gameLayer->addChild(joystickSkin,7);
        joystickSkin->setPosition(ccp(80, 80));
        CCUserDefault *userdefault=CCUserDefault::sharedUserDefault();
        
//        char str[20];
//       sprintf(str, "%s",CCUserDefault::sharedUserDefault()->getStringForKey("joystickPosition").c_str())  ;
//        CCPoint pos=CCPointFromString(str);
//        CCLog("pos .x=%f",pos.x);
    }
    
    cuttingLineNode = new LMLine();
    DataManager->gameLayer->addChild(cuttingLineNode,100);
}

# pragma mark - checkCollision

void  SXSnakeManager:: checkCollision()
{
    CCObject *obj;
    CCARRAY_FOREACH(this->staticObjects, obj) {
        SXCustomSprite *scutonprite=(SXCustomSprite*)obj;
        
        if(ccpDistance(this->snake->getPosition(), scutonprite->getPosition())<=15 && !this->snake->isEnteredUnderGround){
            this->toDeleteArray->addObject(scutonprite);
            this->staticObjects->removeObject(scutonprite);
            this->addingToSnakeHead();
           
             // CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("body-part-collect.caf");
        }
    }
}

# pragma mark - Create Snake and its parts
void SXSnakeManager::createSnakeHead()
{
    char str[20]={};
  //  sprintf(str,"snakeHead%d.png",DataManager->snakeNumber);
    sprintf(str,"snakeHead%d.png",4);
    
    snake =snake->spriteWithFrame(str);
    snake->initialisze();
    DataManager->gameLayer->addChild(snake,5);
    this->snake->joystickSkin=joystickSkin;
  
    snake->snakeTrailParticle = CCParticleSystemQuad::create("dot.plist");
    MainLayer->addChild(snake->snakeTrailParticle);
    snake->snakeTrailParticle->setPosition(ccp(-20,-20));
}

void SXSnakeManager::createSnakeBody()
{
    bodyCount++;
    if(bodyCount<5)
    {
        this->creatBody(kMovingBody);
    }
    else
    {
        if((bodyCount%10)==0)
        {
            this->creatBody(kMovingBody);
        }
        
        else if (bodyCount%9==0)
        {
            this->creatBody(kMovingBody);
        }
        
        else{
            this->creatBody(kMovingBody);
        }
    }
    
    if(this->staticObjects->count()<=2){
        this->creatBody(kMovingBody);
    }
}

void SXSnakeManager:: creatBody(BodyType type){
    
    char str[30];
    //sprintf(str, "Body%d.png",DataManager->snakeNumber);
    int rand = BonusManager->getRandomNumberBetween(2,3);
    sprintf(str, "rat%d.png",rand);
    
    switch (type) {
        case KStaticbody:   // static body 
        {
            SXSnakeBody *body=body->spriteWithFrame(str);
                
//            CCPoint point=this->getFreePositionForbody();
                CCPoint point=SXUtility::getRandomPoint();
            body->setPosition(point);
            DataManager-> gameLayer->addChild(body,4);
            this->staticObjects->addObject(body);
        }            
            break;
            
            case kMovingBody:  // moving body
            {
                    SXMovingBody *body=body->spriteWithFrame(str);
                    //  body->setPosition(SXUtility::getRandomPoint());
                    BoundrySide inBoundry=SXUtility::getBoundarySide();
                    this->side=inBoundry;
                    
                    if(side==kTop)
                    {
                            body->setPosition(ccp(SXUtility::getRandomPoint().x, 320));
                            
                    }
                    
                    else if(side==kBottom)
                    {
                            body->setPosition(ccp(SXUtility::getRandomPoint().x, 0));
                            
                    }
                    
                    else if(side ==kLeft)
                    {
                            body->setPosition(ccp(0,SXUtility::getRandomPoint().y ));
                    }
                    
                    else  // right
                    {
                            body->setPosition(ccp(480,SXUtility::getRandomPoint().y ));
                    }
                    
                    DataManager->gameLayer->addChild(body,4);
                    this->movingStaticObjects->addObject(body);
                    this->staticObjects->addObject(body);
            }            
                    break;
                    

        case KDisappearBoy: // disapper body  
        {
            SXDisapperBody *body=body->spriteWithFrame(str);
            body->setPosition(SXUtility::getRandomPoint());
            DataManager->gameLayer->addChild(body,4);
            this->staticObjects->addObject(body);
        }
            
        break;
        default:
            break;
    }
}

# pragma mark -  getposition  for body 

CCPoint SXSnakeManager::getFreePositionForbody() {
    CCPoint freePos;
    CCPoint point=SXUtility::getRandomPoint();
     
    CCObject *obj;
    CCARRAY_FOREACH(MainLayer->BackgroundMgr-> tunnelArray, obj) {
        
        SXTunnel *tunnel=(SXTunnel*)obj;
       // if(!(tunnel->boundingBox().containsPoint(point)))
        int distane=ccpDistance(tunnel->getPosition(), point);

        if(distane>=40)
        {
            freePos=ccp(point.x, point.y);
        }
        else {
            this->getFreePositionForbody();
        }
    }
        return freePos;
}

# pragma mark -  Callback methods
void SXSnakeManager::deleteBodyAfterFadeIn( CCObject* sender){
    
    SXSnakeBody *body=(SXSnakeBody*)sender;
    DataManager->gameLayer->removeChild(body, true);
}

# pragma mark -  Update methods
void SXSnakeManager::snakeUpdate()
{
    this->snake->update();
    this->snake->checkForHeadOutsideTehBounds();
    this->checkCollision();
}

void SXSnakeManager::staticBodyTick()
{
    CCObject *obj=NULL;
    if (!snake->isFreezewrEnabled) {
        CCARRAY_FOREACH(this->movingStaticObjects,obj)
        {
            SXMovingBody *body=(SXMovingBody*)obj;
            // boundary condition
            if(body->getPositionX()>500 || body->getPositionX()<-30)
            {
                body->xvalur=-body->xvalur;
                body->bodyOutsideBoundaryCount++;
            }
            if(body->getPositionY()>305 || body->getPositionY()<-30){
                body->yvalue=-30;
                body->bodyOutsideBoundaryCount++;
            }
            
            if( body->getPositionY()<-30){
                body->yvalue=30;
                body->bodyOutsideBoundaryCount++;
            }
            
            //        if(body->bodyOutsideBoundaryCount>=2 && body->IsMoving)
            //        {
            //            body->IsMoving=false;
            //            this->toDeleteArray->addObject(body);
            //            this->movingStaticObjects->removeObject(body);
            //        }
            
            float x=body->getPosition().x+body->xvalur*.01;
            float y=body->getPosition().y+body->yvalue*.01;
            float angle=SXUtility::getAngleFromCurrentPoint(body->getPosition(), CCPoint(x, y));
            body->setRotation(angle);
            body->setPosition(ccp(x, y));
        }
    }
}

# pragma mark - add to snake head
void SXSnakeManager::addingToSnakeHead()
{
    this->createSnakeBody();
    this->snake->addingToSnakeHead();
    DataManager->gameLayer->uiManager->noOfParts++;
    DataManager->gameLayer->uiManager->score+=100;
}

# pragma mark - Touches
void SXSnakeManager:: handleWithTap(CCTouch *touch, CCEvent *event){
    if(DataManager->secondTick%13==0) {
      //  this->createSnakeBody();
    }
    
    this->snake->handleWithTap(touch, event);
   //CCTouch *touch= (CCTouch *)touches->anyObject();
    //CCPoint position=touch->getLocationInView();
    
  }

# pragma mark - Clearz
void SXSnakeManager::clear() {
        CCObject *obj;
        CCARRAY_FOREACH(this->toDeleteArray, obj){
        SXCustomSprite *sprite=(SXCustomSprite*)obj;
        DataManager->gameLayer->removeChild(sprite);
        this->staticObjects->removeObject(sprite);
        this->snake->movableObjects->removeObject(sprite);
    }
    toDeleteArray->removeAllObjects();
}

# pragma mark - Dealloc

SXSnakeManager::~SXSnakeManager(){
    CCLog(" snake manager dealloc");

    CC_SAFE_RELEASE(this->toDeleteArray);
    CC_SAFE_RELEASE(this->staticObjects);
    CC_SAFE_RELEASE(this->movingStaticObjects);
    CC_SAFE_RELEASE(this->allStaticObjects);
    
}
