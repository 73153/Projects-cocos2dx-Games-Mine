//
//  SXBackgroundManager.cpp
//  Snake_xt
//
//  Created by Pavitra on 01/02/13.
//
//

#include "SXBackgroundManager.h"
#include "SXDataManager.h"
#include "SXTunnel.h"
#include "SXGameConstants.h"
#include "SXMainController.h"
#include "SXUtility.h"
#include "SXSnake.h"
#include "SXSnakeManager.h"

SXBackgroundManager::SXBackgroundManager()
{
        //Tunnel
        this->tunnelArray=CCArray::create();
        this->tunnelArray->retain();
        
       this->getPositionForUnderGrd();
        //this->gePositionForTeleport();
    
        }

SXBackgroundManager::~SXBackgroundManager()
{
       // CCLog(" bG manager  dealloc");
        
        CC_SAFE_RELEASE(this->tunnelArray);
}

void SXBackgroundManager::gePositionForTeleport()
{
      //  isTeleportFound=true;
       
        
        teleport1StatPoint=CCPoint(SXUtility::getRandomNumberBetween(30,250),SXUtility::getRandomNumberBetween(50, 280));
        teleport1EndPoint=CCPoint(SXUtility::getRandomNumberBetween(270,460),SXUtility::getRandomNumberBetween(50, 280));
        
        float  distance=ccpDistance(teleport1StatPoint, teleport1EndPoint);
       // CCLog("%f=ditance",distance);
        if(distance<200)
        {
                teleport1StatPoint=CCPoint(300,100);
                teleport1EndPoint=CCPoint(100,250);
                this->addTelePort(teleport1StatPoint, teleport1EndPoint);
                
        }
               if(distance>=200)
        {
                  this->addTelePort(teleport1StatPoint, teleport1EndPoint);
       }
}

void SXBackgroundManager::addTelePort(CCPoint teleport1StatPoint, CCPoint teleport1EndPoint)
{
        CCScaleTo *action = CCScaleTo::create(4,1 );
        CCScaleTo *action1 = CCScaleTo::create(4,1 );
        CCActionInterval *fadeAction=CCFadeIn::create(2);
      
        SXTunnel *teleport1=teleport1->spriteWithframe("Hole.png");
        teleport1->startPoint=teleport1StatPoint;
        teleport1->endPoint=teleport1EndPoint;
        teleport1->setPosition(teleport1StatPoint);
        teleport1->tunnelRect= CCRectMake( teleport1->getPositionX()-10,teleport1->getPositionY()-10,22,22);
        this->tunnelArray->addObject(teleport1);
        MainLayer->addChild(teleport1,1,kteleport1Tag);
        teleport1->runAction(action1);
                
        SXTunnel *teleport2=teleport2->spriteWithframe("Hole.png");
        teleport2->startPoint=teleport1EndPoint;
        teleport2->endPoint=teleport1StatPoint;
        teleport2->setPosition(teleport1EndPoint);
        teleport2->tunnelRect= CCRectMake( teleport2->getPositionX()-10,teleport2->getPositionY()-10,22,22);
        this->tunnelArray->addObject(teleport2);
        teleport2->runAction(action);
        
        MainLayer->addChild(teleport2,1,kteleport2Tag);
        CCActionInterval *fadeOut=CCFadeOut::create(2);
        CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXBackgroundManager::removeTelePort));
        MainLayer->runAction(CCSequence::create(fadeAction,CCDelayTime::create(30),fadeOut,callBack,NULL));
}

void SXBackgroundManager::removeTelePort()
{
       isTeleportFound=false;
        SXTunnel *teleport1=(SXTunnel*)MainLayer->getChildByTag(kteleport1Tag);
        SXTunnel *teleport2 =(SXTunnel*)MainLayer->getChildByTag(kteleport2Tag);
        MainLayer->removeChild(teleport1);
        MainLayer->removeChild(teleport2);
        this->tunnelArray->removeObject(teleport2);
        this->tunnelArray->removeObject(teleport1);
}

void SXBackgroundManager::removeUnderGrd()
{
        if(!Snake->isEnteredUnderGround)
        {
                isUndergrdPresent=false;
                MainLayer->removeChildByTag(kUnderGrdTag);
                MainLayer->removeChildByTag(kUnderGrdEndTag);
        }
        else
        {
                this->removeAfterSnakeExitUnderGrd();
        }
}

void SXBackgroundManager::removeAfterSnakeExitUnderGrd()
{
        CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXBackgroundManager::removeUnderGrd));
        MainLayer->runAction(CCSequence::create(CCDelayTime::create(5),callBack,NULL));
        
}
void SXBackgroundManager::update()
{
       if(DataManager->secondTick%35==0)
     {
//               if(!isUndergrdPresent)
//               {
               //this->gePositionForTeleport();
               //}
     }

      if(DataManager->secondTick%35==0) //30//67
     {
               if(!isTeleportFound)
               {
                       this->getPositionForUnderGrd();
               }
       }
}

void SXBackgroundManager::getPositionForUnderGrd()
{
      isUndergrdPresent=true;
        underGrdStrt=CCPoint(SXUtility::getRandomNumberBetween(50,200),SXUtility::getRandomNumberBetween(50, 280));
        underGrdEd=CCPoint(SXUtility::getRandomNumberBetween(270,460),SXUtility::getRandomNumberBetween(50, 280));
       
        float  distance=ccpDistance(underGrdStrt, underGrdEd);
        if(distance<=150)
        {
                underGrdStrt=CCPoint(120,80);
                underGrdEd=CCPoint(375,250);
                this->addUnderGround(underGrdStrt, underGrdEd);
        }
        if(distance>150)
        {
           this->addUnderGround(underGrdStrt, underGrdEd);
        }
}

void SXBackgroundManager::addUnderGround(CCPoint underGrdStrt, CCPoint underGrdEd)
{
        CCActionInterval *fadeAction=CCFadeIn::create(3);
        CCActionInterval *fadeAction1=CCFadeIn::create(3);
        
        CCSprite *underGrdStart=CCSprite ::createWithSpriteFrameName("tunnel.jpg");
        underGrdStart->setOpacity(0);
        MainLayer->addChild(underGrdStart,1,kUnderGrdTag);
        underGrdStart->setPosition(CCPoint(underGrdStrt));
        underGrdStart->runAction(fadeAction1);
        
        CCSprite *underGrdEnd=CCSprite ::createWithSpriteFrameName("tunnel.jpg");
        underGrdEnd->setOpacity(0);
        MainLayer->addChild(underGrdEnd,1,kUnderGrdEndTag);
        underGrdEnd->setPosition(CCPoint(underGrdEd));
        underGrdEnd->runAction(fadeAction);
        
        CCCallFuncN *callBack = CCCallFuncN::create(this,callfuncN_selector(SXBackgroundManager::removeUnderGrd));
        MainLayer->runAction(CCSequence::create(CCDelayTime::create(15),callBack,NULL)); //20
        }

      
