//
//  SXBackgroundManager.h
//  Snake_xt
//
//  Created by Pavitra on 01/02/13.
//
//

#ifndef __Snake_xt__SXBackgroundManager__
#define __Snake_xt__SXBackgroundManager__

#include <iostream>
#include "SXGameManager.h"

class SXBackgroundManager :public SXGameManager
{
    
 public:
      SXBackgroundManager();
    ~SXBackgroundManager();
    
        CCArray *tunnelArray;
        
        //TelePort
     
        void gePositionForTeleport();
        void addTelePort(CCPoint x,CCPoint y);
         void removeTelePort();
        
        CCPoint teleport1StatPoint;
        CCPoint teleport1EndPoint;
     
        bool isTeleportFound;
        
        //UnderGround
        
        CCPoint underGrdStrt;
        CCPoint underGrdEd;

        void update();
        void removeUnderGrd();
        void removeAfterSnakeExitUnderGrd();
         void getPositionForUnderGrd();
    void addUnderGround(CCPoint x,CCPoint y);
        
        bool isUndergrdPresent;
        
      

};
#endif /* defined(__Snake_xt__SXBackgroundManager__) */
