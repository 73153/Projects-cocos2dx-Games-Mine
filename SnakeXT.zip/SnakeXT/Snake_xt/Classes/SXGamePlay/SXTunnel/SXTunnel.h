//
//  SXTunnel.h
//  Snake_xt
//
//  Created by Pavitra on 23/01/13.
//
//

#ifndef __Snake_xt__SXTunnel__
#define __Snake_xt__SXTunnel__

#include <iostream>
#include "SXCustomSprite.h"
#include "cocos2d.h"
using namespace cocos2d;

class SXTunnel : public SXCustomSprite {
    
public:
    
    CCPoint startPoint;
    CCPoint endPoint;
     CCRect tunnelRect;
    
    
    SXTunnel();
    ~SXTunnel();
    SXTunnel* spriteWithFile(const char *pszFileName);
    SXTunnel*  spriteWithframe(const char *pszFileName);
};

#endif /* defined(__Snake_xt__SXTunnel__) */
