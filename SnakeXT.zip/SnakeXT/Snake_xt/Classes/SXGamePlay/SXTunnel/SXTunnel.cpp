//
//  SXTunnel.cpp
//  Snake_xt
//
//  Created by Pavitra on 23/01/13.
//
//

#include "SXTunnel.h"
SXTunnel ::SXTunnel(){
    
    this->startPoint=ccp(70, 280);
    this->endPoint=ccp(350, 50);
        this->setScale(0);
}

SXTunnel ::~SXTunnel() {
    
}

SXTunnel* SXTunnel ::spriteWithFile(const char *pszFileName)
{
       char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    
    SXTunnel *tempSpr = new SXTunnel();
    tempSpr->initWithFile(pszFileName);

    return tempSpr;
}

SXTunnel* SXTunnel ::spriteWithframe(const char *pszFileName)
{
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    
    SXTunnel *tempSpr = new SXTunnel();
    tempSpr->initWithSpriteFrameName(pszFileName);
    
    return tempSpr;
}
