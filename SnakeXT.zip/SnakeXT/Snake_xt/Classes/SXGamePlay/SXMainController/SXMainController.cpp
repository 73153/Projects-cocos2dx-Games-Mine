//
//  SXMainController.cpp
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

//#include "CocosDenshion.h"
#include "SimpleAudioEngine.h"
#include "SXMainController.h"
#include "SXDataManager.h"
#include "b2Contact.h"
#include "b2DebugDraw.h"

#include "SXUIManager.h"
#include "SXSnakeManager.h"
#include "SXLevelManager.h"
#include "SXBonusManager.h"
#include "SXCollisionManager.h"
#include "SXBackgroundManager.h"
#include "SXEnvironmentManager.h"
#include "SXMissileManager.h"

#include "SXObstacle.h"
#include "SXSnake.h"
#include "SXSnakeEffects.h"
#include "SXTunnel.h"
#include "GB2ShapeCache.h"
#include "SXUtility.h"
#include "SXGameConstants.h"
#include "SXObstaclesManager.h"

#include "SXTimeSliderLayer.h"

#define PTM_RATIO 32

CCScene* SXMainController::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    SXMainController* layer = new SXMainController();
    scene->addChild(layer);
    layer->release();
    
    return scene;
}

SXMainController::SXMainController()
{
 // CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("MenuSound.mp3", true);
  // CocosDenshion::SimpleAudioEngine::sharedEngine()->setBackgroundMusicVolume(0.05);
    this->canCheckForAngle=true;
    touchStartPoint=CCPointZero;
    touchCount=0;
    this->initPhysics();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SXSnakeNewImages.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SXMenuImages.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SXBonusNewImages.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("AnimationImages.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SXGamePlay.plist");
    
    gbox2d::GB2ShapeCache::sharedGB2ShapeCache()->addShapesWithFile("SXObstacleShapes.plist");
    
    DataManager->gameLayer=this;
    SXUtility:: addGameAnimationsToAnimationCache("AnimationData.plist");
    
    //contact listener
    mycontactListener =new MyContactListener();
    world->SetContactListener(mycontactListener);
    
    this->bonusManager=new SXBonusManager();
    this->uiManager=new SXUIManager();
    this->snakeManager = new SXSnakeManager();
    this->levelManager=new SXLevelManager();
    this->obstacleManager=new SXObstaclesManager();
    this->checkCollisionManager=new SXCollisionManager();
    this->BackgroundMgr=new SXBackgroundManager();
    this->environmentManager=new SXEnvironmentManager();
    this->missileManager=new SXMissileManager();
    
    this->initialiseScrollView();
    
    char str[10]={};
    sprintf(str,"BG%d.png",19);
    CCSprite *bg=CCSprite::create("fondo.png");
    this->addChild(bg,-1);
    bg->setPosition(ccp(240,160));
    
    this->levelManager->setUPLevelForTheGame(DataManager->currentLevel,DataManager->gameMode );
    
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName("Close.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName("Close.png");
    
    CCMenuItemSprite  *closeButton =  CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(SXMainController::closeButtonAction));
    closeButton->setPosition(ccp(30,300));
    closeButton->setTag(4);
    
    menu=CCMenu::create(closeButton,NULL);
    this->addChild(menu,7);
    menu->setPosition(CCPointZero);
        if(DataManager->secondTick%10==0)
        {
                
        }
}

void SXMainController::initialiseScrollView() {
    
    scrollView=CCScrollView::create(CCSizeMake(480, 320));
    this->addChild(scrollView,7);
    scrollView->setContentSize(CCSizeMake(480, 1650));
    scrollView->setPosition(CCPoint(0, 0));
    scrollView->setContentOffset(CCPoint(0, -450));
    
    int x=0;
    int y=60;
    for (int i=0; i<10; i++){
        SXTimeSliderLayer *layer=new SXTimeSliderLayer();
        layer->type=i;

        layer->initialize();
        scrollView->addChild(layer);
        layer->setPosition(ccp(x, y));
        
        layer->setTag(55);
        layer->addLabels();
        y=y+160;
    }
    
    scrollView->setDirection(kCCScrollViewDirectionVertical);
}

#pragma mark- OnEnter
void SXMainController::onEnter() {
    
    CCLayer::onEnter();
    }

void SXMainController::onExit() {
    CCLayer::onExit();

}


#pragma mark- Close Button

void SXMainController::closeButtonAction()
{
    this->removeChild(this->scrollView);
    if(!this->snakeManager->isToucMode){
        DataManager->firstTap=true;
    }
    else{
    }
    this->setTouchEnabled(true);

    scheduleUpdate();
    this->schedule(schedule_selector(SXMainController::secondTick),1);
    this->removeChild(menu);
    uiManager->optionButtonItem->setEnabled(true);
    uiManager->pauseButton->setEnabled(true);
    CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, 0, false);
}

#pragma mark- tick

void SXMainController::update(float dt)
{
    touchCount++;
    //It is recommended that a fixed time step is used with Box2D for stability
    //of the simulation, however, we are using a variable time step here.
    //You need to make an informed choice, the following URL is useful
    //http://gafferongames.com/game-physics/fix-your-timestep/
    
    int velocityIterations = 8;
    int positionIterations = 1;
    
    // Instruct the world to perform a single step of simulation. It is
    // generally best to keep the time step and iterations fixed.
    world->Step(dt, velocityIterations, positionIterations);
    
    // updating body position
    for(b2Body *b = world->GetBodyList(); b; b=b->GetNext()) {
        if (b->GetUserData() != NULL)
        {
            CCSprite *sprite = (CCSprite *)b->GetUserData();
            
            b2Vec2 b2Position = b2Vec2(sprite->getPosition().x /PTM_RATIO,
                                       sprite->getPosition().y/PTM_RATIO);
            float32 b2Angle = -1 * CC_DEGREES_TO_RADIANS(sprite->getRotation());
            
            b->SetTransform(b2Position, b2Angle);
        }
    }
    
    //checking collision
    //std::vector<b2Body *>toDestroy;
    std::vector<MyContact>::iterator pos;
    for(pos = mycontactListener->_contacts.begin();
        pos != mycontactListener->_contacts.end(); ++pos)
    {
        MyContact contact = *pos;
        
        b2Body *bodyA = contact.fixtureA->GetBody();
        b2Body *bodyB = contact.fixtureB->GetBody();
        
        if (bodyA->GetUserData() != NULL && bodyB->GetUserData() != NULL)
        {
            
            SXCustomSprite *spriteA = (SXCustomSprite *) bodyA->GetUserData();
            SXCustomSprite *spriteB = (SXCustomSprite *) bodyB->GetUserData();
            this->checkCollisionManager->checkCollision(spriteA, spriteB);
        }
    }
    
    // clear array
    this->snakeManager->clear();
    this->obstacleManager->clear();
    this->bonusManager->clear();
    this->missileManager->clear();
    
    this->checkCollisionManager->checkCollision();
    this->snakeManager->staticBodyTick();
    
    if(DataManager->firstTap){
        this->snakeManager->snakeUpdate();
    }
}

void SXMainController::secondTick()
{
    this->uiManager->updateLabels();
    this->obstacleManager->createObstacle();
    this->bonusManager->update();
    this->environmentManager->update();
    this->missileManager->addMissile();
    DataManager->secondTick++;
    this->BackgroundMgr->update();
}


#pragma mark- draw
void SXMainController::draw()
{
    //
    // IMPORTANT:
    // This is only for debug purposes
    // It is recommend to disable it
    //
    CCLayer::draw();
    
    ccGLEnableVertexAttribs( kCCVertexAttribFlag_Position );
    
    kmGLPushMatrix();
    
    world->DrawDebugData();
    
    kmGLPopMatrix();
}

void SXMainController::initPhysics()
{
    b2Vec2 gravity;
    gravity.Set(0.0f, 0.0f);
    world = new b2World(gravity);
    
    // Do we want to let bodies sleep?
    world->SetAllowSleeping(false);
    
    world->SetContinuousPhysics(true);
    
    SXDataManager::sharedManager()->world=world;
    
    b2DebugDraw *debugDraw = new b2DebugDraw(PTM_RATIO);
    //world->SetDebugDraw(debugDraw);
    uint32 flags = 0;
    
    flags += b2Draw::e_shapeBit;
    //flags += b2Draw::e_jointBit;
   // flags += b2Draw::e_centerOfMassBit;
    //flags += b2Draw::e_aabbBit;
    //flags += b2Draw::e_pairBit;
    debugDraw->SetFlags(flags);
}

#pragma mark - touches

bool  SXMainController:: ccTouchBegan(CCTouch *touch, CCEvent *event)
 {
    this->canCheckForAngle=true;
    touchCount=0;
//    CCTouch *touch= (CCTouch *)touches->anyObject();
    CCPoint position=touch->getLocationInView();
    
    touchStartPoint=CCDirector::sharedDirector()->convertToGL(position);
     if(!snakeManager->isToucMode){
         snakeManager->joystickSkin->setPosition(touchStartPoint);
     }
     return true;
}

//void  SXMainController:: ccTouchMoved(CCTouch *touch, CCEvent *event) {
//    
//    if(snakeManager->isJoystick) {
//        return;
//    }
//    
//    //CCTouch *touch= (CCTouch *)touches->anyObject();
//    CCPoint position=touch->getLocationInView();
//    pos=CCDirector::sharedDirector()->convertToGL(position);
//    // code lines for snake movement using swipe
//    
//   /* if(ccpDistance(touchStartPoint, pos)>=30) {
//        this->canCheckForAngle=false;
//        float angle=(SXUtility::getAngleFromCurrentPoint(touchStartPoint, pos));
//        this->snakeManager->snake->setRotation((angle));
//        Snake->currentAngle=angle;
//        touchCount=0;
//    }*/
//}

void SXMainController:: ccTouchEnded(CCTouch *touch, CCEvent *event)
 {
    DataManager->firstTap=true;
    
    if(!snakeManager->isToucMode) {
        snakeManager->joystickSkin->setPosition(ccp(80, 80));
        touchCount=0;
    }
    else
    {
        this->snakeManager->handleWithTap(touch, event);
    }
}

#pragma  mark- remove body
void SXMainController::removeBody(CCObject *obj )
{
    SXCustomSprite *sprite=(SXCustomSprite*)obj;
    
    for(b2Body *b = world->GetBodyList(); b; b=b->GetNext())
    {
        if (b->GetUserData() != NULL)
        {
            SXCustomSprite *tempspr=(SXCustomSprite*)b->GetUserData();
            if(tempspr==sprite)
            {
                world->DestroyBody(b);
            }
        }
    }
}

#pragma mark - Dealloc

SXMainController::~SXMainController() {
    
    this->unscheduleAllSelectors();
    delete this->snakeManager;
    delete this->levelManager;
    delete this->checkCollisionManager;
    delete this->environmentManager;
    delete this->BackgroundMgr;
    delete this->missileManager;
    delete this->bonusManager;
    delete this->obstacleManager;
    delete this->uiManager;
    
}

