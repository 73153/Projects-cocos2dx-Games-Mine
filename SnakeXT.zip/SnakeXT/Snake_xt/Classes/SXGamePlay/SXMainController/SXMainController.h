//
//  SXMainController.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//
//

#ifndef Snake_xt_SXMainController_h
#define Snake_xt_SXMainController_h

#include "cocos2d.h"
#include "cocos-ext.h"

#include "SXGameConstants.h"

#include "Box2D.h"
#include "MyContactListener.h"



USING_NS_CC_EXT;
USING_NS_CC;

class SXSnakeManager;
class SXUIManager;
class SXLevelManager;
class SXBonusManager;
class SXObstaclesManager;
class SXCollisionManager;
class SXBackgroundManager;
class SXEnvironmentManager;
class SXMissileManager;
class SXCustomSprite;

using namespace cocos2d;

class SXMainController : public cocos2d::CCLayer 
{
    
    
public:
    SXMainController();
    virtual ~SXMainController();
    
    b2World* world;
    MyContactListener *mycontactListener;
    
    
    bool isJoystickMode;
    bool canCheckForAngle;
    int touchCount;
    CCPoint touchStartPoint;
    CCPoint endTopuchPoint;
    
    SXSnakeManager *snakeManager;
    SXLevelManager *levelManager;
    SXSnakeManager *snakemgr;
    SXUIManager *uiManager;
    SXBonusManager *bonusManager;
    SXObstaclesManager *obstacleManager;
    SXCollisionManager *checkCollisionManager;
    SXBackgroundManager *BackgroundMgr;
    SXEnvironmentManager *environmentManager;
    SXMissileManager*missileManager;
    
    static CCScene* scene();
    void initPhysics();
    virtual void draw();
    
    virtual bool  ccTouchBegan(CCTouch *touch, CCEvent *event);
   // virtual void ccTouchMoved(CCTouch *touch, CCEvent *event);
    virtual void  ccTouchEnded(CCTouch *touch, CCEvent *event)
;

    
    void closeButtonAction();
    void secondTick();
    void update(float dt);
    
    void removeBody(CCObject *obj);
    
    virtual void onEnter();
    virtual void onExit();
    CCScrollView *scrollView;
    CCMenu *menu;
    void initialiseScrollView();
    
    CCPoint pos;
       
};

#endif
