//
//  Snake_xtAppController.h
//  Snake_xt
//
//  Created by Pavitra on 31/12/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
