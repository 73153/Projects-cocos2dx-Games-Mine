//
//  FilterService.h
//  TCam
//
//  Created by Mohammad Azam on 6/16/12.
//  Copyright (c) 2012 HighOnCoding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FilterService : NSObject
{
    
}

-(NSMutableArray *) getAll;

@end
