//
//  FilterService.m
//  TCam
//
//  Created by Mohammad Azam on 6/16/12.
//  Copyright (c) 2012 HighOnCoding. All rights reserved.
//

#import "FilterService.h"

@implementation FilterService


-(NSMutableArray *) getAll
{
   
}

@end
