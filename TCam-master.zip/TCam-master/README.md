Author: Mohammad Azam
Website: www.highoncoding.com

TCAM is my take on building an app like Instagram. TCAM uses the Core Image features provided in the iOS 5 framework to create filters. TCAM also uses the Twitter API in the iOS 5 framework to send a tweet along with the image attachment.

<b>Current Version: </b> 

- Take pictures using your iPhone camera
- Apply filters to the picture 
- Share picture on Twitter

<img src="http://www.highoncoding.com/articleimages/tcam1.png">

<img src="http://www.highoncoding.com/articleimages/tcam2.png">
