//
//  MazeAppController.h
//  Maze
//
//  Created by Anshul on 22/04/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
