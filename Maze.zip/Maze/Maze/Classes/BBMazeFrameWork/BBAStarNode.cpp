//
//  BBAStarNode.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 12/02/13.
//
//

#include "BBAStarNode.h"

BBAStarNode::BBAStarNode() {
    
    this->active = true;
    this->isWall = false;
    this->neighbourNodesArray = CCArray::create();
    this->neighbourNodesArray->retain();
    this->costMultiplier = 1.0f;
}

BBAStarNode::~BBAStarNode() {
    
    CC_SAFE_RELEASE_NULL(this->neighbourNodesArray);
}

float BBAStarNode::costToNode(BBAStarNode *node) {
    
    CCPoint src = ccp(this->position.x, this->position.y);
    CCPoint dst = ccp(node->position.x, node->position.y);
       
    float cost = ccpDistance(src, dst)*node->costMultiplier;
    return cost;
}

bool BBAStarNode::isNodeIsInList(BBAStarNode *a, cocos2d::CCArray *list) {
    
    for(int i = 0; i < list->count(); i++)
    {
        BBAStarNode *b=(BBAStarNode*)list->objectAtIndex(i);
        if(a->position.x==b->position.x && a->position.y==b->position.y)
        {
            return true;
        }
        
    }
    return false;
}

