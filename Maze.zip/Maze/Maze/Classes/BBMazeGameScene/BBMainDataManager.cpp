//
//  BBDatamanager.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#include "BBMainDataManager.h"
#include "cocos2d.h"

static BBMainDataManager *gSharedManager = NULL;

#pragma mark - Default
BBMainDataManager::BBMainDataManager(void){
    
    this->pageCount = 1;
    this->starCount = 0;
    currentLevel = 1;
  //  isPressedRestartButton=false;
    isPressedGamerButton=false;
   // isTouchedScreen=false;
   // isFarmerReachedDestination=false;
}

BBMainDataManager::~BBMainDataManager(void){}

BBMainDataManager* BBMainDataManager::sharedManager(void) {
    
	BBMainDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBMainDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBMainDataManager::init(void) {
	return true;
}

