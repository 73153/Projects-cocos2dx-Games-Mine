//
//  BBMenuScene.h
//  MazeSample
//
//  Created by Manjunatha Reddy on 28/02/13.
//
//

#ifndef __MazeSample__BBMenuScene__
#define __MazeSample__BBMenuScene__

#include "cocos2d.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

class BBMenuScene:public CCLayer
{
private:
    BBMenuScene();
    ~BBMenuScene();
        
public: 
    static CCScene* scene();
    void action(CCMenuItemFont* sender);
};

#endif /* defined(__MazeSample__BBMenuScene__) */
