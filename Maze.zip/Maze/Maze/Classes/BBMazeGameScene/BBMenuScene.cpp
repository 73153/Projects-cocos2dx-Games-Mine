//
//  BBMenuScene.cpp
//  MazeSample
//
//  Created by Manjunatha Reddy on 28/02/13.
//
//

#include "BBMenuScene.h"
#include "BBMainDataManager.h"
#include "BBMazeGameScene.h"

#include "SimpleAudioEngine.h"

using namespace CocosDenshion;
using namespace cocos2d;


#pragma mark - Default
CCScene* BBMenuScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBMenuScene();
    scene->addChild(layer);
    layer->release();
    return scene;
}

BBMenuScene::BBMenuScene()
{
    int xPos = 200;
    int yPos = 484;
    CCMenuItemLabel *item;
    CCMenu *menu = CCMenu::create();
        
        
        if (SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
        {
                SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/maze_oldmac.mp3",true);
        }
        
    if( !BBMainDataManager::sharedManager()->isPressedGamerButton)
    {
            SimpleAudioEngine::sharedEngine()->playEffect("Sounds/welcometobaccizmazes.mp3",false);
    }
        
    for (int i=1; i <= 15; i++) {
        
        CCLabelTTF *menuLabel=CCLabelTTF::create(CCString::createWithFormat("Maze%d",i)->getCString(), "Apple Casual",32);
        
        item = CCMenuItemLabel::create(menuLabel,this, menu_selector(BBMenuScene::action));
        item->setPosition(ccp(xPos, yPos));
        item->setTag(i);
        
        xPos = xPos + 150;
        
        if (i%5 == 0) {
            xPos = 200;
            yPos = yPos - 100;
        }
        menu->addChild(item);
    }
    this->addChild(menu,17);
    menu->setPosition(CCPointZero);
        
        
      

}

BBMenuScene::~BBMenuScene()
{
    //CCLog("Destructor of menuScene");
}


#pragma mark - Menu Action 
void BBMenuScene::action(CCMenuItemFont *sender)
{
    int tag = sender->getTag();
    BBMainDataManager::sharedManager()->currentLevel = tag;
    
    char mazeName[20];
    sprintf(mazeName, "Maze%d",tag);
    BBMainDataManager::sharedManager()->mazeName = mazeName;
    
    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
}

