//
//  Flare.m
//  DesertRace
//
//  Created by Mohammad Azam on 6/4/11.
//  Copyright 2011 HighOnCoding. All rights reserved.
//

#import "Flare.h"


@implementation Flare

@synthesize flareParticle,isCollided,isRed; 



@end
