/*
 *  Force.cpp
 *  hour_screen
 *
 *  Created by Michael Tucker on 6/4/10.
 *  Copyright 2010 BASE / APEX. All rights reserved.
 *
 */

#include "Force.h"

Force::Force(){
	touch_id = -1;

}