//
//  popclock2AppDelegate.h
//  popclock2
//
//  Created by Michael Tucker on 9/11/10.
//  Copyright BASE / APEX 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
