//
//  RootViewController.h
//  MonsterSmashingTest
//
//  Created by Vivek on 19/06/13.
//
//

#ifndef MonsterSmashingTest_RootViewController_h
#define MonsterSmashingTest_RootViewController_h


#include "UIKit/UIKit.h"


class RootViewController : UIViewController {
    
};

#endif
