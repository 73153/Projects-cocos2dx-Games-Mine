//
//  Monster.cpp
//  MonsterSmashingTest
//
//  Created by Vivek on 19/06/13.
//
//

#include "Monster.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* Monster::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    Monster *layer = Monster::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

//Monster::Monster()
//{

//}

//Monster::~Monster()
//{
    
//}