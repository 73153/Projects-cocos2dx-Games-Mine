//
//  MonsterRun.cpp
//  MonsterSmashingTest
//
//  Created by Vivek on 19/06/13.
//
//

#include "MonsterRun.h"
#include "SimpleAudioEngine.h"
#include "Monster.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* MonsterRun::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    MonsterRun *layer = MonsterRun::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
MonsterRun::MonsterRun()
{
    
}

MonsterRun::~MonsterRun()
{
    CC_SAFE_RELEASE(monstersOnScreenArr);
    CC_SAFE_RELEASE(monstersArr);
    //    CC_SAFE_RELEASE(arrayBezier);
}

bool MonsterRun::init()
{
    //////////////////////////////
    // 1. super init first
    if (CCLayer::init() )
    {
        this->setTouchEnabled(true);
        
        // Add background
        winSize = CCDirector::sharedDirector()->getWinSize();
        CCSprite *background = CCSprite::create("Bg.png");
        background->setPosition(ccp(winSize.width/2, winSize.height/2));
        this->addChild(background,-4);
        
        //initializing monsters
        monstersArr = CCArray::create();
        monstersArr->retain();
        
        
        Monster *m1 = Monster::create();
        m1->setTag(0);
        m1->MonsterSprite =  "monsterGreen.png";
        m1->SplashSprite = "splashMonsterGreen.png";
        m1->MinVelocity = 2.0;
        m1->MaxVelocity = 8.0;
        m1->Movement = 1;
        m1->KillMethod = 1;
        monstersArr->addObject(m1);
        
        Monster *m2 = Monster::create();
        
        m2->setTag(1);
        m2->MonsterSprite =  "monsterBlue.png";
        m2->SplashSprite = "splashMonsterBlue.png";
        m2->MinVelocity = 2;
        m2->MaxVelocity = 8.0;
        m2->Movement = 2;
        m2->KillMethod = 1;
        monstersArr->addObject(m2);
        
        
        Monster *m3 = Monster::create();
        
        m3->setTag(2);
        m3->MonsterSprite = "monsterRed.png";
        m3->SplashSprite = "splashMonsterRed.png";
        m3->MinVelocity = 3;
        m3->MaxVelocity = 6.0;
        m3->Movement = 3;
        m3->KillMethod = 2;
        monstersArr->addObject(m3);
        
        this->schedule(schedule_selector(MonsterRun::addMonster), 1);
        
        
        monstersOnScreenArr = CCArray::create();
        monstersOnScreenArr->retain();
	}
	return this;
}

void MonsterRun::addMonster(CCTime dt) {
    
    //select a random monster from the _monsters Array
    int selectedMonster = arc4random() % monstersArr->count();
    
    //get some monster caracteristics
    Monster *monster = (Monster*)monstersArr->objectAtIndex(selectedMonster);
    
    
    //!IMPORTANT -- Every Sprite in Screen must be an new CCSprite! Each Sprite can only be one time on screen
    CCSprite *spriteMonster = CCSprite::create(monster->MonsterSprite.c_str());
    spriteMonster->setTag(selectedMonster);
    
    
    //BLOCK 1 - Determine where to spawn the monster along the Y axis
    int minX = spriteMonster->getContentSize().width / 2;
    int maxX = winSize.width - spriteMonster->getContentSize().width/2;
    int rangeX = maxX - minX;
    int actualY = (arc4random() % rangeX) + minX;
    
    //BLOCK 2 - Determine speed of the monster
    float minDuration =(float)monster->MinVelocity;
    float maxDuration = (float)monster->MaxVelocity;
    int rangeDuration = maxDuration - minDuration;
    float actualDuration = (arc4random() % rangeDuration) + minDuration;
    
    if(spriteMonster->getTag() == 0){ //STRAIGHT MOVIMENT
        
        
        spriteMonster->setPosition(ccp(actualY,winSize.height + spriteMonster->getContentSize().height/2));
        this->addChild(spriteMonster);
        // ZigZag movement Start
        CCArray *arrayBezier = CCArray::create();
        arrayBezier->retain();
        ccBezierConfig bezier;
        CCBezierBy *bezierAction1;
        float splitDuration = actualDuration / 6.0;
        for(int i = 0; i< 6; i++){
            
            if(i % 2 == 0){
                bezier.controlPoint_1 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            else{
                bezier.controlPoint_1 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            
            arrayBezier->addObject(bezierAction1);
        }
        CCSequence *seq = CCSequence::create(arrayBezier);
        
        spriteMonster->runAction(seq);
        
        /* //BLOCK 3 - Create the monster slightly off-screen along the right edge,
         // and along a random position along the Y axis as calculated above
         spriteMonster->setPosition(ccp(actualY,winSize.height + spriteMonster->getContentSize().height/2));
         this->addChild(spriteMonster,10);
         
         //BLOCK 4 - Create the actions
         CCMoveTo *move =   CCMoveTo::create(actualDuration,ccp( actualY,-spriteMonster->getContentSize().height/2));
         //
         
         spriteMonster->runAction(move);*/
        
    }
    else if(spriteMonster->getTag() == 1){ //ZIGZAG-SNAKE MOVIMENT
        
        /* Create the monster slightly off-screen along the right edge,
         and along a random position along the Y axis as calculated above
         */
        spriteMonster->setPosition(ccp(actualY,winSize.height + spriteMonster->getContentSize().height/2));
        this->addChild(spriteMonster);
        
        
        
        // ZigZag movement Start
        CCArray *arrayBezier = CCArray::create();
        arrayBezier->retain();
        ccBezierConfig bezier;
        CCBezierBy *bezierAction1;
        float splitDuration = actualDuration / 6.0;
        for(int i = 0; i< 6; i++){
            
            if(i % 2 == 0){
                bezier.controlPoint_1 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            else{
                bezier.controlPoint_1 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            
            arrayBezier->addObject(bezierAction1);
        }
        
        //        arrayBezier->addObject(Seq);
        
        CCSequence *seq = CCSequence::create(arrayBezier);
        
        spriteMonster->runAction(seq);
        // ZigZag movement End
        
    }
    else
    {
        spriteMonster->setPosition(ccp(actualY,winSize.height + spriteMonster->getContentSize().height/2));
        this->addChild(spriteMonster);
        
        // ZigZag movement Start
        CCArray *arrayBezier = CCArray::create();
        arrayBezier->retain();
        ccBezierConfig bezier;
        CCBezierTo *bezierAction1;
        float splitDuration = actualDuration / 6.0;
        for(int i = 0; i< 6; i++){
            
            if(i % 2 == 0){
                bezier.controlPoint_1 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            else{
                bezier.controlPoint_1 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = CCBezierTo::create(splitDuration, bezier);
            }
            
            arrayBezier->addObject(bezierAction1);
        }
        
        //            arrayBezier->addObject(Seq);
        
        CCSequence *seq = CCSequence::create(arrayBezier);
        
        spriteMonster->runAction(seq);
        // ZigZag movement End
        
    }
    monstersOnScreenArr->addObject(spriteMonster);
}

// Add this method
void MonsterRun::ccTouchesBegan(CCSet* touches,CCEvent* event) {
    
    CCArray *monstersToDelete = CCArray::create();
    monstersToDelete->retain();
    
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint location = touch->getLocationInView();
    
    
    CCObject *obj = NULL;
    CCARRAY_FOREACH(monstersOnScreenArr, obj)
    {
        CCSprite *monsterSpr = (CCSprite*)obj;
        if(monsterSpr->boundingBox().containsPoint(location))
        {
            Monster *m =(Monster*)monstersArr->objectAtIndex(monsterSpr->getTag());
            this->remove(monsterSpr);
            
            monsterSpr = CCSprite::create(m->SplashSprite.c_str());
            
            monsterSpr->setPosition(location);
            this->addChild(monsterSpr,10);
            //
            //            CCSequence *seq = CCSequence::createWithTwoActions(CCDelayTime::create(2),CCCallFuncN::create(this, callfuncN_selector(MonsterRun::remove)));
            //            this->runAction(seq);
            
            
        }
    }
}



void MonsterRun::remove(CCObject *sender){
    
    CCNode *tempMonster = (CCNode *)sender;
    //    tempMonster->removeFromParentAndCleanup(true);
    this->monstersOnScreenArr->removeObject(tempMonster);
    
    this->removeChild(tempMonster);
    
}

void MonsterRun::removeFromParent(CCObject *sender)
{
    CCSprite *spr=(CCSprite*)sender;
    spr->removeFromParentAndCleanup(true);
    
}
