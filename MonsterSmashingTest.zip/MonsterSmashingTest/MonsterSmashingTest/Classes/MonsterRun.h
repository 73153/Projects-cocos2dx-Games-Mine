//
//  MonsterRun.h
//  MonsterSmashingTest
//
//  Created by Vivek on 19/06/13.
//
//

#ifndef MonsterSmashingTest_MonsterRun_h
#define MonsterSmashingTest_MonsterRun_h

#include "MonsterRun.h"
#include "cocos2d.h"

USING_NS_CC;

class MonsterRun : public cocos2d::CCLayer
{
public:
    // Method 'init' in cocos2d-x returns bool, instead of 'id' in cocos2d-iphone (an object pointer)
    virtual bool init();
    
    MonsterRun();
    ~MonsterRun();
    
    CCArray * monstersArr;
    CCArray * monstersOnScreenArr;
    // there's no 'id' in cpp, so we recommend to return the class instance pointer
    static cocos2d::CCScene* scene();
    
    void addMonster(CCTime dt);
    void remove(CCObject *sender);
    void removeFromParent(CCObject *sender);
    
    void ccTouchesBegan(CCSet *touches, CCEvent*event);
    void removeSprite();
    

    
    CCSize winSize;
    
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(MonsterRun);
};


#endif
