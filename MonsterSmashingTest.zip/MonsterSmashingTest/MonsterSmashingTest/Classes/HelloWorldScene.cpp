#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"
#include "MonsterRun.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if (CCLayer::init() )
    {
        
        winSize = CCDirector::sharedDirector()->getWinSize();
        CCSprite *background =CCSprite::create("backgroundMonsters2.png");
        //dirt.scale = 1.0;
        background->setPosition(ccp(winSize.width/2, winSize.height/2));
        this->addChild(background ,-2);
        
        CCSprite *logo =CCSprite::create("MonsterSmashing.png");
        logo->setScale(1.2);
        logo->setPosition(ccp(winSize.width /2 , 800 ));
        
        // add the label as a child to this Layer
        this->addChild(logo);
        
  
        CCSprite *normalSprite=CCSprite::create("playButton.png");
        CCSprite *selectedSprite=CCSprite::create("playButtonSelected.png");

        
       CCMenuItemSprite *startGameButtonSpr =  CCMenuItemSprite::create(normalSprite,selectedSprite,this, menu_selector(HelloWorld::onStartGamePressed));
        
        CCMenuItemImage *soundOn = CCMenuItemImage::create("soundOn.png","soundOnSelected.png");
        CCMenuItemImage *soundOff = CCMenuItemImage::create("soundOff.png","soundOffSelected.png");
        
        CCMenuItemToggle *toggleItem = CCMenuItemToggle::createWithTarget(this,                                                               menu_selector(HelloWorld::soundButtonTapped), soundOn, soundOff,NULL);
        
        CCMenu *menu=CCMenu::create(startGameButtonSpr, toggleItem,NULL);
        menu->setPosition(winSize.width * 0.5f, winSize.height * 0.4f);
        menu->alignItemsVerticallyWithPadding(15);
        this->addChild(menu);
                                                        
    }

    return this;
}

void HelloWorld::soundButtonTapped()
{
    
}

void HelloWorld::onStartGamePressed()
{
    CCDirector::sharedDirector()->replaceScene(MonsterRun::scene());
}

void HelloWorld::menuCloseCallback(CCObject* pSender)
{
    CCDirector::sharedDirector()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
