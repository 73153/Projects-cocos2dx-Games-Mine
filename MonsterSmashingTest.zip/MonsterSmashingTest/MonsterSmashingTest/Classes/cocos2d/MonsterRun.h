//
//  MonsterRun.h
//  Monster Smashing
//
//  Created by Jorge Costa on 3/12/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MonsterRun : CCLayer {
    NSMutableArray * _monsters;
    NSMutableArray * _monstersOnScreen;
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;



@end
