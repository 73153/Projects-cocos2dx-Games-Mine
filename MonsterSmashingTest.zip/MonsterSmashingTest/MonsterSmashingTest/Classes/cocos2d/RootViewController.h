//
//  RootViewController.h
//  Monster Smashing
//
//  Created by Jorge Costa on 3/12/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
