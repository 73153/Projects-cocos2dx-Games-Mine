//
//  HelloWorldLayer.m
//  MonsterSmashing
//
//  Created by Jorge Costa on 3/3/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#import "HelloWorldLayer.h"
#import "AppDelegate.h"
#import "MonsterRun.h"

CGSize winSize;

// HelloWorldLayer implementation
@implementation HelloWorldLayer


// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene {
	CCScene *scene = [CCScene node];
	HelloWorldLayer *layer = [HelloWorldLayer node];
	[scene addChild: layer];
	return scene;
}

// on "init" you need to initialize your instance
-(id) init {
	if( (self=[super init]) ) {
        
        winSize = [CCDirector sharedDirector].winSize;
        CCSprite *background = [CCSprite spriteWithFile:@"backgroundMonsters2.png"];
        //dirt.scale = 1.0;
        background.position = ccp(winSize.width/2, winSize.height/2);
        [self addChild:background z:-2];

        CCSprite *logo = [CCSprite spriteWithFile:@"MonsterSmashing.png"];
        logo.scale = 1.2;
        logo.position =  ccp(winSize.width /2 , 800 );
        
        // add the label as a child to this Layer
        [self addChild: logo];
        
        CCMenuItem *startGameButtonImage = [CCMenuItemImage itemFromNormalImage:@"playButton.png" selectedImage:@"playButtonSelected.png" target:self selector:@selector(onStartGamePressed)];
        
        CCMenuItem *_soundOn = [[CCMenuItemImage  itemFromNormalImage:@"soundOn.png"
                                                         selectedImage:@"soundOnSelected.png" target:nil selector:nil] retain];
        CCMenuItem *_soundOff = [[CCMenuItemImage itemFromNormalImage:@"soundOff.png"
                                                         selectedImage:@"soundOffSelected.png" target:nil selector:nil] retain];
        CCMenuItemToggle *toggleItem = [CCMenuItemToggle itemWithTarget:self
                                                               selector:@selector(soundButtonTapped:) items:_soundOn, _soundOff, nil];
        
        //Create a menu from the button and center it on the screen
        CCMenu *menu = [CCMenu menuWithItems:startGameButtonImage, toggleItem, nil];
        menu.position = ccp(winSize.width * 0.5f, winSize.height * 0.4f);
        [menu alignItemsVerticallyWithPadding:15];
        
        //Add the menu as a child to this layer
        [self addChild:menu];
	}
	return self;
}

- (void)soundButtonTapped:(id)sender {
    //Part 3
}

- (void)onStartGamePressed {
	CCScene *MonsterRunScene = [MonsterRun scene];
    
	[[CCDirector sharedDirector] replaceScene:MonsterRunScene];
}

- (void) dealloc {

	[super dealloc];
}

@end
