//
//  Monster.m
//  Monster Smashing
//
//  Created by Jorge Costa on 4/13/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "Monster.h"


@implementation Monster

// no synthesize of properties is needed.
@synthesize monsterSprite = _monsterSprite;
@synthesize splashSprite = _splashSprite;
@synthesize minVelocity = _minVelocity;
@synthesize maxVelocity = _maxVelocity;
@synthesize movement = _movement;
@synthesize killMethod = _killMethod;

@end
