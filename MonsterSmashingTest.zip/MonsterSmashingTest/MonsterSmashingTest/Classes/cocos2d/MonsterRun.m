//
//  MonsterRun.m
//  Monster Smashing
//
//  Created by Jorge Costa on 3/12/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "MonsterRun.h"
#import "HelloWorldLayer.h"
#import "Monster.h"

CGSize winSize;

@implementation MonsterRun

+(CCScene *) scene{
	CCScene *scene = [CCScene node];
	
	MonsterRun *layer = [MonsterRun node];
	
	[scene addChild: layer];
	
	return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
        
        self.isTouchEnabled = YES;
        
        // Add background
        winSize = [CCDirector sharedDirector].winSize;
        CCSprite *background = [CCSprite spriteWithFile:@"WoodRetroApple_iPad_HomeScreen.jpg"];
        background.position = ccp(winSize.width/2, winSize.height/2);
        [self addChild:background z:-2];
        
        //initializing monsters
        _monsters = [[NSMutableArray alloc] init];
        
        Monster *m1 = [[Monster alloc] init];
        [m1 setTag:1];
        [m1 setMonsterSprite:[[NSString alloc] initWithString:@"monsterGreen.png"]];
        [m1 setSplashSprite:[[NSString alloc] initWithString:@"splashMonsterGreen.png"]];
        [m1 setMinVelocity:2.0];
        [m1 setMaxVelocity:8.0];
        [m1 setMovement:1];
        [m1 setKillMethod:1];
        [_monsters addObject:m1];

        Monster *m2 = [[Monster alloc] init];
        [m2 setTag:2];
        [m2 setMonsterSprite:[[NSString alloc] initWithString:@"monsterBlue.png"]];
        [m2 setSplashSprite:[[NSString alloc] initWithString:@"splashMonsterBlue.png"]];
        [m2 setMinVelocity:2.0];
        [m2 setMaxVelocity:8.0];
        [m2 setKillMethod:1];
        [m2 setMovement:1];
        [_monsters addObject:m2];

        Monster *m3 = [[Monster alloc] init];
        [m3 setTag:3];
        [m3 setMonsterSprite:[[NSString alloc] initWithString:@"monsterRed.png"]];
        [m3 setSplashSprite:[[NSString alloc] initWithString:@"splashMonsterRed.png"]];
        [m3 setMinVelocity:3.0];
        [m3 setMaxVelocity:6.0];
        [m3 setKillMethod:2];
        [m3 setMovement:2];
        [_monsters addObject:m3];
 
        [self schedule:@selector(addMonster:) interval:0.5];
        
        _monstersOnScreen = [[NSMutableArray alloc] init];
    
	}
	return self;
}

// Add this method
-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    NSMutableArray *monstersToDelete = [[NSMutableArray alloc] init];
    
    UITouch * touch = [[touches allObjects] objectAtIndex:0];
    CGPoint touchLocation = [self convertTouchToNodeSpace:touch];
    for (CCSprite *monster in _monstersOnScreen) {
        if (CGRectContainsPoint(monster.boundingBox, touchLocation)) {
            [monstersToDelete addObject:monster];
            
            //add animation with fade - splash
            Monster *m = [_monsters objectAtIndex:(monster.tag-1)];
            CCSprite *splashPool = [[CCSprite alloc] initWithFile:[m splashSprite]];
            
            if([m killMethod] == 1){
                splashPool.position = monster.position;
                [self addChild:splashPool];
                
                CCFadeOut *fade = [CCFadeOut actionWithDuration:3];  //this will make it fade
                CCCallFuncN *remove = [CCCallFuncN actionWithTarget:self selector:@selector(removeSprite:)];
                CCSequence *sequencia = [CCSequence actions: fade, remove, nil];
                [splashPool runAction:sequencia];
                //finish splash
            }
            if([m killMethod] == 2){
                // in Part 3 - Particles section
            }
            break;
            
        }
    }
    
     for (CCSprite *monster in monstersToDelete) {
         [monster stopAllActions];
         [_monstersOnScreen removeObject:monster];
         [self removeChild:monster cleanup:YES];
     }
}


-(void) removeSprite:(id)sender {
    [self removeChild:sender cleanup:YES];
}


- (void) addMonster:(ccTime)dt {
    
    //select a random monster from the _monsters Array
    int selectedMonster = arc4random() % [_monsters count];
    
    //get some monster caracteristics
    Monster *monster = [_monsters objectAtIndex:selectedMonster];
    int m = [monster movement];
    
    //!IMPORTANT -- Every Sprite in Screen must be an new CCSprite! Each Sprite can only be one time on screen
    CCSprite *spriteMonster = [[CCSprite alloc] initWithFile:[monster monsterSprite]];
    spriteMonster.tag = [monster tag];
    
    
    //BLOCK 1 - Determine where to spawn the monster along the Y axis
    CGSize winSize = [CCDirector sharedDirector].winSize;
    int minX = spriteMonster.contentSize.width / 2;
    int maxX = winSize.width - spriteMonster.contentSize.width/2;
    int rangeX = maxX - minX;
    int actualY = (arc4random() % rangeX) + minX;
    
    //BLOCK 2 - Determine speed of the monster
    int minDuration = [monster minVelocity];
    int maxDuration = [monster maxVelocity];
    int rangeDuration = maxDuration - minDuration;
    int actualDuration = (arc4random() % rangeDuration) + minDuration;
    
    if(m == 1){ //STRAIGHT MOVIMENT
        
        //BLOCK 3 - Create the monster slightly off-screen along the right edge,
        // and along a random position along the Y axis as calculated above
        spriteMonster.position = ccp( actualY,winSize.height + spriteMonster.contentSize.height/2);
        [self addChild:spriteMonster];
        
        //BLOCK 4 - Create the actions
        CCMoveTo * actionMove = [CCMoveTo actionWithDuration:actualDuration position:ccp( actualY,-spriteMonster.contentSize.height/2)];
        CCCallBlockN * actionMoveDone = [CCCallBlockN actionWithBlock:^(CCNode *node) {
            [_monstersOnScreen removeObject:node];
            [node removeFromParentAndCleanup:YES];
        }];
        
        [spriteMonster runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];

        [_monstersOnScreen addObject:spriteMonster];        
    } 
    else if(m == 2){ //ZIGZAG-SNAKE MOVIMENT
        
        /* Create the monster slightly off-screen along the right edge,
         and along a random position along the Y axis as calculated above
         */
        spriteMonster.position = ccp( actualY,winSize.height + spriteMonster.contentSize.height/2);
        [self addChild:spriteMonster];
                
        CCCallBlockN * actionMoveDone = [CCCallBlockN actionWithBlock:^(CCNode *node) {
            [_monstersOnScreen removeObject:node];
            [node removeFromParentAndCleanup:YES];
            
        }];
        
        // ZigZag movement Start
        NSMutableArray *arrayBezier = [[NSMutableArray alloc] init];
        ccBezierConfig bezier;
        id bezierAction1;
        float splitDuration = actualDuration / 6.0;
        for(int i = 0; i< 6; i++){
            
            if(i % 2 == 0){
                bezier.controlPoint_1 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY+100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = [CCBezierTo actionWithDuration:splitDuration bezier:bezier];
            }
            else{
                bezier.controlPoint_1 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.controlPoint_2 = ccp(actualY-100,winSize.height-(100+(i*200)));
                bezier.endPosition = ccp(actualY,winSize.height-(200+(i*200)));
                bezierAction1 = [CCBezierTo actionWithDuration:splitDuration bezier:bezier];
            }
            
            [arrayBezier addObject:bezierAction1];
        }
        
        [arrayBezier addObject:actionMoveDone];
        
        id seq = [CCSequence actionsWithArray:arrayBezier];
        
        [spriteMonster runAction:seq];
        // ZigZag movement End

        [_monstersOnScreen addObject:spriteMonster];
    }
}


// on "dealloc" you need to release all your retained objects
- (void) dealloc {
    [_monstersOnScreen release];
    _monstersOnScreen = nil;
    
	[super dealloc];
}




@end
