//
//  Monster.h
//  MonsterSmashingTest
//
//  Created by Vivek on 19/06/13.
//
//

#ifndef MonsterSmashingTest_Monster_h
#define MonsterSmashingTest_Monster_h

#include "cocos2d.h"
#include "Monster.h"

USING_NS_CC;

class Monster : public cocos2d::CCNode
{
public:
    // Method 'init' in cocos2d-x returns bool, instead of 'id' in cocos2d-iphone (an object pointer)
//    virtual bool init();
    
//    Monster();
//    ~Monster();
    
    // there's no 'id' in cpp, so we recommend to return the class instance pointer
    static cocos2d::CCScene* scene();
    std::string MonsterSprite;
    std::string SplashSprite;
    float  MinVelocity;
    float  MaxVelocity;
    int  Movement;
    int  KillMethod;
    int movement;
    
    CCSize winSize;
    
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(Monster);
};



#endif
