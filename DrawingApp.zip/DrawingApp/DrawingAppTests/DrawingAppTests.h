//
//  DrawingAppTests.h
//  DrawingAppTests
//
//  Created by i-CRG Labs on 5/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface DrawingAppTests : SenTestCase {
@private
    
}

@end
