int color;

extern int color;