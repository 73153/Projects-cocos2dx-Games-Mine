//
//  LWFFacebookFrndListScreen.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 17/07/13.
//
//

#include "LWFFacebookFrndListScreen.h"
#include "AppDelegate.h"
#include "LWFDataManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFGameProgressScreen.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFGenreListScene.h"
#include "LWFGame.h"


using namespace cocos2d;
using cocos2d::extension::CCTableView;
using cocos2d::extension::CCTableViewCell;
using cocos2d::extension::kCCTableViewFillTopDown;
using cocos2d::extension::kCCScrollViewDirectionVertical;


//CCScene* LWFFacebookFrndListScreen::scene()
//{
//    CCScene *scene=CCScene::create();
//
//    LWFFacebookFrndListScreen *introSceneLayer=new LWFFacebookFrndListScreen();
//    scene->addChild(introSceneLayer);
//    return scene;
//}

static int friendsortless(const CCObject* p1, const CCObject* p2)
{
    return (((CCDictionary*)p1)->valueForKey("name")->compare(((CCDictionary*)p2)->valueForKey("name")->getCString())<0);
}


#pragma mark - Other functions
static bool isPrefix(std::string const& l1, std::string const&l2)
{
    std::string s1 =l1,s2=l2;
    
    std::transform(s1.begin(), s1.end(), s1.begin(), ::tolower);
    std::transform(s2.begin(), s2.end(), s2.begin(), ::tolower);
    
    
    if(s2=="")
        return true;
    const char*p = s1.c_str();
    const char*q = s2.c_str();
    while (*p&&*q)
        if (*p++!=*q++)
            return false;
    return true;
}
LWFFacebookFrndListScreen::LWFFacebookFrndListScreen()
{
    currentGameArray = CCArray::create();
    currentGameArray->retain();

}

LWFFacebookFrndListScreen::~LWFFacebookFrndListScreen()
{
    friendsInstaledList->release();
    friendsNotInstaledList->release();
    friendsList->release();
    filteredfriendsList->release();
    
}
bool LWFFacebookFrndListScreen::init()
{
    if( !CCLayer::init() )
	{
		return false;
	}
    
    // AppDelegate *delegate=((AppDelegate*)CCApplication::sharedApplication());
    //array allocation
    friendsList = new CCArray;
    filteredfriendsList = new CCArray;
    friendsNotInstaledList = new CCArray;
    friendsInstaledList = new CCArray;
    
    tableView=NULL;
    issearching =false;
    isActiveTabPlay =true;
    loadedFriendList=false;
    
    //bg
    CCSprite * bg = CCSprite::create("LoginPage/Username-Login.png");
    this->addChild(bg);
    CCNodePlaceAtTop(bg,ccp(0,0));
    
    //    {
        CCSprite *topBar=CCSprite::create("LoginPage/bottombar.png");
        bg->addChild(topBar);
        topBar->setPosition(ccp(bg->getContentSize().width/2,458));
    //  }
    
  CCLabelTTF    *labelStatusCode = CCLabelTTF::create("FACEBOOK", "Marker Felt", 30);
  labelStatusCode->setPosition(ccp(170 ,25));
  topBar-> addChild(labelStatusCode,20);
    
    alertLabel = CCLabelTTF::create("", "Marker Felt", 30);
    alertLabel->setPosition(ccp(160 ,300));
    this-> addChild(alertLabel,20);
    

    //Alphabets
    CCSprite *alphabetsprite=CCSprite::create("FaceBookFriendListScreen/abc_txt.png");
    //this->addChild(alphabetsprite,3);
    // CCNodePlaceAtRight(alphabetsprite,ccp(-10,0));
    //  alphabetsprite->setPosition(ccp(290,200));
    
    loadnormalView(NULL);
    loadLabelMenu();
    
    CCSprite *playButtonNormalSpr = CCSprite::create("FaceBookFriendListScreen/play_btn.png");
    CCSprite *playButtonSelectedSpr = CCSprite::create("FaceBookFriendListScreen/play_btn.png");
    
    playTab =CCMenuItemSprite::create(playButtonNormalSpr,playButtonSelectedSpr,this, menu_selector(LWFFacebookFrndListScreen::switchTab));
    playTab->setPosition(ccp(100, 20));
    playTab->setTag(CCTAG(play));
    
    CCSprite *inviteButtonNormalSpr = CCSprite::create("FaceBookFriendListScreen/invite_btn.png");
    CCSprite *inviteSelectedSpr = CCSprite::create("FaceBookFriendListScreen/invite_btn.png");
    
    inviteTab =CCMenuItemSprite::create(inviteButtonNormalSpr,inviteSelectedSpr,this, menu_selector(LWFFacebookFrndListScreen::switchTab));
    inviteTab->setPosition(ccp(250, 20));
    inviteTab->setTag(CCTAG(invite));
    
//    CCSprite * topbar = CCSprite::create("FaceBookFriendListScreen/topbar_fb.png");
//    this->addChild(topbar);
//    topbar->setPosition(ccp(160,465));
    
//    CCMenuScrollable * menu = CCMenuScrollable::create();
//    menu->setContentSize(topbar->getContentSize());
    
    
    CCSprite *doneButtonNormalSpr = CCSprite::create("FaceBookFriendListScreen/back_btn.png");
    CCSprite *doneButtonSelectedSpr = CCSprite::create("FaceBookFriendListScreen/back_btn.png");
    
    CCMenuItemSprite * button = CCMenuItemSprite::create(doneButtonNormalSpr, doneButtonSelectedSpr, this, menu_selector(LWFFacebookFrndListScreen::BackButton));
    button->setPosition(CCPointMake(40,455));
    
    CCMenu *tempMenu = CCMenu::create(button,inviteTab,playTab,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,20);
    

    this->runAction(CCCallFunc::create(this, callfunc_selector(LWFFacebookFrndListScreen::loadActivity)));
    this->search(NULL);
	return true;
//    
}

void LWFFacebookFrndListScreen::loadActivity(CCObject* sender)
{
    checkForNetWork();
    // ActivtyIndicator::activityIndicatorOnScene("Loading friend list..", (MathMeScene*)this,true);
}

void LWFFacebookFrndListScreen::checkForNetWork()
{
    //  using namespace cocos2d::httpios;
    
    CCHttpRequest* request = new    CCHttpRequest();
    
    std::string url="http://www.google.com";
    request->setUrl(url.c_str());
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFFacebookFrndListScreen::onnetworkRequestCompleted));
    // optional fields
    request->setTag("Network test");
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
}

void LWFFacebookFrndListScreen::onnetworkRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    //using namespace httpios;
    
    if (!this->isRunning()) {
        return;
    }
    
    CCHttpResponse *response = (CCHttpResponse*)data;
    if(!response->isSucceed())
    {
        ActivtyIndicator::PopIfActiveFromScene(this);
        
        this->addChild(DialogOk::create( "Network error", "Failed to connect to facebook",  this, menu_selector(LWFFacebookFrndListScreen::BackButton)));
        return;
    }
    
    FetchFriendList();
}

void LWFFacebookFrndListScreen::remove()
{
    ActivtyIndicator::PopIfActiveFromScene(this);
}

void LWFFacebookFrndListScreen::switchTab(CCObject *Sendeer){
    
    CCNode * sendernode = (CCNode*)Sendeer;
    if(sendernode->getTag() == CCTAG(play) && !isActiveTabPlay)
    {
//        playTab->setVisible(true);
//        inviteTab->setVisible(false);
        
        isActiveTabPlay = !isActiveTabPlay;
    }else if(sendernode->getTag() != CCTAG(play) && isActiveTabPlay)
    {
//        playTab->setVisible(false);
//        inviteTab->setVisible(true);
        isActiveTabPlay = !isActiveTabPlay;
    }
    
    this->loadFriendList();
}

#pragma mark - CCMenuScrollable Functions
CCRect CCMenuScrollable::rect()
{
    //    return CCRectMake( m_tPosition.x - m_tContentSize.width * m_tAnchorPoint.x,
    //                      m_tPosition.y - m_tContentSize.height * m_tAnchorPoint.y,
    //                      m_tContentSize.width, m_tContentSize.height);
}


bool CCMenuScrollable::ccTouchBegan(CCTouch* touch, CCEvent* event)
{
    
    CCPoint touchLocation = touch->getLocation();
    
    CCPoint local = this->convertToNodeSpace(touchLocation);
    CCRect r = this->rect();
    r.origin = CCPointZero;
    
    if (!r.containsPoint(local))
    {
        return false;
    }
    
    initialLocation = local;
    
    
    exitTracking=false;
    return CCMenu::ccTouchBegan(touch, event);
}

void CCMenuScrollable::ccTouchMoved(CCTouch* touch, CCEvent* event)
{
    CCPoint touchLocation = touch->getLocation();
    CCPoint local = this->convertToNodeSpace(touchLocation);
    
    if(ccpDistance(local, initialLocation)>10)
    {
        exitTracking =true;
    }
    
    if(exitTracking)
    {
        
        
        if(m_eState == kCCMenuStateTrackingTouch)
        {
            CCMenu::ccTouchCancelled(touch, event);
            if(scrollView)
                scrollView->ccTouchBegan(touch, event);
        }else
        {
            if(scrollView)
                scrollView->ccTouchMoved(touch, event);
        }
        touch->retain();
        if(savedtouch)
            savedtouch->release();
        savedtouch = touch;
        
    }else
    {
        CCMenu::ccTouchMoved(touch, event);
        
    }
    
    
}


void CCMenuScrollable::ccTouchEnded(CCTouch* touch, CCEvent* event)
{
    if(exitTracking)
    {
        if(scrollView)
            scrollView->ccTouchEnded(touch, event);
        
        if(savedtouch)
            savedtouch->release();
        savedtouch=NULL;
    }else
        CCMenu::ccTouchEnded(touch, event);
    
}


CCMenuScrollable::~CCMenuScrollable()
{
    
}


void CCMenuScrollable::onExit()
{
    if(exitTracking)
        if(scrollView)
            scrollView->ccTouchCancelled(savedtouch, NULL);
    
    
    
    if(savedtouch)
        savedtouch->release();
    savedtouch=NULL;
    
    CCMenu::onExit();
    
}



void CCMenuScrollable::ccTouchCancelled(CCTouch* touch, CCEvent* event)
{
    if(exitTracking)
    {
        if(scrollView)
            scrollView->ccTouchCancelled(touch, event);
        
        
        if(savedtouch)
            savedtouch->release();
        
        savedtouch=NULL;
        
        
    }else
        
        
        CCMenu::ccTouchCancelled(touch, event);
    
    
}

#pragma mark - Table View functions

void LWFFacebookFrndListScreen::tableCellTouched(cocos2d::extension::CCTableView *table, cocos2d::extension::CCTableViewCell *cell)
{
    FacebookFriendCell *cell1= (FacebookFriendCell*)cell ;
    CCScaleTo *scaleAction1=CCScaleTo::create(0.05, 0.95);
    CCScaleTo *scaleAction2=CCScaleTo::create(0.05, 1);
    CCSequence *seq=CCSequence::createWithTwoActions(scaleAction1, scaleAction2);
    
    cell->runAction(seq);
    
    cell1->facebookInvite();
    
}

CCSize LWFFacebookFrndListScreen::cellSizeForTable(CCTableView *table)
{
    return CCSizeMake(50, 100);
}

CCTableViewCell* LWFFacebookFrndListScreen::tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx)
{
    CCDictionary * dict = (CCDictionary *)filteredfriendsList->objectAtIndex(idx);
    const CCString * name =dict->valueForKey("name");
    const CCString * facebookid =dict->valueForKey("id");
    
    FacebookFriendCell *cell;
    if(isActiveTabPlay)
        cell  = FacebookFriendCell::create(name->getCString(),facebookid->getCString(),false);
    else
        cell  = FacebookFriendCell::create(name->getCString(),facebookid->getCString(),true);
    
    
    cell->screen = this;
    return cell;
}

void LWFFacebookFrndListScreen::scrollToIndex(CCObject* sender)
{
    
    CCMenuItemFont* senderitem = (CCMenuItemFont*)sender;
    if(senderitem->getTag()== '?')
        this->search(sender);
    else if(senderitem->getTag()== '?')
        this->scrollToIndexCh('0');
    else
        this->scrollToIndexCh((char)senderitem->getTag());
}

void LWFFacebookFrndListScreen::scrollToIndexCh(char ch)
{
    
    tableView->unscheduleAllSelectors();
    tableView->getContainer()->stopAllActions();
    
    
    //endsearch(this);
    CCObject * pObj;
    int count=0;
    
    bool found=false;
    char lastfoundchar= '\0';
    int lastfoundCount =0;
    
    CCARRAY_FOREACH(filteredfriendsList, pObj)
    {
        
        std::string name= std::string(((CCDictionary*)pObj)->valueForKey("name")->getCString());
        
        std::string prefix;
        prefix+=ch;
        
        
        if(name[0] !=lastfoundchar)
        {
            lastfoundchar= name[0];
            lastfoundCount = count-1;
        }
        
        
        
        if(prefix[0] <name[0])
            break;
        
        if(isPrefix(name, prefix) )
        {
            found=true;
            
            
            break;
            
            
        }
        
        count++;
        
    }
    
    
    
    
    if(!found)
        count = lastfoundCount;
    
    
    CCPoint offset = tableView->minContainerOffset();
    
    if(offset.y >  numberOfCellsInTableView(tableView) *  cellSizeForTable(tableView).height)
    {
        return ;
    }
    
    offset.y+=cellSizeForTable(tableView).height*(count);
    
    if(offset.y>0)
        offset.y=0;
    
    tableView->setContentOffset(offset);
    
}
unsigned int LWFFacebookFrndListScreen::numberOfCellsInTableView(CCTableView *table)
{
    return filteredfriendsList->count();
}



void LWFFacebookFrndListScreen::loadnormalView(CCObject *sender)
{
    tableView = CCTableView::create(this, CCSizeMake(320, 300));
//    tableView->setPosition(ccp(2,300));
    tableView->setDirection(cocos2d::extension::kCCScrollViewDirectionVertical);
    //tableView->setPosition(ccp(200,50));
    tableView->setDataSource(this);
    tableView->setVerticalFillOrder(cocos2d::extension::kCCTableViewFillTopDown);
    tableView->setDelegate(this);
    this->addChild(tableView);
    
        tableView->setPosition(ccp(100,100));

    
    CCLog("tableView-<.egtposition=%f,%f",tableView->getPosition().x,tableView->getPosition().y);
}

#pragma mark - CCMenuItemFontHidden For Play/Invite
class CCMenuItemFontHidden:public CCMenuItemFont {
    
    
public:
    
    static CCMenuItemFontHidden * create(const char *value)
    {
        CCMenuItemFontHidden *pRet = new CCMenuItemFontHidden();
        pRet->initWithString(value, NULL, NULL);
        pRet->autorelease();
        return pRet;
    }
    
    void visit()
    {
        
        
    }
    
};

void LWFFacebookFrndListScreen:: loadLabelMenu(){
    CCMenu * menu =CCMenuScrollable::create();
    
    menu->setContentSize(CCSize(100, 300));
    
    
    CCPoint offset=CCPoint(0,-35);
    
    CCPoint stride=CCPoint(0,25);
    
    {
        CCMenuItemFont * font = CCMenuItemFontHidden::create("***?");
        font->setTag('?');
        menu->addChild(font);
        font->setTarget(this, menu_selector(LWFFacebookFrndListScreen::scrollToIndex));
        CCNodePlaceAtTop(font,offset);
        
        offset=ccpSub(offset, stride);
        offset=ccpSub(offset, ccp(0,10));
    }
    
    for (char i='A'; i<='Z'; i++)
    {
        std::string name;
        name+="***";
        name+=i;
        CCMenuItemFont * font = CCMenuItemFontHidden ::create(name.c_str());//CCMenuItemFontHidden
        menu->addChild(font);
        font->setTarget(this, menu_selector(LWFFacebookFrndListScreen::scrollToIndex));
        CCNodePlaceAtTop(font,offset);
        font->setTag(i);
        offset=ccpSub(offset, stride);
    }
    
    {
        CCMenuItemFont * font = CCMenuItemFontHidden::create("**#*");
        menu->addChild(font);
        font->setTarget(this, menu_selector(LWFFacebookFrndListScreen::scrollToIndex));
        CCNodePlaceAtTop(font,offset);
        font->setTag('#');
        offset=ccpSub(offset, stride);
    }
    
    
    this->addChild(menu,5);
    CCNodePlaceAtRight(menu,ccp(25,20));
}

void LWFFacebookFrndListScreen::loadFriendList()
{
    loadedFriendList=true;
    filteredfriendsList->removeAllObjects();
    
    
    if(friendsInstaledList->count()==0)
    {
        isActiveTabPlay=false;
//        inviteTab->setVisible(true);
//        playTab->setVisible(false);
    }
    
    if(isActiveTabPlay)
    {
        playTab->setEnabled(false);
        inviteTab->setEnabled(true);
        filteredfriendsList->addObjectsFromArray(friendsInstaledList);
    }
    else
    {
        playTab->setEnabled(true);
        inviteTab->setEnabled(false);
        filteredfriendsList->addObjectsFromArray(friendsNotInstaledList);
    }
    
    LWFDataManager::sharedManager()->FBFriendList=CCArray::create();
    LWFDataManager::sharedManager()->FBFriendList->retain();
    LWFDataManager::sharedManager()->FBFriendList->initWithArray(friendsInstaledList);
    tableView->reloadData();
    reinitlist();
    
    // ActivtyIndicator::PopIfActive();
}

void LWFFacebookFrndListScreen::sortList(){
    std::sort(friendsInstaledList->data->arr, friendsInstaledList->data->arr + friendsInstaledList->data->num, friendsortless);
    
    std::sort(friendsNotInstaledList->data->arr, friendsNotInstaledList->data->arr + friendsNotInstaledList->data->num, friendsortless);
    
}
#pragma mark- Search Methods
void LWFFacebookFrndListScreen::search(CCObject *Sender){
    {
        AppDelegate *delegate=((AppDelegate*)CCApplication::sharedApplication());
        
        if(tableView)
            tableView->removeFromParentAndCleanup(true);
        
        CCMenuItemImage * searchitem = CCMenuItemImage::create("FaceBookFriendListScreen/Search.png",
                                                               "FaceBookFriendListScreen/Search.png",
                                                               "FaceBookFriendListScreen/Search.png",this,
                                                               menu_selector(LWFFacebookFrndListScreen::startsearch));
        
          searchitem->setPosition(ccp(160,400));
        

        CCMenu *tempMenu = CCMenu::create(searchitem,NULL);
        tempMenu->setPosition(CCPointZero);
        this->addChild(tempMenu,2);
        

        tableView = CCTableView::create(this, CCSizeMake(480,300));
        tableView->setPosition(ccp(0,50));
            
        tableView->setDirection(kCCScrollViewDirectionVertical);
        tableView->setDataSource(this);
        tableView->setVerticalFillOrder(kCCTableViewFillTopDown);
        tableView->setDelegate(this);
        this->addChild(tableView);
        
        pTextField = CCTextFieldTTF::textFieldWithPlaceHolder("Search",
                                                              "Helvetica-Bold",
                                                             20);
        searchitem->addChild(pTextField);
       pTextField->setDelegate(this);
        pTextField->setPosition(ccp(80,15));
     
        issearching = true;
    }
}

void LWFFacebookFrndListScreen::startsearch(CCObject *sender){
    pTextField->setPlaceHolder("");
    pTextField->attachWithIME();
    issearching =true;
}

void LWFFacebookFrndListScreen::filterSearch( const char * ptr){
    filteredfriendsList->removeAllObjects();
    
    CCArray * tempList;
    
    if(isActiveTabPlay)
        tempList = friendsInstaledList;
    else
        tempList = friendsNotInstaledList;
    
    
    
    CCObject* pObj = NULL;
    
    CCARRAY_FOREACH(tempList, pObj)
    {
        
        std::string name= std::string(((CCDictionary*)pObj)->valueForKey("name")->getCString());
        if(isPrefix(name, ptr))
        {
            filteredfriendsList->addObject(pObj);
        }
    }
    
    tableView->reloadData();
    reinitlist();
    
}

void LWFFacebookFrndListScreen::endsearch(CCObject *Sender){
    if(!issearching)
        return;
    searchBox->removeFromParentAndCleanup(true);
    searchBox =NULL;
    if(tableView)
        tableView->removeFromParentAndCleanup(true);
    tableView =NULL;
    
    
    loadnormalView(Sender);
    
    filterSearch("");
    issearching =false;
    
}


#pragma mark- TextField Methods
bool LWFFacebookFrndListScreen::onTextFieldModifedText(cocos2d::CCTextFieldTTF * pSender, std::string text, int nLen)
{
    
    filterSearch(text.c_str());
    
    return false;
}

bool LWFFacebookFrndListScreen::onTextFieldDeleteBackward(cocos2d::CCTextFieldTTF * sender, const char * delText, int nLen)
{
    
    std::string myString =sender->getString();
    
    return onTextFieldModifedText(sender, myString.substr(0, myString.size()-1), nLen);
}


bool LWFFacebookFrndListScreen::onTextFieldInsertText(CCTextFieldTTF * pSender, const char * text, int nLen)
{
    // if insert enter, treat as default to detach with ime
    if ('\n' == *text)
    {
        return false;
    }
    
    
    // if the textfield's char count more than m_nCharLimit, doesn't insert text anymore.
    if (pSender->getCharCount() > 20)
    {
        return true;
    }
    
    return onTextFieldModifedText(pSender, std::string(pSender->getString())+text, nLen);
    
}

void LWFFacebookFrndListScreen::BackButton(CCObject* sender)
{
    //  CCPopScene();
    CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
}

#pragma mark - request,response from server for getting currentGame
void LWFFacebookFrndListScreen::requestToGetOpponentDetails(std::string email)
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToLoadSelectedOpponent(email).c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFFacebookFrndListScreen::responseForTheRequestToGetOpponentDetails));
    LWFHttpClient::getInstance()->send(request);
    request->release();
}

void LWFFacebookFrndListScreen::responseForTheRequestToGetOpponentDetails(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    
    if(message=="Success!!!")
    {
        LWFDataManager::sharedManager()->opponentID=document["userId"].GetString();
        //initially challeNGE id will be Null
        LWFDataManager::sharedManager()->currentChallengeId = "9999";
        LWFDataManager::sharedManager()->roundCount = 0;
        
        CCLog("Going to game scene with opponent id %s",LWFDataManager::sharedManager()->opponentID.c_str());
        
        CCDirector::sharedDirector()->replaceScene(LWFGenreListScene::scene());
    }
    
    else if(message=="Challenge already exists with this user!!!")
    {
        alertLabel->setString(document["msg"].GetString());
        
    }
    else if (message=="You can't play against you!!!")
    {
        alertLabel->setString(document["msg"].GetString());
    }
    else if(message=="User doesn't exist!!!")
    {
        alertLabel->setString(document["msg"].GetString());
    }
}


void LWFFacebookFrndListScreen::sendPlayRequestInvitation( const char * facebookid ,const char * username)
{
    CCLog(" sending request to %s with user name %s",facebookid,username);
    
    char requestTagstring[256];
	sprintf(requestTagstring, "%d",requestTag);
    CCHttpRequest* request = new CCHttpRequest();
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToGetFaceBookUserDetails(facebookid).c_str());
    CCLog("%s",request->getUrl());
    request->setTag(requestTagstring);
    request->setRequestType(CCHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFFacebookFrndListScreen::onGamePlayRequestCompleted));

    // optional fields
    //request->setTag("sendPlayRequestInvitation");
    
    CCHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
}


#pragma mark - Server/Network Related Functions
void LWFFacebookFrndListScreen::onGamePlayRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    
    if (!this->isRunning()) {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
 
    std::string message= document["msg"].GetString();
    CCLog("message=%s",message.c_str());
    
    if(message=="Facebook user not exists")
    {
        //        DialogOk * dialog =new DialogOk;
        //        dialog->init("Network error", "Facebook User  not exit", this, NULL);
        //        this->addChild(dialog,5);
        //        dialog->release();
        //
        //        ActivtyIndicator::PopIfActive();
        //        return;
    }
    
    if(message=="Invalid APIKey")
    {
        //        DialogOk * dialog =new DialogOk;
        //        dialog->init("Network error", "Failed to login ,try again", this, NULL);
        //        this->addChild(dialog,5);
        //        dialog->release();
        //
        //        MMGameManager::sharedManager()->resetUser("0", "", "", "0","");
        //        ActivtyIndicator::PopIfActive();
        //        return;
    }
    if(message=="APIKey session out!!!"){
        //        DialogOk * dialog =new DialogOk;
        //        dialog->init("API Key error", "API Key session Out", this, NULL);
        //        this->addChild(dialog,5);
        //        dialog->release();
        
        
    }
    
    if(message=="Success")
    {
        
       
        std::string emilID=document["user"]["email"].GetString();
        CCLog("Opponent email id is %s",emilID.c_str());
        this->requestToGetOpponentDetails(emilID);
    }
        

}

