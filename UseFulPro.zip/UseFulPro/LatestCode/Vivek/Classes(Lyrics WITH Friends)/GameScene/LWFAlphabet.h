//
//  LWFAlphabet.h
//  LyricsWithFriends
//
//  Created by Deepthi on 24/06/13.
//
//

#ifndef __LyricsWithFriends__LWFAlphabet__
#define __LyricsWithFriends__LWFAlphabet__

#include <iostream>
#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;

class LWFAlphabet:public CCObject
{
public:
    
    LWFAlphabet();
    ~LWFAlphabet();
    
    bool isHint;
    std::string alphabet;
};


#endif /* defined(__LyricsWithFriends__LWFAlphabet__) */
