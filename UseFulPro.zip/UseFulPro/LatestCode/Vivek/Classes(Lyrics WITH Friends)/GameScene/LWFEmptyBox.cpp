//
//  LWFEmptyBox.cpp
//  LyricsWithFriends
//
//  Created by Krithik B on 24/05/13.
//
//

#include "LWFEmptyBox.h"
#include "LWFDataManager.h"
#include "cocos2d.h"

USING_NS_CC;


LWFEmptyBox::LWFEmptyBox()
{
    this->currentKeyBoardBtn = NULL;
    this->canAddAlphabet=true;
   
}

LWFEmptyBox* LWFEmptyBox::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

LWFEmptyBox* LWFEmptyBox::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    LWFEmptyBox *pobSprite = new LWFEmptyBox();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}


LWFEmptyBox::~LWFEmptyBox()
{
    this->currentKeyBoardBtn = NULL;
}

#pragma MARK - returnEmptyBoxPosition
CCPoint LWFEmptyBox::getEmptyBoxPosition(int emptyBoxNo,int xVal,int yVal,int xSpaceVal,int ySpaceVal,int possibleEmptyBoxInLine,int xStartVal)
{
 
    CCLOG("%d=emptyboxno",emptyBoxNo);
    CCLOG("%d=possibleEmptyBoxInLine",possibleEmptyBoxInLine);
    if(emptyBoxNo==possibleEmptyBoxInLine)
    {
        xVal=xStartVal;
        yVal=yVal-ySpaceVal;
    }
//    if(emptyBoxNo<=10)
//    {
//        if(LWFDataManager::sharedManager()->index==0)
//        {
//            yVal=260;
//        }
//        else if(LWFDataManager::sharedManager()->index==1)
//        {
//            yVal=268;
//        }
//        else
//        {
//            yVal=272;
//            
//        }
//    }
//    else if(emptyBoxNo>=11 && emptyBoxNo<=21)
//    {
//        if(LWFDataManager::sharedManager()->index==0)
//        {
//            yVal=220;
//        }
//        else if(LWFDataManager::sharedManager()->index==1)
//        {
//            yVal=236;
//        }
//        else
//        {
//            yVal=246;
//        }
//    }
//    else if(emptyBoxNo>=22&& emptyBoxNo<=32)
//    {
//        if(LWFDataManager::sharedManager()->index==0)
//        {
//            yVal=180;
//        }
//        else if(LWFDataManager::sharedManager()->index==1)
//        {
//            yVal=204;
//        }
//        else
//        {
//            yVal=220;
//        }
//    }
//    else if(emptyBoxNo>=33&&emptyBoxNo<=43)
//    {
//        if(LWFDataManager::sharedManager()->index==0)
//        {
//            yVal=140;
//        }
//        else if(LWFDataManager::sharedManager()->index==1)
//        {
//            yVal=172;
//        }
//        else
//        {
//            yVal=194;
//        }
//        
//    }
//    else if(emptyBoxNo>=44)
//    {
//        yVal=168;
//    }
//    
//    xVal=xVal+28;
//    
//    if(emptyBoxNo==0||emptyBoxNo==11||emptyBoxNo==22||emptyBoxNo==33||emptyBoxNo==44)
//    {
//        xVal=20;
//    }
    CCLOG("%d:%d=x:y",xVal,yVal);
     return CCPoint(xVal, yVal);
  }