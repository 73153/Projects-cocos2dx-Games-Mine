//
//  LWFGameScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#ifndef LyricsWithFriends_LWFGameScene_h
#define LyricsWithFriends_LWFGameScene_h

#include "cocos2d.h"
#include "cocos-ext.h"

#include "LWFKeyboardBTN.h"
#include "LWFEmptyBox.h"

#include "rapidjson.h"
#include "filestream.h"
#include "document.h"
#include "LWFHint.h"


#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

using namespace cocos2d;



class LWFGameScene:public cocos2d::CCLayer
{
public:
    
    LWFGameScene();
    ~LWFGameScene();
    
    virtual void onEnter();
    virtual void onExit();
    
    static cocos2d::CCScene* scene();
    CREATE_FUNC(LWFGameScene);
    
    
    bool isGameOver;
    
    CCScene *scene(int value);
    
 
    //initialiseFunc
    void initialiseFunc();
    void initialiseVariables();
    void initialiseUI();
    
    //SONG
    CCDictionary *selectedSongDict;
     
    //shuffle
    int* shuffleArray(int num[100],int count);
    int* store_randomArray;

    
    bool  isSpaceFoundInBeggining;
    LWFEmptyBox *emptyBoxSpr;
    
    //TIME
    int seconds;
    void startTimerFunc( cocos2d::CCTime dt);
    CCLabelTTF *timerLabel;
    
    //GAME
    void gameOver();
    
    //Question
    void loadTheQuestion();
    void checkForQuestionLayOut();
    void playSongFunc();

    int questionFontSize;
    float labelXval;
    float labelYval;
    float labelXpos;
    float labelYpos;
    
    //Hint
    void generateRandomHint();
    
    CCMenuItemSprite *hintButton;
    
    //KEYBOARD

    CCDictionary *keyboardAlphabetsDict;
    LWFKeyboardBTN *currentDraggedKeyboardAlphabet;
    CCArray *keyBoardLettersArr;

    void placeAlphabetAtTheCentreOfLine(int startVal);
    int numberOfCharactersInkeyBoard();
    void checkForKeyboardUILayout();
    void checkForkeyBoardArrayEmpty();
    void addKeyBoard();
    void canDragAlphabetFunc();
    void placingAllkeyBoardAlphabetToEmptyBoxAfterTimerExpires();

    //variables required for keyBoardLayout
    int keyBoardXval;
    int keyBoardYval;
    float keyboardScaleVal;
    int noOfCharactersInLine;
    int placedCharactersInaLine;
    int spaceBtnTwoCharactersHorizontally;
    int spaceBtnTwoCharactersVertically;
    int alphabetAllignmentVal;
    int keyBoardCharacterCount;
    CCPoint originalKeyPosition;
    
    bool isPlacedAlphabet;
    bool canDragTheAlphabet;
    bool isDoneScreenAdded;
    bool isDragingAnyKeyboardAlphabet;
    
    //variable used for doneScreen
    int correctPlacedAlphabets;
    int noOfWordsCompleted;
    CCMenuItemSprite *doneButon;
    CCLabelTTF   *scoreLabel;
    CCLabelTTF   *lyricsCompletedBonusLabel;
    CCLabelTTF   *wordCompleted;
    CCLabelTTF   *lettersDragged;
    
    //Score
    int score;
    int lyricsCompletedBonus;
    CCLabelTTF *pointLabel;
    CCLabelTTF *opponentScoreLabel;

    void addScoreAfterCompletingEachWord();
    void addScoreAfterEachAlphabetSucessfullyPlacing();
    void addScoreAfterGameCompletion();
    void addDoneScreen();
    

    
    //Empty box
    CCArray *emptyBoxArr;
    
    //used for checking word complition
    int startIndex;
    int endIndex;
    int placedCharacterCount;
    
    std::string emptyBoxCharacters;
    
    void addEmptyBox();
    void checkForWordComplete();
    void checkForWordCompleteFromStartIndexToEndIndex(int startIndex,int endIndex);
    void addAlphabetToEmptyBox(LWFKeyboardBTN *currentAlphabet,LWFEmptyBox *emptyBox);
    void checkForEmptyBoxLayout();
   
    //used for emptyBoxLayOut
    int emptyBoxXval;
    int emptyBoxYval;
    float emptyBoxScaleVal;
    int noOfemptyBoxInLine;
    int spaceBtnTwoemptyBoxHorizontally;
    int spaceBtnTwoemptyBoxVertically;
    int xStartVal;
    int emptyBoxLineNo;
    int placedEmptyBoxCount;
    int ySpaceValInitial;
    int ySpaceValAfter;
    
    //Buttons & UI
    CCMenuItemSprite *skipButton;
    CCMenuItemSprite *playButton;
    CCMenuItemSprite *menuButton;
    
    void backBtnAction();
    void playFunc();
    void doneFunc();
    void skipFunc();
    void menuFunc();
        
//    //hint
//    CCArray *hintArray;
//    void selectionOfRandomAlphabetAsHint();
//    LWFHint *hint;
//    bool isHintPresent;
//    std::string songAns[100];
//
//    
//    int hintPos;

     //-----Answer
    //used to store contents of ans in array
    void addAnswertToArray();
    CCArray *alphabetArray;
    //variable used to store space in ans

    std::vector<int> locationsOfSpaceInAnswer;
    //finding space position
    void findSpacePositionInAnswer();
    //used to check whether space is present in the ans
    bool checkWhetherSpaceIsPresentAtIndex(int indexVal);
    //when to start the game
    bool canStartTheGame;
    
    //Touches
    virtual void ccTouchesBegan(CCSet* touches, CCEvent* event);
    virtual void ccTouchesMoved(CCSet* touches, CCEvent *event);
    virtual void ccTouchesEnded(CCSet* touches, CCEvent* event);
    virtual void ccTouchesCancelled(CCSet* touches, CCEvent* event);
    
    //Utility
    //Returns the array of charatcer locations
    std::vector<int> findLocation(std::string sample, char findIt);
    std::string getStringWithOutSpace(std::string pressedAlphabet);
    static int getRandomNumberBetween(int min, int max);



};


#endif
