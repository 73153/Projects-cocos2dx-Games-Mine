//
//  LWFEmptyBox.h
//  LyricsWithFriends
//
//  Created by Krithik B on 24/05/13.
//
//

#ifndef LyricsWithFriends_LWFEmptyBox_h
#define LyricsWithFriends_LWFEmptyBox_h


#include "cocos2d.h"
#include "LWFKeyboardBTN.h"

USING_NS_CC;

class LWFEmptyBox:public CCSprite
{
public:
    LWFEmptyBox();
    ~ LWFEmptyBox();
    
    static LWFEmptyBox* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static LWFEmptyBox* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    
    LWFKeyboardBTN *currentKeyBoardBtn;
    //    LWFKeyboardBTN *currentKeyBoardBtn;
    
    bool isHintBox;
    bool canAddAlphabet;
    bool isSolved;
    bool isWordGroupFormed;
    
    std::string alphabet;
   
    CCPoint getEmptyBoxPosition(int emptyBoxNo,int xVal,int yVal,int xSpace,int ySpace,int noOfEmptyBoxInLine,int xStartVal);
    
 };


#endif
