//
//  LWFHint.h
//  LyricsWithFriends
//
//  Created by Deepthi on 24/06/13.
//
//

#ifndef __LyricsWithFriends__LWFHint__
#define __LyricsWithFriends__LWFHint__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;

class LWFHint:public CCObject
{
public:
    LWFHint();
    ~LWFHint();
    
     int hintIndex;


};

#endif /* defined(__LyricsWithFriends__LWFHint__) */
