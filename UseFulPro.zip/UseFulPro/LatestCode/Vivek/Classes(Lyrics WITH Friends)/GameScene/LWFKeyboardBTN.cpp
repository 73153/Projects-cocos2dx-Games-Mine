//
//  LWFKeyboardBTN.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 20/05/13.
//
//

#include "LWFKeyboardBTN.h"
#include "LWFDataManager.h"
#include "cocos2d.h"

USING_NS_CC;


LWFKeyboardBTN::LWFKeyboardBTN()
{
        
}

LWFKeyboardBTN* LWFKeyboardBTN::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

LWFKeyboardBTN* LWFKeyboardBTN::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    LWFKeyboardBTN *pobSprite = new LWFKeyboardBTN();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

CCPoint LWFKeyboardBTN::getEmptyBoxPosition(int i, int keyBoardXpos, int keyBoardYpos,int spaceXval,int spaceYval,int noOfCharacters)
{

    if(i==noOfCharacters)
     {
        keyBoardYpos=keyBoardYpos-spaceYval;
        keyBoardXpos=20;

     }
   

    return CCPoint(keyBoardXpos,keyBoardYpos);

    
}


LWFKeyboardBTN::~LWFKeyboardBTN()
{
    
}