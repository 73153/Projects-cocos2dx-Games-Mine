//
//  LWFCreateURLSharedManager.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//

#include "LWFCreateURLSharedManager.h"
#include "SimpleAudioEngine.h"
#include "LWFDataManager.h"
#include <string>

#define BASE_URL "http://juegostudio.co.in/lyricswithfriendz/lyricsapi/api/"

USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;
using namespace CocosDenshion;


static LWFCreateURLSharedManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

LWFCreateURLSharedManager::LWFCreateURLSharedManager(void)
{
    
}

LWFCreateURLSharedManager::~LWFCreateURLSharedManager(void)
{
    
}


LWFCreateURLSharedManager* LWFCreateURLSharedManager::sharedManager(void) {
    
	LWFCreateURLSharedManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new LWFCreateURLSharedManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool LWFCreateURLSharedManager::init(void)
{
   
	return true;
}



std::string LWFCreateURLSharedManager::createLoginURL(std::string emailID,std::string passWord,std::string signin)
{
    std::string url=BASE_URL"signin?";
 
    url =url+"userId"+"=""&";
    url=url+"facebookId"+"=""&";
    url=url+"name"+"=""&";
    url=url+"email"+"="+emailID+"&";
    url=url+"password"+"="+passWord+"&";
    url=url+"gender"+"=""&";
    url=url+"country"+"=""&";
    url=url+"facebookThumbnail"+"=""&";
    url=url+"type"+"="+signin+"&";
    url=url+"iosPushId"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("PushNotificationDeviceToken","NoPush");
    
    return url;
}

std::string LWFCreateURLSharedManager::createURLToLoginThroughFB(std::string emailID,std::string faceBookID,std::string facebookThumbnail,std::string userName,std::string gender)
{
    std::string type ="signup";
    std::string url=BASE_URL"signin?";
    
    url =url+"userId"+"=""&";
    url=url+"facebookId"+"="+faceBookID+"&";
    url=url+"name"+"="+userName+"&";
    url=url+"email"+"="+emailID+"&";
    url=url+"password"+"=""&";
    url=url+"gender"+"="+gender+"&";
    url=url+"country"+"=""&";
    url=url+"facebookThumbnail"+"="+facebookThumbnail+"&";
    url=url+"type"+"="+type+"&";
    //if no PushNotificationDeviceToken then set default val 12345
    url=url+"iosPushId"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("PushNotificationDeviceToken","NoPush");
    
    return url;

}

std::string LWFCreateURLSharedManager::createRegistrationURL(std::string userName, std::string emailID, std::string password, std::string signup)
{
    std::string url=BASE_URL"signin?";
  
    url =url+"userId"+"=""&";
    url=url+"facebookId"+"=""&";
    url=url+"name"+"="+userName+"&";
    url=url+"email"+"="+emailID+"&";
    url=url+"password"+"="+password+"&";
    url=url+"gender"+"=""&";
    url=url+"country"+"=""&";
    url=url+"facebookThumbnail"+"=""&";
    url=url+"type"+"="+signup+"&";
    url=url+"iosPushId"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("PushNotificationDeviceToken","NoPush");

    return url;
}

std::string LWFCreateURLSharedManager::createLogOutURL()
{

    std::string url=BASE_URL"signout?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0");
  
     CCLOG("%s=value",CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0").c_str());
    return  url;
 }

std::string LWFCreateURLSharedManager::createURLToGetLyrics()
{
    std::string url=BASE_URL"getlyrics?";
    
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url=url+"categoryId"+"=""&";
    url=url+"levelId"+"=""&";
    url=url+"difficultyId"+"=""&";
    url=url+"limit"+"="+"1";
    return url;
    
  }

std::string LWFCreateURLSharedManager::createURLToGetRandomOpponents()
{
    std::string url=BASE_URL"getrandomuser?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url=url+"gender"+"="+"";
    return url;
}

std::string LWFCreateURLSharedManager::createURLToSubmitChallenge()
{
    char a[100]={};
    LWFDataManager::sharedManager()->roundCount++;
    sprintf(a, "%d",LWFDataManager::sharedManager()->roundCount);
    
    std::string url = BASE_URL"submitchallenge?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
   
    CCLOG("%s",LWFDataManager::sharedManager()->currentChallengeId.c_str());
    CCLOG("in submit challen opponent=%s",LWFDataManager::sharedManager()->opponentID.c_str());
    
    if( LWFDataManager::sharedManager()->currentChallengeId=="9999")
    {
            url=url+"challengeId"+"=""&";
    }
    else
    {
        
        url = url+"challengeId"+"="+LWFDataManager::sharedManager()->currentChallengeId+"&";
    }
    
    url=url+"opponentUserId"+"="+LWFDataManager::sharedManager()->opponentID+"&";
    url=url+"turnId"+"="+LWFDataManager::sharedManager()->opponentID+"&";
    url=url+"round"+"="+a+"&";
    url=url+"lyricsId"+"="+ LWFDataManager::sharedManager()->lyricsID+"&";
    url=url+"gameConfig"+"="+"&";
    url=url+"userConfig"+"=""&";
    url=url+"status"+"=""&";
    url=url+"score"+"="+LWFDataManager::sharedManager()->scoreCount+"&";
    url=url+"wonBy"+"="+"";
    return url;
    
}

std::string LWFCreateURLSharedManager:: createURLToLoadCurrentGames()
{
    std::string url=BASE_URL"getgames?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
     url=url+"challengeId"+"="+LWFDataManager::sharedManager()->currentChallengeId;
    return  url;
}

std::string LWFCreateURLSharedManager::createURLToCloseChallenge()
{
    http://juegostudio.co.in/lyricswithfriendz/lyricsapi/api/closechallenge?APIKey=bfe0514ce0e8de9dd153552dfcb567b2072b2dab&challengeId=1
    std::string url =BASE_URL"closechallenge?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url = url+"challengeId"+"="+LWFDataManager::sharedManager()->currentChallengeId;
    return url;
}

std::string LWFCreateURLSharedManager::createURLToGetChallenge()
{
    std::string url =BASE_URL"getchallenge?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url = url+"challengeId"+"="+LWFDataManager::sharedManager()->currentChallengeId;
    return url;
    
}

std::string LWFCreateURLSharedManager::createURLForPush()
{
    std::string msg="Hello";
    std::string url =BASE_URL"poke?";
     url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url=url+"pokeUserId"+"="+LWFDataManager::sharedManager()->currentUserID+"&";
    url=url+"msg"+"="+msg;
    return  url;
}

std::string LWFCreateURLSharedManager::createURLToLoadSelectedOpponent(std::string emailID)
{
    std::string url=BASE_URL"playgame?";
    url=url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0")+"&";
    url=url+"email"+"="+emailID;
    
   return url;
}

std::string LWFCreateURLSharedManager::createURLToGetFaceBookUserDetails( const char * facebookid)
{
    std::string url=BASE_URL"getfacebookuserdetails?";
    url = url+"facebookId"+"="+facebookid+"&";
    url = url+"APIKey"+"="+CCUserDefault::sharedUserDefault()->getStringForKey("APIKey", "0");
    return url;
}

