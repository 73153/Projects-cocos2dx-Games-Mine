//
//  LWFOpponentSelectionScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 11/07/13.
//
//

#include "LWFOpponentSelectionScene.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFGenreListScene.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFGenreListScene.h"
#include "LWFDataManager.h"
#include "LWFGameProgressScreen.h"


CCScene* LWFOpponentSelectionScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFOpponentSelectionScene *layer = LWFOpponentSelectionScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - Constuctor
LWFOpponentSelectionScene::LWFOpponentSelectionScene()
{
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,300));
    this->addChild(labelStatusCode,20);
    
    CCSprite *bgSpr = CCSprite::create("LoginPage/Username-Loginre-bg.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    
    CCSprite *userNameSpr = CCSprite::create("opponentSelectionPage/userName.png");
    userNameSpr->setPosition(ccp(160,254));
    this->addChild(userNameSpr);
    
    CCSprite *bottombarSpr = CCSprite::create("LoginPage/bottombar.png");
    bottombarSpr->setPosition(ccp(160,26));
    this->addChild(bottombarSpr,1);
    
    CCSprite *backButtonNormalSpr = CCSprite::create("LoginPage/back_bt.png");
    CCSprite *backButtonSelectedSpr = CCSprite::create("LoginPage/back_bt.png");
    
    CCMenuItemSprite *backButtonMenuItem = CCMenuItemSprite::create(backButtonNormalSpr, backButtonSelectedSpr, this, menu_selector(LWFOpponentSelectionScene::goBackToGameProgressScreen));
    backButtonMenuItem->setPosition(CCPointMake(28,458));

    
    CCSprite *doneButtonNormalSpr = CCSprite::create("DonePage/done-bt.png");
    CCSprite *doneButtonSelectedSpr = CCSprite::create("DonePage/done-bt.png");
    
    
    CCMenuItemSprite *doneButton = CCMenuItemSprite::create(doneButtonNormalSpr, doneButtonSelectedSpr, this, menu_selector(LWFOpponentSelectionScene::onClickOfDoneBtn));
    doneButton->setPosition(CCPointMake(160,170));

    CCMenu *tempMenu = CCMenu::create(doneButton,backButtonMenuItem,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);

    
    this->userNameFunc();
   
}

#pragma mark - Requset to,Response from server 
void LWFOpponentSelectionScene::loadTheSelectedOpponentFromServer()
{
    
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToLoadSelectedOpponent(mail).c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFOpponentSelectionScene::onLoadingTheSelectedOpponentFromServerCompleted));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    labelStatusCode->setString("Waiting");

}

void LWFOpponentSelectionScene::onLoadingTheSelectedOpponentFromServerCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    
    if(message=="Success!!!")
    {
        LWFDataManager::sharedManager()->opponentID=document["userId"].GetString();
        //initially challeNGE id will be Null
        LWFDataManager::sharedManager()->currentChallengeId = "9999";
        LWFDataManager::sharedManager()->roundCount = 0;

        CCDirector::sharedDirector()->replaceScene(LWFGenreListScene::scene());
    }
    
    else if(message=="Challenge already exists with this user!!!")
    {
        labelStatusCode->setString(document["msg"].GetString());

    }
    else if (message=="You can't play against you!!!")
    {
        labelStatusCode->setString(document["msg"].GetString());
    }
    else if(message=="User doesn't exist!!!")
    {
          labelStatusCode->setString(document["msg"].GetString());
    }
  
  
    
}
#pragma MARK - EditBoxFunctions
void LWFOpponentSelectionScene::editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox)
{
    CCLog("editBox %p DidBegin !", editBox);
}

void LWFOpponentSelectionScene::editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox)
{
    CCLog("editBox %p DidEnd !", editBox);
}

void LWFOpponentSelectionScene::editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text)
{
    
    
    CCLog("editBox %p TextChanged, text: %s ", editBox, text.c_str());
    mail =userName->getText();
    
    
}

void LWFOpponentSelectionScene::editBoxReturn(cocos2d::extension::CCEditBox* editBox)
{
    CCLog("editBox %p was returned !");
    
}

#pragma mark - OnClickOfUserNameFunc
void LWFOpponentSelectionScene::userNameFunc()
{
    CCSize editBoxSize = CCSizeMake(276,34);
    userName=cocos2d::extension::CCEditBox::create(editBoxSize,cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    userName->setPosition(ccp(250,254));        ;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	userName->setFont("Arial", 20);
#else
	userName->setFont("fonts/Paint Boy.ttf", 20);
#endif
    userName->setFontColor(ccRED);
    
    userName->setPlaceholderFontColor(ccWHITE);
    userName->setMaxLength(15);
    userName->setReturnType(cocos2d::extension::kKeyboardReturnTypeDone);
    userName->setDelegate(this);
    addChild(userName,2);
    
}

#pragma mark - DoneBtnFunc
void LWFOpponentSelectionScene::onClickOfDoneBtn()
{
     this->loadTheSelectedOpponentFromServer();
}

#pragma mark - backButonFunc
void LWFOpponentSelectionScene::goBackToGameProgressScreen()
{
    CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
}

#pragma mark - Destructor
LWFOpponentSelectionScene::~LWFOpponentSelectionScene()
{
    
}
