//
//  LWFOpponentSelectionScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 11/07/13.
//
//

#ifndef __LyricsWithFriends__LWFOpponentSelectionScene__
#define __LyricsWithFriends__LWFOpponentSelectionScene__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

#include "rapidjson.h"
#include "filestream.h"
#include "document.h"
#include "httpiOS.h"

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

using namespace cocos2d;
using namespace cocos2d::extension;

class LWFOpponentSelectionScene:public CCLayer,public cocos2d::extension::CCEditBoxDelegate
{
public:
    
    LWFOpponentSelectionScene();
    ~LWFOpponentSelectionScene();
    
    static cocos2d::CCScene* scene();
    
    CCLabelTTF *labelStatusCode;
    
    std::string mail;
    
    //editBox
    cocos2d::extension::CCEditBox* userName;
    
    //editBox  functions(overridding delegate functions)
    virtual void editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox);
    virtual void editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox);
    virtual void editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text);
    virtual void editBoxReturn(cocos2d::extension::CCEditBox* editBox);

    //EMAIL
    void userNameFunc();
    void onClickOfDoneBtn();
    void goBackToGameProgressScreen();
    
    void loadTheSelectedOpponentFromServer();
    void onLoadingTheSelectedOpponentFromServerCompleted(cocos2d::CCNode *sender, void *data);
    
    CREATE_FUNC(LWFOpponentSelectionScene);
};

#endif /* defined(__LyricsWithFriends__LWFOpponentSelectionScene__) */
