//
//  LWFLoginScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#ifndef LyricsWithFriends_LWFLoginScene_h
#define LyricsWithFriends_LWFLoginScene_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient


class LWFLoginScene:public cocos2d::CCLayer,public cocos2d::extension::CCEditBoxDelegate
{
        
public:
         LWFLoginScene();
    ~LWFLoginScene();
    
    
    
    static cocos2d::CCScene* scene();
    
    //editBox related variables
    cocos2d::extension::CCEditBox* userName;
    cocos2d::extension::CCEditBox* passWord;
    
    
    //editBox  functions(overridding delegate functions)
    virtual void editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox);
    virtual void editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox);
    virtual void editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text);
    virtual void editBoxReturn(cocos2d::extension::CCEditBox* editBox);
    
    
    //functions
    void initialiseUI();
    void initialiseFunctions();
    void goBackToMainScene();
    void userNameFunc();
    void passwordFunc();
    void onClickOfLogin();
    void onClickOfCreateAccount();
    void loginFunc();
    
    
    //label
    void displayTheAlertLabel( rapidjson::Document & document,std::string msg);
   
    //response
    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);
     cocos2d::CCLabelTTF* labelStatusCode;

    //variables used to store userID,password
    std::string userId;
    std::string userPassword;
    
     //check For internet
    bool isNetWorkPresent;
    void checkForNetWork();
    void onNetworkCheckIsFinished(cocos2d::CCNode *sender, void *data);

    
    //variables
    cocos2d::CCMenuItemSprite *startGameButtonMenuItem;
    CCMenuItemSprite *loginButtonMenuItem ;
    CREATE_FUNC(LWFLoginScene);
    
};

#endif
