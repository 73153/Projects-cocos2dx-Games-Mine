//
//  LWFGenreListScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#include "LWFGenreListScene.h"
#include "LWFGameScene.h"
#include "LWFLoginScene.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFDataManager.h"
#include "LWFQuestionLoadingscene.h"
#include "LWFGameProgressScreen.h"

using namespace cocos2d;

CCScene* LWFGenreListScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFGenreListScene *layer = LWFGenreListScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}
LWFGenreListScene::LWFGenreListScene()
{
    
}

void LWFGenreListScene::onEnter()
{
    CCLayer::onEnter();
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GenreScene/genreSceneImages.plist");
    this->initialiseUI();
}

void LWFGenreListScene::onExit()
{
    CCLayer::onExit();
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFrameByName("GenreScene/genreSceneImages.plist");
}

void LWFGenreListScene::initialiseUI()
{
    CCSize winsize=CCDirector::sharedDirector()->getWinSize();
    
    CCSprite *topbarSpr = CCSprite::createWithSpriteFrameName("selct_genre_topbar.png");
    topbarSpr->setScaleY(1.1);
    topbarSpr->setPosition(ccp(160,461));
    this->addChild(topbarSpr);
    

    LWFDataManager::sharedManager()->canPressSkipButton=true;
    
    CCSprite *bgSpr = CCSprite::create("GenreScene/bg.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    CCSprite *popButtonNormalSpr = CCSprite::createWithSpriteFrameName("pop_btn.png");
    CCSprite *popButtonSelectedSpr = CCSprite::createWithSpriteFrameName("pop_btn_hvr.png");
    
    CCMenuItemSprite *popSongButton = CCMenuItemSprite::create(popButtonNormalSpr, popButtonSelectedSpr, this, menu_selector(LWFGenreListScene::popSongBtnAction));
    popSongButton->setPosition(CCPointMake(160,335));
    
    CCSprite *rockButtonNormalSpr = CCSprite::createWithSpriteFrameName("rock_btn.png");
    CCSprite *rockButtonSelectedSpr = CCSprite::createWithSpriteFrameName("rock_btn_hvr.png");
    
    CCMenuItemSprite *rockButton = CCMenuItemSprite::create(rockButtonNormalSpr, rockButtonSelectedSpr, this, menu_selector(LWFGenreListScene::rockSongBtnAction));
    rockButton->setPosition(CCPointMake(162,273));
    
    CCSprite *blueButtonNormalSpr = CCSprite::createWithSpriteFrameName("contry_btn.png");
    CCSprite *blueButtonSelectedSpr = CCSprite::createWithSpriteFrameName("contry_btn_HVR.png");
    
    
    CCMenuItemSprite *blueButton = CCMenuItemSprite::create(blueButtonNormalSpr, blueButtonSelectedSpr, this, menu_selector(LWFGenreListScene::contryBtnAction));
    blueButton->setPosition(CCPointMake(162,214));
    
    /*
     CCSprite *newAgeButtonButtonNormalSpr = CCSprite::createWithSpriteFrameName("nw_age_btn.png");
     CCSprite *newAgeButtonSelectedSpr = CCSprite::createWithSpriteFrameName("nw_age_btn_hvr.png");
     
     CCMenuItemSprite *newAgeButton = CCMenuItemSprite::create(newAgeButtonButtonNormalSpr, newAgeButtonSelectedSpr, this, menu_selector(LWFGenreListScene::rockSongBtnAction));
     newAgeButton->setPosition(CCPointMake(162,204));
     
     CCSprite *holidayButtonButtonNormalSpr = CCSprite::createWithSpriteFrameName("holiday_btn.png");
     CCSprite *holidayButtonSelectedSpr = CCSprite::createWithSpriteFrameName("holiday_btn_hvr.png");
     
     CCMenuItemSprite *holidayButton = CCMenuItemSprite::create(holidayButtonButtonNormalSpr, holidayButtonSelectedSpr, this, menu_selector(LWFGenreListScene::rockSongBtnAction));
     holidayButton->setPosition(CCPointMake(160,144));
     
     CCSprite *contryButtonButtonNormalSpr = CCSprite::createWithSpriteFrameName("contry_btn.png");
     CCSprite *contryButtonSelectedSpr = CCSprite::createWithSpriteFrameName("contry_btn_HVR.png");
     
     CCMenuItemSprite *contryButton = CCMenuItemSprite::create(contryButtonButtonNormalSpr, contryButtonSelectedSpr, this, menu_selector(LWFGenreListScene::rockSongBtnAction));
     contryButton->setPosition(CCPointMake(160,82));
     */
    
    CCSprite *backButtonNormalSpr = CCSprite::create("LoginPage/back_bt.png");
    CCSprite *backButtonSelectedSpr = CCSprite::create("LoginPage/back_bt.png");
    
    CCMenuItemSprite *backButton = CCMenuItemSprite::create(backButtonNormalSpr, backButtonSelectedSpr, this, menu_selector(LWFGenreListScene::backBtnAction));
    backButton->setPosition(CCPointMake(28,461));
    
    CCMenu *tempMenu = CCMenu::create(popSongButton,rockButton,blueButton,backButton, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
}

void LWFGenreListScene::popSongBtnAction()
{

  CCDirector::sharedDirector()->replaceScene(LWFQuestionLoadingscene::scene());
}

void LWFGenreListScene::backBtnAction()
{
    
  CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
    
}

void LWFGenreListScene::contryBtnAction()
{
       
      CCDirector::sharedDirector()->replaceScene(LWFQuestionLoadingscene::scene());
    //  CCDirector::sharedDirector()->replaceScene(LWFGameScene::scene());
    
}

void LWFGenreListScene::rockSongBtnAction()
{
    
    CCDirector::sharedDirector()->replaceScene(LWFQuestionLoadingscene::scene());
    //CCDirector::sharedDirector()->replaceScene(LWFGameScene::scene());
}


LWFGenreListScene::~LWFGenreListScene()
{
    
}
