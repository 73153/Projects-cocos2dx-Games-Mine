//
//  LWFGenreListScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 17/05/13.
//
//

#ifndef LyricsWithFriends_LWFGenreListScene_h
#define LyricsWithFriends_LWFGenreListScene_h

#include "cocos2d.h"
class LWFGenreListScene:public cocos2d::CCLayer
{
public:
    LWFGenreListScene();
    ~LWFGenreListScene();
    
    virtual void onEnter();
    virtual void onExit();
    
    void initialiseUI();
    
    void popSongBtnAction();
    void rockSongBtnAction();
    void backBtnAction();
    void contryBtnAction();
    void onClickOfLogOut();
    
    void replaceSceneOnSuccessfulLogOut(std::string msg);
    
    void onHttpRequestCompleted(cocos2d::CCNode *sender, void *data);
    cocos2d::CCLabelTTF* labelStatusCode;
    
    cocos2d::CCMenuItemSprite * logOutItem;
    
    
    static cocos2d::CCScene* scene();
    CREATE_FUNC(LWFGenreListScene);
    
};





#endif
