//
//  LWFChallenges.h
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#ifndef __LyricsWithFriends__LWFChallenges__
#define __LyricsWithFriends__LWFChallenges__

#include <iostream>

#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;


class LWFChallenges: public CCObject
{
public:
    LWFChallenges();
    ~LWFChallenges();
    
    std::string userName;
    std::string opponentName;
    std::string turnID;
    std::string roundNo;
    std::string opponentUserId;
    
};

#endif /* defined(__LyricsWithFriends__LWFChallenges__) */
