//
//  LWFCurrentGamesList.h
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#ifndef LyricsWithFriends_LWFCurrentGamesList_h
#define LyricsWithFriends_LWFCurrentGamesList_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

class LWFChallenge;
class LWFCurrentGamesList :public cocos2d::CCLayer,public cocos2d::extension::CCTableViewDataSource,public cocos2d::extension::CCTableViewDelegate


{
public:
   
    LWFCurrentGamesList();
    ~LWFCurrentGamesList();
    

    

    
    static cocos2d::CCScene* scene();
    
    CCLabelTTF *labelStatusCode;
    // CCArray *currentGamesArray;
    CCArray *tabelArray;
    
    CCArray *currentGamesArray;
    
    //request,response-ToLoadCurrentGame
    void requestToLoadCurrentGames();
    void afterCompletionOfLoadingCurrentGames(cocos2d::CCNode *sender, void *data);
    //    void afterCompletionOfGettingChallenge(cocos2d::CCNode *sender, void *data);
    
    //func used to check whose turn
    void checkTheTurnFunc();
    
    void addingChallengeList();
    void onClickOfChallenge(CCObject *sender);
    //button
    void backBtnAction();
    
    //label
    void displayTheAlertLabel( rapidjson::Document & document,std::string msg);
    
    void addingTheContentsBasedOnTurn();
    
    
    //Tabel cell
    
    virtual cocos2d::CCSize tableCellSizeForIndex(CCTableView *table, unsigned int idx);
    virtual cocos2d::extension::CCTableViewCell* tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(cocos2d::extension::CCTableView *table);
    void tableCellTouched(cocos2d::extension::CCTableView *table, cocos2d::extension::CCTableViewCell *cell);
    
    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view) {
    };
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view) {
    }
    
    CREATE_FUNC(LWFCurrentGamesList);
};

#include "LWFGame.h"
#include "LWFDataManager.h"
#include "LWFSelectedChallengeScreen.h"

class LWFGame;

#pragma mark - FacebookFriendCell functions

class CurrentGamesCell:public CCTableViewCell
{
    bool minvite;
    
public:
    std::string challengeid;
    LWFGame *game;
    bool isCellSpace = false;
    
    static CurrentGamesCell * create(LWFGame *inGame)
    {
        CurrentGamesCell * facebookfriend = new CurrentGamesCell;
        facebookfriend->init(inGame);
        
        facebookfriend->autorelease();
        return facebookfriend;
    }
    
    void goToChallenge()
    {
        if(this->isCellSpace)
        {
            return;
        }

        LWFDataManager::sharedManager()->currentChallengeId = challengeid;
        CCDirector::sharedDirector()->replaceScene(LWFSelectedChallengeScreen::scene());
    }
    
    bool init(LWFGame *inGame)
    {
        if(inGame->isSpace)
        {
            this->isCellSpace = true;
            
            CCLabelTTF * label = CCLabelTTF::create(inGame->gameProgressLabel.c_str(), "Helvetica", 20);
            this->addChild(label);
            label->setColor(ccWHITE);
            label->setAnchorPoint(CCPointZero);
            label->setPosition(ccp(10,10));

            return true;
        }
                
        CCSprite * sprite = CCSprite::create("selectedChallengePage/colm1.png");
        sprite->setAnchorPoint(CCPointZero);
        sprite->setPosition(CCPointZero);
        this->addChild(sprite);
        this->setContentSize(sprite->getContentSize());
        
        challengeid=inGame->ChallengeID;
        
        CCLabelTTF * labelttf = CCLabelTTF::create(inGame->name.c_str(), "Helvetica", 20);
        this->addChild(labelttf);
        labelttf->setColor(ccWHITE);
        labelttf->setAnchorPoint(CCPointZero);
        
        labelttf->setPosition(ccp(10,10));
        
        return true;
    }
};


#endif
