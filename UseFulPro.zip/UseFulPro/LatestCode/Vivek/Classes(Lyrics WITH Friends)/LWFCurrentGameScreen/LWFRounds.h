//
//  LWFRounds.h
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#ifndef __LyricsWithFriends__LWFRounds__
#define __LyricsWithFriends__LWFRounds__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;


class LWFRounds: public CCObject
{
public:
    LWFRounds();
    ~LWFRounds();
    
    std::string userScore;
    std::string opponentScore;
    
};


#endif /* defined(__LyricsWithFriends__LWFRounds__) */
