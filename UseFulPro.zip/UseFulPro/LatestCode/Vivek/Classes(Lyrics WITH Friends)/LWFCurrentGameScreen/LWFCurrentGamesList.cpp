//
//  LWFCurrentGamesList.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#include "LWFCurrentGamesList.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFDataManager.h"
#include "LWFGameProgressScreen.h"
#include "LWFChallenge.h"
#include "LWFGameScene.h"
#include "LWFQuestionLoadingscene.h"
#include "LWFGame.h"
#include "LWFChallenges.h"
#include "LWFRounds.h"
#include "LWFSelectedChallengeScreen.h"




CCScene*  LWFCurrentGamesList::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFCurrentGamesList *layer =  LWFCurrentGamesList::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFCurrentGamesList:: LWFCurrentGamesList()
{
    //Load the user Id
    std::string userID= CCUserDefault::sharedUserDefault()->getStringForKey("UserId");
    CCLog("userID is %s",userID.c_str());
    LWFDataManager::sharedManager()->currentUserID =userID;

    CCSize winsize =CCDirector::sharedDirector()->getWinSize();
    
    currentGamesArray = CCArray::create();
    currentGamesArray->retain();
    
    tabelArray=CCArray::create();
    tabelArray->retain();

    CCSprite *bgSpr = CCSprite::create("MainPage/CreateGamelogin.png");
    bgSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(bgSpr,-1);
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,250));
    this->addChild(labelStatusCode,20);
    
    CCSprite *backButtonButtonNormalSpr = CCSprite::create("LoginPage/back_bt.png");
    CCSprite *backButtonButtonSelectedSpr = CCSprite::create("LoginPage/back_bt.png");
    
    CCMenuItemSprite *backButton = CCMenuItemSprite::create(backButtonButtonNormalSpr, backButtonButtonSelectedSpr, this, menu_selector(LWFCurrentGamesList::backBtnAction));
    backButton->setPosition(CCPointMake(28,458));
    
    CCMenu *tempMenu = CCMenu::create(backButton, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
  
    
    this->requestToLoadCurrentGames();
    
    
}

#pragma mark - LoadingTheCurrentGames
void  LWFCurrentGamesList::requestToLoadCurrentGames()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToLoadCurrentGames().c_str());
   CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFCurrentGamesList::afterCompletionOfLoadingCurrentGames));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    
    labelStatusCode->setString("Waiting");
}

#pragma mark - afterCompletingLoadingTheCurrentGames
void LWFCurrentGamesList::afterCompletionOfLoadingCurrentGames(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    
        if(document.HasMember("users"))
        {
               std::string alert=document["users"].GetString();
              this->displayTheAlertLabel(document,alert);
        }
    if(document.HasMember("games"))
    {
        labelStatusCode->setVisible(false);
        
        for(rapidjson::SizeType i=0;i<document["games"].Size();i++)
        {
            const rapidjson::Value &game=document["games"][i];

  
            std::string name=game["name"].GetString();
            std::string challengeId=game["challengeId"].GetString();
            std::string turnID=game["turnId"].GetString();
            std::string userID=game["userId"].GetString();
            std::string challengeStatus=game["challengeStatus"].GetString();
        
            
            LWFGame *currentGame =new LWFGame();
            currentGame->ChallengeID=challengeId;
            currentGame->turnID=turnID;
            currentGame->userID=userID;
            currentGame->name=name;
            currentGame->challengeStatus=challengeStatus;
            currentGame->isSpace=false;
            //placing current game contents to the array
            this->currentGamesArray->addObject(currentGame);
            }

    }
    
    
    if(this->currentGamesArray->count()==0)
    {
        
        labelStatusCode->setString("No Challenges");
    }
    else
    {
        this->addingTheContentsBasedOnTurn();

        //Tabelview
        CCTableView *tableView = CCTableView::create(this, CCSizeMake(480,320));
        
        tableView->setDirection(cocos2d::extension::kCCScrollViewDirectionVertical);
        tableView->setPosition(ccp(0,0));
        tableView->setDataSource(this);
        tableView->setVerticalFillOrder(cocos2d::extension::kCCTableViewFillTopDown);
        tableView->setDelegate(this);
        this->addChild(tableView);
        tableView->setTag(1);
        

     
          }


}

#pragma mark - addingTheContentsBasedOnTurn
void LWFCurrentGamesList::addingTheContentsBasedOnTurn()
{

     //Add USER TURN objects to table array
    
    LWFGame *spaceGame= new LWFGame();
    spaceGame->isSpace=true;
    spaceGame->gameProgressLabel="USER TURN";
    tabelArray->addObject(spaceGame);

    
    for(int i=0;i<this->currentGamesArray->count();i++)
    {
        LWFGame *game =(LWFGame*)this->currentGamesArray->objectAtIndex(i);
        
        if(LWFDataManager::sharedManager()->currentUserID==game->turnID)
        {
            CCLog("%s=LWFDataManager::sharedManager()->currentUserID",LWFDataManager::sharedManager()->currentUserID.c_str());
            CCLog("%s=game->turnID",game->turnID.c_str());

            if(game->challengeStatus=="2")
            {
                tabelArray->addObject(game);
            }
        }
    }
    
    CCLOG("current table array count is %d",tabelArray->count());
    
    //Add OPPONENT TURN objects to table array
    
    spaceGame= new LWFGame();
    spaceGame->isSpace=true;
    tabelArray->addObject(spaceGame);
    spaceGame->gameProgressLabel="OPPONENT TURN";

    
    for(int i=0;i<currentGamesArray->count();i++)
    {
    
        LWFGame *game =(LWFGame*)currentGamesArray->objectAtIndex(i);
        CCLog("%s=LWFDataManager::sharedManager()->currentUserID",LWFDataManager::sharedManager()->currentUserID.c_str());
        CCLog("%s=game->turnID",game->turnID.c_str());
        if(LWFDataManager::sharedManager()->currentUserID!=game->turnID)
        {
            if(game->challengeStatus=="2")
            {
                tabelArray->addObject(game);
            }
        }
    }
    
    
    //Add Game over objects to table array
    spaceGame= new LWFGame();
    spaceGame->isSpace=true;
    tabelArray->addObject(spaceGame);
    spaceGame->gameProgressLabel="GAME OVER";

    
    for(int i=0;i<currentGamesArray->count();i++)
    {
        LWFGame *game =(LWFGame*)currentGamesArray->objectAtIndex(i);
        if(game->challengeStatus=="1")
        {
                tabelArray->addObject(game);
        }        
    }
    
    
    CCLOG("Table Array count  %d",tabelArray->count());
}


#pragma mark - backButton
void LWFCurrentGamesList::backBtnAction()
{
    CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
}


#pragma mark - alertMsg
void LWFCurrentGamesList::displayTheAlertLabel(rapidjson::Document & doc,std::string msg)
{
    labelStatusCode->setString("No Challenges");
   
}

#pragma mark - Table View functions

void LWFCurrentGamesList::tableCellTouched(cocos2d::extension::CCTableView *table, cocos2d::extension::CCTableViewCell *cell)
{
    CurrentGamesCell *cell1= (CurrentGamesCell*)cell ;
    
    CCScaleTo *scaleAction1=CCScaleTo::create(0.05, 0.95);
    CCScaleTo *scaleAction2=CCScaleTo::create(0.05, 1);
    CCSequence *seq=CCSequence::createWithTwoActions(scaleAction1, scaleAction2);
    
    cell1->runAction(seq);
    cell1->goToChallenge();
}

CCSize LWFCurrentGamesList::tableCellSizeForIndex(CCTableView *table, unsigned int idx)
{
    LWFGame *game =(LWFGame*)tabelArray->objectAtIndex(idx);
    if(game->isSpace)
    {
            return CCSizeMake(480, 100);
    }
    else
    {
            return CCSizeMake(480, 69);
    }
}

CCTableViewCell* LWFCurrentGamesList::tableCellAtIndex(cocos2d::extension::CCTableView *table, unsigned int idx)
{
    LWFGame *game =(LWFGame*)tabelArray->objectAtIndex(idx);
    CurrentGamesCell *cell;
    cell  = CurrentGamesCell::create(game);
   
       
    return cell;
}

unsigned int LWFCurrentGamesList::numberOfCellsInTableView(CCTableView *table)
{
      return tabelArray->count();
}


#pragma mark - destructor
LWFCurrentGamesList::~LWFCurrentGamesList()
{
    CC_SAFE_RELEASE_NULL(currentGamesArray);
    CC_SAFE_RELEASE_NULL(tabelArray);
   
}