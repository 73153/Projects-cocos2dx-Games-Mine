//
// LWFChallenge.h
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#ifndef LyricsWithFriends_LWFCurrentGameCustomClass_h
#define LyricsWithFriends_LWFCurrentGameCustomClass_h

#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;


class LWFChallenge: public CCObject
{
   public:
   
   LWFChallenge();
    ~LWFChallenge();
    
    std::string difficultyLevel;
    std::string challengeId;
    std::string previousChallengeId;
    std::string turnId;
    std::string winCount;
    std::string loseCount;
    std::string challengeStatus;
    std::string userStatus;
    std:: string opponentStaus;
    std::string wonBy;
    std::string userId;
    std::string opponentName;
    int score;
    
   
    
};


#endif
