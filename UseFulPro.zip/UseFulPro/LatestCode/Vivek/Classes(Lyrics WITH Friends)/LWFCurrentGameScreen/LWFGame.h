//
//  LWFGames.h
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#ifndef __LyricsWithFriends__LWFGame__
#define __LyricsWithFriends__LWFGame__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;

class LWFGame: public CCObject
{
public:
    
    LWFGame();
    ~LWFGame();
    
    std::string ChallengeID;
    std::string turnID;
    std::string userID;
    std::string name;
    std::string challengeStatus;
    std::string gameProgressLabel;

    
    bool isSpace;
    
    
    
};



#endif /* defined(__LyricsWithFriends__LWFGames__) */
