//
//  LMObjectiveC.m
//  LostMonster
//
//  Created by Krithik B on 9/4/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//

#import "LWFObjectiveC.h"

#import <MediaPlayer/MediaPlayer.h>



#include "SimpleAudioEngine.h"
#include "cocos2d.h"


using namespace cocos2d;

@implementation LWFObjectiveC

AVAudioPlayer *sharedPlayer;

#pragma mark - Play Video


//+ (void)playVideo:(int)iStateAfterPlay fullscreen:(int)iFullScreen file:(NSString*)strFilennameNoExtension fileExtension:(NSString*)strExtension withTutorialLblHeading:(NSString*)inTutorialHeading
+ (void)playVideo:(int)iStateAfterPlay fullscreen:(int)iFullScreen file:(NSString*)strFilennameNoExtension;
{
    //  CCLOG("%s",strFilennameNoExtension);

    //Play audio here
    
  NSString *nsurlstring=[NSString stringWithFormat:@"%@",strFilennameNoExtension,Nil];
    NSURL *nsurl = [NSURL URLWithString:nsurlstring];
//    
  dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//    
    dispatch_async(queue, ^{
        if(sharedPlayer!=NULL)
        {
            [sharedPlayer.delegate release];
            [sharedPlayer stop];
            [sharedPlayer release];
        }
        
        NSURLRequest * urlrequest = [NSURLRequest requestWithURL:nsurl];
        NSError * error=NULL;
        NSData * data=[NSURLConnection sendSynchronousRequest:urlrequest returningResponse:NULL error:&error];
        

        NSLog(@"error  IS %@",error);
        if(!error)
        {
            CCNotificationCenter::sharedNotificationCenter()->postNotification("songSuccessfullyDownloaded", (CCObject*)1);
            
            sharedPlayer=[[AVAudioPlayer alloc] initWithData:data error:&error];
            [sharedPlayer prepareToPlay];
        }
        else
        {
             CCNotificationCenter::sharedNotificationCenter()->postNotification("songSuccessfullyDownloaded", (CCObject*)0);
        }
        
    });

}


+(void)playSong
{
     [sharedPlayer play];
}

+(void)stopSong
{
    [sharedPlayer stop];
}

#pragma mark - Dealloc

- (void)dealloc
{
    [super dealloc];
}

@end
