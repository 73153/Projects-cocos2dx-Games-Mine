//
//  LMObjectiveC.h
//  LostMonster
//
//  Created by Krithik B on 9/4/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "cocos2d.h"
#import <AVFoundation/AVFoundation.h>

//This Class handles the objective c Functions !!!

@interface LWFObjectiveC : NSObject
{
 

       
    
}

//Video
//+(void)playVideo:(int)iStateAfterPlay fullscreen:(int)iFullScreen file:(NSString*)strFilennameNoExtension fileExtension:(NSString*)strExtension withTutorialLblHeading:(NSString*)inTutorialHeading;

+(void)playVideo:(int)iStateAfterPlay fullscreen:(int)iFullScreen file:(NSString*)strFilennameNoExtension;
+(void)playSong;
+(void)stopSong;

@end
