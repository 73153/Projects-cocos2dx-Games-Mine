//
//  LWFRegisterScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 12/06/13.
//
//


#include "LWFRegisterScene.h"
#include "LWFGenreListScene.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFLoginScene.h"
#include "LWFGameProgressScreen.h"
#include "LWFDataManager.h"

#include "cocos2d.h"
using namespace cocos2d;

CCScene* LWFRegisterScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFRegisterScene *layer = LWFRegisterScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma MARK - constructor
LWFRegisterScene::LWFRegisterScene()
{
    this->intialiseUI();
    this->initialiseFunctions();
     
   
}

#pragma mark - initialiseUI
void LWFRegisterScene::intialiseUI()
{
    CCSize winSize=CCDirector::sharedDirector()->getWinSize();
    
    textFieldIndicationLbl = CCLabelTTF::create(" ", "", 30);
    textFieldIndicationLbl->setPosition(ccp(10,10));
    addChild(textFieldIndicationLbl);
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20);
    labelStatusCode->setPosition(ccp(170 ,350));
    addChild(labelStatusCode,20);
    
    CCSprite *bgSpr = CCSprite::create("LoginPage/Username-Login.png");
    bgSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->addChild(bgSpr,-1);
    
    CCSprite *topbarSpr = CCSprite::create("RegistrationPage/topbarRegistration.png");
    topbarSpr->setPosition(ccp(160,458));
    this->addChild(topbarSpr,2);
    
    CCSprite *mailIDTextFieldSpr = CCSprite::create("RegistrationPage/email.png");
    mailIDTextFieldSpr->setPosition(ccp(160,277));
    this->addChild(mailIDTextFieldSpr);
    
    CCSprite *userNameFieldSpr = CCSprite::create("RegistrationPage/name.png");
    userNameFieldSpr->setPosition(ccp(160,309));
    this->addChild(userNameFieldSpr);
    
    CCSprite *passWordTextFieldSpr = CCSprite::create("RegistrationPage/password.png");
    passWordTextFieldSpr->setPosition(ccp(160,243));
    this->addChild(passWordTextFieldSpr);
    
    CCSprite *reenterpassWordTextFieldSpr = CCSprite::create("RegistrationPage/confirm.png");
    reenterpassWordTextFieldSpr->setPosition(ccp(160,209));
    this->addChild(reenterpassWordTextFieldSpr);
    
    
    CCSprite *bottombarSpr = CCSprite::create("RegistrationPage/bottombar.png");
    bottombarSpr->setPosition(ccp(160,26));
    this->addChild(bottombarSpr,1);
    
    
     
    CCSprite *backButtonNormalSpr = CCSprite::create("RegistrationPage/back_bt.png");
    CCSprite *backButtonSelectedSpr = CCSprite::create("RegistrationPage/back_bt.png");
    
    CCMenuItemSprite *backButtonMenuItem = CCMenuItemSprite::create(backButtonNormalSpr, backButtonSelectedSpr, this, menu_selector(LWFRegisterScene::goBackToLoginScene));
    backButtonMenuItem->setPosition(CCPointMake(28,458));

    CCSprite *registerButtonNormalSpr = CCSprite::create("RegistrationPage/registration.png");
    CCSprite *registerButtonSelectedSpr = CCSprite::create("RegistrationPage/registration.png");
    
    registerItem = CCMenuItemSprite::create(registerButtonNormalSpr, registerButtonSelectedSpr, this, menu_selector(LWFRegisterScene::onClickOfRegisterButton));
    registerItem->setPosition(CCPointMake(164,132));
    registerItem->setEnabled(true);
    
    
    CCMenu *tempMenu = CCMenu::create(registerItem,backButtonMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);

    
    
}



#pragma MARK - EditBoxFunctions
void LWFRegisterScene::editBoxEditingDidBegin(CCEditBox* editBox)
{
    CCLog("editBox %p DidBegin !", editBox);
}

void LWFRegisterScene::editBoxEditingDidEnd(CCEditBox* editBox)
{
    CCLog("editBox %p DidEnd !", editBox);
}

void LWFRegisterScene::editBoxTextChanged(CCEditBox* editBox, const std::string& text)
{
    CCLog("editBox %p TextChanged, text: %s ", editBox, text.c_str());
    
    enteredUserName=userNameTextField->getText();
    enteredEmailId=mailIDTextField->getText();
    enteredPassword=passWordTextField->getText();
    reenteredPassword=reEnterPasswordTextField->getText();
     
}

void LWFRegisterScene::editBoxReturn(CCEditBox* editBox)
{
    CCLog("editBox %p was returned !");
    
    if (mailIDTextField == editBox)
    {
        // textFieldIndicationLbl->setString("Name EditBox return !");
    }
    else if (passWordTextField == editBox)
    {
        // startGameButtonMenuItem->setEnabled(true);
        //  textFieldIndicationLbl->setString("passWordTextField EditBox return !");
    }
}

#pragma mark - backButtonFunc
void LWFRegisterScene::goBackToLoginScene()
{
    CCDirector::sharedDirector()->replaceScene(LWFLoginScene::scene());
}

#pragma mark - initialiseFunctions
void LWFRegisterScene::initialiseFunctions()
{
    this-> mailIDTextFieldFunc();
    this-> passWordTextFieldFunc();
    this->reenterPassWordTextFieldFunc();
    this->userNameTextFieldFunc();
}


#pragma mark - textFIELD
void LWFRegisterScene::mailIDTextFieldFunc()
{
    CCSize editBoxSize = CCSizeMake(276,34);
    mailIDTextField=cocos2d::extension::CCEditBox::create(editBoxSize,cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    mailIDTextField->setPosition(ccp(232,277));        ;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	mailIDTextField->setFont("Arial", 20);
#else
	mailIDTextField->setFont("fonts/Paint Boy.ttf", 20);
#endif
    mailIDTextField->setFontColor(ccRED);
    
    mailIDTextField->setPlaceholderFontColor(ccWHITE);
    mailIDTextField->setMaxLength(30);
    mailIDTextField->setReturnType(cocos2d::extension::kKeyboardReturnTypeDone);
    mailIDTextField->setDelegate(this);
    addChild(mailIDTextField,2);

}

void LWFRegisterScene::passWordTextFieldFunc()
{
    passWordTextField = cocos2d::extension::CCEditBox::create(CCSize(276,34), cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    passWordTextField->setPosition(ccp(245,243));
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	passWordTextField->setFont("American Typewriter", 20);
#else
	passWordTextField->setFont("fonts/American Typewriter.ttf", 20);
#endif
    passWordTextField->setFontColor(ccGREEN);
    
    passWordTextField->setMaxLength(10);
    passWordTextField->setInputFlag(cocos2d::extension::kEditBoxInputFlagPassword);
    passWordTextField->setInputMode(cocos2d::extension::kEditBoxInputModeSingleLine);
    passWordTextField->setDelegate(this);
    addChild(passWordTextField,2);

}

void LWFRegisterScene::reenterPassWordTextFieldFunc()
{
    reEnterPasswordTextField = cocos2d::extension::CCEditBox::create(CCSize(276,34), cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    reEnterPasswordTextField->setPosition(ccp(245,209));
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	reEnterPasswordTextField->setFont("American Typewriter", 20);
#else
	reEnterPasswordTextField->setFont("fonts/American Typewriter.ttf", 20);
#endif
    reEnterPasswordTextField->setFontColor(ccGREEN);
    
    reEnterPasswordTextField->setMaxLength(10);
    reEnterPasswordTextField->setInputFlag(cocos2d::extension::kEditBoxInputFlagPassword);
    reEnterPasswordTextField->setInputMode(cocos2d::extension::kEditBoxInputModeSingleLine);
    reEnterPasswordTextField->setDelegate(this);
    addChild(reEnterPasswordTextField,2);
    
}

void LWFRegisterScene::userNameTextFieldFunc()
{
    CCSize editBoxSize = CCSizeMake(276,34);
    userNameTextField=cocos2d::extension::CCEditBox::create(editBoxSize,cocos2d::extension::CCScale9Sprite::create("LoginPage/whitetab-1.png"));
    userNameTextField->setPosition(ccp(213,309));        ;
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	userNameTextField->setFont("Arial", 20);
#else
	userNameTextField->setFont("fonts/Paint Boy.ttf", 20);
#endif
    userNameTextField->setFontColor(ccRED);
    
    userNameTextField->setPlaceholderFontColor(ccWHITE);
    userNameTextField->setMaxLength(15);
    userNameTextField->setReturnType(cocos2d::extension::kKeyboardReturnTypeDone);
    userNameTextField->setDelegate(this);
    addChild(userNameTextField,2);
}

#pragma mark - Registration
void LWFRegisterScene::onClickOfRegisterButton()
{
    registerItem->setEnabled(false);
    this->checkForNetWork();
}
void LWFRegisterScene::registerButtonFunc()
{
    if(this->isNetWorkPresent)
    {
   if(strcmp(enteredPassword.c_str(), reenteredPassword.c_str())==0)
   {
       std::string type="signup";
    LWFHttpRequest* request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createRegistrationURL(enteredUserName,enteredEmailId,enteredPassword,type).c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFRegisterScene::onHttpRequestCompleted));
    request->setTag("GET test1");
    LWFHttpClient::getInstance()->send(request);
    request->release();
    labelStatusCode->setString("waiting...");
   }
    else
    {
        labelStatusCode->setString("password not matched");
          registerItem->setEnabled(true);
    }
    }
    
    
}

void LWFRegisterScene::onHttpRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning()) {
      return;
   }
   
   rapidjson::Document document;
   
   LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
   
  
    std::string message=document["msg"].GetString();
   
    if(document.HasMember("user"))
    {
        LWFDataManager::sharedManager()->currentUserID=document["user"]["userId"].GetString();
        CCUserDefault::sharedUserDefault()->setStringForKey("UserId", document["user"]["userId"].GetString());

    }
    

    
   CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
  
      this->displayAlert(document,message);
    
}

#pragma mark -checkForNetWork

void LWFRegisterScene::checkForNetWork()
{
    LWFHttpRequest* request = new    LWFHttpRequest();
    
    std::string url="http://google.com";
    request->setUrl(url.c_str());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFRegisterScene::onNetworkCheckIsFinished));
    // optional fields
    request->setTag("Network test");
    LWFHttpClient::getInstance()->send(request);
    
    // don't forget to release it, pair to new
    request->release();
    
}
void LWFRegisterScene::onNetworkCheckIsFinished(cocos2d::CCNode *sender, void *data)
{
    //using namespace httpios;
    //   DLOG("");
    if (!this->isRunning()) {
        return;
    }
    
    
    
    LWFHttpResponse *response = (LWFHttpResponse*)data;
    if(!response->isSucceed())
    {
        isNetWorkPresent=false;
        labelStatusCode->setString("Network Error");
    }
    else
    {
        isNetWorkPresent=true;
        this->registerButtonFunc();
    }
}




#pragma mark - displayAlert
void LWFRegisterScene::displayAlert(rapidjson::Document &document, std::string alert)
{
 
    std::string successMsg="User signed in successfully";
       
    if(strcmp(alert.c_str(), successMsg.c_str())==0)
    {
        std::string api =document ["user"]["APIKey"].GetString();
        CCUserDefault::sharedUserDefault()->setStringForKey("APIKey", api);

        cocos2d::CCUserDefault::sharedUserDefault()->flush();

        CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
    }
    else
    {
        labelStatusCode->setString(alert.c_str());
        registerItem->setEnabled(true);
    }
    

    
}

#pragma MARK - destructor
LWFRegisterScene::~LWFRegisterScene()
{
    
}