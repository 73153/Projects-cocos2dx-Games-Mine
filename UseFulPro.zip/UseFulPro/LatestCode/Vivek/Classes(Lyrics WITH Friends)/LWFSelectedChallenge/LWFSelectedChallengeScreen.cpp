//
//  LWFSelectedChallengeScreen.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#include "LWFSelectedChallengeScreen.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFRounds.h"
#include "LWFChallenges.h"
#include "LWFDataManager.h"
#include "LWFGenreListScene.h"
#include "LWFCurrentGamesList.h"


CCScene*  LWFSelectedChallengeScreen::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    LWFSelectedChallengeScreen *layer =  LWFSelectedChallengeScreen::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
LWFSelectedChallengeScreen:: LWFSelectedChallengeScreen()
{
    //Load the user Id
    std::string userID= CCUserDefault::sharedUserDefault()->getStringForKey("UserId");
    LWFDataManager::sharedManager()->currentUserID =userID;
    
    roundArray=CCArray::create();
    roundArray->retain();
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,250));
    this->addChild(labelStatusCode,20);
    
    
    userNameLabel = CCLabelTTF::create("", "Marker Felt", 20,CCSize(130,100),kCCTextAlignmentCenter);
    userNameLabel->setPosition(ccp(80,235));
    this->addChild(userNameLabel,1);
    
    opponentNameLabel = CCLabelTTF::create("", "Marker Felt", 20,CCSize(130,100),kCCTextAlignmentCenter);
    opponentNameLabel->setPosition(ccp(250,235));
    this->addChild(opponentNameLabel,1);
    
    CCSprite * roundDetailBg = CCSprite::create("selectedChallengePage/round-detail.png");
    roundDetailBg->setPosition(ccp(160,240 ));
    this->addChild(roundDetailBg,-1);
    
    
    CCSprite *backButtonNormalSpr = CCSprite::create("LoginPage/back_bt.png");
    CCSprite *backButtonSelectedSpr = CCSprite::create("LoginPage/back_bt.png");
    
    
    CCMenuItemSprite   *backBtn = CCMenuItemSprite::create(backButtonNormalSpr, backButtonSelectedSpr, this, menu_selector(LWFSelectedChallengeScreen::backBtnFunc));
    backBtn->setPosition(CCPointMake(28,458));
    
    
    CCSprite *playButtonNormalSpr = CCSprite::create("selectedChallengePage/play-bt.png");
    CCSprite *playButtonSelectedSpr = CCSprite::create("selectedChallengePage/play-bt.png");
    
    
    playButton = CCMenuItemSprite::create(playButtonNormalSpr, playButtonSelectedSpr, this, menu_selector(LWFSelectedChallengeScreen::playButtonFunc));
    playButton->setPosition(CCPointMake(160,40));
    playButton->setVisible(false);
    //playButtonMenuItem->setEnabled(true);
    
    CCSprite *doneButtonNormalSpr = CCSprite::create("DonePage/done-bt.png");
    CCSprite *doneButtonSelectedSpr = CCSprite::create("DonePage/done-bt.png");
    
    
    doneButton = CCMenuItemSprite::create(doneButtonNormalSpr, doneButtonSelectedSpr, this, menu_selector(LWFSelectedChallengeScreen::doneButtonFunc));
    doneButton->setPosition(CCPointMake(160,40));
    doneButton->setVisible(false);
    
    CCMenu *tempMenu = CCMenu::create(playButton,doneButton,backBtn,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
    this->requestToLoadSelectedChallengeDetails();
}



#pragma mark - Request,Response
void LWFSelectedChallengeScreen::requestToLoadSelectedChallengeDetails()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToGetChallenge().c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFSelectedChallengeScreen::afterCompletionOfLoadingSelectedChallengeDetails));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    labelStatusCode->setString("Waiting");
}

void LWFSelectedChallengeScreen::afterCompletionOfLoadingSelectedChallengeDetails(cocos2d::CCNode *sender, void *data)
{
    
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    
    challenge = new LWFChallenges();
    
    
    if(message=="Success")
    {
        labelStatusCode->setVisible(false);
        //userName
        if(document.HasMember("userName"))
        {
            std::string userName=document["userName"].GetString();
            challenge->userName=userName;
            
        }
        if(document.HasMember("opponentName"))
        {
            //opponentName
            std::string opponentName=document["opponentName"].GetString();
            challenge->opponentName=opponentName;
            
        }
        
        std::string userID =document["opponentUserId"].GetString();
        challenge->opponentUserId=userID;
        LWFDataManager::sharedManager()->opponentID=   challenge->opponentUserId;
        CCLOG("oppentID=%s",LWFDataManager::sharedManager()->opponentID.c_str());
        //CCLOG("opponentid=%s", challenge->userID.c_str());
        
        
        std::string turnID=document["turnId"].GetString();
        challenge->turnID=turnID;
        
        
        //used to keep trcak of rounds of a player
        LWFDataManager::sharedManager()->roundCount=document["round"].GetInt();
        CCLOG("roundCount=%d",LWFDataManager::sharedManager()->roundCount);
        
        //used to print user,opponentName
        char a[500]={};
        sprintf(a, "%s", challenge->userName.c_str());
        userNameLabel->setString(a);
        
        char b[500]={};
        sprintf(b, "%s",   challenge->opponentName.c_str());
        opponentNameLabel->setString(b);
        
        
        CCLOG("userName=%s", challenge->userName.c_str());
        CCLOG("opponentName=%s",challenge->opponentName.c_str());
        
        
    }
    //accessing scores from array
    if (document.HasMember("rounds"))
    {
        for(rapidjson::SizeType i=0;i<document["rounds"].Size();i++)
        {
            const rapidjson::Value &game= document["rounds"][i];
            
            LWFRounds *round=new LWFRounds();
            if(game.HasMember("opponentScore"))
            {
                std::string opponentScore=game["opponentScore"].GetString();
                round->opponentScore=opponentScore;
            }
            
            //If opponent has not played the round yet
            if(!game.HasMember("opponentScore"))
            {
                round->opponentScore = "Empty";
                CCLOG("No Record of Opponenet score so its thr turn");
            }
            if(game.HasMember("userScore"))
            {
                std::string userScore=game["userScore"].GetString();
                round->userScore=userScore;
            }
            if(!game.HasMember("userScore"))
            {
               round->userScore="Empty";
                CCLOG("No Record of User score so its our turn");
            }
            //placing the score contents to the array
            roundArray->addObject(round);
            
        }
    }
    
    //func used to access result from from
    this->getTheContentsFromRoundArray();
    
}

#pragma mark - backBtnFunc
void LWFSelectedChallengeScreen::backBtnFunc()
{
    CCDirector::sharedDirector()->replaceScene(LWFCurrentGamesList::scene());
}
#pragma mark - playButtonFunc
void LWFSelectedChallengeScreen::playButtonFunc()
{
    //if the turn is users then replace scene to genrescene
    CCDirector::sharedDirector()->replaceScene(LWFGenreListScene::scene());
}

#pragma mark - doneButtonFunc
void LWFSelectedChallengeScreen::doneButtonFunc()
{
    //if the turn is opponents then replace scene to currentGame
    CCDirector::sharedDirector()->replaceScene(LWFCurrentGamesList::scene());
}

#pragma mark - gettingTheContentsFromArray
void LWFSelectedChallengeScreen::getTheContentsFromRoundArray()
{
    int userScoreXpos=80;
    int opponentScoreXpos=230;
    int yPos=195;
    
    int count=0;
    
    CCLOG("%d=roundArray",roundArray->count());
    for(int i=0;i<roundArray->count();i++)
    {
        count++;
        LWFRounds *round =(LWFRounds*)roundArray->objectAtIndex(i);
        
        userScoreLabel = CCLabelTTF::create("", "Arial",17);
        this->addChild(userScoreLabel,1);
        
        opponentScoreLabel = CCLabelTTF::create("", "Arial",17);
        this->addChild(opponentScoreLabel,1);
        
        
        
        CCString *oppnentScoreval=CCString::createWithFormat("%s",round->opponentScore.c_str());
        LWFDataManager::sharedManager()->opponentScore= oppnentScoreval->intValue();
        
        
        CCString *userScore =CCString::createWithFormat("%s",round->userScore.c_str());
        LWFDataManager::sharedManager()->userScore=userScore->intValue();
        
        //opponentScore
        char a[100]={};
        sprintf(a,"%d",    LWFDataManager::sharedManager()->opponentScore);
        opponentScoreLabel->setString(a);
        
        //userScore
        char b[100]={};
        sprintf(b, "%d",LWFDataManager::sharedManager()->userScore);
        userScoreLabel->setString(b);
        
        
        userScoreLabel->setPosition(ccp(userScoreXpos,yPos));
        opponentScoreLabel->setPosition(ccp(opponentScoreXpos, yPos));
        yPos=yPos-25;
        //used to check whose turn is next
        if(challenge->turnID==LWFDataManager::sharedManager()->currentUserID)
        {
            if(LWFDataManager::sharedManager()->roundCount==6)
            {
                playButton->setVisible(false);
                doneButton->setVisible(true);
                
            }
            else
            {
                playButton->setVisible(true);
            }
            
            if(round->userScore =="Empty")
            {
                userScoreLabel->setString("your turn");
                CCLOG("your turn");
            }
        }
        else if(challenge->turnID!=LWFDataManager::sharedManager()->currentUserID)
        {
            doneButton->setVisible(true);
            
            if( round->opponentScore =="Empty")
            {
                opponentScoreLabel->setString("thier turn");
                CCLOG("v turn");
            }
        }        
    }
    
    CCLOG("opponent score=%d",LWFDataManager::sharedManager()->opponentScore);
    CCLOG("userScore=%d",LWFDataManager::sharedManager()->userScore);
    
}

#pragma MARK -  destructor
LWFSelectedChallengeScreen::~LWFSelectedChallengeScreen()
{
    CC_SAFE_RELEASE_NULL(roundArray);
}