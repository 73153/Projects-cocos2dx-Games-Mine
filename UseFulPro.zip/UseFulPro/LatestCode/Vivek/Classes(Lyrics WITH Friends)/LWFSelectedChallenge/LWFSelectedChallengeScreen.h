//
//  LWFSelectedChallenge.h
//  LyricsWithFriends
//
//  Created by Deepthi on 03/07/13.
//
//

#ifndef __LyricsWithFriends__LWFSelectedChallengeScreen__
#define __LyricsWithFriends__LWFSelectedChallengeScreen__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient

class LWFChallenges;
class LWFSelectedChallengeScreen :public cocos2d::CCLayer
{
public:
    
    LWFSelectedChallengeScreen();
    ~LWFSelectedChallengeScreen();
    
    static cocos2d::CCScene* scene();
    
    LWFChallenges *challenge;
    
      
    //to display userName,score
    CCLabelTTF *userNameLabel;
    CCLabelTTF *userScoreLabel;
    //to display opponentname,score
    CCLabelTTF *opponentNameLabel;
    CCLabelTTF *opponentScoreLabel;
    //to display the waiting status
    CCLabelTTF *labelStatusCode;
    
    //request to load selectedChallenge
    void requestToLoadSelectedChallengeDetails();
    void afterCompletionOfLoadingSelectedChallengeDetails(cocos2d::CCNode *sender, void *data);
    
    void backBtnFunc();
    
    void getTheContentsFromRoundArray();
    CCArray *roundArray;
    
    //menuFunc
    void playButtonFunc();
    void doneButtonFunc();
    
    CCMenuItem  *playButton;
    CCMenuItem  *doneButton;
 
    
        
    CREATE_FUNC(LWFSelectedChallengeScreen);
    
};


#endif /* defined(__LyricsWithFriends__LWFSelectedChallenge__) */
