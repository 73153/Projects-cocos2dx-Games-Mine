//
//  LWFFacebookLoginScene.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 28/06/13.
//
//

#include "LWFFacebookLoginScene.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFGameProgressScreen.h"
#include "LWFFacebookFrndListScreen.h"
#include "LWFMainScene.h"
#include "LWFDataManager.h"

using namespace cocos2d;

CCScene* LWFFacebookLoginScene::scene()
{
    CCScene *scene=CCScene::create();
    
    LWFFacebookLoginScene *introSceneLayer=new LWFFacebookLoginScene();
    scene->addChild(introSceneLayer);
    return scene;
}

#pragma mark - constructor

LWFFacebookLoginScene::LWFFacebookLoginScene()
{
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    addChild(labelStatusCode,20);

    this->facebookLoginStart(this);
    
  }

#pragma mark - destructor
LWFFacebookLoginScene::~LWFFacebookLoginScene()
{
    
}

#pragma mark - checkForNetWork
void LWFFacebookLoginScene::facebookLoginStart(cocos2d::CCObject *Sender)
{
    //used to check whether network is present
    this->checkForNetWork();
}
void LWFFacebookLoginScene::checkForNetWork()
{
    labelStatusCode->setString("Checking for network");
    LWFHttpRequest* request = new    LWFHttpRequest();
    std::string url="http://google.com";
    request->setUrl(url.c_str());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFFacebookLoginScene::onNetworkCheckIsFinished));
    request->setTag("Network test");
    LWFHttpClient::getInstance()->send(request);
    // don't forget to release it, pair to new
    request->release();
}
void LWFFacebookLoginScene::onNetworkCheckIsFinished(cocos2d::CCNode *sender, void *data)
{
    //using namespace httpios;
    //   DLOG("");
    if (!this->isRunning())
    {
        return;
    }
    
    LWFHttpResponse *response = (LWFHttpResponse*)data;
    if(!response->isSucceed())
    {
        
    }
    else
    {
        this->facebookLogin(this);
    }
}

#pragma mark - checkForFaceLogin
void LWFFacebookLoginScene::facebookLoginDone(bool isSuccessFull)
{
    
    if (!this->isRunning()) {
        return;
    }
    
    if(isSuccessFull)
    {
        CCLOG("Login successfull");
        //if login is successsful then fetch info
        this->facebookProfileInfoFetch();
    }
    
    else
    {
          CCDirector::sharedDirector()->replaceScene(LWFMainScene::scene());
        //    labelStatusCode->setString("Failed to login to facebook");
        //    this->facebookLoginFailedOK(this);
    }
}

#pragma mark - loginToLyricsServerThroughFaceBook
void LWFFacebookLoginScene::loginToLyricsThroughFB()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToLoginThroughFB(emailID, facebookUserId,facebookUserPictureUrl, facebookNoSpaceUserName,facebookUserGender).c_str());
    CCLOG("%s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFFacebookLoginScene::onloginToLyricsServerRequestCompleted));
    request->setTag("GET test1");
    LWFHttpClient::getInstance()->send(request);
    request->release();
    
    
}

void LWFFacebookLoginScene::onloginToLyricsServerRequestCompleted(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning()) {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    
    std::string message=document["msg"].GetString();
    CCLOG("msg=%s",message.c_str());
    
 
    std::string successMsg="User signed in successfully";
    if(strcmp(message.c_str(), successMsg.c_str())==0)
    {

        LWFDataManager::sharedManager()->currentUserID  = document["user"]["userId"] .GetString();
        CCUserDefault::sharedUserDefault()->setStringForKey("UserId", document["user"]["userId"].GetString());

        // CCLog("%s=LWFDataManager::sharedManager()->currentUserID",LWFDataManager::sharedManager()->currentUserID.c_str());
        std::string UserName = document["user"]["name"] .GetString();
        std::string api =document ["user"]["APIKey"].GetString();
        
        CCUserDefault::sharedUserDefault()->setStringForKey("APIKey", api);
        cocos2d::CCUserDefault::sharedUserDefault()->flush();
        
        CCLog("facebook loged in with API KEY %s",api.c_str());
        CCLog("facebook loged in with name %s",LWFDataManager::sharedManager()->currentUserID.c_str());
        
        CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
    }    
}


