//
//  LWFFacebookLoginScene.h
//  LyricsWithFriends
//
//  Created by Deepthi on 28/06/13.
//
//

#ifndef LyricsWithFriends_LWFFacebookLoginScene_h
#define LyricsWithFriends_LWFFacebookLoginScene_h

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

#include "rapidjson.h"
#include "filestream.h"
#include "document.h"
#include "httpiOS.h"


using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient



class LWFFacebookLoginScene:public CCLayer
{
    LWFFacebookLoginScene();
    ~LWFFacebookLoginScene();
    
public:
       static CCScene* scene();
    
    CCLabelTTF *labelStatusCode;
    
    void facebookLogin(CCObject* sender);
    static  void FacebookLoginOut(CCObject* sender);
    
    //facebook login failed
    void facebookLoginStart(CCObject *Sender);
    // void facebookLoginFailedOK(CCObject* sender);
    
    void facebookLoginDone(bool isSuccessFull);
    void facebookProfileInfoFetch();

    void onNetworkCheckIsFinished(CCNode *sender, void *data);
    void checkForNetWork();
    
    void facebookLoginSilent(CCObject* sender);

    void FetchFriendList();
    void loginPreviousSession();
    
    void loginToLyricsThroughFB();
    void onloginToLyricsServerRequestCompleted(cocos2d::CCNode *sender, void *data);
   
    
    
    std::string facebookUserName, facebookUserId, facebookUserGender,
    facebookUserPictureUrl, facebookNoSpaceUserName, androiPushId, deviceManufacturer, deviceModel;
    
    std::string emailID;
 
    //  bool isNetWorkPresent;
    
};

#endif
