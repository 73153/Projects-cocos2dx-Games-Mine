//
//  LWFSubmitChallenge.h
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#ifndef LyricsWithFriends_LWFSubmitChallenge_h
#define LyricsWithFriends_LWFSubmitChallenge_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include <iostream>

//#include "rapidjson/prettywriter.h"
//#include "rapidjson/filestream.h"
//#include "rapidjson/document.h"
#include "rapidjson.h"
#include "filestream.h"
#include "document.h"

using namespace cocos2d;
using namespace cocos2d::extension;

#define LWFHttpRequest  cocos2d::httpios::CCHttpRequest
#define LWFHttpResponse cocos2d::httpios::CCHttpResponse
#define LWFHttpClient cocos2d::httpios::CCHttpClient


class LWFSubmitChallenge :public cocos2d::CCLayer

{
public:
    LWFSubmitChallenge();
    ~LWFSubmitChallenge();
    
    static cocos2d::CCScene* scene();
    
    CCLabelTTF *labelStatusCode;
    
    
    void submitChallengeToServer();
    void afterCompletionOfSubmitingChallenge(cocos2d::CCNode *sender, void *data);
    
    //  void afterCompletionOfClearChallenge(cocos2d::CCNode *sender, void *data);

    CREATE_FUNC(LWFSubmitChallenge);
};


#endif
