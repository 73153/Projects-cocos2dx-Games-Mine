//
//  LWFSubmitChallenge.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 20/06/13.
//
//

#include "LWFSubmitChallenge.h"
#include "LWFNetworkResponseSharedManager.h"
#include "LWFCreateURLSharedManager.h"
#include "LWFDataManager.h"
#include "LWFGameScene.h"
#include "LWFGenreListScene.h"
#include "LWFCurrentGamesList.h"
#include "LWFGameProgressScreen.h"


CCScene*  LWFSubmitChallenge::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
     LWFSubmitChallenge *layer =  LWFSubmitChallenge::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - constructor
 LWFSubmitChallenge:: LWFSubmitChallenge()
{
    
    labelStatusCode = CCLabelTTF::create("", "Marker Felt", 20,CCSize(300,100),kCCTextAlignmentCenter);
    labelStatusCode->setPosition(ccp(160 ,350));
    this->addChild(labelStatusCode,20);
    

    
    this->submitChallengeToServer();
    
    
}

#pragma mark - submitChallengeToServer
void  LWFSubmitChallenge::submitChallengeToServer()
{
    LWFHttpRequest * request = new LWFHttpRequest();
    // required fields
    request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToSubmitChallenge().c_str());
    CCLOG("submitChallengeToServer URL is %s",request->getUrl());
    request->setRequestType(LWFHttpRequest::kHttpGet);
    request->setResponseCallback(this, callfuncND_selector(LWFSubmitChallenge::afterCompletionOfSubmitingChallenge));
    LWFHttpClient::getInstance()->send(request);
    request->release();
    
    labelStatusCode->setString("Waiting");
    
    
//    if( LWFDataManager::sharedManager()->currentChallengeId!="9999")
//    {
//        LWFHttpRequest * request = new LWFHttpRequest();
//        // required fields
//        request->setUrl(LWFCreateURLSharedManager::sharedManager()->createURLToCloseChallenge().c_str());
//        CCLOG("%s",LWFCreateURLSharedManager::sharedManager()->createURLToCloseChallenge().c_str());
//        request->setRequestType(LWFHttpRequest::kHttpGet);
//        request->setResponseCallback(this, callfuncND_selector(LWFSubmitChallenge::afterCompletionOfClearChallenge));
//        LWFHttpClient::getInstance()->send(request);
//        request->release();
//        
//        labelStatusCode->setString("Waiting");
//
//    }

}

void LWFSubmitChallenge::afterCompletionOfSubmitingChallenge(cocos2d::CCNode *sender, void *data)
{
    if (!this->isRunning())
    {
        return;
    }
    
    rapidjson::Document document;
    
    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
    

    std::string message=document["msg"].GetString();
    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
    
//   int challengeID1=document["challengeId"].GetInt();
//    CCLOG("%d",challengeID1);
//
    
    //  Challenge Submitted!!!
   

    if(message=="Challenge Submitted!!!" ||message=="Success")
   {
        CCDirector::sharedDirector()->replaceScene(LWFGameProgressScreen::scene());
   }
    
 }

//void LWFSubmitChallenge::afterCompletionOfClearChallenge(cocos2d::CCNode *sender, void *data)
//{
//    if (!this->isRunning())
//    {
//        return;
//    }
//    
//    rapidjson::Document document;
//    
//    LWFNetworkResponseSharedManager::sharedManager()->getResponseBuffer(sender, data,document);
//    
//    std::string message=document["msg"].GetString();
//    CCUserDefault::sharedUserDefault()->setStringForKey("msg", message);
//
//}

#pragma mark - destructor
LWFSubmitChallenge::~LWFSubmitChallenge()
{
    
}