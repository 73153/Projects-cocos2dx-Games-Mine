//
//  LWFDataManager.cpp
//  LyricsWithFriends
//
//  Created by Deepthi on 07/06/13.
//
//

#include "LWFDataManager.h"
#include "cocos2d.h"

static LWFDataManager *gSharedManager = NULL;

LWFDataManager::LWFDataManager()
{
    this->index=0;
    this->opponentScore=0;
    this->roundCount=0;
    this->userScore=0;
    this->canPressSkipButton=true;
    this->isLogInWithFB=false;
   
    
}

LWFDataManager* LWFDataManager::sharedManager(void) {
        
	LWFDataManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new LWFDataManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool LWFDataManager::init(void)
{
	return true;
    
    
}
LWFDataManager::~LWFDataManager()
{
}

