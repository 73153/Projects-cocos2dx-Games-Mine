//
//  LWFDataManager.h
//  LyricsWithFriends
//
//  Created by Deepthi on 07/06/13.
//
//

#ifndef LyricsWithFriends_LWFDataManager_h
#define LyricsWithFriends_LWFDataManager_h

#include "cocos2d.h"
#include "CCBReader.h"


USING_NS_CC;
USING_NS_CC_EXT;


class LWFDataManager : public cocos2d::CCObject
{
        
public:
        
    LWFDataManager();
    ~LWFDataManager();
    //  virtual TIDataManager(void);
    
    bool init(void);
    static LWFDataManager* sharedManager(void);
    
    int index;
    
    std::string selectedSong;
    std::string answer;
    
    std::string lyricsID;
    
    std::string emailID;
    
     int opponentScore;
     int userScore;
    
    std::string currentChallengeId;
    
    std::string currentUserID;
    
    std::string songPath;
    std::string opponentID;
    
    char scoreCount[50]={};
    
    bool canPressSkipButton;
    
    int roundCount;
    
    bool isAppRunning;
    
    bool isChoosingMoreFrds;
    
    bool isLogInWithFB;
    
    CCArray *FBFriendList;
  
    
};



#endif
