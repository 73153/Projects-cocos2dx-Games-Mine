//
//  CTASharedSoundManager.cpp
//  CountTheAnimals
//
//  Created by Vivek on 03/07/13.
//
//


#include "CTASharedSoundManager.h"

#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;


static CTASharedSoundManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

CTASharedSoundManager::CTASharedSoundManager(void)
{
        
}

CTASharedSoundManager::~CTASharedSoundManager(void)
{
        
}


CTASharedSoundManager* CTASharedSoundManager::sharedManager(void) {
        
	CTASharedSoundManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new CTASharedSoundManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool CTASharedSoundManager::init(void) {
	return true;
}


#pragma mark - Sound Manager Implementation

void CTASharedSoundManager::playShortSoundOnClickOfCorrecAns()
{
         correctRandomSound= arc4random()%7;
       
        if(correctRandomSound==0)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/happy.mp3", false);
        }
        else if(correctRandomSound==1)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/yeaaah.mp3", false);
                
        }
        else if(correctRandomSound==2)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/wow1.mp3", false);
                
        }
        else if(correctRandomSound==3)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/uhum.mp3", false);
        }

             else if(correctRandomSound==4)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/yes-Perfect.mp3", false);
                
        }
        else if(correctRandomSound==5)
        {
                 sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/happy2.mp3", false); 
        }
               else 
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/yes3.mp3", false);
                
        }


}

void CTASharedSoundManager::playLongSoundOnClickOfCorrectAns()
{
        int rand= arc4random()%3;
        if(rand==0)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/applause_sound.mp3", false);
        }
        else if(rand==1)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/smiley3.mp3", false);
                
        }
        else
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/CongragulationSounds/clapping.mp3", false);
        }
 
}
   
void CTASharedSoundManager::playOnStarAnimation()
{
        int rand= arc4random()%2;
        char song[50]={};
        if(rand==0)
        {
                rand=2;
        }
        
        sprintf(song,"CTASounds/StarSound/star%d.mp3",rand);
        SimpleAudioEngine::sharedEngine()->playEffect(song, false);
}

void CTASharedSoundManager::playOnGettingTrophy()
{
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/yougetatrophy.mp3");
}

void CTASharedSoundManager::playGameCompletePopUpSound()
{
   sound= SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/playagainorgoback.mp3");
}

void CTASharedSoundManager::playGameButtonSound()
{
    int random = arc4random()%4;
    
    if(random == 0)
    {
       sound= SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/thankyouforcoming.mp3");
    }
    else if (random==1)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/comebacksoon.mp3");
    }
    else if (random==2)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/lets_play_again_soon.mp3");
    }
    else 
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/thanksforplayingcomebacksoon.mp3");
    }
}

void CTASharedSoundManager::playPlayAgainButtonSound()
{
    int random = arc4random()%2;
    
    if(random == 0)
    {
       sound= SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/thatwasfun.mp3");
    }
    else if (random==1)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/great.mp3");
    }
}
   
void CTASharedSoundManager::playSoundOnTappingDogAfterPopup()
{
    int rand =arc4random()%2;
    if(rand==0)
    {
        sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/tapcontroller.mp3");
    }
    else if(rand==1)
    {
        sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/play_again_orgoback.mp3");
    }
    else
    {
        sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/playagainorgoback.mp3");
    }
}

void CTASharedSoundManager::addCongratulationBanner(bool bannerStatus,CCPoint pos)
{
    std::string soundName;
    std::string imageName;
    
    
    int rand = arc4random()%25;
    soundName="CTASounds/CongragulationSounds/";
    imageName="spriteSheets/CongratulationBanner/";
    
    if(rand==0)
    {
        soundName=soundName+ "amazing.mp3";
        imageName=imageName+"Amazing!.png";
    }
    else if(rand==1)
    {
        soundName=soundName+ "awesome.mp3";
        imageName=imageName+"Awesome!.png";
        
        //   spr = CCSprite::create("BBSharedResources/CongratulationBanner/Awesome!.png");
        // SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/awesome.mp3", false);
    }
    else if(rand==1)
    {
        soundName=soundName+"bigstep.mp3";
        imageName=imageName+"Big-step.png";
        
    }
    else if(rand==2)
    {
        soundName=soundName+"bravo.mp3";
        imageName=imageName+"Bravo!.png";
        
    }
    else if(rand==3)
    {
        soundName=soundName+"brilliant.mp3";
        imageName=imageName+"Brilliant!.png";
        
    }
    else if(rand==4)
    {
        soundName=soundName+"congratulations.mp3";
        imageName=imageName+"Congratulations!.png";
        
    }
    else if(rand==5)
    {
        soundName=soundName+"excellent.mp3";
        imageName=imageName+"Excellent!.png";
    }
    else if(rand==6)
    {
        soundName=soundName+"fantastic.mp3";
        imageName=imageName+"Fantastic!.png";
        
    }
    else if(rand==7)
    {
        soundName=soundName+"goodjob.mp3";
        imageName=imageName+"Good-Job!.png";
        
    }
    else if(rand==8)
    {
        soundName=soundName+"great_effort.mp3";
        imageName=imageName+"Great-effort!.png";
    }
    else if(rand==9)
    {
        soundName=soundName+"great-job.mp3";
        imageName=imageName+"Great-Job!.png";
        
    }
    else if(rand==10)
    {
        soundName=soundName+"great.mp3";
        imageName=imageName+"Great!.png";
        
    }
    
    
    else if(rand==11)
    {
        soundName=soundName+"incredible.mp3";
        imageName=imageName+"Incredible!.png";
        
    }
    else if(rand==12)
    {
        soundName=soundName+"nicework.mp3";
        imageName=imageName+"Nice-work!.png";
    }
    else if(rand==13)
    {
        soundName=soundName+"original.mp3";
        imageName=imageName+"Original!.png";
        
    }
    else if(rand==14)
    {
        soundName=soundName+"outstanding.mp3";
        imageName=imageName+"Outstanding!.png";
        
        
    }
    else if(rand==15)
    {
        soundName=soundName+"perfect.mp3";
        imageName=imageName+"Perfect!.png";
    }
    
    else if(rand==16)
    {
        soundName=soundName+"Super_happy!.mp3";
        imageName=imageName+"Super_happy!.png";
        
    }
    else if(rand==17)
    {
        soundName=soundName+"super.mp3";
        imageName=imageName+"Super!.png";
        
    }
    else if(rand==18)
    {
        soundName=soundName+"terrific.mp3";
        imageName=imageName+"Terrific.png";
        
    }
    else if(rand==19)
    {
        soundName=soundName+"thatsgreat.mp3";
        imageName=imageName+"That’s-Great!.png";
    }
    else if(rand==20)
    {
        soundName=soundName+"thatsgreat.mp3";
        imageName=imageName+"That’s-Great!.png";
    }
    else if(rand==21)
    {
        soundName=soundName+"unique.mp3";
        imageName=imageName+"Unique!.png";
    }
    else if(rand==22)
    {
        soundName=soundName+"very_nice.mp3";
        imageName=imageName+"Very_nice!.png";
    }
    else if(rand==23)
    {
        soundName=soundName+"welldone.mp3";
        imageName=imageName+"Well-done!.png";
    }
    else if(rand==24)
    {
        soundName=soundName+"wonderful.mp3";
        imageName=imageName+"Wonderful!.png";
        
    }
    else if(rand==25)
    {
        soundName=soundName+"wonderful.mp3";
        imageName=imageName+"Wow!.png";
        
    }
    if(bannerStatus)
    {
        bannerSpr = CCSprite::create(imageName.c_str());
        bannerSpr->setPosition(pos);
        bannerSpr->setTag(1000);
        CCDirector::sharedDirector()->getRunningScene()->addChild(bannerSpr,10);
        SimpleAudioEngine::sharedEngine()->playEffect(soundName.c_str(), false);
    }
    else
    {
          SimpleAudioEngine::sharedEngine()->playEffect(soundName.c_str(), false);
    }
}

