//
//  CTAHomeScene.cpp
//  CountTheAnimals
//
//  Created by Vivek on 03/07/13.
//
//


#include "CTAGameScene.h"
#include "SimpleAudioEngine.h"
#include "CTADataManager.h"
#include "CTASprite.h"
#include "BacciTalking.h"
#include "CTAHomeScene.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* CTAHomeScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CTAHomeScene *layer = CTAHomeScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

CTAHomeScene::CTAHomeScene()
{
    winSize =CCDirector::sharedDirector()->getWinSize();
    CCLabelTTF *levelLbl=CCLabelTTF::create("COUNT THE ANIMAL","Anja Eliane accent", 50);
    
    CCMenuItemLabel *item = CCMenuItemLabel::create(levelLbl, this, menu_selector(CTAHomeScene::replaceToCTAGameScene));
    
    CCMenu *menu = CCMenu::create(item,NULL);
    menu->setPosition(CCPoint(winSize.width/2, winSize.height/2));
    this->addChild(menu,1);
}

CTAHomeScene::~CTAHomeScene()
{
    
}


void CTAHomeScene::replaceToCTAGameScene()
{
     CCDirector::sharedDirector()->replaceScene(CTAGameScene::scene());
}

