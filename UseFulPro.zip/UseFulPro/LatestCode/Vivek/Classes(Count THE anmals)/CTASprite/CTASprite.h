//
//  CTASprite.h
//  CountTheAnimals
//
//  Created by Vivek on 26/06/13.
//
//

#ifndef CTASprite_CTASprite_h
#define CTASprite_CTASprite_h

#include "cocos2d.h"
#include "CTASprite.h"


using namespace cocos2d;

class CTASprite : public CCSprite, public CCTargetedTouchDelegate
{
    
public:
    
    CTASprite(void);
    ~CTASprite(void);
    
    // Creation of a tile...
    static CTASprite* spriteWithFile(const char *pszFileName);
    static CTASprite* spriteWithFrame(const char *pszFileName);
    static CTASprite* create(const char *pszFileName);
    static CTASprite* create(CCSpriteFrame *pSpriteFrame);
    static CTASprite* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static CTASprite* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    
    public:
   void initialAnimation();
   void stayAnimation();
    
    // variables
    const char *animalName;
    CCPoint initialPosition;
    CCPoint FinalPosition;
    bool isSolved;
};


#endif
