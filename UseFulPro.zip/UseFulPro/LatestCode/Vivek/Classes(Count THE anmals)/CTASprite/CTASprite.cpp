//
//  CTASprite.cpp
//  CountTheAnimals
//
//  Created by Vivek on 26/06/13.
//
//

#include "CTASprite.h"
#include "CTASprite.h"

CTASprite::CTASprite(void)
{
    this->animalName=NULL;
    this->isSolved=false;
}

CTASprite::~CTASprite(void)
{
}

// To create separate sprite from file...
CTASprite* CTASprite::spriteWithFile(const char *pszFileName)
{
    CTASprite *pobSprite = new CTASprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        //pobSprite->scheduleUpdate();
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
	return NULL;
}

// To create sprite from sprite sheet!
CTASprite* CTASprite::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    CTASprite *tempSpr = CTASprite::create(pFrame);
    return tempSpr;
}


CTASprite* CTASprite::create(const char *pszFileName)
{
    CTASprite *pobSprite = new CTASprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

CTASprite* CTASprite::create(CCSpriteFrame *pSpriteFrame)
{
    CTASprite *pobSprite = new CTASprite();
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

CTASprite* CTASprite::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "This is Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

CTASprite* CTASprite::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    CTASprite *pobSprite = new CTASprite();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}