//
//  FindMamaIpadScene.h
//  FindMamaIpad
//
//  Created by Vivek on 11/03/13.
//
//

#ifndef FindMamaIpad_FindMamaIpadScene_h
#define FindMamaIpad_FindMamaIpadScene_h
#include "cocos2d.h"
#include "FindMamaIpad.h"
#include "FMPartsSprite.h"
#include "cocos-ext.h"
#include "CCBReader.h"

USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;
class FindMamaIpad : public CCLayer
{
public:
    //default
    virtual void onEnter();
    virtual void onExit();
    
    static CCScene* scene();
    
    FindMamaIpad();
    ~FindMamaIpad();
    
    //Initialize
    void initialiseGameUI();
    void addStars();
    void initialiseGame();
    void initialiseVariables();
    
    //animal layer
    CCLayer *animalLayer;
    
    //Variables
    CCSize winSize;
    CCLabelTTF *animalLabel;
    
    int levelNo;
    int* store_randomArray;
    int movedChildCount;
    int gameCount;
    
    bool isFatherPresent;
    bool isChildMotherGameSolved;
    bool canRenderTexture;
    
    CCParticleSystem *addParticleEffectToTexture;
    
    //Animal Array
    CCArray *motherArr;
    CCArray *childArr;
    CCArray *fatherArr;
    CCArray *randNumberarrayForMother;
    CCArray *randNumberarrayForFather;
    CCArray *arrayOfAnimalsAccordingToGroupName;
 
    CCArray *lineSprarray;
    CCArray *linesInfoArr;
    CCArray *starArray;
    
    CCDictionary *levelNameDict;
    
    CCMenuItemSprite *leftArrowMenuItem;
    CCMenuItemSprite *rightArrowMenuItem;
    
    CCSprite *award;

    //Animals
    void addChilds( int noOfChild);
    void addMothers( int noOfMother);
    void addFathers( int noOfFather);
    
    //Menu
    void restart();
    void homeButton(CCMenuItemImage *sender);
    void goToPreviousLevel(CCMenuItemSprite *sender);
    void goToNextLevel(CCMenuItemSprite *sender);
    
    
    //Animal Sprites
    FMPartsSprite *selectedAnimal;
    FMPartsSprite* getOriginalChild();
    
    CCRenderTexture* createStroke(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity)
    ;
    //Game Logic
    float getAngleBetweenPoint(CCPoint currentPoint,CCPoint toPoint);
    int* randomizeInt(int GameCards[10]);
       
    //moving to CCPoint
    void moveAllFatherToChildPos();
    void moveSelectedAnimalToMatchedAnimalPos(CCObject *Sender,void* Data);
    void addChildAsChildOfMother(CCObject *sender );

    //star sprite
    void addNewStar();
    void addParticleEffect();
    
    //sound
    void playCheersSound();
    void playOhhSound();
    void animalSound();
    void readyfornextlevel();
    void drawalinefrom_mama();
    
    //label
    void setAnimalLabelName(const char* name);
    
    //Texture
    CCRenderTexture *m_pTarget;
    CCSprite *m_pBrush;
    void addTexture();
    void clearTexture();
    
    //game over
    void gameOver();
    void goToFirstLevel();
    
    //Touches
    void ccTouchesBegan(CCSet* touches, CCEvent* event);
    void ccTouchesMoved(CCSet* touches,CCEvent* event);
    void ccTouchesEnded(CCSet* touches, CCEvent* event);
    void ccTouchesCancelled(CCSet *pTouches, CCEvent *pEvent);

    void isCorrectParentSelected(FMPartsSprite *child ,FMPartsSprite *parent, CCPoint point);
   
    //clear
    void clear();
    void clearLines(CCObject *Sender);
    
    CREATE_FUNC(FindMamaIpad);
};



class FindMamaIpadParameterObject :public cocos2d::CCObject {
    
public:
    FMPartsSprite *child;
    FMPartsSprite *parent;
    FindMamaIpadParameterObject();
    ~FindMamaIpadParameterObject();
    
};

#endif


