//
//  FindMamaIpadScene.cpp
//  FindMamaIpad
//
//  Created by Vivek on 11/03/13.
//
//

#include "FindMamaIpad.h"
#include "cocos2d.h"
#include "FMPartsSprite.h"
#include "FMDataManager.h"
#include "SimpleAudioEngine.h"
#include "FMLevelSelect.h"

using namespace cocos2d;
USING_NS_CC_EXT;

#pragma mark default
CCScene* FindMamaIpad::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    FindMamaIpad *layer = new FindMamaIpad();
    
    // add layer as a Parent to scene
    scene->addChild(layer);
    
    CC_SAFE_RELEASE(layer);
    // return the scene
    return scene;
}


FindMamaIpad::FindMamaIpad()
{
    
}

FindMamaIpad::~FindMamaIpad()
{
    
    m_pBrush->release();
    m_pTarget->release();

    m_pBrush=NULL;
    m_pTarget=NULL;
    
    CC_SAFE_RELEASE_NULL(this->motherArr);
    CC_SAFE_RELEASE_NULL(this->childArr);
    CC_SAFE_RELEASE_NULL(this->randNumberarrayForMother);
    CC_SAFE_RELEASE_NULL(this->lineSprarray);
    CC_SAFE_RELEASE_NULL(this->starArray);
    CC_SAFE_RELEASE_NULL(this->fatherArr);
    CC_SAFE_RELEASE_NULL(this->randNumberarrayForFather);
}


void FindMamaIpad::onExit()
{
    CCLayer::onExit();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("SpriteSheets/FindMyMamaBaby.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("SpriteSheets/FindMyMamaParent.plist");
}


void FindMamaIpad::onEnter()
{
    CCLayer::onEnter();
    
    //load plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SpriteSheets/FindMyMamaBaby.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("SpriteSheets/FindMyMamaParent.plist");
    
    this->initialiseVariables();
    
    this->initialiseGameUI();
    
    this->initialiseGame();
    
    //Add drawing texture
    this->addTexture();
    
}

#pragma mark - initialise
void FindMamaIpad::initialiseVariables(){
    
    winSize = CCDirector::sharedDirector()->getWinSize();
    
    this->motherArr = CCArray::create();
    this->motherArr->retain();
    
    this->childArr = CCArray::create();
    this->childArr->retain();
    
    this->randNumberarrayForMother= CCArray::create();
    this->randNumberarrayForMother->retain();
    
    this->lineSprarray= CCArray::create();
    this->lineSprarray->retain();
    
    this->starArray= CCArray::create();
    this->starArray->retain();
    
    this->fatherArr= CCArray::create();
    this->fatherArr->retain();
    
    this->movedChildCount=0;
    this->gameCount=0;
    
    this->isFatherPresent=false;
    this->canRenderTexture=true;
}

void FindMamaIpad::initialiseGameUI()
{
    this->addStars();
    
    CCSprite *goBackToGameSelectionNormalSprite = CCSprite::createWithSpriteFrameName("game_home control.png");
    CCSprite *goBackToGameSelectionSelectedSprite = CCSprite::createWithSpriteFrameName("game_home control.png");
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(goBackToGameSelectionNormalSprite, goBackToGameSelectionSelectedSprite, this, menu_selector(FindMamaIpad::homeButton));
    backMenuItem->setPosition(CCPointMake(86,677));
    
    //Restart button
    CCSprite *normalSprite = CCSprite::createWithSpriteFrameName("repeat.png");
    CCSprite *selectedSprite = CCSprite::createWithSpriteFrameName("repeat.png");
    CCMenuItemSprite  *restartMenuItem = CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(FindMamaIpad::restart));
    restartMenuItem->setPosition(ccp(952,677));
    
    //Left and right Arrrow for selecting difficulty
    CCSprite *rightArrowNormalSpr = CCSprite::createWithSpriteFrameName("rightArrow.png");
    CCSprite *rightArrowSelectedSpr = CCSprite::createWithSpriteFrameName("rightArrow.png");
    rightArrowMenuItem = CCMenuItemSprite::create(rightArrowNormalSpr, rightArrowSelectedSpr, this, menu_selector(FindMamaIpad::goToNextLevel));
    rightArrowMenuItem->setPosition(CCPointMake(973,winSize.height/2));
    
    rightArrowMenuItem->setVisible(false);
    rightArrowMenuItem->setEnabled(false);
    
    CCSprite *leftArrowNormalSpr = CCSprite::createWithSpriteFrameName("leftArrow.png");
    CCSprite *leftArrowSelectedSpr = CCSprite::createWithSpriteFrameName("leftArrow.png");
    
    leftArrowMenuItem = CCMenuItemSprite::create(leftArrowNormalSpr, leftArrowSelectedSpr, this, menu_selector(FindMamaIpad::goToPreviousLevel));
    leftArrowMenuItem->setPosition(CCPointMake(50,winSize.height/2));
    
    //setting visibility for the arrow buttons based on the levels
    if(FMDataManager::sharedManager()->currentLevel==1){
        leftArrowMenuItem->setVisible(false);
        leftArrowMenuItem->setEnabled(false);
    }
    
    CCMenu *tempMenu = CCMenu::create(restartMenuItem, backMenuItem, rightArrowMenuItem,leftArrowMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,3);
    
    animalLabel = CCLabelTTF::create("", "", 45);
    this-> addChild(animalLabel,3);
    animalLabel->setColor(ccc3(255, 0, 0));
    
    award=CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,2);
    award->setScale(0.7);
    award->setPosition(ccp(500,688));
    award->setVisible(false);
    
}

void FindMamaIpad::initialiseGame()
{
    this->animalLayer=CCLayer::create();
    this->addChild(this->animalLayer,1);
    this->animalLayer->setPosition(ccp(0,0));
    
    this->canRenderTexture=false;
    this->isChildMotherGameSolved=false;
    this->movedChildCount=0;
    this->gameCount=0;
 
    
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("FMSpritesIpad.plist");
    
    CCDictionary  *allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    CCDictionary *animalGroupInfoDict = (CCDictionary*)allCardInfoDict->objectForKey("AnimalGroup");
    
    CCDictionary *levelsInfoDict = (CCDictionary*)allCardInfoDict->objectForKey("Levels");
    linesInfoArr = (CCArray*)allCardInfoDict->objectForKey("Lines");
    
    char levelName[40]={};
    sprintf(levelName,"Page%d",FMDataManager::sharedManager()->currentLevel);
    
    levelNameDict = (CCDictionary*)levelsInfoDict->objectForKey(levelName);
    int  noOfChildren = levelNameDict->valueForKey("noOfChildAnimals")->intValue();
    int  noOfParents = levelNameDict->valueForKey("noOfParentAnimals")->intValue();
    
    this->isFatherPresent=levelNameDict->valueForKey("isFatherPresent")->boolValue();
    
    //Background sprite
    CCString *bgName = (CCString*)levelNameDict->valueForKey("background");
    
    char BGName[80];
    sprintf(BGName,"SpriteSheets/%s",bgName->getCString());
    CCSprite *backgroundforSpr = CCSprite::create(BGName);
    backgroundforSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->animalLayer->addChild(backgroundforSpr);
    
    sprintf(BGName,"%d/20",FMDataManager::sharedManager()->currentLevel);
    
    CCLabelTTF *levelLbl=CCLabelTTF::create(BGName, "Apple Casual", 45);
    this->animalLayer->addChild(levelLbl,1);
    levelLbl->setColor(ccc3(0,162,255));
    levelLbl->setPosition(CCPointMake(950, 80));
    
    CCRenderTexture *stroke =createStroke(levelLbl, 2,ccWHITE, 100);
    this->animalLayer-> addChild(stroke);
    
    
    CCSprite *dogSpr = CCSprite::createWithSpriteFrameName("dog_base.png");
    this->animalLayer->addChild(dogSpr,3);
    
    CCSprite *dogBaseSpr = CCSprite::createWithSpriteFrameName("dog_animation_all_export_barking_3.png");
    dogSpr->addChild(dogBaseSpr,2);
    dogSpr->setPosition(ccp(90, 50));
    dogBaseSpr->setPosition(ccp(65, 110));
    
    // remove the line color
    levelNo=FMDataManager::sharedManager()->currentLevel;
    
    if(levelNo==3|| levelNo==4|| levelNo==10){
        // remove blue and yellow line from array
        linesInfoArr->removeObjectAtIndex(0,true);
        //linesInfoArr->removeObjectAtIndex(6,true);
    }
    
    if(levelNo==1|| levelNo==2|| levelNo==7||levelNo==8||levelNo==9||levelNo==13|| levelNo==14 || levelNo==15 || levelNo==16|| levelNo==5|| levelNo==6||levelNo==10||levelNo==11){
        // remove green line from array
        linesInfoArr->removeObjectAtIndex(5);
    }
    
    CCString *AnimalGroupString = (CCString*)levelNameDict->valueForKey("AnimalGroup");
    arrayOfAnimalsAccordingToGroupName=(CCArray*)animalGroupInfoDict->objectForKey(AnimalGroupString->getCString());
    
    //store unique no's into array
    int no_to_randomize[10];
    for (int i = 0 ; i <arrayOfAnimalsAccordingToGroupName->count(); i++){
        no_to_randomize[i] = i;
    }
    
    //store indexes into an integer Array from randomize method
    
    store_randomArray = this->randomizeInt(no_to_randomize);
    
    this->addMothers( noOfParents);
    this->addChilds(noOfChildren);
    this->gameCount=this->childArr->count();
    
    if(FMDataManager::sharedManager()->isGameBegin)
    {
        CCSequence *Seq=CCSequence::create(CCDelayTime::create(.1),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::drawalinefrom_mama)),NULL);
        this->runAction(Seq);
    }
    
    
    if(this->isFatherPresent) {
        this->addFathers(noOfChildren);
        this->gameCount=this->childArr->count() + this->fatherArr->count();
    }
}

#pragma mark - createStroke
CCRenderTexture*  FindMamaIpad :: createStroke(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity)
{
    
    CCRenderTexture* rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2,
                                                  label->getTexture()->getContentSize().height+size * 2);
    
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    // label->setAnchorPoint(ccp(0,0.5));
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    
    rt->begin();
    
    for (int i=0; i<360; i+=50)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    
    return rt;
}


#pragma mark - Add animals
void FindMamaIpad::addMothers( int noOfParents)
{
    this->randNumberarrayForFather = CCArray::create();
    this->randNumberarrayForFather->retain();
    
    //mother
    for(int i=0; i<noOfParents; i++)
    {
        int randNum = store_randomArray[i];
        CCString *rand_No_string = CCString::createWithFormat("%d",randNum);
        this->randNumberarrayForMother->addObject(rand_No_string);
        this->randNumberarrayForFather->addObject(rand_No_string);
        
        CCDictionary   *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(randNum);
        char Name[30]={};
        const char *animalName= (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        sprintf(Name,"%s-A.png",animalName);
        
        FMPartsSprite *motherSpr  = motherSpr->createWithSpriteFrameName(Name);
        motherSpr->sound=selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(motherSpr,3);
        //position
        CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPosition");
        CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
        CCPoint firstParentPos=CCPointFromString(posSting->getCString());
        motherSpr->setPosition(CCPoint(firstParentPos));
        motherSpr->matchId = randNum;
        motherSpr->animalName = animalName;
        this->motherArr->addObject(motherSpr);
    }
}

void FindMamaIpad::addFathers( int noOfFather)
{
    //fathers
    for(int i=0; i<noOfFather; i++)
    {
        int randNo = arc4random()% this->randNumberarrayForFather->count();
        
        CCString *rand_Number_string = (CCString*)this->randNumberarrayForFather->objectAtIndex(randNo);
        int rand = rand_Number_string->intValue();
        this->randNumberarrayForFather->removeObject(rand_Number_string);
        
        CCDictionary   *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(rand);
        char Name[30]={};
        const char *animalName= (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        sprintf(Name,"%s-C.png",animalName);
        
        FMPartsSprite *fatherSpr  = fatherSpr->createWithSpriteFrameName(Name);
        fatherSpr->sound=selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(fatherSpr,3);
        //position
        CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPosition");
        CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
        CCPoint firstParentPos=CCPointFromString(posSting->getCString());
        fatherSpr->setPosition(CCPoint(firstParentPos));
        fatherSpr->matchId = rand;
        fatherSpr->animalName = animalName;
        this->fatherArr->addObject(fatherSpr);
        if(levelNo==19)
        {
            fatherSpr->setPosition(CCPoint(firstParentPos.x+80,-100));
        }else{
            fatherSpr->setPosition(CCPoint(firstParentPos.x,-100));
        }
    }
}

void FindMamaIpad::addChilds(int noOfChildren)
{
    //Child
    for(int i=0; i<noOfChildren; i++)
    {
        int randNo = arc4random()% this->randNumberarrayForMother->count();
        
        CCString *rand_Number_string = (CCString*)this->randNumberarrayForMother->objectAtIndex(randNo);
        int rand = rand_Number_string->intValue();
        
        this->randNumberarrayForMother->removeObject(rand_Number_string);
        
        CCDictionary   *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(rand);
        char Name[30]={};
        const char *animalName= (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        sprintf(Name,"%s-B.png",animalName);
        
        FMPartsSprite *childSpr  = childSpr->createWithSpriteFrameName(Name);
        childSpr->sound=selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(childSpr,3);
        //position
        CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("childAnimalPosition");
        CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
        CCPoint firstParentPos=CCPointFromString(posSting->getCString());
        childSpr->setPosition(CCPoint(firstParentPos));
        childSpr->matchId = rand;
        childSpr->animalName = animalName;
        this->childArr->addObject(childSpr);
    }
}

//Animal sound
void FindMamaIpad::animalSound()
{
    char soundName[30]={};
    sprintf(soundName, "Sounds/AnimalSounds/%s",selectedAnimal->sound);
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(soundName);
}



#pragma mark - touches methods
void FindMamaIpad::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)touches->anyObject();
    CCPoint  touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    //Create Particle Effect
    addParticleEffectToTexture = CCParticleSystemQuad::create("prinkal.plist");
    addParticleEffectToTexture->setPosition(touchPoint);
    this->animalLayer->addChild(addParticleEffectToTexture, 2);
    CCObject* ChildSpriteObj = NULL;
    
    if(isChildMotherGameSolved){              // father
        CCARRAY_FOREACH(this->fatherArr, ChildSpriteObj){
            
            FMPartsSprite *aChildSpr = (FMPartsSprite *)ChildSpriteObj;
            
            if (aChildSpr->isSolved){
                
                continue;
            }
            
            if (aChildSpr->boundingBox().containsPoint(touchPoint))
            {
                selectedAnimal = aChildSpr;
                this->canRenderTexture=true;
                this->setAnimalLabelName(aChildSpr->animalName);
                CCSequence *Seq=CCSequence::create(CCDelayTime::create(0.1),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::animalSound)),NULL);
                this->runAction(Seq);
                break;
            }
        }
    }
    
    CCARRAY_FOREACH(this->childArr, ChildSpriteObj) { //child
        
        FMPartsSprite *aChildSpr = (FMPartsSprite *)ChildSpriteObj;
        
        if (aChildSpr->isSolved){
            
            continue;
        }
        
        if (aChildSpr->boundingBox().containsPoint(touchPoint))
        {
            selectedAnimal = aChildSpr;
            this->canRenderTexture=true;
            this->setAnimalLabelName(aChildSpr->animalName);
            CCSequence *Seq=CCSequence::create(CCDelayTime::create(0.1),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::animalSound)),NULL);
            this->runAction(Seq);
            break;
        }
    }
}

void FindMamaIpad::ccTouchesMoved(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    addParticleEffectToTexture->setPosition(touchPoint);
    
    if(canRenderTexture==false) {
        return;
    }
    
    CCPoint start = touch->getLocation();
    CCPoint end = touch->getPreviousLocation();
    // begin drawing to the render texture
    m_pTarget->begin();
    
    float distance = ccpDistance(start, end);
    if (distance > 1)
    {
        int d = (int)distance;
        for (int i = 0; i < d; i++)
        {
            float difx = end.x - start.x;
            float dify = end.y - start.y;
            float delta = (float)i / distance;
            m_pBrush->setPosition(ccp(start.x + (difx * delta), start.y + (dify * delta)));
            m_pBrush->setRotation(rand() % 360);
            m_pBrush->setColor(ccc3(rand() % 255, 255, 255));
            m_pBrush->setColor(ccc3(255,0,0));
            // Call visit to draw the brush, don't call draw..
            m_pBrush->visit();
        }
    }
    
    // finish drawing and return context back to the screen
    m_pTarget->end();
}

void FindMamaIpad::ccTouchesEnded(CCSet *touches,CCEvent *event)
{
    m_pTarget->clear(0,0,0,0);
    
    addParticleEffectToTexture->stopSystem();
    
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    if(this->selectedAnimal==NULL) {
        return;
    }
    
    if(this->selectedAnimal->isSolved){
        return;
    }
    
    CCObject* ChildSpriteObj = NULL;
    
    CCARRAY_FOREACH(this->motherArr, ChildSpriteObj) {
        
        FMPartsSprite *aMotherSpr = (FMPartsSprite *)ChildSpriteObj;
        
        int distance=ccpDistance(aMotherSpr->getPosition(), touchPoint);
        
        if(distance<100)
        {
            this->setAnimalLabelName(aMotherSpr->animalName);
            this->isCorrectParentSelected(this->getOriginalChild(),aMotherSpr, touchPoint);
        }
    }
    
    this->canRenderTexture=false;
}

void FindMamaIpad::ccTouchesCancelled(CCSet *touches,CCEvent *event){
    
    addParticleEffectToTexture->stopSystem();
}


#pragma mark - Getting the correct sprite selected
FMPartsSprite* FindMamaIpad::getOriginalChild() {
    
    CCObject *obj;
    if(this->isChildMotherGameSolved){
        CCARRAY_FOREACH_REVERSE(this->fatherArr, obj){
            FMPartsSprite *aChild=(FMPartsSprite*)obj;
            if(this->selectedAnimal==aChild){
                return aChild;
            }
        }
    }
    
    else{
        CCARRAY_FOREACH_REVERSE(this->childArr, obj){
            FMPartsSprite *aChild=(FMPartsSprite*)obj;
            
            if(this->selectedAnimal==aChild){
                return aChild;
            }
        }
    }
    
    return NULL;
}

void FindMamaIpad::isCorrectParentSelected(FMPartsSprite *child, FMPartsSprite *mother,CCPoint touchPoint){
    
    if(child==NULL) {
        return;
    }
    
    if(child->isSolved){
        return;
    }
    this->canRenderTexture=false;
    
    if(child->matchId==mother->matchId ) {
        child->isSolved=true;
        this->gameCount--;
        if(this->gameCount==0)
        {
            this->gameOver();
        }
        this->setAnimalLabelName("Matched");
        int randLineN0=arc4random()%linesInfoArr->count();
        CCString *lineName=(CCString*)linesInfoArr->objectAtIndex(randLineN0);
        CCSprite  *line=CCSprite::createWithSpriteFrameName(lineName->getCString());
        this->animalLayer->addChild(line,0,100);
        
        //calculate the ContentSize and Pos of the targetPosition and the selectedSprite Position
        CCPoint ChildPos = child->getPosition();
        CCPoint motherPos = mother->getPosition();
        float angle = this->getAngleBetweenPoint(ChildPos,motherPos);
        line->setScale(.2);
        line->setRotation(angle);
        line->setPosition(ChildPos);
        line->setAnchorPoint(CCPoint(0.5,0.95));
        
        float distance = ccpDistance(ChildPos,motherPos);
        
        //scale line
        CCActionInterval *action = CCScaleTo::create(0.4, 0.6,distance/(line->getContentSize().height));
        CCSequence *Seq=CCSequence::create(action,CCDelayTime::create(.2),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::clearLines)),NULL);
        line->runAction(Seq);
        
        FindMamaIpadParameterObject *object=new FindMamaIpadParameterObject();
        object->child=child;
        object->parent=mother;
        
        CCCallFuncND *Callback=CCCallFuncND::create(this, callfuncND_selector(FindMamaIpad::moveSelectedAnimalToMatchedAnimalPos), object);
        CCSequence *Seq1=CCSequence::create(CCDelayTime::create(.5),Callback,NULL);
        
        
        this->runAction(Seq1);
        
        this->playCheersSound();
    }
    
    else{
        this->setAnimalLabelName("Not matched");
        this->playOhhSound();
    }
}

#pragma mark - generating RandomNumbers
int* FindMamaIpad::randomizeInt(int noOfAnimalSprites[15]) {
    
    //variables used for swapping
    int swap;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i < arrayOfAnimalsAccordingToGroupName->count(); i++){
        
        rand_no = arc4random() %  arrayOfAnimalsAccordingToGroupName->count();
        
        swap = noOfAnimalSprites[rand_no];
        noOfAnimalSprites[rand_no]= noOfAnimalSprites[i];
        noOfAnimalSprites[i] = swap;
    }
    return noOfAnimalSprites;
}

#pragma mark - addTexture
void FindMamaIpad::addTexture(){
    
    m_pTarget = CCRenderTexture::create(winSize.width,winSize.height, kCCTexture2DPixelFormat_RGBA8888);
    m_pTarget->retain();
    m_pTarget->setPosition(ccp(winSize.width / 2, winSize.height / 2));
    this->addChild(m_pTarget,4);
    
    m_pBrush = CCSprite::create("fire.png");
    m_pBrush->retain();
    m_pBrush->setColor(ccORANGE);
    
    m_pBrush->setScale(0.4);
    this->setTouchEnabled(true);
}


#pragma mark - Moving sprite to there respective Pos
void FindMamaIpad::moveSelectedAnimalToMatchedAnimalPos(CCObject *Sender, void* data) {
    
    FindMamaIpadParameterObject *object=(FindMamaIpadParameterObject*)data;
    CCPoint  originalMotherLocation = ccp(object->parent-> getPositionX()+60,object->parent-> getPositionY()-50);
    
    if(this->isChildMotherGameSolved){
        originalMotherLocation = ccp(object->parent-> getPositionX(),object->parent-> getPositionY()-150);
        CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(originalMotherLocation));
        object->child->runAction(selectedSpritePos);
    }
    
    else{
        if(this->isFatherPresent)
        {
            char childName[30];
            sprintf(childName, "%s-B.png",object->child->animalName);
            FMPartsSprite *childSprite=childSprite->createWithSpriteFrameName(childName);
            object->parent->addChild(childSprite);
            childSprite->setPosition(object->parent->convertToNodeSpace(object->child->getPosition()));
            this->animalLayer->removeChild(object->child);
            this->childArr->removeObject(object->child);
            
            CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(object->parent->convertToNodeSpace(originalMotherLocation)));
            childSprite->runAction(selectedSpritePos);
        }
        else{
            CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(originalMotherLocation));
            object->child->runAction(selectedSpritePos);
        }
    }
    
    this->movedChildCount++;
    if(this->isFatherPresent  &&  this->movedChildCount==this->fatherArr->count()){
        this->isChildMotherGameSolved=true;
        this->moveAllFatherToChildPos();
    }
}

void FindMamaIpad::moveAllFatherToChildPos(){
    
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Mama-Sounds/thenhelpfathers_mama.mp3");
    CCObject *obj;
    CCARRAY_FOREACH(this->fatherArr, obj){
        FMPartsSprite *fatherSpr=(FMPartsSprite*)obj;
        
        CCMoveTo *moveAction=CCMoveTo::create(.5, ccp(fatherSpr->getPosition().x, 230));
        fatherSpr->runAction(moveAction);
    }
}

#pragma mark - gameOver
void FindMamaIpad::gameOver()
{
    this->addNewStar();
    CCSprite *booble=CCSprite::createWithSpriteFrameName("booble.png");
    this->animalLayer->addChild(booble,3);
    booble->setScale(0.7);
    booble->setPosition(ccp(225,210));
    
    if(FMDataManager::sharedManager()->currentLevel>=1 && FMDataManager::sharedManager()->currentLevel<20)
    {
        if(FMDataManager::sharedManager()->currentLevel==1)
        {
            leftArrowMenuItem->setVisible(false);
            leftArrowMenuItem->setEnabled(false);
            rightArrowMenuItem->setVisible(true);
            rightArrowMenuItem->setEnabled(true);
            
        }
        else{
            rightArrowMenuItem->setVisible(true);
            rightArrowMenuItem->setEnabled(true);
            leftArrowMenuItem->setVisible(true);
            leftArrowMenuItem->setEnabled(true);
        }
    }
    if(FMDataManager::sharedManager()->currentLevel==20)
    {
        rightArrowMenuItem->setVisible(false);
        rightArrowMenuItem->setEnabled(false);
        leftArrowMenuItem->setVisible(true);
        leftArrowMenuItem->setEnabled(true);
        award->setVisible(false);
    }
    
    if(FMDataManager::sharedManager()->currentLevel>=1 && FMDataManager::sharedManager()->currentLevel<20)
    {
        CCSequence *Seq=CCSequence::create(CCDelayTime::create(3.4),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::goToNextLevel)),NULL);
        this->runAction(Seq);
    }
    else{
        
         CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Mama-Sounds/yougetatrophy.mp3");
        
        CCSprite *booble=CCSprite::createWithSpriteFrameName("booble.png");
        this->animalLayer->addChild(booble,3);
        booble->setScale(0.7);
        booble->setPosition(ccp(225,210));
        
        award=CCSprite::createWithSpriteFrameName("award.png");
        this->addChild(award,5);
        award->setScale(0.7);
        award->setVisible(true);
        award->setPosition(ccp(500,688));
      
    }
    
    if(isFatherPresent)
    {
        if(FMDataManager::sharedManager()->currentLevel>=1 && FMDataManager::sharedManager()->currentLevel<20)
        {
            CCSequence *Seq=CCSequence::create(CCDelayTime::create(2),CCCallFuncN::create(this, callfuncN_selector(FindMamaIpad::readyfornextlevel)),NULL);
            this->runAction(Seq);
        }
    }
}

void FindMamaIpad::goToFirstLevel()
{
    FMDataManager::sharedManager()->currentLevel=1;
    CCDirector::sharedDirector()->replaceScene(FindMamaIpad::scene());
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
}

#pragma mark - add stars
void FindMamaIpad::addStars(){
    
    int x=245;
    int y=30;
    
    for(int i=0;i<FMDataManager::sharedManager()->starCount;i++){
        CCSprite *starFullSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starFullSprite,4);
        
        starFullSprite->setTag(i);
        starFullSprite->setPosition(ccp(x, y));
        this->starArray->addObject(starFullSprite);
        x=x+60;
    }
    
    for(int i=0;i<10-FMDataManager::sharedManager()->starCount;i++){
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,3);
        starEmptySprite->setTag(i);
        starEmptySprite->setPosition(ccp(x, y));
        x=x+60;
    }
}

void FindMamaIpad::addNewStar()
{
    CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
    starSprite->setPosition(ccp(245+((FMDataManager::sharedManager()->starCount)*60),30));
    this->addChild(starSprite,4);
    this->starArray->addObject(starSprite);
    
    CCRotateTo *rotate=CCRotateTo::create(.5, 720);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.16, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.16, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIN = CCFadeIn::create(0.1);
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut,fadeIN,NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut,fadeIN,NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.25),  seq2,NULL);
    starSprite->runAction(seq3);
    
    FMDataManager::sharedManager()->starCount++;
    if(FMDataManager::sharedManager()->starCount==10)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Mama-Sounds/yougetatrophy.mp3");
        
        FMDataManager::sharedManager()->starCount=0;
        for (int i=0; i<this->starArray->count(); i++){
            
            CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
            this->removeChild(star, true);
        }
        this->starArray->removeAllObjects();
        award->setVisible(true);
        award->setScale(0);
        
        CCScaleTo *scaleSmall = CCScaleTo::create(0.6,.7);
        award->runAction(scaleSmall);
        
    }
    
    else {
        award->setVisible(false);
    }
}


#pragma mark - play Sounds

void FindMamaIpad::drawalinefrom_mama()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Mama-Sounds/helpbabies_mamas.mp3");
}

void FindMamaIpad::readyfornextlevel(){
    
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Mama-Sounds/readyfornextlevel.mp3");
}


void FindMamaIpad::playCheersSound()
{
    int toNumber = 3;
    int fromNumber = 1;
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    char cheers[150]={};
    sprintf(cheers,"Sounds/matched/cheers%d.mp3",randomNumber);
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/matched/cheers1.mp3");
}

void FindMamaIpad::playOhhSound()
{
    int toNumber = 3;
    int fromNumber = 1;
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    char cheers[150]={};
    sprintf(cheers,"Sounds/notmatched/ohh%d.mp3",randomNumber);
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/notmatched/ohh1.mp3");
}


#pragma mark - lables to display
void FindMamaIpad::setAnimalLabelName(const char*name){
    
    animalLabel->setPosition(ccp(500, 670));
    animalLabel->setString(name);
    CCScaleTo *scaleBig = CCScaleTo::create(0.6,1);
    CCScaleTo *scaleSmall = CCScaleTo::create(0.6,0);
    CCAction *sequenceAction  = CCSequence::create(scaleBig,scaleSmall,NULL);
    animalLabel->runAction(sequenceAction);
}


#pragma mark - GetAngleBetween Two Points
float FindMamaIpad::getAngleBetweenPoint(CCPoint currentPoint, CCPoint toPoint) {
    
    float angle;
    CCPoint difference = ccpSub(currentPoint,toPoint);
    angle = -1 * (atan2(difference.y, difference.x) * 180 / M_PI + 90) + 180;
    
    if (angle < 0) {
        angle = 360 + angle;
    }
    return abs(angle);
}

#pragma  mark - clearTexture
void FindMamaIpad::clearTexture()
{
    m_pTarget->clear(0,0,0,0);
}


#pragma mark - restart btn
void FindMamaIpad::restart() {
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->stopAllActions();
    this->clear();
    award->setVisible(false);
    
    this->initialiseGame();
}

void FindMamaIpad::homeButton(CCMenuItemImage *sender)
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    FMDataManager::sharedManager()->isGameBegin=false;
    
    FMDataManager::sharedManager()->currentLevel=1;
    this->stopAllActions();
    
    this->clear();
    
    rightArrowMenuItem->setVisible(false);
    rightArrowMenuItem->setEnabled(false);
    leftArrowMenuItem->setVisible(false);
    leftArrowMenuItem->setEnabled(false);
    
    award->setVisible(false);
    
    this->initialiseGame();
}

#pragma mark - goToNextLevel
void FindMamaIpad::goToNextLevel(CCMenuItemSprite *sender)
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    FMDataManager::sharedManager()->isGameBegin=false;
    
    this->stopAllActions();
    this->clear();
    
    FMDataManager::sharedManager()->currentLevel++;
    rightArrowMenuItem->setVisible(false);
    rightArrowMenuItem->setEnabled(false);
    leftArrowMenuItem->setVisible(false);
    leftArrowMenuItem->setEnabled(false);
    
    award->setVisible(false);
    
    this->initialiseGame();
}

#pragma mark - goToPreviousScene
void FindMamaIpad::goToPreviousLevel (CCMenuItemSprite *sender)
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    FMDataManager::sharedManager()->isGameBegin=false;
    
    this->stopAllActions();
    this->clear();
    FMDataManager::sharedManager()->currentLevel--;
    rightArrowMenuItem->setVisible(false);
    rightArrowMenuItem->setEnabled(false);
    leftArrowMenuItem->setVisible(false);
    leftArrowMenuItem->setEnabled(false);
    
    award->setVisible(false);
    
    this->initialiseGame();
}

#pragma mark - Clear
void FindMamaIpad::clearLines(CCObject *Sender ){
    CCSprite *lineSprite=(CCSprite*)Sender;
    this->animalLayer->removeChild(lineSprite,true);
}

void FindMamaIpad::clear(){
    
    this->award->setVisible(false);
    this->fatherArr->removeAllObjects();
    this->childArr->removeAllObjects();
    this->motherArr->removeAllObjects();
    this->randNumberarrayForMother->removeAllObjects();
    this->lineSprarray->removeAllObjects();
    this->animalLayer->removeAllChildrenWithCleanup(true);
    this->removeChild(this->animalLayer,true);
    
}


// FindMamaIpad parameter object
#pragma mark - FindMamaIpad parameter object
FindMamaIpadParameterObject ::FindMamaIpadParameterObject(){
    
}

FindMamaIpadParameterObject ::~FindMamaIpadParameterObject(){
    
}

