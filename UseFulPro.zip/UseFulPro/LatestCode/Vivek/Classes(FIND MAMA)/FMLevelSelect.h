//
//  FMLevelSelect.h
//  FindMama
//
//  Created by Vivek on 20/04/13.
//
//

#ifndef TIGameSceneIphone_FMLevelSelect_h
#define TIGameSceneIphone_FMLevelSelect_h

#include "cocos2d.h"
#include "FindMamaIpad.h"

using namespace cocos2d;

class FMLevelSelect :public cocos2d :: CCLayer
{
public:
    
    FMLevelSelect();
    ~FMLevelSelect();
    virtual bool init();
    static cocos2d::CCScene* scene();
    CCSize winsize;
    
    void onClick();
    void onClickEasy();
    void backCallBack(CCObject* psender);
    CREATE_FUNC(FMLevelSelect);
    
};




#endif
