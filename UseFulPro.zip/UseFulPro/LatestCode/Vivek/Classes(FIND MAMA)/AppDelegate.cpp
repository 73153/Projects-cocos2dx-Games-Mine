//
//  AppDelegate.cpp
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#include "AppDelegate.h"
#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "FMLevelSelect.h"
#include "FMDataManager.h"


USING_NS_CC;
using namespace CocosDenshion;

AppDelegate::AppDelegate()
{
    
}

AppDelegate::~AppDelegate()
{
}

bool AppDelegate::applicationDidFinishLaunching()
{
    // initialize director
    CCDirector *pDirector = CCDirector::sharedDirector();
    pDirector->setOpenGLView(CCEGLView::sharedOpenGLView());
    
    // turn on display FPS
    // pDirector->setDisplayStats(true);
    
    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    CCSize designSize;
    CCSize resourceSize;
    CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
    
    std::vector<std::string> searchPaths;
    
    FMDataManager::sharedManager()->target = getTargetPlatform();
    
    if (FMDataManager::sharedManager()->target == kTargetIphone)
        
    {
        if (screenSize.height > 320) //iPhone Retina
        {
            resourceSize = CCSizeMake(960, 640);
            searchPaths.push_back("SpriteSheets");
        }
        else
        {
            resourceSize = CCSizeMake(480, 320);
            searchPaths.push_back("Iphone");
        }
        designSize = CCSizeMake(480,320);
    }
    if (FMDataManager::sharedManager()->target == kTargetIpad)
    {
        if(screenSize.height > 768) //ipadRetina
        {
            resourceSize = CCSizeMake(2048, 1536);
            searchPaths.push_back("IpadHD");
        }
        else{
            resourceSize = CCSizeMake(1024, 768);
            searchPaths.push_back("SpriteSheets");
        }
        designSize = CCSizeMake(1024,768);
    }
    pFileUtils->setSearchPaths(searchPaths);
    
    pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
    CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
    
    pDirector->setAnimationInterval(1.0 / 60);
    
    //create a scene. it's an autorelease object
    CCScene *pScene = FMLevelSelect::scene();
    
    //run
    pDirector->runWithScene(pScene);
    
    return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground()
{
    CCDirector::sharedDirector()->stopAnimation();
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->pauseAllEffects();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground()
{
    CCDirector::sharedDirector()->startAnimation();
    SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->resumeAllEffects();
}
