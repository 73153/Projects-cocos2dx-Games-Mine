//
//  FMLevelSelect.cpp
//  FindMama
//
//  Created by Vivek on 20/04/13.
//
//

#include "FMLevelSelect.h"
#include "cocos2d.h"
#include "FindMamaIphone.h"
#include "FindMamaIpad.h"
#include "FMDataManager.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;

CCScene* FMLevelSelect::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    FMLevelSelect *layer =  FMLevelSelect::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

FMLevelSelect::FMLevelSelect()
{
     winsize = CCDirector::sharedDirector()->getWinSize();
}

FMLevelSelect::~ FMLevelSelect()
{
    
}

bool  FMLevelSelect::init()
{
    setVisible(true);
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
    }
    if (FMDataManager::sharedManager()->target == kTargetIphone)
    {
        setTouchEnabled(true);
        CCLabelTTF *label = CCLabelTTF::create("LEVELS","Helvetica",40 );
        this->addChild(label,1,3);
        label->setPosition(ccp(winsize.width/2,winsize.height/2));
        this->onClick();
        return true;
    }else{
        setTouchEnabled(true);
        CCLabelTTF *label = CCLabelTTF::create("LEVELS","Helvetica",40);
        this->addChild(label,1,3);
        label->setPosition(ccp(winsize.width/2,winsize.height/2));
        this->onClick();
        return true;
    }
}


void  FMLevelSelect::onClick()
{
    if (FMDataManager::sharedManager()->target == kTargetIphone)
    {
       
        CCMenuItemFont::setFontName("Marker Felt");
        CCMenuItemFont::setFontSize(90);
        CCMenuItemFont *item1 = CCMenuItemFont ::create("START",this,menu_selector( FMLevelSelect::onClickEasy));
        item1->setPosition(winsize.width/2,winsize.height/2);
        CCMenu *menuObj = CCMenu::create (item1,NULL);
        menuObj->setPosition(winsize.width/2,winsize.height/2);
        this-> addChild(menuObj,4);
        menuObj->alignItemsVertically();
        menuObj->setColor(ccc3(255, 0, 0));
        
    }
    else{
        CCMenuItemFont::setFontName("Marker Felt");
        CCMenuItemFont::setFontSize(90);
        CCMenuItemFont *item1 = CCMenuItemFont ::create("START",this,menu_selector( FMLevelSelect::onClickEasy));
        CCMenu *menuObj = CCMenu::create (item1,NULL);
        this-> addChild(menuObj,4);
        menuObj->setPosition(winsize.width/2,winsize.height/2);
        menuObj->setColor(ccc3(255, 0, 0));
        menuObj->alignItemsVertically();
    }
    
}

void  FMLevelSelect::onClickEasy()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    if (FMDataManager::sharedManager()->target == kTargetIphone)
    {
        FMDataManager::sharedManager()->currentLevel=1;
        CCDirector::sharedDirector()->replaceScene(FindMamaIphone::scene());
    }
    else{
        FMDataManager::sharedManager()->currentLevel=1;
        CCDirector::sharedDirector()->replaceScene(FindMamaIpad::scene());
    }
    
}
