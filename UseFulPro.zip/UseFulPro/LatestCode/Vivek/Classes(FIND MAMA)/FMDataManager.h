//
//  FMDataManager.h
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#ifndef FindMama_FMDataManager_h
#define FindMama_FMDataManager_h

#include "cocos2d.h"
#include "CCBReader.h"
#include "FMDataManager.h"

USING_NS_CC;
USING_NS_CC_EXT;


class FMDataManager: public cocos2d::CCObject  {
    
private:
    
    FMDataManager(void);
    virtual ~FMDataManager(void);
    
public:

    bool init(void);
    static FMDataManager* sharedManager(void);
    
    const char *gameLevelName;
    int currentLevel;
    bool isGameBegin;
    int starCount;
    int movedCount;
    TargetPlatform target;
    
};


#endif
