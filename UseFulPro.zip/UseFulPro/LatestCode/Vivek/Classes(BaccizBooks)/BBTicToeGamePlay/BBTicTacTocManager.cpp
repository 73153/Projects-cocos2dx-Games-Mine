//
//  BBTicTacTocManager.cpp
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/6/13.
//
//

#include "BBTicTacTocManager.h"
#include "cocos2d.h"

static BBTicTacTocManager *gSharedManager = NULL;

BBTicTacTocManager::BBTicTacTocManager(void)
{
    this->starCount=0;
    this->isNewGame=true;
}

BBTicTacTocManager* BBTicTacTocManager::sharedManager(void) {
    
	BBTicTacTocManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBTicTacTocManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBTicTacTocManager::init(void) {
	return true;
}

