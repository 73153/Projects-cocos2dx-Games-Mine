//
//  BBTicTacTocManager.h
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/6/13.
//
//

#ifndef BaccizBooks_BBTicTacTocManager_h
#define BaccizBooks_BBTicTacTocManager_h

#include "cocos2d.h"


USING_NS_CC;


class BBTicTacTocManager: public cocos2d::CCObject  {
    
private:
    
    BBTicTacTocManager(void);
    
    
public:
    
    bool init(void);
    static BBTicTacTocManager* sharedManager(void);
    
    
    int starCount;
    bool isNewGame;
    
    TargetPlatform target;
};



#endif
