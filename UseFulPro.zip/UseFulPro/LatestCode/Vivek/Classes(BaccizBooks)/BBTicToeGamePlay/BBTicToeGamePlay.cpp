//
//  BBTicToeGamePlay.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 24/01/13.
//
//

#include "BBTicToeGamePlay.h"
#include "SimpleAudioEngine.h"
#include "CCNumber.h"
#include "BBUtility.h"
#include "cocos-ext.h"
#include "CCBReader.h"
#import "CCBSequence.h"
#include "BBMainDataManager.h"
#include "BBGameSelection.h"

#define kCpuSpriteAdded 555
#define kPlayerSpriteAdded 666
#define kNoSprite  0
#define kNoDangerousIndex 999

using namespace cocos2d;

#pragma mark - Scene
CCScene* BBTicToeGamePlay::scene()
{
    //'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    //add layer as a child to scene
    CCLayer* layer = new BBTicToeGamePlay();
    scene->addChild(layer);
    layer->release();
    return scene;
}


#pragma mark - Init
BBTicToeGamePlay::BBTicToeGamePlay()
{
    this->setTouchEnabled(true);
}

void BBTicToeGamePlay::onEnter()
{
    CCLayer::onEnter();
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("TicTacToe/BBTTTImages.plist");
    
    //initialise variables
    this->initialiseVariables();
    
    //add ticToe background
    this->addTicToeBackGround();
}

void BBTicToeGamePlay::onEnterTransitionDidFinish()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/tictactoe_music.mp3", true);
    if(BBTicTacTocManager::sharedManager()->isNewGame)
    {
        BBTicTacTocManager::sharedManager()->isNewGame = false;
     introSeq =1;
//     this->playIntro();
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::playIntro)),NULL);
        this->runAction(callBack);
    }
}


#pragma mark -  Dealloc
void BBTicToeGamePlay::onExit()
{
    CCLayer::onExit();
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("TicTacToe/BBTTTImages.plist");
    
}

BBTicToeGamePlay::~BBTicToeGamePlay()
{
    CC_SAFE_RELEASE_NULL(this->ticToePointArray);
    CC_SAFE_RELEASE_NULL(this->freeSlotsArray);
}


void BBTicToeGamePlay::initialiseVariables()
{
    //array initialisation
    
    this->ticToePointArray=CCPointArray::create(10);
    this->ticToePointArray->retain();
    //
    this->freeSlotsArray=CCArray::create();
    this->freeSlotsArray->retain();
    
    //two player
    this->isFirstPlayeTurn=true;
    
    //single player
    this->isCpuTurn=false;
    this->isSpriteAddedInitiallyInIpadVsPlayerMode=false;
    
    this->noOfBoxsFilled=0;
    this->isGameOver=false;
    this->isLabelAdded=false;
    
    //default sprite
    this->isPlayerSelectedXsprite=true;
    
    this->isDifficultModePlay=true;
    
    for(int i=0;i<9;i++)
    {
        index[i]=kNoSprite;
    }
    
    
    int gameMode=CCUserDefault::sharedUserDefault()->getIntegerForKey("gameMode");
    
    if(gameMode==1)
    {
        this->isTwoPlayer=true;
        this->isPlayerVsIad=false;
        this->isIpadVsPlayer=false;
    }
    else if(gameMode==2)
    {
        this->isIpadVsPlayer=true;
        this->isPlayerVsIad=false;
        this->isTwoPlayer=false;
        
    }
    else
    {
        this->isPlayerVsIad=true;
        this->isIpadVsPlayer=false;
        this->isTwoPlayer=false;
        
    }
    
    //for storing 9 points in array
    float xPos=167;
    float yPos=244;
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        xPos=355;
        yPos=528;
    }
    CCPoint touchPoint;
    for(int i=1;i<10;i++)
    {
        touchPoint.x=xPos;
        touchPoint.y=yPos;
        this->ticToePointArray->addControlPoint(touchPoint);
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            if(i%3==0)
            {
                xPos=355;
                yPos=yPos-135;
            }
            else{
                xPos=xPos+150;
            }
        }
        else
        {
            if(i%3==0)
            {
                xPos=165;
                yPos=yPos-74;
            }
            else{
                xPos=xPos+74;
                
            }
            
        }
    }
}


#pragma mark - Add UI
void BBTicToeGamePlay::addTicToeBackGround()
{
    winsize = CCDirector::sharedDirector()->getWinSize();
    CCSprite *bg = CCSprite::create("BBSharedResources/BackGrounds/BG.png");
    bg->setPosition(CCPointMake(winsize.width/2, winsize.height/2));
    this->addChild(bg);
    
    CCSprite *ticToeBg=CCSprite::createWithSpriteFrameName("tictactoe_copy.png");
    ticToeBg->setPosition(CCPointMake(winsize.width/2, winsize.height/2+10));
    this->addChild(ticToeBg,2);
    
    int gameMode=CCUserDefault::sharedUserDefault()->getIntegerForKey("gameMode");
    if(gameMode==1)
    {
        selectPlayerBg=CCSprite::createWithSpriteFrameName("twoPlayers.png");
        
    }
    else if(gameMode==2){
        selectPlayerBg=CCSprite::createWithSpriteFrameName("ipadVsPlayer.png");
        
    }
    else{
        selectPlayerBg=CCSprite::createWithSpriteFrameName("playerVsIpad.png");
        
    }
    
    selectPlayerBg->setScale(0.5);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        selectPlayerBg->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2+160));
    }
    else
    {
        selectPlayerBg->setPosition(CCPointMake(408, 240));
        
    }
    this->addChild(selectPlayerBg,2);
    
    
    //add x button
    CCSprite *normalSprite=CCSprite::createWithSpriteFrameName("X_OFF.png");
    CCSprite *selectedSprite=CCSprite::createWithSpriteFrameName("X_ON.png");
    
    xMenuItem=CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(BBTicToeGamePlay::action));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        xMenuItem->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2+10));
    }
    else
    {
        xMenuItem->setPosition(CCPointMake(407, 163));
        
    }
    xMenuItem->setTag(1);
    
    
    //add o button
    normalSprite=CCSprite::createWithSpriteFrameName("o_Off.png");
    selectedSprite=CCSprite::createWithSpriteFrameName("o_ON.png");
    
    oMenuItem=CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(BBTicToeGamePlay::action));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        oMenuItem->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2-140));
    }
    else
    {
        oMenuItem->setPosition(CCPointMake(407, 100));
        
    }
    oMenuItem->setTag(2);
    
    
    //add restart button
    
    normalSprite=CCSprite::createWithSpriteFrameName("PlayAgain_restart.png");
    selectedSprite=CCSprite::createWithSpriteFrameName("PlayAgain_restart_off.png");
    
    restartMenuItem=CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(BBTicToeGamePlay::action));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        restartMenuItem->setPosition(CCPointMake(winsize.width/2-400, winsize.height/2+80));
    }
    else
    {
        restartMenuItem->setPosition(CCPointMake(winsize.width/2 - 200, winsize.height/2 + 40));
        
    }
    restartMenuItem->setTag(3);
    
    
    //menu
    buttonMenu=CCMenu::create(xMenuItem,oMenuItem,NULL);
    buttonMenu->setPosition(CCPointZero);
    this->addChild(buttonMenu, 2);
    
    //temp restart button menu
    CCMenu *tempMenu=CCMenu::create(restartMenuItem,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
    
    
    //add back button
    normalSprite=CCSprite::createWithSpriteFrameName("control.png");
    
    CCMenuItemSprite *backMenuItem=CCMenuItemSprite::create(normalSprite, normalSprite, this, menu_selector(BBTicToeGamePlay::action));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        backMenuItem->setPosition(CCPointMake(winsize.width/2-400, winsize.height/2+290));
    }
    else
    {
        backMenuItem->setPosition(CCPointMake(45, 290));
        
    }
    backMenuItem->setTag(999);
    
    CCMenu *selectMenu=CCMenu::create(backMenuItem,NULL);
    selectMenu->setPosition(CCPointZero);
    this->addChild(selectMenu,2);
    
    
    this->schedule(schedule_selector(BBTicToeGamePlay::applyBlinkAction), 0.5);
    
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        bazziTalking->initialize(this,CCPoint(35,38));
    }
    actionTag = 5000;
    

    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        CCSprite *dogBase=CCSprite::createWithSpriteFrameName("dog_base.png");
        dogBase->setPosition(CCPointMake(80,48));   //117.9 48
        this->addChild(dogBase);
    }
    
    this->addStars();
    
}

#pragma mark - Two Player Function
void BBTicToeGamePlay::addSpriteOnTouchedPoint(int currentIndex)
{
    if(this->isFirstPlayeTurn)
    {
        this->addSpriteOfType(this->isPlayerSelectedXsprite, currentIndex, kPlayerSpriteAdded);
        this->isFirstPlayeTurn=false;
    }
    else {
        
        this->addSpriteOfType(!this->isPlayerSelectedXsprite, currentIndex, kCpuSpriteAdded);
        this->isFirstPlayeTurn=true;
    }
}

#pragma mark - Single Player Functions
void BBTicToeGamePlay:: addDelayActionAfterPlayerTurn()
{
    CCDelayTime *actionDelay = CCDelayTime::create(0.5f);
    CCSequence *actionSequence = CCSequence::createWithTwoActions(actionDelay, CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addComputerPlayedSprite)));
    this->runAction(actionSequence);
}

void BBTicToeGamePlay::addComputerPlayedSprite()
{
    if(this->isGameOver)
    {
        return;
    }
    
    int currentIndex=this->getFreeIndex();
    
    this->addSpriteOfType(!this->isPlayerSelectedXsprite, currentIndex, kCpuSpriteAdded);
    
    
    this->isCpuTurn=false;
}

int BBTicToeGamePlay::getFreeIndex()
{
    int selectedFreeIndex;
    
    //select Random value if only 2 boxes filled
    if(noOfBoxsFilled<2)
    {
        return selectedFreeIndex=this->getEasyModeIndex();
    }
    if(this->isDifficultModePlay)
    {
        selectedFreeIndex=this->getDangerIndex(kCpuSpriteAdded);
        
        if(selectedFreeIndex==kNoDangerousIndex)
        {
            selectedFreeIndex=this->getDangerIndex(kPlayerSpriteAdded);
        }
        if(selectedFreeIndex==kNoDangerousIndex)
        {
            selectedFreeIndex=this->getEasyModeIndex();
        }
    }
    
    return selectedFreeIndex;
}

int BBTicToeGamePlay::getEasyModeIndex()
{
    if(this->freeSlotsArray->count()>0)
    {
        this->freeSlotsArray->removeAllObjects();
    }
    for(int i=0;i<9;i++)
    {
        if(index[i]==kNoSprite)
        {
            cocos2d_extensions::CCNumber<int> *intOne = cocos2d_extensions::CCNumber<int>::numberWithValue(i);
            this->freeSlotsArray->addObject(intOne);
        }
    }
    int randomNumber=(arc4random()%this->freeSlotsArray->count());
    
    cocos2d_extensions::CCNumber<int> * selectedCoordinateInt = (cocos2d_extensions::CCNumber<int> *)freeSlotsArray->objectAtIndex(randomNumber);
    int value = selectedCoordinateInt->getValue();
    
    return value;
    
}


int BBTicToeGamePlay::getDangerIndex(int type)
{
    int compIndex=0;
    
    //1
    if(index[0]==type&&index[1]==type)
    {
        if(index[2]==kNoSprite)
        {
            return compIndex=2;
        }
        else
            goto step2;
        
    }
    //2
    step2:
    if(index[1]==type&&index[2]==type)
    {
        if(index[0]==kNoSprite)
        {
            return compIndex=0;
        }
        else
            goto step3;
    }
    //3
    step3:
    if(index[0]==type&&index[3]==type)
    {
        if(index[6]==kNoSprite)
        {
            return compIndex=6;
        }
        else
            goto step4;
    }
    //4
    step4:
    if(index[3]==type&&index[6]==type)
    {
        if(index[0]==kNoSprite)
        {
            return compIndex=0;
        }
        else
            goto step5;
    }
    //5
    step5:
    if(index[6]==type&&index[7]==type)
    {
        if(index[8]==kNoSprite)
        {
            return compIndex=8;
        }
        else
            goto step6;
    }
    //6
    step6:
    if(index[7]==type&&index[8]==type)
    {
        if(index[6]==kNoSprite)
        {
            return compIndex=6;
        }
        else
            goto step7;
    }
    //7
    step7:
    if(index[5]==type&&index[8]==type)
{
    if(index[2]==kNoSprite)
    {
        return compIndex=2;
    }
    else
        goto step8;
}
    //8
    step8:
    if(index[2]==type&&index[5]==type)
    {
        if(index[8]==kNoSprite)
        {
            return compIndex=8;
        }
        else
            goto step9;
    }
    //9
    step9:
    if(index[1]==type&&index[4]==type)
    {
        if(index[7]==kNoSprite)
        {
            return compIndex=7;
        }
        else
            goto step10;
    }
    //10
    step10:
    if(index[4]==type&&index[7]==type)
    {
        if(index[1]==kNoSprite)
        {
            return compIndex=1;
        }
        else
            goto step11;
    }
    //11
    step11:
    if(index[3]==type&&index[4]==type)
    {
        if(index[5]==kNoSprite)
        {
            return compIndex=5;
        }
        else
            goto step12;
    }
    //12
    step12:
    if(index[4]==type&&index[5]==type)
    {
        if(index[3]==kNoSprite)
        {
            return compIndex=3;
        }
        else
            goto step13;
    }
    //13
    step13:
    if(index[0]==type&&index[4]==type)
    {
        if(index[8]==kNoSprite)
        {
            return compIndex=8;
        }
        else
            goto step14;
    }
    //14
    step14:
    if(index[4]==type&&index[8]==type)
    {
        if(index[0]==kNoSprite)
        {
            return  compIndex=0;
        }
        else
            goto step15;
    }
    //15
    step15:
    if(index[2]==type&&index[4]==type)
    {
        if(index[6]==kNoSprite)
        {
            return compIndex=6;
        }
        else
            goto step16;
    }
    //16
    step16:
    if(index[4]==type&&index[6]==type)
    {
        if(index[2]==kNoSprite)
        {
            return compIndex=2;
        }
        else
            goto step17;
    }
    //17
    step17:
    if(index[0]==type&&index[2]==type)
    {
        if(index[1]==kNoSprite)
        {
            return compIndex=1;
        }
        else
            goto step18;
    }
    //18
    step18:
    if(index[0]==type&&index[6]==type)
    {
        if(index[3]==kNoSprite)
        {
            return compIndex=3;
        }
        else
            goto step19;
    }
    //19
    step19:
    if(index[6]==type&&index[8]==type)
    {
        if(index[7]==kNoSprite)
        {
            return compIndex=7;
        }
        else
            goto step20;
    }
    //20
    step20:
    if(index[2]==type&&index[8]==type)
    {
        if(index[5]==kNoSprite)
        {
            return compIndex=5;
        }
        else
            goto step21;
    }
    //21
    step21:
    if(index[1]==type&&index[7]==type)
    {
        if(index[4]==kNoSprite)
        {
            return compIndex=4;
        }
        else
            goto step22;
    }
    //22
    step22:
    if(index[3]==type&&index[5]==type)
    {
        if(index[4]==kNoSprite)
        {
            return compIndex=4;
        }
        else
            goto step23;
    }
    //23
    step23:
    if(index[1]==type&&index[8]==type)
    {
        if(index[4]==kNoSprite)
        {
            return compIndex=4;
        }
        else
            goto step24;
    }
    //24
    step24:
    if(index[2]==type&&index[6]==type)
    {
        if(index[4]==kNoSprite)
        {
            return compIndex=4;
        }
        
    }
    //if no matches
    return kNoDangerousIndex;
}

#pragma mark - Common Functions
void BBTicToeGamePlay::addSpriteOfType(bool isXType,int currentIndex,int filledIndexType)
{
    CCSprite *aSprite;
    if(isXType)
    {
        
        aSprite=CCSprite::createWithSpriteFrameName("X_ON.png");
        this->oMenuItem->selected();
        this->xMenuItem->unselected();
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/x_plays.mp3");
        
    }
    else{
        aSprite=CCSprite::createWithSpriteFrameName("o_ON.png");
        this->xMenuItem->selected();
        this->oMenuItem->unselected();
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/o_plays.mp3");
        
    }
    
    CCPoint pos=this->ticToePointArray->getControlPointAtIndex(currentIndex);
    aSprite->setPosition(pos);
    this->addChild(aSprite,1);
    index[currentIndex]=filledIndexType;
    
    this->noOfBoxsFilled++;
    
    
    bool isWon=this->checkGameResult(filledIndexType);
    if(isWon)
    {
        if(filledIndexType==kPlayerSpriteAdded)
        {
            if(this->isPlayerSelectedXsprite)
            {
                this->addLabel("X Wins!");
                
            }
            else{
                this->addLabel("O Wins!");
            }
            //   CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("BBSounds/DogAnimSounds/clapping.mp3");
            
            CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/winner_tic.mp3");
            
        }
        else{
            
            if(this->isPlayerSelectedXsprite)
            {
                this->addLabel("O Wins!");
            }
            else{
                
                this->addLabel("X Wins!");
            }
            
            
            if(!this->isTwoPlayer)
            {
                //  CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("BBSounds/DogAnimSounds/okaytryagain.mp3");
                //    this->mAnimationManager->runAnimationsForSequenceNamed("DogTryAgain");
                
            }
            else
            {
                //  CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("BBSounds/DogAnimSounds/clapping.mp3");
                //     this->mAnimationManager->runAnimationsForSequenceNamed("DogClap");
                
            }
            
        }
        this->isGameOver=true;
        this->isLabelAdded=true;
        this->schedule(schedule_selector(BBTicToeGamePlay::addBlinkActionForRefreshButton), 0.5);
        
        
        
    }
    if(this->noOfBoxsFilled==9&&!isWon)
    {
        this->addLabel("You tied!");
        this->isGameOver=true;
        
        this->isLabelAdded=true;
        this->schedule(schedule_selector(BBTicToeGamePlay::addBlinkActionForRefreshButton), 0.5);
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/tied_game_tic.mp3");
    }
    
    
    
}
void BBTicToeGamePlay::applyBlinkAction(float dt)
{
    if(this->oMenuItem->isSelected())
    {
        this->oMenuItem->unselected();
        this->xMenuItem->selected();
    }
    else{
        this->oMenuItem->selected();
        this->xMenuItem->unselected();
    }
    
}
void BBTicToeGamePlay::addBlinkActionForRefreshButton(float dt)
{
    if(this->restartMenuItem->isSelected())
    {
        this->restartMenuItem->unselected();
    }
    else{
        this->restartMenuItem->selected();
    }
}

void BBTicToeGamePlay::action(cocos2d::CCMenuItemImage *sender)
{
    int tag=sender->getTag();
    winsize=CCDirector::sharedDirector()->getWinSize();
    switch (tag)
    {
        case 1: //xMenu item
            
            this->xMenuItem->selected();
            this->oMenuItem->unselected();
            
            this->unschedule(schedule_selector(BBTicToeGamePlay::applyBlinkAction));
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                xMenuItem->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2+10));
                oMenuItem->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2-140));
            }
            else
            {
                xMenuItem->setPosition(CCPointMake(407, 100));
                oMenuItem->setPosition(CCPointMake(407, 163));
                
            }
            this->isPlayerSelectedXsprite=true;
            //disable Menu
            this->buttonMenu->setEnabled(false);
            //Add Initial Sprite If ipadVsPlayer Mode
            if(this->isIpadVsPlayer)
            {
                CCDelayTime *actionDelay = CCDelayTime::create(0.5f);
                CCSequence *actionSequence = CCSequence::createWithTwoActions(actionDelay, CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addComputerPlayedSprite)));
                this->runAction(actionSequence);
                this->isSpriteAddedInitiallyInIpadVsPlayerMode=true;
            }
            break;
        case 2://oMenu item
            
            this->xMenuItem->unselected();
            this->oMenuItem->selected();
            
            
            this->unschedule(schedule_selector(BBTicToeGamePlay::applyBlinkAction));
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                this->oMenuItem->setPosition(CCPointMake( winsize.width/2+355, winsize.height/2+10));
                this->xMenuItem->setPosition(CCPointMake(winsize.width/2+355, winsize.height/2-140));
            }
            else
            {
                this->oMenuItem->setPosition(CCPointMake(407, 163));
                this->xMenuItem->setPosition(CCPointMake( 407, 100));
                
            }
            this->isPlayerSelectedXsprite=false;
            //disable Menu
            this->buttonMenu->setEnabled(false);
            if(this->isIpadVsPlayer)
            {
                CCDelayTime *actionDelay = CCDelayTime::create(0.5f);
                CCSequence *actionSequence = CCSequence::createWithTwoActions(actionDelay, CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addComputerPlayedSprite)));
                this->runAction(actionSequence);
                this->isSpriteAddedInitiallyInIpadVsPlayerMode=true;
            }
            
            break;
        case 3://temp restart
            
            CCDirector::sharedDirector()->replaceScene(BBTicToeGamePlay::scene());
            CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/restart_match.mp3");
            break;
            
            
        case 999://games button
//            CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/tictactoe_backhome.mp3");
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            if(isDogTalking)
            {
                CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
                callStopDogAnimation();
            }
            BBTicTacTocManager::sharedManager()->isNewGame = true;
            BBSharedSoundManager::sharedManager()->playGameButtonSound();
            BBMatchDataManager::sharedManager()->starCount = 0;
            CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
            break;
            
            
        default:
            break;
    }
    
}

bool BBTicToeGamePlay::checkGameResult(int type)
{
    CCDelayTime *actionDelay = CCDelayTime::create(0.2f);
    if((index[0]==type&&index[1]==type&&index[2]==type))
    {
        this->indexPoint=1;
        this->rotatingAngle=90;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[3]==type&&index[4]==type&&index[5]==type)
    {
        this->indexPoint=4;
        this->rotatingAngle=90;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[6]==type&&index[7]==type&&index[8]==type)
    {
        this->indexPoint=7;
        this->rotatingAngle=90;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[0]==type&&index[3]==type&&index[6]==type)
    {
        this->indexPoint=3;
        this->rotatingAngle=0;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[1]==type&&index[4]==type&&index[7]==type)
    {
        this->indexPoint=4;
        this->rotatingAngle=0;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[2]==type&&index[5]==type&&index[8]==type)
    {
        this->indexPoint=5;
        this->rotatingAngle=0;
        this->scalingFactor=1.35;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[0]==type&&index[4]==type&&index[8]==type)
    {
        this->indexPoint=4;
        this->rotatingAngle=-45;
        this->scalingFactor=1.65;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else if(index[2]==type&&index[4]==type&&index[6]==type)
    {
        this->indexPoint=4;
        this->rotatingAngle=45;
        this->scalingFactor=1.65;
        CCSequence *seq=CCSequence::createWithTwoActions(actionDelay,CCCallFuncN::create(this, callfuncN_selector(BBTicToeGamePlay::addLine)));
        this->runAction(seq);
        return true;
    }
    else
        
        return false;
    
}
void BBTicToeGamePlay::addLine()
{
    CCPoint point=this->ticToePointArray->getControlPointAtIndex(this->indexPoint);
    CCSprite *lineSprite=CCSprite::createWithSpriteFrameName("winLine.png");
    lineSprite->setRotation(this->rotatingAngle);
    lineSprite->setPosition(point);
    
    
    lineSprite->setScaleY(this->scalingFactor);
    this->addChild(lineSprite, 3);
    
    CCDelayTime *delayAction=CCDelayTime::create(0.2);
    CCBlink *blinkAction=CCBlink::create(1, 3);
    CCSequence *seq=CCSequence::createWithTwoActions(delayAction, blinkAction);
    lineSprite->runAction(seq);
    
}
void BBTicToeGamePlay::addLabel(const char *labelname)
{
    if(this->isLabelAdded)
    {
        this->header->removeFromParentAndCleanup(1);
    }
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        header=CCLabelTTF::create(labelname, "Noteworthy-Bold", 75);
        header->setPosition(CCPointMake(512, 680));
    }
    else
    {
        header=CCLabelTTF::create(labelname, "Noteworthy-Bold", 28);
        header->setPosition(CCPointMake(240,295));
    }
    this->addChild(header,2);
    this->isLabelAdded=false;
}
void BBTicToeGamePlay::checkForGameMode(CCPoint location)
{
    CCRect selectGameModeBGRect=selectPlayerBg->boundingBox();
    if(selectGameModeBGRect.containsPoint(location))
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/player_mode_tic.mp3");
        if(this->isPlayerVsIad)
        {
            selectPlayerBg->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("ipadVsPlayer.png"));
            this->isIpadVsPlayer=true;
            this->isPlayerVsIad=false;
            this->isTwoPlayer=false;
            
        }
        else if(this->isIpadVsPlayer)
        {
            selectPlayerBg->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("twoPlayers.png"));
            this->isTwoPlayer=true;
            this->isPlayerVsIad=false;
            this->isIpadVsPlayer=false;
            
            
        }
        else if(this->isTwoPlayer)
        {
            selectPlayerBg->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("playerVsIpad.png"));
            this->isTwoPlayer=false;
            this->isPlayerVsIad=true;
            this->isIpadVsPlayer=false;
            
        }
        
    }
    
    
}

#pragma mark - Touches
void BBTicToeGamePlay::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
    if(this->noOfBoxsFilled==9||this->isGameOver||this->isCpuTurn)
    {
        return;
    }
    CCSetIterator it;
    CCTouch* touch;
    
    bool isPlayerCanAddSprite=true;
    for( it = pTouches->begin(); it != pTouches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        //Add IntialSprite if Mode is IpadVsPlay
        CCRect selectGameModeBGRect=selectPlayerBg->boundingBox();
        if(!this->isSpriteAddedInitiallyInIpadVsPlayerMode&&this->isIpadVsPlayer&&!selectGameModeBGRect.containsPoint(location))
        {
            this->isPlayerSelectedXsprite=false;
            this->addComputerPlayedSprite();
            this->isSpriteAddedInitiallyInIpadVsPlayerMode=true;
            isPlayerCanAddSprite=false;
        }
        //selectGamePlay Mode
        if(this->buttonMenu->isEnabled())
        {
            this->checkForGameMode(location);
        }
        
        
        //GamePlay
        for(int i=0;i<this->ticToePointArray->count();i++)
        {
            CCPoint point=this->ticToePointArray->getControlPointAtIndex(i);
            CCRect bgRect;
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                bgRect =CCRectMake(point.x-75, point.y-55, 150, 110);
            }
            else
            {
                bgRect =CCRectMake(point.x-60, point.y-40, 75, 55);
            }
            
            if(bgRect.containsPoint(location)&&index[i]==kNoSprite)
            {
                this->unschedule(schedule_selector(BBTicToeGamePlay::applyBlinkAction));
                this->buttonMenu->setEnabled(false);
                if(this->isTwoPlayer)//--------------------------------------------Two player
                {
                    this->addSpriteOnTouchedPoint(i);
                    CCUserDefault::sharedUserDefault()->setIntegerForKey("gameMode", 1);
                    
                    
                }
                else
                {
                    if(this->isPlayerVsIad) //----------------------------------------------------------Single player
                    {
                        this->addSpriteOfType(this->isPlayerSelectedXsprite, i, kPlayerSpriteAdded);
                        
                        this->isCpuTurn=true;
                        
                        this->addDelayActionAfterPlayerTurn();
                        CCUserDefault::sharedUserDefault()->setIntegerForKey("gameMode", 3);
                        
                        
                    }
                    else if(this->isIpadVsPlayer)
                    {
                        if(isPlayerCanAddSprite)
                        {
                            this->addSpriteOfType(this->isPlayerSelectedXsprite, i, kPlayerSpriteAdded);
                            
                            this->isCpuTurn=true;
                            
                            this->addDelayActionAfterPlayerTurn();
                            CCUserDefault::sharedUserDefault()->setIntegerForKey("gameMode", 2);
                            
                            
                        }
                        
                    }
                }
                
                
            }
        }
    
        CCRect bBox = bazziTalking->animatedDog->boundingBox();
        
        if(bBox.containsPoint(this->convertTouchToNodeSpace(touch)))
        {
            this->sayHint();
        }
    
    }
    
}

#pragma mark - Dog Animation Methods

void BBTicToeGamePlay::callStopDogAnimation()
{
    bazziTalking->stopDogTalking();
    isDogTalking = false;
    this->setTouchEnabled(true);
}

//play the intro animation of the dog Talking.
void BBTicToeGamePlay::playIntro()
{
    switch (introSeq)
    {
        case 1:
        {
            this->setTouchEnabled(false);
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobacciztictactoe.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.3),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::playIntro)),NULL);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
        case 2:
        {
            bazziTalking->stopDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.5),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::playIntro)),NULL);
            this->runAction(callBack);
        }
            break;
            
        case 3:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/toplaytictactoe.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(6.5),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::playIntro)),NULL);
            this->runAction(callBack);

        }
            break;
            
        case 4:
        {
            bazziTalking->stopDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.5),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::playIntro)),NULL);
            this->runAction(callBack);
        }
            break;
            
        case 5:
        {
            bazziTalking->startDogTalking();
            
            int i = arc4random()%1;
            
            if(i == 0)
            {
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/chooseifyouwantxoro_tic.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.8),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
                this->runAction(callBack);
            }
            else
            {
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/chooseyour_avatar_tic.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
                this->runAction(callBack);
            }
            

        }
            break;
    }
    
    introSeq++;
}


void BBTicToeGamePlay::sayHint()
{
    int i = arc4random() % 3;
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }
    
    
    if (i == 0)
    {
        bazziTalking->startDogTalking();
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/youwinifyou.mp3");
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(5.0),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        isDogTalking = true;
    }
    
    if(i == 1)
    {
        bazziTalking->startDogTalking();
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/ifyoucantwin_tic.mp3");
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(4.0),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        isDogTalking = true;
    }
    
    if(i == 2)
    {
//        bazziTalking->startDogTalking();
//        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/ifnotsureofrightmatch.mp3");
//        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.8),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
//        callBack->setTag(actionTag);
//        this->runAction(callBack);
//        isDogTalking = true;
    }
    
}



# pragma mark - stars
void BBTicToeGamePlay::addStars()
{
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        xPos=300;
        yPos=35;
    }
    else
    {
        xPos=125;
        yPos=10; //25
    }
    
    
    for(int i=0;i<BBMatchDataManager::sharedManager()->starCount;i++)
    {
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        //   starEmptySprite->setAnchorPoint(ccp(.5,.5));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
    for(int i=0;i<10-BBMatchDataManager::sharedManager()->starCount;i++)
    {
        starEmptySprite=CCSprite::createWithSpriteFrameName("star_white.png");
        //       starEmptySprite->setAnchorPoint(ccp(.5,.5));
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
}

void BBTicToeGamePlay::addNewStar()
{
    BBSharedSoundManager::sharedManager()->playOnStarAnimation();
    
    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.8),CCCallFunc::create(this,callfunc_selector(BBTicToeGamePlay::callStopDogAnimation)),NULL);
    this->runAction(callBack);
    
    CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        starSprite->setPosition(ccp(300+((BBMatchDataManager::sharedManager()->starCount)*50),35));
    }
    else
    {
        starSprite->setPosition(ccp(125+((BBMatchDataManager::sharedManager()->starCount)*25),10/*25*/));
    }
    this->addChild(starSprite,20);
    
    CCRotateBy *rotate = CCRotateBy::create(.8, 430);
    
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.2, 3.2);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.1, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    //
    //
    CCFadeOut *fadeout = CCFadeOut::create(0.2);
    CCFadeIn *fadeIN = CCFadeIn::create(0.1);
    //        //              //  if(starSprite)
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
    CCSequence *seq1 = CCSequence::create(fadeout,fadeIN,NULL);
    CCSequence *seq2 = CCSequence::create(fadeout,fadeIN,NULL);
    //
    CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.2),  seq2,NULL);
    starSprite->runAction(seq3);
    BBMatchDataManager::sharedManager()->starCount++;
    
}



