//
//  BaccizBooksAppDelegate.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 08/02/13.
//  Copyright __MyCompanyName__ 2013. All rights reserved.
//

#include "AppDelegate.h"
#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "BBGameSelection.h"
#include "BBMainDataManager.h"

USING_NS_CC;
using namespace CocosDenshion;

AppDelegate::AppDelegate()
{
        
}

AppDelegate::~AppDelegate()
{
        
}

bool AppDelegate::applicationDidFinishLaunching()
{
        
        
        // initialize director
        CCDirector *pDirector = CCDirector::sharedDirector();
        pDirector->setOpenGLView(CCEGLView::sharedOpenGLView());
        
        // turn on display FPS
        // pDirector->setDisplayStats(true);
        
        CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
        
        CCSize designSize;
        CCSize resourceSize;
        CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
        
        std::vector<std::string> searchPaths;
                
        BBMainDataManager::sharedManager()->target = getTargetPlatform();
        
        if (BBMainDataManager::sharedManager()->target == kTargetIphone)
        {
                if (screenSize.height > 320) //iPhone Retina
                {
                        resourceSize = CCSizeMake(960, 640);
                        searchPaths.push_back("ipad-Normal");
                }
                else
                {
                        resourceSize = CCSizeMake(480, 320);
                        // searchPaths.push_back("Iphone");
                }
                designSize = CCSizeMake(480,320);
        }
        else if (BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
                if(screenSize.height > 768) //ipadRetina
                {
                        resourceSize = CCSizeMake(2048, 1536);
                        searchPaths.push_back("ipad-HD");
                }
                else{
                        resourceSize = CCSizeMake(1024, 768);
                        searchPaths.push_back("ipad-Normal");
                }
                designSize = CCSizeMake(1024,768);
        }
        pFileUtils->setSearchPaths(searchPaths);
        
        pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
        CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
        
        pDirector->setAnimationInterval(1.0 / 60);
        
        // create a scene. it's an autorelease object
        CCScene *pScene = BBGameSelection::scene();
        pDirector->runWithScene(pScene);
        
        
        return true;
}

// This function will be called when the app is inactive. When comes a phone call,it's be invoked too
void AppDelegate::applicationDidEnterBackground()
{
        CCDirector::sharedDirector()->stopAnimation();
        SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
        SimpleAudioEngine::sharedEngine()->pauseAllEffects();
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground()
{
        CCDirector::sharedDirector()->startAnimation();
        SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
        SimpleAudioEngine::sharedEngine()->resumeAllEffects();
}
