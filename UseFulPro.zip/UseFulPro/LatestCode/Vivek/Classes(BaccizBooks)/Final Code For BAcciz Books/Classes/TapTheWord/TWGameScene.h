//
//  TWGameScene.h
//  TapTheWords
//
//  Created by Deepthi on 28/03/13.
//
//

#ifndef TapTheWords_TWGameScene_h
#define TapTheWords_TWGameScene_h

#include "cocos2d.h"
#include "cocos-ext.h"
#include "CCBReader.h"
#include "BacciTalking.h"


USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;

class TWGameScene : public cocos2d::CCLayer
{
public:
        //Default
        TWGameScene();
        ~TWGameScene();
        
        virtual void onEnter();
        virtual void onExit();
        static CCScene* scene();
        
        //Dictionary Variables
        CCDictionary *gameDict;
        CCDictionary *levelSelection;
        CCArray *AnimalPositionArray;
        
        //Game Variables
        int *store_randomArray;
        
        CCSprite *selectedSpr;
        CCSprite *award;
        CCSprite *booble;
    
        CCLabelTTF *touchSprLabel;
        CCLabelTTF *selectedAnimalNam;
        
        CCArray *numberArray;
        CCArray *animalNameArray;
        CCArray  *selectItems;
        
        bool isCorrect;
        int tapCount;
        int count;
        int wrongTapCount;
             
        BacciTalking *bazziTalking;
        
        void callStopDogAnimation();
    
        void idleCheckTick();
    
        //Touch
        void ccTouchesBegan(CCSet* touches, CCEvent* event);
        
        //AfterFinishingLevel
        void playAgainFunc();
        void goBackFunc();
        void afterFinishingLevelFunc();

        
        //Game logic
        void generateRandomNoArray();
        void addAnimalNames();
        void intialiseGameUI();
        void chooseAnimal();
        
        
        void correctFuncAction();
        void wrongFuncAction();
        void twoTimeWrongMatchedSound();
        void remove(CCObject *sender);
        //replace
        void replaceScene();
         
        //star
        void addStars();
        void addNewStar();
        
        void addCongratulationBnner();
        
        //Stroke
        CCRenderTexture* createStroke(CCLabelTTF *label,int size,ccColor3B color);
        
        //sound
        void repeatSound();
        void setDelay();
        void initialiseSounds();
        void animalSound();
        
        CCMenuItemSprite *replaySoundBtn;
        CCMenuItemSprite *dogSpr;
        
        CCDictionary *selectedAnimalName;
        
        int *shuffleArray(int num[16]);
        
        CCLabelTTF *pageCount;
        CCLabelTTF  *title;
        int xPos;
        int yPos;
        int dogTalking;
        void initialDogAdviceFunc();
        CCSprite *tapSpr ;
        bool isDogTalking;
        bool canTap;
        bool isAddedCongratulationPopUp;
        void onTappingDog();
        void goBackToGameSelectionScene();
        void calladdingTrophyFunc();
        bool isGameFinished;
        void calStopDogAnimationAfterStarAnimation();
        void playTheSound();
        void scaleAnimalName(CCLabelTTF *animName);
        void playAgainFuncAfterDelay();

              
        CREATE_FUNC(TWGameScene);
};


#endif
