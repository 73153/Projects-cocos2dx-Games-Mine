//
//  BBDatamanager.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#include "BBPuzzleDataManager.h"
#include "cocos2d.h"

static BBPuzzleDataManager *gSharedManager = NULL;

BBPuzzleDataManager::BBPuzzleDataManager(void){
    
    gamePlaySound = true;
    canTapDog = true;
    
    starCount = 0;
    
    canPlayPuzzleGamePlaySound = true;
    isEmptyBoxSelected = false;
    
    isPuzzleGameOver = false;
    
    starArray = CCArray::create();
    starArray->retain();
}

BBPuzzleDataManager::~BBPuzzleDataManager(void){

    CC_SAFE_RELEASE_NULL(starArray);
}

BBPuzzleDataManager* BBPuzzleDataManager::sharedManager(void) {
    
	BBPuzzleDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBPuzzleDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBPuzzleDataManager::init(void) {
	return true;
}

