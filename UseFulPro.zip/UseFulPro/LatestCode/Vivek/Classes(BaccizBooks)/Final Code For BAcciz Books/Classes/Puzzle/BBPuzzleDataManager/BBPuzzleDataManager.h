//
//  BBDatamanager.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//


#include "cocos2d.h"
#include "CCBReader.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

class BBPuzzleDataManager: public CCObject  {
    
private:
    
    BBPuzzleDataManager(void);
    virtual ~BBPuzzleDataManager(void);
    
public:
    
    CCBReader *cocosBuilderReader;
    CCBReader *cocosBuilderAlphabetReader;
    CCNodeLoader *cocosBuilderLoader;
    
    bool init(void);

    static BBPuzzleDataManager* sharedManager(void);
    
    bool gamePlaySound;
    bool canPlayPuzzleGamePlaySound;
    bool canTapDog;
    bool isEmptyBoxSelected;
    bool isPuzzleGameOver;
    
    const char *puzzleName;
    const char *puzzleDifficultyTypeName;
    const char *puzzleDifficultyNumber;
    TargetPlatform target;
    
    int starCount;
    CCArray *starArray;
};


