//
//  BBPuzzleGameSelection.cpp
//  BaccizBooks
//
//  Created by Vivek on 13/02/13.
//
//


#include "BBPuzzleGameSelection.h"
#include "BBPuzzleGame.h"
#include "BBGameSelection.h"
#include "BBMainDataManager.h"
#include "BBSharedSoundManager.h"
#include "BBPuzzleDataManager.h"
#include "CustomTableViewCell.h"
#include "BacciTalking.h"

#define kPuzzleBGStartTag 555
#define kDifficultySoundTag 666

#include "SimpleAudioEngine.h"
using CocosDenshion::SimpleAudioEngine;

using namespace cocos2d;
USING_NS_CC;


CCScene* BBPuzzleGameSelection::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBPuzzleGameSelection();
    scene->addChild(layer);
    layer->release();
    
    return scene;
}

BBPuzzleGameSelection::BBPuzzleGameSelection() {
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeUnusedSpriteFrames();
    CCTextureCache::sharedTextureCache()->removeUnusedTextures();
        
    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();

    std::vector<std::string> searchPaths;
    CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();

    CCSize resourceSize;
    CCSize designSize;
    if (BBMainDataManager::sharedManager()->target == kTargetIphone)
    {
        if (screenSize.height > 320) //iPhone Retina
        {
            searchPaths.push_back("ipad-Normal/Puzzle");
            searchPaths.push_back("ipad-Normal");
            searchPaths.push_back("Puzzle");
        }
        else
        {
            searchPaths.push_back("Puzzle");
        }
    }
    else if (BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        if(screenSize.height > 768) //ipadRetina
        {
            searchPaths.push_back("ipad-HD/Puzzle");
            searchPaths.push_back("ipad-HD");
            searchPaths.push_back("ipad-Normal/Puzzle");

        }
        else{
            searchPaths.push_back("ipad-Normal/Puzzle");
            searchPaths.push_back("ipad-Normal");
        }
    }
    pFileUtils->setSearchPaths(searchPaths);
    //this->puzzleDifficultyLevel=0;
}


void BBPuzzleGameSelection::onEnter(){
    
    CCLayer::onEnter();
    
    //loading PuzzleMainPage plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GamePlaySpriteSheets/BBPuzzleGame/PuzzleMainPage.plist");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GamePlaySpriteSheets/BBPuzzleGame/PuzzleMainPageTwo.plist");
    
    //loading plist
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("Puzzle_Game.plist");
    CCDictionary *allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    
    this->allPuzzleListArr = (CCArray *)allCardInfoDict->valueForKey("GameTypes");
    
    
    //Play BG Sound
    if(SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
    {
        SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/puzzles_music.mp3", true);
    }
    
    
    //Dog base
    CCSprite *dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        dogBase->setPosition(CCPointMake(80, 48));
    }
    else
    {
        dogBase->setVisible(false);
    }
    this->addChild(dogBase,3);
    
    
    //puzzleWonAward Sprite
    puzzleWonAward = CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(puzzleWonAward,6);
    puzzleWonAward->setScale(0.7);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        puzzleWonAward->setPosition(ccp(522,190));
    }
    else
    {
        puzzleWonAward->setPosition(ccp(230,80));
        
    }
    puzzleWonAward->setVisible(false);
    
    this->addStars();
    
    if (BBPuzzleDataManager::sharedManager()->isPuzzleGameOver) {
    
        CCFiniteTimeAction *action = CCSequence::createWithTwoActions(CCDelayTime::create(0.1), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::addNewStar)));
        this->runAction(action);
    }
    
    //Bacci Talking
    bazziTalking = new BacciTalking();
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85, 128));
    }
    else if(CCDirector::sharedDirector()->getContentScaleFactor() == 2){
        
        bazziTalking->initialize(this,CCPoint(15, 20));
    }
    else
    {
        bazziTalking->initialize(this,CCPoint(15, 38));
    }
    
    
    //Play Sequence of Sounds
    if (BBPuzzleDataManager::sharedManager()->gamePlaySound == true)
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::welcomeToBaccizPuzzle)), NULL);
        this->runAction(Seq);
        
        CCSequence *Seq1 = CCSequence::create(CCDelayTime::create(3), CCCallFunc::create(this, callfunc_selector(BBPuzzleGameSelection::playPuzzleSound)), NULL);
        Seq1->setTag(1000);
        this->runAction(Seq1);
        
        //Look for the best path
        CCSequence *Seq2 = CCSequence::create(CCDelayTime::create(12), CCCallFunc::create(this, callfunc_selector(BBPuzzleGameSelection::selectDifficultySound)), NULL);
        Seq2->setTag(2000);
        this->runAction(Seq2);
        
        //Look for the Obstacles
        CCSequence *Seq3 = CCSequence::create(CCDelayTime::create(16), CCCallFunc::create(this, callfunc_selector(BBPuzzleGameSelection::chooseWhichPuzzle)), NULL);
        Seq3->setTag(3000);
        this->runAction(Seq3);
        
        CCSequence *Seq4 = CCSequence::create(CCDelayTime::create(19), CCCallFuncN::create(this,callfuncN_selector(BBPuzzleGameSelection::puzzlePutTogetherSound)), NULL);
        Seq4->setTag(4000);
        this->runAction(Seq4);
    }
    
    this->initializeDifficultyLvl();
    this->initializeUI();
    this->initializePuzzleList();
    
    //call to last SelectedPuzzle
    float lastPuzzleScrollOffsetPosX = CCUserDefault::sharedUserDefault()->getFloatForKey("lastPuzzleScrollOffsetPosX");
    
    this->loadLastPuzzleScrollOffset(lastPuzzleScrollOffsetPosX);
    
    //Set Visibility for Left & Right Arrow Buttons based on the last Offset
    if (BBMainDataManager::sharedManager()->target==kTargetIpad) {
        
        if (lastPuzzleScrollOffsetPosX==0) {
            leftArrowMenuItem->setVisible(false);
        }
        else if (lastPuzzleScrollOffsetPosX<=-3400) {
            rightArrowMenuItem->setVisible(false);
        }
    }
    else {
        
        if (lastPuzzleScrollOffsetPosX==0) {
            leftArrowMenuItem->setVisible(false);
        }
        else if (lastPuzzleScrollOffsetPosX==-1476) {
            rightArrowMenuItem->setVisible(false);
        }
    }
}

#pragma mark - Initialize
void BBPuzzleGameSelection::initializeDifficultyLvl()
{    
    winSize = CCDirector::sharedDirector()->getWinSize();
    
    //By Default 4 piece will be selected
//    SimpleAudioEngine::sharedEngine()->stopEffect(stopSoundForLevels);
    BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName = "FourPiece";
    
    this->spriteArray = CCArray::create();
    this->spriteArray->retain();
    
    //call to last gameLevel played
    puzzleDifficultyLevel = CCUserDefault::sharedUserDefault()->getIntegerForKey("puzzleDifficultyLevel");

    //Set the content offset to the entered content offset
    CCUserDefault::sharedUserDefault()->getStringForKey("gameContentOffset");
    
    CCObject *aPuzzleObj = NULL;
    CCARRAY_FOREACH(this->allPuzzleListArr, aPuzzleObj)
    {
        CCDictionary *aPuzzleDict = (CCDictionary *)aPuzzleObj;
        CCString *sprPuzzleChar = (CCString*)aPuzzleDict->valueForKey("labelName");
        spriteArray->addObject(sprPuzzleChar);
    }
}

void BBPuzzleGameSelection::initializeUI() {
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad){
         
        //Add BG
        CCSprite *bg = CCSprite::create("Puzzle/puzzle_background.png");
        bg->setPosition(CCPoint(winSize.width/2, winSize.height/2));
        this->addChild(bg);
        
        this->difficultyLevelButton();
        
        //add back button
        CCSprite *backBtn = CCSprite::createWithSpriteFrameName("control.png");
        
        CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(backBtn, backBtn, this, menu_selector(BBPuzzleGameSelection::backButtonSounds));
        backMenuItem->setPosition(CCPointMake(winSize.width/2-430, winSize.height/2+330));
        
        //Add Left & Right Button
        CCSprite *leftArrowSpr = CCSprite::createWithSpriteFrameName("back-slide-arrow.png");
        
        leftArrowMenuItem = CCMenuItemSprite::create(leftArrowSpr, leftArrowSpr, this, menu_selector(BBPuzzleGameSelection::leftArrowPressed));
        leftArrowMenuItem->setPosition(CCPointMake(50,440));
        leftArrowMenuItem->setScale(0.8);
        
        CCSprite *rightArrowSpr = CCSprite::createWithSpriteFrameName("front-slide-arrow.png");
        
        rightArrowMenuItem = CCMenuItemSprite::create(rightArrowSpr, rightArrowSpr, this, menu_selector(BBPuzzleGameSelection::rightArrowPressed));
        rightArrowMenuItem->setPosition(CCPointMake(975,440));
        rightArrowMenuItem->setScale(0.8);
        
        CCMenu *selectMenu = CCMenu::create(backMenuItem, leftArrowMenuItem, rightArrowMenuItem, NULL);
        selectMenu->setPosition(CCPointZero);
        this->addChild(selectMenu,2);
    }
    else {
        
        //Add BG
        CCSprite *bg = CCSprite::create("Puzzle/puzzle_background.png");
        bg->setPosition(CCPoint(240, 160));
        this->addChild(bg);
        
        this->difficultyLevelButton();
        
        //add back button
        CCSprite *backBtn = CCSprite::createWithSpriteFrameName("control.png");
        
        CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(backBtn, backBtn, this, menu_selector(BBPuzzleGameSelection::backButtonSounds));
        backMenuItem->setPosition(CCPointMake(winSize.width/2-200, winSize.height/2+135));
        
        //Add Left & Right Button
        CCSprite *leftArrowSpr = CCSprite::createWithSpriteFrameName("back-slide-arrow.png");
        
        leftArrowMenuItem = CCMenuItemSprite::create(leftArrowSpr, leftArrowSpr, this, menu_selector(BBPuzzleGameSelection::leftArrowPressed));
        leftArrowMenuItem->setPosition(CCPointMake(25, winSize.height/2+10));
        leftArrowMenuItem->setScale(0.8);
        
        CCSprite *rightArrowSpr = CCSprite::createWithSpriteFrameName("front-slide-arrow.png");
        
        rightArrowMenuItem = CCMenuItemSprite::create(rightArrowSpr, rightArrowSpr, this, menu_selector(BBPuzzleGameSelection::rightArrowPressed));
        rightArrowMenuItem->setPosition(CCPointMake(457, winSize.height/2+10));
        rightArrowMenuItem->setScale(0.8);
        
        CCMenu *selectMenu = CCMenu::create(backMenuItem, leftArrowMenuItem, rightArrowMenuItem, NULL);
        selectMenu->setPosition(CCPointZero);
        this->addChild(selectMenu,2);
    }
}


void BBPuzzleGameSelection::difficultyLevelButton()
{
    normalSprLevelSelection = CCSprite::createWithSpriteFrameName("Selection.png");
    this->addChild(normalSprLevelSelection,3);
    normalSprLevelSelection->setScale(1.1);
    
//    this->setDifficultyForLevel(puzzleDifficultyLevel);
    
    // OR ( if any probs in this check backUp projects) 
    
    if(puzzleDifficultyLevel == 0) 
        puzzleDifficultyLevel = 1;
    
    //to set the level selection mark on the difficulty level buttons
    this->setPositionForDifficultyLevelIndicator(puzzleDifficultyLevel);
    
    //to set the diffifulty level without touch we need to call this method
    this->getDifficultyLevelName(puzzleDifficultyLevel);
    
    CCArray *menuItemsArr = CCArray::create();
    menuItemsArr->retain();
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        int buttonPosX = 290;
        
        //Puzzle game Difficulty level selection
        for (int i=1; i <=4 ; i++) {
            
            char spriteName[15];
            sprintf(spriteName,"level%d.png",i);
            
            CCSprite *normalSprLevel = CCSprite::createWithSpriteFrameName(spriteName);
            CCSprite *selectedSprLevel = CCSprite::createWithSpriteFrameName(spriteName);
            
            CCMenuItemSprite *difficultyLevelBtn = CCMenuItemSprite::create(normalSprLevel, selectedSprLevel, this, menu_selector(BBPuzzleGameSelection::difficultyLevel));
            
            difficultyLevelBtn->setTag(i);
            difficultyLevelBtn->setPosition(ccp(buttonPosX,100));
            
            menuItemsArr->addObject(difficultyLevelBtn);
            
            buttonPosX = buttonPosX + 150;
        }
        
        CCMenu *menu = CCMenu::createWithArray(menuItemsArr);
        menu->setPosition(CCPointZero);
        addChild(menu,2);
    }
    else
    {
        int buttonPosX = 145;
        
        //Puzzle game Difficulty level selection
        for (int i=1; i<=4 ; i++) {
            
            char spriteName[15];
            sprintf(spriteName,"level%d.png",i);
            CCSprite *normalSprLevel = CCSprite::createWithSpriteFrameName(spriteName);
            CCSprite *selectedSprLevel = CCSprite::createWithSpriteFrameName(spriteName);
            
            CCMenuItemSprite *difficultyLevelBtn = CCMenuItemSprite::create(normalSprLevel, selectedSprLevel, this, menu_selector(BBPuzzleGameSelection::difficultyLevel));
            
            difficultyLevelBtn->setTag(i);
            difficultyLevelBtn->setPosition(ccp(buttonPosX,30));
            
            menuItemsArr->addObject(difficultyLevelBtn);
            buttonPosX = buttonPosX + 75;
        }
        
        CCMenu* menu = CCMenu::createWithArray(menuItemsArr);
        menu->setPosition(CCPointZero);
        addChild(menu,2);
    }
    CC_SAFE_RELEASE_NULL(menuItemsArr);
}


void BBPuzzleGameSelection::initializePuzzleList() {
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        CCSize winSize = CCDirector::sharedDirector()->getWinSize();
        //Add Table
        tableView = CCTableView::create(this, CCSizeMake(1020,500));
        tableView->setDirection(kCCScrollViewDirectionHorizontal);
        tableView->setPosition(ccp(0,winSize.height/2 - 200));
        tableView->setDelegate(this);
        this->addChild(tableView);
        tableView->reloadData();
        this->tableView->canMoveScroll = true;
    }
    else{
        
        CCSize winSize = CCDirector::sharedDirector()->getWinSize();
        //Add Table
        tableView = CCTableView::create(this, CCSizeMake(495, 230));
        tableView->setDirection(kCCScrollViewDirectionHorizontal);
        tableView->setPosition(ccp(0,winSize.height/2 - 110));
        tableView->setDelegate(this);
        this->addChild(tableView);
        tableView->reloadData();
        this->tableView->canMoveScroll = true;
    }
}

#pragma mark - Sounds
void BBPuzzleGameSelection::welcomeToBaccizPuzzle() {
    
    soundPlayPuzzle = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizpuzzles.mp3");
    
    bazziTalking->startDogTalking();
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(14), CCCallFunc::create(this, callfunc_selector(BBPuzzleGameSelection::stopDogTalking)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGameSelection::playPuzzleSound() {
    
    bazziTalking->startDogTalking();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundPlayPuzzle);
    soundPlayPuzzle = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/1_toplaypuzzlegame_puzzle.mp3");
}

void BBPuzzleGameSelection::selectDifficultySound() {
    
    //Bacci Pointing Right
    bazziTalking->createDogPointingRight();
    
    //set Visibility for Dog Talking
    bazziTalking->stopDogTalking();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundPlayPuzzle);
    soundDifficulty = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/2_selectdifficulty_level_dif.mp3");
    
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(CCDelayTime::create(1), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::setDogVisibility)));
    this->runAction(seq);
}

void BBPuzzleGameSelection::setDogVisibility() {
    
    //set Visibility for Dog Talking
    bazziTalking->setDogTalkingVisibility();
}

void BBPuzzleGameSelection::chooseWhichPuzzle() {
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundDifficulty);
    soundWhichPuzzle = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/3_choosewhich_puzzle.mp3");
    
    //Dog Talking
    bazziTalking->startDogTalking();
    
//    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(CCDelayTime::create(1), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::stopDogTalking)));
//    this->runAction(seq);
}

void BBPuzzleGameSelection::puzzlePutTogetherSound() {
    
//    SimpleAudioEngine::sharedEngine()->stopEffect(soundDifficulty);
//    soundDifficulty = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/3_puzzleyouwanttoputtogether_puzzle.mp3");
    
    bazziTalking->createDogPointingUp();
    
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(1), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::setDogVisibility)), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::stopDogTalking)), NULL);
    this->runAction(seq);
}

void BBPuzzleGameSelection::stopDogTalking() {
    
    bazziTalking->stopDogTalking();
}

void BBPuzzleGameSelection::startDogTalking() {
    
    bazziTalking->startDogTalking();
}

#pragma mark - Add Stars
void BBPuzzleGameSelection::addStars() {
    
    int xPos;
    int yPos;
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        xPos=230;
        yPos=715;
    }
    else
    {
        xPos=100;
        yPos=300;
    }
    
    for(int i=0; i<BBPuzzleDataManager::sharedManager()->starCount; i++){
        
        CCSprite *starFullSprite = CCSprite::createWithSpriteFrameName("star_yellow.png");
        starFullSprite->setTag(i);
        starFullSprite->setPosition(ccp(xPos, yPos));
        this->addChild(starFullSprite,4);
        
        BBPuzzleDataManager::sharedManager()->starArray->addObject(starFullSprite);
        
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
    for(int i=0; i<12-BBPuzzleDataManager::sharedManager()->starCount; i++){
        
        CCSprite *starEmptySprite = CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,3);
        starEmptySprite->setVisible(false);
        
        starEmptySprite->setTag(i);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
}

void BBPuzzleGameSelection::addNewStar() {
    
//    //Sound for Star
//    SimpleAudioEngine::sharedEngine()->stopAllEffects();
//    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/yougetastar.mp3");
    
    CCSprite *starSprite = CCSprite::createWithSpriteFrameName("star_yellow.png");
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        starSprite->setPosition(ccp(230+((BBPuzzleDataManager::sharedManager()->starCount)*50),715));
    }
    else
    {
        starSprite->setPosition(ccp(100+((BBPuzzleDataManager::sharedManager()->starCount)*25),300));
    }
    
    this->addChild(starSprite, 10);
    BBPuzzleDataManager::sharedManager()->starArray->addObject(starSprite);
    
    CCRotateTo *rotate = CCRotateTo::create(0.5, 720);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.16, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.16, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIn = CCFadeIn::create(0.1);
    
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq, NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut, fadeIn, NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut, fadeIn, NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr, seq1, CCDelayTime::create(0.25), seq2, NULL);
    starSprite->runAction(seq3);
    
    //increment star Count
    BBPuzzleDataManager::sharedManager()->starCount++;
    
    //Add a Award on the screen
    if(BBPuzzleDataManager::sharedManager()->starCount == 12){
        
        puzzleWonAward->setVisible(true);
    }
    else {
        
        puzzleWonAward->setVisible(false);
    }
    
    //Remove star from once it reaches the max count
    if (BBPuzzleDataManager::sharedManager()->starCount == 12) {
                
        for (int i=0; i<BBPuzzleDataManager::sharedManager()->starArray->count(); i++)
        {
            CCSprite *star = (CCSprite*)BBPuzzleDataManager::sharedManager()->starArray->objectAtIndex(i);
            this->removeChild(star, true);
        }
    }
}

#pragma mark - Touch
void BBPuzzleGameSelection::tableCellTouched(CCTableView* table, CCTableViewCell* cell){
    
    soundWhenPuzzleSelected = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/puzzle_choice_bbclack.mp3");
    
    //call to goToPuzzle method
    this->goToPuzzle(cell->getIdx());
}


#pragma mark - Table View Methods
CCSize BBPuzzleGameSelection::cellSizeForTable(CCTableView *table)
{
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        return CCSizeMake(340.0f,800);
    }
    else
    {
        return CCSizeMake(164.0f,350);
    }
}

void BBPuzzleGameSelection::loadLastPuzzleScrollOffset(float lastPuzzleScrollOffsetPosX) {
    
    this->tableView->setContentOffset(ccp(lastPuzzleScrollOffsetPosX, 0), false);
}


CCTableViewCell* BBPuzzleGameSelection::tableCellAtIndex(CCTableView *table, unsigned int idx)
{
    CCTableViewCell *cell = table->dequeueCell();
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        
        if (!cell) {
            cell = new CustomTableViewCell();
            cell->autorelease();
            
            //Get a Puzzle Item
            CCDictionary *aPuzzleItem = (CCDictionary *)this->allPuzzleListArr->objectAtIndex(idx);
            
            CCSprite *aPuzzleBG = CCSprite::createWithSpriteFrameName(aPuzzleItem->valueForKey("bgspriteFrameName")->getCString());
            aPuzzleBG->setAnchorPoint(CCPointZero);
            aPuzzleBG->setPosition(ccp(0,0));
            aPuzzleBG->setTag(kPuzzleBGStartTag);
            cell->addChild(aPuzzleBG,2);
            
//            CCLog("spriteFrameName %s",aPuzzleItem->valueForKey("spriteFrameName")->getCString());
            CCSprite *aPuzzle = CCSprite::createWithSpriteFrameName(aPuzzleItem->valueForKey("spriteFrameName")->getCString());
            aPuzzle->setScale(aPuzzleItem->valueForKey("scaleMainPageImage")->floatValue());
            aPuzzle->setPosition(ccp(aPuzzleBG->getContentSize().width/2, aPuzzleBG->getContentSize().height/2));
            aPuzzleBG->addChild(aPuzzle,2);
            aPuzzle->setTag(kPuzzleBGStartTag);
        }
        else
        {
            CCDictionary *aPuzzleItem = (CCDictionary *)this->allPuzzleListArr->objectAtIndex(idx);
            
            CCSpriteFrame *frameBG = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(aPuzzleItem->valueForKey("bgspriteFrameName")->getCString());
            CCSprite *aPuzzleBG = (CCSprite *)cell->getChildByTag(kPuzzleBGStartTag);
            aPuzzleBG->setDisplayFrame(frameBG);
            
            CCSpriteFrame *framePuzzle = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(aPuzzleItem->valueForKey("spriteFrameName")->getCString());
            CCSprite *aPuzzle = (CCSprite *)aPuzzleBG->getChildByTag(kPuzzleBGStartTag);
            aPuzzle->setDisplayFrame(framePuzzle);
            
            aPuzzle->setScale(aPuzzleItem->valueForKey("scaleMainPageImage")->floatValue());
        }
    }
    else
    {
        if (!cell) {
            cell = new CustomTableViewCell();
            cell->autorelease();
            
            //Get a Puzzle Item
            CCDictionary *aPuzzleItem = (CCDictionary *)this->allPuzzleListArr->objectAtIndex(idx);
            
            CCSprite *aPuzzleBG = CCSprite::createWithSpriteFrameName(aPuzzleItem->valueForKey("bgspriteFrameName")->getCString());
            aPuzzleBG->setAnchorPoint(CCPointZero);
            aPuzzleBG->setPosition(ccp(0,0));
            
            aPuzzleBG->setTag(kPuzzleBGStartTag);
            aPuzzleBG->setScale(0.9);
            cell->addChild(aPuzzleBG,2);
            CCSprite *aPuzzle = CCSprite::createWithSpriteFrameName(aPuzzleItem->valueForKey("spriteFrameName")->getCString());
            aPuzzle->setScale(aPuzzleItem->valueForKey("scaleMainPageImage")->floatValue());
            aPuzzle->setPosition(ccp(aPuzzleBG->getContentSize().width/2, aPuzzleBG->getContentSize().height/2));
            aPuzzleBG->addChild(aPuzzle,2);
            aPuzzle->setTag(kPuzzleBGStartTag);
            
        }
        else
        {
            CCDictionary *aPuzzleItem = (CCDictionary *)this->allPuzzleListArr->objectAtIndex(idx);
            
            CCSpriteFrame *frameBG = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(aPuzzleItem->valueForKey("bgspriteFrameName")->getCString());
            CCSprite *aPuzzleBG = (CCSprite *)cell->getChildByTag(kPuzzleBGStartTag);
            aPuzzleBG->setDisplayFrame(frameBG);
            
            CCSpriteFrame *framePuzzle = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(aPuzzleItem->valueForKey("spriteFrameName")->getCString());
            CCSprite *aPuzzle = (CCSprite *)aPuzzleBG->getChildByTag(kPuzzleBGStartTag);
            aPuzzle->setDisplayFrame(framePuzzle);
            
            aPuzzle->setScale(aPuzzleItem->valueForKey("scaleMainPageImage")->floatValue());
            aPuzzle->setScale(0.7);
        }
    }
    return cell;
}

unsigned int BBPuzzleGameSelection::numberOfCellsInTableView(CCTableView *table)
{
    return this->allPuzzleListArr->count();
}


void BBPuzzleGameSelection::scrollViewDidScroll(CCScrollView* view)
{
    float currentOffsetX = this->tableView->getContentOffset().x;
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        if(currentOffsetX>=-3 ) {
            
            leftArrowMenuItem->setVisible(false);
            rightArrowMenuItem->setVisible(true);
        }
        else if(currentOffsetX<=-325 && currentOffsetX>=-3058) {
            
            leftArrowMenuItem->setVisible(true);
            rightArrowMenuItem->setVisible(true);
        }
        else if(currentOffsetX<=-3070)
        {
            rightArrowMenuItem->setVisible(false);
        }
    }
    else { // iPhone
        
        if (currentOffsetX >= -3){
            leftArrowMenuItem->setVisible(false);
            rightArrowMenuItem->setVisible(true);
        }
        else if (currentOffsetX<=-160 && currentOffsetX>=-1475) {
            rightArrowMenuItem->setVisible(true);
            leftArrowMenuItem->setVisible(true);
        }
        else if(currentOffsetX<=-1640){
            rightArrowMenuItem->setVisible(false);
        }
    }
}

#pragma mark - Button Functions
void BBPuzzleGameSelection::leftArrowPressed(CCObject *sender)
{    
    if(this->tableView->canMoveScroll)
    {
        this->tableView->canMoveScroll = false;
        CCPoint currentContentOffset = this->tableView->getContentOffset();
                
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            float newContentOffsetX = currentContentOffset.x + 340.0f;
            
            if(newContentOffsetX>=0)
                newContentOffsetX = 0.0f;
            
            this->tableView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
            
            //Setting Visibility for Arrow Buttons
            if(newContentOffsetX>=-3){
                leftArrowMenuItem->setVisible(false);
                rightArrowMenuItem->setVisible(true);
            }
            else if(newContentOffsetX>=-340) {
                leftArrowMenuItem->setVisible(true);
            }
            else {
                leftArrowMenuItem->setVisible(true);
                rightArrowMenuItem->setVisible(true);
            }
        }
        else
        {
            float newContentOffsetX = currentContentOffset.x + 164.0f;
            
            if(newContentOffsetX>=0)
                newContentOffsetX = 0.0f;
            
            this->tableView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
            
            //Setting Visibility for Arrow Buttons
            if(newContentOffsetX==0){
                leftArrowMenuItem->setVisible(false);
                rightArrowMenuItem->setVisible(true);
            }
            else if(newContentOffsetX>=-164) {
                leftArrowMenuItem->setVisible(true);
            }
            else {
                leftArrowMenuItem->setVisible(true);
                rightArrowMenuItem->setVisible(true);
            }
        }
    }
}


void BBPuzzleGameSelection::rightArrowPressed(CCObject *sender)
{    
    if(this->tableView->canMoveScroll)
    {
        this->tableView->canMoveScroll = false;
        CCPoint currentContentOffset = this->tableView->getContentOffset();
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            float newContentOffsetX = currentContentOffset.x - 340.0f;
            
            float maxContentOffsetX = -1*(340.0f*this->allPuzzleListArr->count())+1020.0f-3;
            
            if(newContentOffsetX <= maxContentOffsetX)
                newContentOffsetX = maxContentOffsetX;
            
            this->tableView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
            
            //Setting Visibility for Arrow Buttons
            if(newContentOffsetX == maxContentOffsetX) {
                rightArrowMenuItem->setVisible(false);
                leftArrowMenuItem->setVisible(true);
            }
            else if(newContentOffsetX <= -3400) {
                rightArrowMenuItem->setVisible(true);
            }
            else {
                leftArrowMenuItem->setVisible(true);
                rightArrowMenuItem->setVisible(true);
            }
        }
        else
        {
            float newContentOffsetX = currentContentOffset.x - 164.0f;
            
            float maxContentOffsetX = -1*(164.0f*this->allPuzzleListArr->count())+495.0f-3;
            
            if(newContentOffsetX <= maxContentOffsetX)
                newContentOffsetX = maxContentOffsetX;
            
            this->tableView->setContentOffset(CCPointMake(newContentOffsetX, currentContentOffset.y),true);
            
            
            //Setting Visibility for Arrow Buttons
            if(newContentOffsetX == maxContentOffsetX) {
                rightArrowMenuItem->setVisible(false);
                leftArrowMenuItem->setVisible(true);
            }
            else if(newContentOffsetX <= -1476) {
                rightArrowMenuItem->setVisible(true);
            }
            else {
                leftArrowMenuItem->setVisible(true);
                rightArrowMenuItem->setVisible(true);
            }
        }
    }
}




void BBPuzzleGameSelection::backButtonSounds(CCMenuItemImage *sender) {
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(CCDelayTime::create(0.4), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::backToMainScene)));
    this->runAction(seq);
}

void BBPuzzleGameSelection::backToMainScene() {
    
    //stop Puzzle BackgroundMusic When you Enter Game Selection Scene
    SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    BBSharedSoundManager::sharedManager()->playGameButtonSound();
    
    BBPuzzleDataManager::sharedManager()->starCount = 0;
    
    for (int i=0; i<BBPuzzleDataManager::sharedManager()->starArray->count(); i++)
    {
        CCSprite *star = (CCSprite*)BBPuzzleDataManager::sharedManager()->starArray->objectAtIndex(i);
        this->removeChild(star, true);
    }
    
    BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound = true;
    BBPuzzleDataManager::sharedManager()->isPuzzleGameOver = false;
    
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}



void BBPuzzleGameSelection::goToPuzzle(int cellIndex) {
    
    CCUserDefault::sharedUserDefault()->setFloatForKey("lastPuzzleScrollOffsetPosX", tableView->getContentOffset().x);
    
    CCString *puzzleName = (CCString *)spriteArray->objectAtIndex(cellIndex);    
    BBPuzzleDataManager::sharedManager()->puzzleName = puzzleName->getCString();
    
    //stop all sound-Effects
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    CCDirector::sharedDirector()->replaceScene(BBPuzzleGame::scene());
    
    BBPuzzleDataManager::sharedManager()->gamePlaySound = false;
}

#pragma mark -Select Difficulty methods

void BBPuzzleGameSelection::difficultyLevel(CCObject *sender){
    
    CCMenuItemImage *aMenuItem = (CCMenuItemImage *)sender;
    int tag = aMenuItem->getTag();
    
    this->setDifficultyForLevel(tag);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundPlayPuzzle);
    SimpleAudioEngine::sharedEngine()->stopEffect(soundWhichPuzzle);
    SimpleAudioEngine::sharedEngine()->stopEffect(soundDifficulty);
}


void BBPuzzleGameSelection::setDifficultyForLevel(int inLevelNo) {
    
    if(inLevelNo == 0)
        inLevelNo = 1;
    
    this->setPositionForDifficultyLevelIndicator(inLevelNo);
    CCUserDefault::sharedUserDefault()->setIntegerForKey("puzzleDifficultyLevel", inLevelNo);
    CCUserDefault::sharedUserDefault()->flush();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSoundForLevels);
    
    {
        if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound){
            
            bazziTalking->stopDogTalking();
            this->stopActionByTag(1000);
            this->stopActionByTag(2000);
            this->stopActionByTag(3000);
            this->stopActionByTag(4000);
            
            //Look for the Obstacles
            CCSequence *Seq3 = CCSequence::create(CCDelayTime::create(3),
                                                  CCCallFunc::create(this, callfunc_selector(BBPuzzleGameSelection::chooseWhichPuzzle)),
                                                  CCDelayTime::create(2),
                                                  CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::stopDogTalking)), NULL);
            Seq3->setTag(3000);
            this->runAction(Seq3);
            
            CCSequence *Seq4 = CCSequence::create(CCDelayTime::create(5),
                                                  CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGameSelection::startDogTalking)),
                                                  CCCallFuncN::create(this,callfuncN_selector(BBPuzzleGameSelection::puzzlePutTogetherSound)), NULL);
            Seq4->setTag(4000);
            this->runAction(Seq4);
            
            bazziTalking->stopDogTalking();
        }
    }
    
    switch(inLevelNo)
    {
        case 1: BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName = "FourPiece";
            
            if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound) {
                
                this->stopActionByTag(777);
                
                stopSoundForLevels = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4pieces.mp3");
            }
            break;
            
        case 2: BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName = "FivePiece";
            
            if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound) {
                
                this->stopActionByTag(777);
                stopSoundForLevels = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/5pieces.mp3");
            }
            break;
            
        case 3: BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName = "NinePiece";
            
            if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound) {
                
                this->stopActionByTag(777);
                
                stopSoundForLevels = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/9pieces.mp3");
            }
            break;
            
        case 4: BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName = "TwelvePiece";
            
            if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound) {
                
                this->stopActionByTag(777);
                
                stopSoundForLevels = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/12pieces.mp3");
            }
            break;
    }
}


void BBPuzzleGameSelection::setPositionForDifficultyLevelIndicator(int inLevel)
{
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        normalSprLevelSelection->setPosition(ccp(150+(150*inLevel),100));
    }
    
    else
    {
        normalSprLevelSelection->setPosition(ccp(75+(75*inLevel),33));
    }
}

void BBPuzzleGameSelection::getDifficultyLevelName(int level){
    
    if(level==1){
        
        BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName="FourPiece";
    }
    else if(level==2){
        
        BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName="FivePiece";
    }
    else if(level==3){
        
        BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName="NinePiece";
    }
    else if(level==4){
        
        BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName="TwelvePiece";
    }
    else {
        
      BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName="FourPiece";
    }
}

#pragma mark - Dealloc
void BBPuzzleGameSelection::onExit(){
    
    CCLayer::onExit();
    
    //To stop schedule for playing sounds
    SimpleAudioEngine::sharedEngine()->stopEffect(soundWhenPuzzleSelected);
    
    this->stopAllActions();
    
    //Removing PuzzleUI Images plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
        
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("Puzzle/GamePlaySpriteSheets/BBPuzzleGame/PuzzleMainPage.plist");
        
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("Puzzle/GamePlaySpriteSheets/BBPuzzleGame/PuzzleMainPageTwo.plist");
}


BBPuzzleGameSelection::~BBPuzzleGameSelection()
{
    CC_SAFE_RELEASE_NULL(this->spriteArray);
}

