//
//  BBSharedSoundManager.h
//  BacciBooks
//
//  Created by Deepthi on 30/10/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//

#ifndef LostMonster_LMSharedSoundManager_h
#define LostMonster_LMSharedSoundManager_h


#include "cocos2d.h"

//THIS IS SHARED MANAGER FOR PLAYING SOUND FROM ANYWHERE
//ALSO IT HANDLES SOME EXTRA THINGS
//

class BBSharedSoundManager: public cocos2d::CCObject {
    
    
public:
    
    //Basic Vars & Methods of Shared Manager
    static BBSharedSoundManager* sharedManager(void);

    BBSharedSoundManager(void);
    ~BBSharedSoundManager(void);
    
    bool init(void);
        
        int sound;

    //Sound Manager Implementation
        void playOnClickOfCorrectAnswer();
        static void playOnClickOfWrongAnswer();
        static void playOnStarAnimation();
        static void playOnGettingTrophy();
        
        void playSoundOnTappingDogAfterPopup();
    
    //Game Complete
    void playGameCompletePopUpSound();
    
    //Home Button Sound
    void playGameButtonSound();
    
    //Play Again Button
    void playPlayAgainButtonSound();
   
        
     
};


#endif
