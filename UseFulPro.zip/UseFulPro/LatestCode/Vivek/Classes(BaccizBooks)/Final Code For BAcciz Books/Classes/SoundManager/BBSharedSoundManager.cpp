//  BBSharedSoundManager.h
//  BacciBooks
//
//  Created by Deepthi on 30/10/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.

#include "BBSharedSoundManager.h"

#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;


static BBSharedSoundManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

BBSharedSoundManager::BBSharedSoundManager(void)
{
        
}

BBSharedSoundManager::~BBSharedSoundManager(void)
{
        
}


BBSharedSoundManager* BBSharedSoundManager::sharedManager(void) {
        
	BBSharedSoundManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBSharedSoundManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBSharedSoundManager::init(void) {
	return true;
}


#pragma mark - Sound Manager Implementation

void BBSharedSoundManager::playOnClickOfCorrectAnswer()
{
        int rand= arc4random()%8;
        if(rand==0)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/happy.mp3", false);
        }
        else if(rand==1)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/happy.mp3", false);
                
        }
        else if(rand==2)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yeaaah.mp3", false);
                
        }
        else if(rand==3)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yeaaah.mp3", false);
                
        }
        else if(rand==4)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/wow1.mp3", false);
                
        }
        else if(rand==5)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/wow1.mp3", false);
                
        }
        else if(rand==6)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yeaaah.mp3", false);
                
                
        }
        else if(rand==7)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yes-Perfect.mp3", false);
                
                
        }
        else if(rand==8)
        {
                sound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yes3.mp3", false);
                
                
        }
        
        
}
void BBSharedSoundManager::playOnClickOfWrongAnswer()
{
        int rand= arc4random()%7;
        if(rand==0)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/failed_tuba_sound.mp3", false);
        }
        else if(rand==1)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/no_harmonica.mp3", false);
                
        }
        else if(rand==2)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/no.mp3", false);
                
        }
        else if(rand==3)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/no2.2.mp3", false);
                
        }
        else if(rand==4)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/ohh1.mp3", false);
                
        }
        else if(rand==5)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/oo_sound.mp3", false);
                
        }
        else if(rand==6)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/sad sound.mp3", false);
                
        }
        else if(rand==7)
        {
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/try again.mp3", false);
                
        }
        
        
        
}

void BBSharedSoundManager::playOnStarAnimation()
{
        int rand= arc4random()%2;
        char song[50]={};
        if(rand==0)
        {
                rand=2;
        }
        
        sprintf(song,"Sounds/CongragulationSounds/star%d.mp3",rand);
        SimpleAudioEngine::sharedEngine()->playEffect(song, false);
}

void BBSharedSoundManager::playOnGettingTrophy()
{
        SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yougetatrophy.mp3");
}

void BBSharedSoundManager::playGameCompletePopUpSound()
{
   sound= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/playagainorgoback.mp3");
}

void BBSharedSoundManager::playGameButtonSound()
{
    int random = arc4random()%4;
    
    if(random == 0)
    {
       sound= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thankyouforcoming.mp3");
    }
    else if (random==1)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/comebacksoon.mp3");
    }
    else if (random==2)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/lets_play_again_soon.mp3");
    }
    else 
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thanksforplayingcomebacksoon.mp3");
    }
}

void BBSharedSoundManager::playPlayAgainButtonSound()
{
    int random = arc4random()%2;
    
    if(random == 0)
    {
       sound= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thatwasfun.mp3");
    }
    else if (random==1)
    {
        sound=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/great.mp3");
    }
}
   
void BBSharedSoundManager::playSoundOnTappingDogAfterPopup()
        {
        int rand =arc4random()%2;
        if(rand==0)
        {
                sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3");
        }
        else if(rand==1)
        {
                sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/play_again_orgoback.mp3");
        }
        else
        {
                sound=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/playagainorgoback.mp3");
        }

    
    
}
