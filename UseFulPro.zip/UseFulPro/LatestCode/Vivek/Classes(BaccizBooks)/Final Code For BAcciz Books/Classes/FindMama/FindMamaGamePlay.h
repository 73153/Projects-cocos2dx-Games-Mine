//
//  FindMamaGamePlayScene.h
//  FindMamaGamePlay
//
//  Created by Vivek on 23/05/13.
//
//

#ifndef FindMamaGamePlay_FindMamaGamePlayScene_h
#define FindMamaGamePlay_FindMamaGamePlayScene_h
#include "cocos2d.h"
#include "FindMamaGamePlay.h"
#include "FMPartsSprite.h"
#include "cocos-ext.h"
#include "CCBReader.h"
#include "BacciTalking.h"

USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;
class FindMamaGamePlay : public CCLayer
{
public:
    //default
    virtual void onEnter();
    virtual void onExit();
    
    static CCScene* scene();
    
    FindMamaGamePlay();
    ~FindMamaGamePlay();
    
    //Initialize
    void initialiseGameUI();
    void addStars();
    void initialiseGame();
    void initialiseVariables();
    
    //animal layer
    CCLayer *animalLayer;
    
    //Variables
    CCSize winSize;
    CCLabelTTF *animalLabel;
    
    //dog Talking Animation
    BacciTalking *bazziTalking;
    void stopDogTalkingAnimation();
    void startDogTalking();
    void stopTheDogAnim();
    
    int dogAnimationCount;
    int levelNumber;
    int* store_randomArray;
    int movedChildCount;
    int gameCount;
    int randNo;
    int cow_Rand_Num;
    int cat_Rand_Num;
    int idleTime;
    
    bool isFatherPresent;
    bool isChildMotherGameSolved;
    bool canRenderTexture;
    bool canStopDogTalking;
    bool canTapChildAnimal;
    bool isGameCompleted;
    bool isGameRestarted;
    bool isWrongMathedAnimalMoreThanThree;
    bool canDrawTargetTexture;
   
    //Particle
    CCParticleSystem *addParticleEffectToTexture;
    void createParticleAtPosition(CCPoint inPosition);
    void moveParticleToTouchedPos(CCPoint tochesLocation);
    void addParticleEffect();
    void removeParticle();
    void removeStrokeFromMamaAfterTwoSeconds();
    
    //Button When Pressed Giving Some Delay
    void restartButtonPressed();
    
    
    //Animal Array
    CCArray *motherArr;
    CCArray *childArr;
    CCArray *fatherArr;
    CCArray *randNoArr;
    
    CCArray *randNumberarrayForMother;
    CCArray *randNumberarrayForFather;
    CCArray *arrayOfAnimalsAccordingToGroupName;
 
    CCArray *lineSprarray;
    CCArray *linesInfoArr;
    
    
    CCDictionary *levelNameDict;
    
    CCMenuItemSprite *leftArrowMenuItem;
    CCMenuItemSprite *rightArrowMenuItem;
    
    CCSprite *award;
    CCSprite *backgroundforSpr;

    //Animals
    void addChilds( int noOfChild);
    void addMothers( int noOfMother);
    void addFathers( int noOfFather);
    
    //Menu
    void homeButton(CCMenuItemImage *sender);
    void goToNextLevel(CCMenuItemSprite *sender);
    
    //Enable And Disable Touch
    void enablingTouch();
    
    //schedular method for the idle animation
    void scheduleIdleTickAfterSounds();
    void idleCheckTick();

    
    //check whether we can tap Animal
    void canTapChildAnimalMakingTrue();
    void canTapChildAnimalMakingFalse();
    
    //Animal Sprites
    FMPartsSprite *selectedAnimal;
    FMPartsSprite* getOriginalChild();
    
    //Stroke for selected sprite and level lable 
    CCRenderTexture* createStrokeForLable(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity);
    CCRenderTexture* createStroke(CCSprite* sparite, int size, ccColor3B color, GLubyte opacity);
    CCRenderTexture* targetTexture;
    
    //Game Logic
    float getAngleBetweenPoint(CCPoint currentPoint,CCPoint toPoint);
    int* randomizeInt(int GameCards[10]);
    int* rand_num(int animals[7]);
       
    //moving Animal to Approprate place
    void moveAllFatherToChildPos();
    void moveSelectedAnimalToMatchedAnimalPos(CCObject *Sender,void* Data);
    void addChildAsChildOfMother(CCObject *sender );

    //star sprite
    void addNewStar();
    
    //starArray
    CCArray *starArray;
   
    //menu item
    CCMenuItemSprite  *restartMenuItem;
    
    //sound
    void playCheersSound();
    void playOhhSound();
    void animalSound(FMPartsSprite *selectedSpr);
    void readyForNextLevelSound();
    void drawaLineFromMamaSound();
    void helpBabies_MamasSound();
    void youFoundAllMamaSound();
    void youGetTrophySound();
    void letGetFamilySound();
    void playOnClickOfMoreThanThreeWrongAnswer();
    void playSoundOnStarAnim();
    void helpPapa_mama();
    void playRandomSoundOnTappingDog();
    void playRandomSoundOnTappingDogOnLevelTwelve();
    void greatSound();
    void welcomeSound();
    void playGameWonRandomSound();
    void drawlinepapatomama();
    
    //label
    void setAnimalLabelName(const char* name);
    
    //Texture
    CCRenderTexture *m_pTarget;
    CCSprite *m_pBrush;
    void addTexture();
    void clearTexture();
    
    //game over
    void gameOver();
    void levelCleared();
    void playAgain();
    
    //Touches
    void ccTouchesBegan(CCSet* touches, CCEvent* event);
    void ccTouchesMoved(CCSet* touches,CCEvent* event);
    void ccTouchesEnded(CCSet* touches, CCEvent* event);
    void ccTouchesCancelled(CCSet *pTouches, CCEvent *pEvent);

    void isCorrectParentSelected(FMPartsSprite *child ,FMPartsSprite *parent, CCPoint point);
   
    //clear
    void clear();
    void clearLines(CCObject *Sender);
    
    CREATE_FUNC(FindMamaGamePlay);
};



class FindMamaGamePlayParameterObject :public cocos2d::CCObject {
    
public:
    FMPartsSprite *child;
    FMPartsSprite *parent;
    FindMamaGamePlayParameterObject();
    ~FindMamaGamePlayParameterObject();
    
};

#endif


