//
//  TIGameScene.h
//  TIGameScene
//
//  Created by Deepthi on 23/03/13.
//
//

#ifndef TIGameScene_TIGameScene_h
#define TIGameScene_TIGameScene_h
#include "cocos2d.h"
#include "cocos-ext.h"
#include "CCBReader.h"
#include "TIAnimalSprite.h"
#include "BacciTalking.h"




USING_NS_CC;
USING_NS_CC_EXT;

using namespace cocos2d;

class TIGameScene : public cocos2d::CCLayer
{
public:
    TIGameScene();
    ~TIGameScene();
    
    virtual void onEnter();
    virtual void onExit();
    
    static cocos2d::CCScene* scene();
    
    //Initiliase
    void initialiseVariables();
    void initialiseGame();
    void initialiseSounds();
    void intialiseGameUI();
    
    void addStars();
    void addNewStar();
    
    CCSprite *award;
    CCSprite *booble;
    
    CCSprite *tittleSpr;
    
    //Game Logic
    void generateRandomNoArray();
    void addAnimals();
    void chooseAnimalName();
    
    
    //Sound
    void animalSound();
    void RepeatSound();
    void twoTimeWrongMatchedSound();
    void afterFinishingLevelFunc();
    void calisTouchEnabledFunc();
    void initialDogAdviceFunc();
    
    //Replace
    void goBackToGameSelectionScene();
    void replaceScene();
    void playAgainFunc();
    void playAgainFuncAfterDelay();
    void goBackFunc();
    
    int dogTalking;
    bool canAddAnimals;
    bool isDogTalking;
    bool isGameFinished;
    void addSound();
    
    void correctFuncAction();
    void wrongFuncAction();
    void transparentActionForWrongSelection();
        
    void addCongratulationBnner();
    
    void remove( CCObject *sender);
    void getLabel(const char *label);
        
   void  tapAnimalAfterFinishingSound();
    
    BacciTalking *bazziTalking;
    void callstopDogTalking();

      //CustomSpr
    TIAnimalSprite *selectedAnimalSprite;
    TIAnimalSprite  *touchSpr;
    
    //Touch
    void ccTouchesBegan(CCSet* touches, CCEvent* event);
    
    CCArray *AnimalPositionArray;
    CCArray *numberArray;
    CCArray *animalArray;
    
    int* store_randomArray;
    int* shuffleArray(int num[20]);
    int count;
    int wrongTapCount;
    
    int xPos;
    int yPos;
    
    CCLabelTTF *animaleNameTitleLbl;
    CCRenderTexture *animaleNameTitleStroke;
    
    CCLabelTTF *pageCount;
    
    void calladdingTrophyFunc();
    
    void calStopDogAnimationAfterStarAnimation();
    
    //Game Idle
    void idleCheckTick();
        
     bool isGameOver;
        
    
    bool canTap;
    bool canRepeatSound;
    int tapCount;
    CCSprite *starEmptySprite;
    
    CCPoint  touchPoint;
    CCRenderTexture* createStroke(CCLabelTTF *label,int size,ccColor3B color, GLubyte opacity);
    
    CCDictionary *gameDict ;
    CCDictionary *levelSelection;
    
    CCMenuItemSprite *dogSpr;
    CCMenuItemSprite *replaySoundBtn;
    
    CREATE_FUNC(TIGameScene);
    
    
};

#endif
