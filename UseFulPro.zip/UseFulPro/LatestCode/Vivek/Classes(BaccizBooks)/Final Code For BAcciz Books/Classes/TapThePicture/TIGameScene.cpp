
#include "SimpleAudioEngine.h"
#include "time.h"
#include "stdlib.h"
#include "cocos2d.h"

#include "TIGameScene.h"
#include "TIDataManager.h"
#include "TIAnimalSprite.h"
#include "BBConfig.h"

#include "BBGameSelection.h"

#include "BacciTalking.h"

#include "BBMainDataManager.h"
#include "BBSharedSoundManager.h"

#include "BBAllGamesFunctionSharedManager.h"


USING_NS_CC_EXT;
USING_NS_CC;
using namespace cocos2d;
using namespace CocosDenshion;

CCScene* TIGameScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    TIGameScene *layer = TIGameScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

//#pragma mark - TIGameScene
TIGameScene ::TIGameScene()
{
    this->wrongTapCount=0;
    canTap=false;
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        std::string pszPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("TTPanimalDetailsIpad.plist");
        gameDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPath.c_str());
    }
    else
    {
        std::string pszPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("TTPanimalDetailsIphone.plist");
        gameDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPath.c_str());
    }
    
    char levelName[20]={};
    sprintf(levelName,"level_%d",TIDataManager::sharedManager()->currentLevel);
    
    levelSelection = (CCDictionary*)gameDict->valueForKey(levelName);
    AnimalPositionArray = (CCArray*)levelSelection->valueForKey("AnimalPosition");
    
        bazziTalking = new BacciTalking();
     
        
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85,128));

    }
    else
    {
        bazziTalking->initialize(this,CCPoint(35,38));
    }
    
        isDogTalking=false;
        isGameFinished=false;
        
        this->isGameOver=false;
        
        this->initialiseVariables();
    
    if(SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/tapthepicture_music.mp3",true);
}


//#pragma mark - initialiseVariables
void TIGameScene::initialiseVariables()
{
    numberArray=CCArray::create();
    numberArray->retain();
    
    animalArray = CCArray::create();
    animalArray->retain();
    
    this->tapCount=0;
}

void TIGameScene::initialiseGame()
{
    this->intialiseGameUI();
    this->addStars();
    this->schedule(schedule_selector(TIGameScene::idleCheckTick), 1);
    
}

#pragma mark - Idle

void TIGameScene::idleCheckTick()
{
    if(this->bazziTalking->isBacciTalking==false)
    {
        this->bazziTalking->idleTime ++;
        
        if(this->bazziTalking->idleTime%kBacciIdleTime==0&&this->bazziTalking->isRunningIdleAnimation==false)
        {
            this->bazziTalking->runBacciIdleAnimation();
        }
    }
}

#pragma mark -  ~TIGameScene
TIGameScene::~TIGameScene()
{
    CC_SAFE_RELEASE_NULL(animalArray);
    CC_SAFE_RELEASE_NULL(numberArray);
}

#pragma MARK - onEnter,onExit
void TIGameScene::onExit()
{
    CCLayer::onExit();
    
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("TapThePicture/BBTIImages.plist");
}


void TIGameScene::onEnter()
{
    CCLayer::onEnter();
    this->wrongTapCount=0;
    
    //load plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("TapThePicture/BBTIImages.plist");
    
    
    this->initialiseGame();
    
    if(TIDataManager::sharedManager()->canPlaySound)
    {
            dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobacciztapthepicture.mp3");
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.5), CCCallFunc::create(this, callfunc_selector(TIGameScene::initialDogAdviceFunc)),NULL);
            this->runAction(Seq);
            TIDataManager::sharedManager()->canTapDog=false;
            
    }
    else
    {
        this->initialiseSounds();
    }
    
    
    
    bazziTalking->startDogTalking();
}

void TIGameScene::initialDogAdviceFunc()
{
    this->setTouchEnabled(true);
    
    TIDataManager::sharedManager()->canPlaySound=false;
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/whenisaskyoutotappicture_tappic.mp3");
    if(TIDataManager::sharedManager()->canAddAnimals)
    {
        TIDataManager::sharedManager()->canAddAnimals=false;
        this->generateRandomNoArray();
        tittleSpr->setVisible(true);
        
    }
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(5.2), CCCallFunc::create(this, callfunc_selector(TIGameScene::addSound)),CCDelayTime::create(3),CCCallFunc::create(this, callfunc_selector(TIGameScene::initialiseSounds)),NULL);
    this->runAction(Seq);
    
    
    
}

void TIGameScene::addSound()
{
    dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thenyouwillknow_word_animal.mp3");
}

#pragma mark - placeBackGroundImages
void TIGameScene::intialiseGameUI()
{
    CCSize winsize=CCEGLView::sharedOpenGLView()->getFrameSize();
    CCSize winSiz=CCDirector::sharedDirector()->getWinSize();

        CCSprite *scenarySpr = CCSprite::create("BBSharedResources/BackGrounds/beach.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        scenarySpr->setPosition(ccp(winSiz.width/2,winSiz.height/2));
    }
    else
    {
        scenarySpr->setPosition(ccp(winSiz.width/2,winSiz.height/2));
    }
    this->addChild(scenarySpr);
    
    tittleSpr=CCSprite::createWithSpriteFrameName("tap-the_.png");
    this->addChild(tittleSpr);
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        tittleSpr->setPosition(ccp(386, 680));
    }
    else
    {
        tittleSpr->setPosition(ccp(183, 295));
        
    }
    tittleSpr->setVisible(false);
    
    char a[20]={};
    sprintf(a, "%d/12",TIDataManager::sharedManager()->pageCount);
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        pageCount=CCLabelTTF::create(a, "Apple Casual" , 50);
        pageCount->setPosition(ccp(930,60));
        
    }
    else
    {      pageCount=CCLabelTTF::create(a, "Apple Casual" , 25);
        pageCount->setPosition(ccp(440,34));
    }
    pageCount->setColor(ccc3(0,162,255));
    CCRenderTexture *stroke =createStroke(pageCount,2,ccWHITE, 100);
    this->addChild(stroke);
    this->addChild(pageCount);
    
    // dog base
    CCSprite *dogBase=CCSprite::createWithSpriteFrameName("dog_base.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        dogBase->setPosition(CCPointMake(80,48));   //117.9 48
    }
    else
    {
        dogBase->setVisible(false);
        //  dogBase->setPosition(CCPointMake(43,22));
    }
    this->addChild(dogBase);
    CCSprite *NormalSpr = CCSprite::createWithSpriteFrameName("repaly_sound.png");
    CCSprite *SelectedSpr = CCSprite::createWithSpriteFrameName("repaly_sound.png");
    
    replaySoundBtn = CCMenuItemSprite::create(NormalSpr, SelectedSpr, this, menu_selector(TIGameScene::RepeatSound));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        replaySoundBtn->setPosition(CCPointMake(952.3,707));
    }
    else
    {
        replaySoundBtn->setPosition(CCPointMake(446,289));
    }
    
    CCSprite *leftArrowNormalSpr = CCSprite::createWithSpriteFrameName("control.png");
    CCSprite *leftArrowSelectedSpr = CCSprite::createWithSpriteFrameName("control.png");
    
    CCMenuItemSprite *leftArrowMenuItem = CCMenuItemSprite::create(leftArrowNormalSpr, leftArrowSelectedSpr, this, menu_selector(TIGameScene::goBackToGameSelectionScene));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        leftArrowMenuItem->setPosition(CCPointMake(78,707.5));
    }
    else
    {
        leftArrowMenuItem->setPosition(CCPointMake(35,285));
    }
    
    CCMenu *tempMenu = CCMenu::create(leftArrowMenuItem,replaySoundBtn, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,1);
    
    //award sprite
    
    award=CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,5);
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        award->setPosition(ccp(512,384));
    }
    else
    {
        award->setPosition(ccp(240,160));
    }
    award->setVisible(false);
    
    //ballon Sprite
    booble=CCSprite::createWithSpriteFrameName("booble.png");
    
    this->addChild(booble,3);
    booble->setScale(0.5);
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        booble->setPosition(ccp(225,210));
    }
    else
    {
        booble->setPosition(ccp(99,96));
        
    }
    booble->setVisible(false);
    
}

void TIGameScene::addStars()
{
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        xPos=230;
        yPos=35;
    }
    else
    {
        xPos=100;
        yPos=25;
    }
    
    
    for(int i=0;i<TIDataManager::sharedManager()->starCount;i++)
    {
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        //   starEmptySprite->setAnchorPoint(ccp(.5,.5));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
    for(int i=0;i<12-TIDataManager::sharedManager()->starCount;i++)
    {
        starEmptySprite=CCSprite::createWithSpriteFrameName("star_white.png");
        //       starEmptySprite->setAnchorPoint(ccp(.5,.5));
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
}
void TIGameScene::addNewStar()
{
    if(!this->tapCount>=1||TIDataManager::sharedManager()->pageCount==12)
    {
        if(TIDataManager::sharedManager()->pageCount<=12)
        {
            SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
            
            if(TIDataManager::sharedManager()->pageCount!=12) //Dont play Star ANimation sound on level 12
                BBSharedSoundManager::sharedManager()->playOnStarAnimation();
            
            bazziTalking->startDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.8),CCCallFunc::create(this,callfunc_selector(TIGameScene::calStopDogAnimationAfterStarAnimation)),NULL);
            this->runAction(callBack);
        }
        
        CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            starSprite->setPosition(ccp(230+((TIDataManager::sharedManager()->starCount)*50),35));
        }
        else
        {
            starSprite->setPosition(ccp(100+((TIDataManager::sharedManager()->starCount)*25),25));
        }
        this->addChild(starSprite,20);
        
        
        CCRotateBy *rotate = CCRotateBy::create(.8, 430);
        
        CCScaleTo *scaleStarTo = CCScaleTo::create(0.2, 3.2);
        CCScaleTo *scaleStarBack = CCScaleTo::create(0.1, 1);
        CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
        
        
        CCFadeOut *fadeout = CCFadeOut::create(0.2);
        CCFadeIn *fadeIN = CCFadeIn::create(0.1);
        //              //  if(starSprite)
        CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
        CCSequence *seq1 = CCSequence::create(fadeout,fadeIN,NULL);
        CCSequence *seq2 = CCSequence::create(fadeout,fadeIN,NULL);
        
        CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.2),  seq2,NULL);
        starSprite->runAction(seq3);
        TIDataManager::sharedManager()->starCount++;
        
        if(TIDataManager::sharedManager()->pageCount==12)
        {
           // this->calladdingTrophyFunc();
                this->addCongratulationBnner();
                bazziTalking->startDogTalking();
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TIGameScene::calladdingTrophyFunc)),NULL);
                this->runAction(Seq);
        }
        else
        {
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TIGameScene::replaceScene)),NULL);
            this->runAction(Seq);
        }
        //
    }
    else
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(0.5), CCCallFunc::create(this, callfunc_selector(TIGameScene::replaceScene)),NULL);
        this->runAction(Seq);
        award->setVisible(false);
    }
}

#pragma mark -  calStopDogAnimationAfterStarAnimation
void TIGameScene::calStopDogAnimationAfterStarAnimation()
{
    bazziTalking->stopDogTalking();
    TIDataManager::sharedManager()->canTapDog=true;
    
}

#pragma mark - Touches
void TIGameScene::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)touches->anyObject();
    touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    CCObject *obj;
    if(bazziTalking->animatedDog->boundingBox().containsPoint(touchPoint))
    {
        if(TIDataManager::sharedManager()->canTapDog)
        {            
            isDogTalking=true;
            TIDataManager::sharedManager()->canTapDog=false;
            SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
            SimpleAudioEngine::sharedEngine()->stopAllEffects();
            //                        SimpleAudioEngine::sharedEngine()->pauseAllEffects();
            
            if(isGameFinished)
            {
                SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
                bazziTalking->startDogTalking();
                dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3");
                this->setTouchEnabled(false);
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.8), CCCallFunc::create(this, callfunc_selector(TIGameScene::callstopDogTalking)),NULL);
                this->runAction(Seq);
            }
            else
            {
                    bazziTalking->startDogTalking();
                dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/whenisaskyoutotappicture_tappic.mp3");
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(4.8), CCCallFunc::create(this, callfunc_selector(TIGameScene::callstopDogTalking)),NULL);
                this->runAction(Seq);
            }
        }
    }
        
    CCARRAY_FOREACH(animalArray, obj)
    {
        //                touchSpr = (TIAnimalSprite *)obj;
        
        TIAnimalSprite *animalSpr=(TIAnimalSprite*)obj;
        if(canTap)
        {
            if (animalSpr->boundingBox().containsPoint(touchPoint))
            {
                touchSpr=animalSpr;
                
                if(touchSpr->animalTag==selectedAnimalSprite->animalTag)
                {
                        if(isGameOver)
                        {
                                return;
                        }
                 
                    this->setTouchEnabled(false);
                    this->correctFuncAction();
                }
                else
                {
                    if(touchSpr->canTapAnimal)
                    {
                            if(isGameOver)
                            {
                                    return;
                            }

                        this->wrongFuncAction();
                        // this->transparentActionForWrongSelection();
                        tapCount++;
                    }
                }
            }
        }
    }
}

#pragma MARK - congragulationSprbANNER
void TIGameScene::addCongratulationBnner()
{
        tittleSpr->setVisible(false);
        animaleNameTitleLbl->setVisible(false);
        animaleNameTitleStroke->setVisible(false);
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
                BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(509,670));
        }
        else
        {
                BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(247,275));
        }
        
}

#pragma  mark - transparentActionForWrongSelection
void TIGameScene::transparentActionForWrongSelection()
{
    
    CCFadeTo*fade =CCFadeTo::create(1,100);
    touchSpr->runAction(fade);
    touchSpr->canTapAnimal=false;
    
    
}
#pragma mark - OnTouchCorrectPic
void TIGameScene::correctFuncAction()
{
    if(isDogTalking)
    {
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    }
    
    this->bazziTalking->startDogTalking();
    
    touchSpr->setVisible(false);
    this->wrongTapCount=0;
    CCSprite *smileySpr =CCSprite::createWithSpriteFrameName("smiley_right.png");
    smileySpr->setPosition(touchSpr->getPosition());
    this->addChild(smileySpr,2);
    
    float scaleX = touchSpr->boundingBox().size.width/smileySpr->boundingBox().size.width;
    float scaleY = touchSpr->boundingBox().size.height/smileySpr->boundingBox().size.height;
    
    smileySpr->setScaleX(scaleX);
    smileySpr->setScaleY(scaleY);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    BBSharedSoundManager::sharedManager()->playOnClickOfCorrectAnswer();
    
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TIGameScene::remove)),CCCallFuncN::create(this, callfuncN_selector(TIGameScene::addNewStar)),NULL);
    smileySpr->runAction(callBack);
    
    replaySoundBtn->setEnabled(false);
}

#pragma mark - OnTouchWrongPic
void TIGameScene::wrongFuncAction()
{
    if(isDogTalking)
    {
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    }

    
    touchSpr->setVisible(false);
    this->wrongTapCount++;
    CCSprite *sadSpr =CCSprite::createWithSpriteFrameName("smiley_sad_wrong.png");
    sadSpr->setPosition((touchSpr->getPosition()));
    this->addChild(sadSpr,2);
    
    sadSpr->setScaleX(touchSpr->boundingBox().size.width/sadSpr->boundingBox().size.width);
    sadSpr->setScaleY(touchSpr->boundingBox().size.height/sadSpr->boundingBox().size.height);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    BBSharedSoundManager::sharedManager()->playOnClickOfWrongAnswer();
    this->setTouchEnabled(false);
    
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TIGameScene::remove)),NULL);
    CCFiniteTimeAction *callBack1=CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this,callfunc_selector(TIGameScene::transparentActionForWrongSelection)),NULL);
    sadSpr->runAction(callBack);
    this->runAction(callBack1);
    
    if(TIDataManager::sharedManager()->canPlayAdviceSound)
    {
        if(wrongTapCount==2)
            
        {
            
            //TIDataManager::sharedManager()->canPlayAdviceSound=false;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this,callfunc_selector(TIGameScene::twoTimeWrongMatchedSound)),CCDelayTime::create(2),NULL);
            this->runAction(callBack);
        }
    }
    
}

void TIGameScene::twoTimeWrongMatchedSound()
{
    bazziTalking->startDogTalking();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thatsnota.mp3");
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this,callfunc_selector(TIGameScene::animalSound)),NULL);
    this->runAction(callBack);
    
}

void TIGameScene::callstopDogTalking()
{
    bazziTalking->stopDogTalking();
    TIDataManager::sharedManager()->canTapDog=true;
    this->setTouchEnabled(true);
}

void TIGameScene::calladdingTrophyFunc()
{
        replaySoundBtn->setEnabled(false);
    isGameOver=true;
    award->setVisible(true);
    CCScaleTo *scaleTo = CCScaleTo::create(.5, 1.2);
    CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
    award->runAction(move_ease_in);
    
    this->setTouchEnabled(true);
    booble->setVisible(true);
    isGameFinished=true;
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(4), CCCallFunc::create(this, callfunc_selector(TIGameScene::afterFinishingLevelFunc)),NULL);
    this->runAction(Seq);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playOnGettingTrophy();
    bazziTalking->startDogTalking();
    CCSequence *SeqOne = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TIGameScene::callstopDogTalking)),NULL);
    this->runAction(SeqOne);
}

#pragma  mark - RandomArray
void TIGameScene::generateRandomNoArray()
{
    int no_to_randomize[20];
    for (int i = 0 ; i <= 15; i++)
    {
        no_to_randomize[i] = i;
    }
    
    this-> store_randomArray = this->shuffleArray(no_to_randomize);
    this->addAnimals();
    
}

#pragma mark - addingAnimals
void TIGameScene::addAnimals()
{
    CCArray  *animalsArrayInfo = (CCArray*)gameDict->valueForKey("Items");
    int noOfAnimals=TIDataManager::sharedManager()->currentLevel*2;
    
    for (int i = 0; i <noOfAnimals ; i++)
    {
        int randomIndex = this->store_randomArray[i];
        
        CCDictionary    *selectAnimal =(CCDictionary*)animalsArrayInfo->objectAtIndex(randomIndex);
        
        CCString *randNumString=CCString::createWithFormat("%d",randomIndex);
        numberArray->addObject(randNumString);
        
        const char *animalName= (const char *)selectAnimal->valueForKey("imageName")->getCString();
        TIAnimalSprite *aItemSpr  = aItemSpr->createWithSpriteFrameName(animalName);
        
        aItemSpr->animalTag=selectAnimal->valueForKey("itemTag")->intValue();
        aItemSpr->sound=selectAnimal->valueForKey("sound")->getCString();
        aItemSpr->itemName=selectAnimal->valueForKey("itemName")->getCString();
        
        aItemSpr->setOpacity(0);
        this->animalArray->addObject(aItemSpr);
        
        
        this->addChild(aItemSpr,1);
        CCFadeIn *fade = CCFadeIn::create(1.5);
        aItemSpr->runAction(fade);
        
        CCString *scaleFactorVal = (CCString *)levelSelection->valueForKey("scaleFactor");
        aItemSpr->setScale(scaleFactorVal->floatValue());
    }
    
    int positionIndex=0;
    CCObject *obj;
    CCARRAY_FOREACH(animalArray, obj)
    {
        CCSprite *spr = (CCSprite*)obj;
        CCString *animalSpritePos = (CCString *)AnimalPositionArray->objectAtIndex(positionIndex);
        CCPoint AnimalPositions = CCPointFromString(animalSpritePos->getCString());
        
        spr->setPosition(CCPoint(AnimalPositions));
        positionIndex++;
        
    }
    this->chooseAnimalName();
}

#pragma MARK - Remove
void TIGameScene::remove(CCObject *sender )
{
    touchSpr->setVisible(true);
    CCSprite *spr =(CCSprite*)sender;
    this->removeChild(spr);
    if(selectedAnimalSprite->boundingBox().containsPoint(touchPoint))
    {
        this->setTouchEnabled(false);
    }
    else
    {
        this->setTouchEnabled(true);
    }
}



#pragma mark - chooseAnimalName
void TIGameScene::chooseAnimalName()
{
    count = numberArray->count();
    int randNoFromArray=arc4random()%count;
    
    selectedAnimalSprite=(TIAnimalSprite*)animalArray->objectAtIndex(randNoFromArray);

    //To avoid getting same animal again & again
    while (TIDataManager::sharedManager()->previousAnimalTag==selectedAnimalSprite->animalTag) {
        
        randNoFromArray=arc4random()%count;
        selectedAnimalSprite=(TIAnimalSprite*)animalArray->objectAtIndex(randNoFromArray);
    }
    this->getLabel(selectedAnimalSprite->itemName);
    
    TIDataManager::sharedManager()->previousAnimalTag = selectedAnimalSprite->animalTag;
}

#pragma  mark - sounds
void TIGameScene::RepeatSound()
{
    if(canTap)
    {
        canTap=false;
        TIDataManager::sharedManager()->canTapDog=false;
        this->initialiseSounds();
        this->bazziTalking->startDogTalking();
        
    }
}

void TIGameScene::initialiseSounds()
{
    if(TIDataManager::sharedManager()->canAddAnimals)
    {
        TIDataManager::sharedManager()->canAddAnimals=false;
        this->generateRandomNoArray();
        tittleSpr->setVisible(true);
        
    }
    
    if(isDogTalking)
    {
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapthe.mp3",false);
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
    }
    
    dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapthe.mp3",false);
    
    
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TIGameScene::animalSound)),NULL);
    this->runAction(callBack);
    
    TIDataManager::sharedManager()->isNewGame=false;
    
}

void TIGameScene::animalSound()
{
    
    char soundName[300]={};
    sprintf(soundName, "%s",selectedAnimalSprite->sound);
    dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(soundName,false);
    
    replaySoundBtn->setEnabled(true);
    
    //        CCScaleTo *scaleto =CCScaleTo::create(1,1.5);
    //        CCScaleTo *scale=CCScaleTo::create(1, 1);
    //        CCSequence *seq=CCSequence::create(scaleto,scale,NULL);
    //        animaleNameTitleLbl->runAction(seq);
    //  bazziTalking->stopDogTalking();
    TIDataManager::sharedManager()->canTapDog=true;
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.3),CCCallFunc::create(this,callfunc_selector(TIGameScene::callstopDogTalking)),CCCallFunc::create(this,callfunc_selector(TIGameScene::tapAnimalAfterFinishingSound)),NULL);
    this->runAction(callBack);
    
    //Make the word Bigger
    CCScaleTo *scaleOne = CCScaleTo::create(0.7, 1.1);
    CCScaleTo *scaleBack = CCScaleTo::create(0.7, 1.0);
    
    CCSequence *sequenceScale = CCSequence::createWithTwoActions(scaleOne, scaleBack);
    CCRepeat *actionRepeat = CCRepeat::create(sequenceScale, 2);
    animaleNameTitleLbl->runAction(actionRepeat);
    animaleNameTitleStroke->runAction((CCActionInterval*)actionRepeat->copy()->autorelease());

    
}

#pragma mark - tapAnimalAfterFinishingSound
void TIGameScene::tapAnimalAfterFinishingSound()
{
        canTap=true;
}
#pragma mark - getLabel
void TIGameScene::getLabel(const char *labelName)
{
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        animaleNameTitleLbl=CCLabelTTF::create(labelName, "Apple Casual" ,75,CCSize(400,50),kCCTextAlignmentLeft);
        animaleNameTitleLbl->setPosition(ccp(739, 680));
    }
    else
    {
        animaleNameTitleLbl=CCLabelTTF::create(labelName, "Apple Casual" , 40,CCSize(200,20),kCCTextAlignmentLeft);
        animaleNameTitleLbl->setPosition(ccp(360, 295));
        
    }
    
    animaleNameTitleLbl->setColor(ccBLACK);
    animaleNameTitleLbl->setAnchorPoint(ccp(0.5,0.5));
    
    animaleNameTitleStroke = createStroke(animaleNameTitleLbl, 2,ccWHITE, 100);
    this->addChild(animaleNameTitleStroke);
    this->addChild(animaleNameTitleLbl);
}

#pragma mark - createStroke
CCRenderTexture*  TIGameScene:: createStroke(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity)
{
    
    CCRenderTexture* rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2,label->getTexture()->getContentSize().height+size * 2);
    
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    // label->setAnchorPoint(ccp(0,0.5));
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    
    rt->begin();
    
    for (int i=0; i<360; i+=50)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    return rt;
}

#pragma mark - shuffleTheArray
int* TIGameScene ::shuffleArray(int num[30]) {
    
    //variables used for swapping
    int temp;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i <= 15; i++){
        
        rand_no = arc4random() % 15;
        temp = num[rand_no];
        num[rand_no]= num[i];
        num[i] = temp;
    }
    return num;
}

#pragma mark - ReplaceScene
void TIGameScene::goBackToGameSelectionScene()
{
   
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    TIDataManager::sharedManager()->pageCount=1;
    TIDataManager::sharedManager()->starCount=0;
    TIDataManager::sharedManager()->currentLevel=1;
    award->setVisible(false);
    booble->setVisible(false);
    
    TIDataManager::sharedManager()->canPlaySound=true;
    TIDataManager::sharedManager()->canAddAnimals=true;
    TIDataManager::sharedManager()->canPlayAdviceSound=true;
    
    BBSharedSoundManager::sharedManager()->playGameButtonSound();
    
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}

void TIGameScene::replaceScene()
{
    //
    TIDataManager::sharedManager()->pageCount++;
    if( TIDataManager::sharedManager()->pageCount>=5&&TIDataManager::sharedManager()->pageCount<=8)
    {
        TIDataManager::sharedManager()->currentLevel=2;
        TIDataManager::sharedManager()->canAddAnimals=true;
        CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
        
    }
    else if( TIDataManager::sharedManager()->pageCount>=9&&TIDataManager::sharedManager()->pageCount<=12)
    {
        TIDataManager::sharedManager()->currentLevel=3;
        TIDataManager::sharedManager()->canAddAnimals=true;
        CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
        
    }
    else if(TIDataManager::sharedManager()->pageCount>=13)//13
    {
        this->calladdingTrophyFunc();
    }
    else
    {
        award->setVisible(false);
        booble->setVisible(false);
        tittleSpr->setVisible(false);
        
        TIDataManager::sharedManager()->canAddAnimals=true;
        CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
    }
    
    
}
void TIGameScene::playAgainFunc()
{
    BBSharedSoundManager::sharedManager()->playPlayAgainButtonSound();
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.0), CCCallFunc::create(this, callfunc_selector(TIGameScene::playAgainFuncAfterDelay)),NULL);
    this->runAction(Seq);
    
}

void TIGameScene::playAgainFuncAfterDelay()
{
    TIDataManager::sharedManager()->pageCount=1;
    TIDataManager::sharedManager()->starCount=0;
    TIDataManager::sharedManager()->currentLevel=1;
    TIDataManager::sharedManager()->canPlaySound=false;
    TIDataManager::sharedManager()->canAddAnimals=true;
    TIDataManager::sharedManager()->canPlayAdviceSound=true;
    
    CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());

}

void TIGameScene::goBackFunc()
{
    this->goBackToGameSelectionScene();
}

void TIGameScene::afterFinishingLevelFunc()
{
    //Play Sound
        BBSharedSoundManager::sharedManager()->playGameCompletePopUpSound();
        
        this->bazziTalking->startDogTalking();
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.4), CCCallFunc::create(this, callfunc_selector(TIGameScene::callstopDogTalking)),NULL);
        this->runAction(Seq);
        
        
        TIDataManager::sharedManager()->canAddAnimals=true;
        CCSize winsize= CCDirector::sharedDirector()->getWinSize();
        award->setVisible(false);
        CCSprite *congragulationSpr = CCSprite::createWithSpriteFrameName("congrats.png");
    congragulationSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(congragulationSpr,10);
    //  bazziTalking->stopDogTalking();
    // congragulationSpr->setScale(2);
    
    CCSprite *playAgainNormalSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    CCSprite *playAgainSelectedSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    
    CCMenuItemSprite *playAgainMenuItem = CCMenuItemSprite::create(playAgainNormalSpr, playAgainSelectedSpr, this, menu_selector(TIGameScene::playAgainFunc));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        playAgainMenuItem->setPosition(ccp(120,10));
    }
    else
    {
        playAgainMenuItem->setPosition(ccp(60,10));
    }
    
    CCSprite *gobackNormalSpr = CCSprite::createWithSpriteFrameName("goback.png");
    CCSprite *gobackSelectedSpr = CCSprite::createWithSpriteFrameName("goback.png");
    
    CCMenuItemSprite *gobackMenuItem = CCMenuItemSprite::create(gobackNormalSpr, gobackSelectedSpr, this, menu_selector(TIGameScene::goBackFunc));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        gobackMenuItem->setPosition(ccp(320, 10));
    }
    else
    {
        gobackMenuItem->setPosition(ccp(160, 10));
    }
    
    CCScaleBy *scaleTo = CCScaleBy::create(1, 1.5);
    CCActionInterval* move_ease_in = CCEaseBackInOut::create((CCActionInterval*)(scaleTo->copy()->autorelease()));
    congragulationSpr->runAction(move_ease_in);
    
    
    CCMenu *tempMenu = CCMenu::create(playAgainMenuItem,gobackMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    congragulationSpr->addChild(tempMenu,10);
    
    
}