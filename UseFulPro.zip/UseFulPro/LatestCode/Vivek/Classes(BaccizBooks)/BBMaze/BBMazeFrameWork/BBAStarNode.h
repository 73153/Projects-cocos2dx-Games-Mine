//
//  BBAStarNode.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 12/02/13.
//
//

#ifndef __BaccizBooks__BBAStarNode__
#define __BaccizBooks__BBAStarNode__

#include "cocos2d.h"
using namespace cocos2d;

class BBAStarNode: public cocos2d::CCObject  {
    
public:
    //Default
    BBAStarNode(void);
    ~BBAStarNode(void);
    
    //Variables
    bool active;
    bool isWall;
    bool didUserAttemptedForBadPath;
    float costMultiplier;
    CCPoint position;
    CCSprite *nodeSprite;
    CCArray *neighbourNodesArray;

    //Methods
    float costToNode(BBAStarNode *node);
    static bool isNodeIsInList(BBAStarNode *a,CCArray *list);
};

#endif /* defined(__BaccizBooks__BBAStarNode__) */
