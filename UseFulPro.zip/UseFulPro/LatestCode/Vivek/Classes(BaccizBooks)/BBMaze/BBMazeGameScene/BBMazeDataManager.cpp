//
//  BBDatamanager.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#include "BBMazeDataManager.h"
#include "cocos2d.h"

static BBMazeDataManager *gSharedManager = NULL;

#pragma mark - Default
BBMazeDataManager::BBMazeDataManager(void){
    
        this->pageCount = 1;
        this->starCount = 0;
        currentLevel = 1;
        this->canPlayWelcomeSound=true;
        this->canPlayAdviceSound=true;
        this->canPlaySecondAdviceSound=true;
        isPressedGamerButton=false;
        this-> canPlayReplaySound=true;
        this->wrongPath=0;
        this->canTapDog=false;
        
        this->isAddedStar=false;
        
        this->dogTapCount=0;
}
   
BBMazeDataManager::~BBMazeDataManager(void){}

BBMazeDataManager* BBMazeDataManager::sharedManager(void) {
    
	BBMazeDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBMazeDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBMazeDataManager::init(void) {
	return true;
}

