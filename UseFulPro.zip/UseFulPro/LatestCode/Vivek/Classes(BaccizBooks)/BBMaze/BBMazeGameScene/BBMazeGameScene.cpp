//
//  BBMazeGameScene.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 13/02/13.
//
//

#include "BBMazeGameScene.h"
#include "BBMazeUtility.h"
#include "SimpleAudioEngine.h"
#include "BacciTalking.h"

#include "BBMazeDataManager.h"
#include "BBMainDataManager.h"
#include "BBConfig.h"

#include "BBSharedSoundManager.h"
#include "BBAllGamesFunctionSharedManager.h"

#include "BBGameSelection.h"


using namespace CocosDenshion;

// #define kMazeDebug

//#pragma mark - Scene
CCScene* BBMazeGameScene::scene()
{
    //'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    //add layer as a child to scene
    CCLayer* layer = new BBMazeGameScene();
    scene->addChild(layer);
    layer->release();
    return scene;
}

//#pragma mark - Default
BBMazeGameScene::BBMazeGameScene()
{
    this->setMazeDefaultValues();
  
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    this->isPixelReading = true;
    this->isRunningAnimation = false;
    this-> isGameFinished=false;
    this->canPlayHintSound=true;
  
     this->hintCount=0;
    
    this->isAddedCongratulationPopUp=false;
    
    this->initializeVariables();
        
    
    //call to UI methods
    this->addBgWithObstacles();
    
    //getting winsize
    CCSize s = CCDirector::sharedDirector()->getWinSize();
    
    //render Texture
    renderTarget = CCRenderTexture::create(s.width, s.height, kCCTexture2DPixelFormat_RGBA8888);
    
    renderTarget->retain();
    renderTarget->setPosition(ccp(s.width/2, s.height/2));
    this->addChild(renderTarget,1);
    
    renderSprite = CCSprite::create("Maze/Images/fire.png");
    renderSprite->retain();
        
     
    //call to update method
    this->schedule(schedule_selector(BBMazeGameScene::update));
    this->scheduleOnce(schedule_selector(BBMazeGameScene::secondTick),2);
        this->schedule(schedule_selector(BBMazeGameScene::farmerTouchedObstacle),1);
    //call to checkPath method
    this->schedule(schedule_selector(BBMazeGameScene::checkPath),1);
        this->schedule(schedule_selector(BBMazeGameScene::idleCheckTick), 1);

    
    if(!isPathFound&&!isGameFinished)
    {
    //    this->schedule(schedule_selector(BBMazeGameScene::convincesound),30);
        
    }
    
    
    
    isRunningFarmerAnimation=true;
}


void BBMazeGameScene::onEnter()
{
    CCLayer::onEnter();
    
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("Maze/SpriteSheets/mazeAnimations.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    //Data plist
    BBMazeUtility::addGameAnimationsToAnimationCache("BBMazeAnimationData.plist");
    //call to initialize Variables
    //Adding UI and stars
    this->addStars();
    this->GameUI();
    this->initialiseSound();
  
    
}

void BBMazeGameScene::onExit()
{
    CCLayer::onExit();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("Maze/SpriteSheets/mazeAnimations.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    
    //   this->stopAllActions();
    //   SimpleAudioEngine::sharedEngine()->stopAllEffects();
}

BBMazeGameScene::~BBMazeGameScene()
{
    renderSprite->release();
    renderTarget->release();
    CC_SAFE_RELEASE(this->gridArray);
    CC_SAFE_RELEASE(this->touchArray);
    CC_SAFE_RELEASE_NULL(this->obstaclesArr);
}

#pragma mark - initialiseDogAdviceFunc
void BBMazeGameScene::initialDogAdviceFunc()
{
    bazziTalking->startDogTalking();
    int rand=arc4random()%2;
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    if(rand==0)
    {
        soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/helpfarmerfindway_maze.mp3",false);
    }
    else
    {
        soundValue=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/helpoldmacfind_maze.mp3",false);
    }
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(Seq);
}

#pragma mark - stopDogTalking
void BBMazeGameScene::calstopDogTalkingFunc()
{
    
    bazziTalking->stopDogTalking();
    
}

#pragma mark - tick
void BBMazeGameScene::secondTick()
{
        replayBtnSpr->setEnabled(true);
}
#pragma mark - Idle

void BBMazeGameScene::idleCheckTick()
{
        if(this->bazziTalking->isBacciTalking==false)
        {
                this->bazziTalking->idleTime ++;
                
                if(this->bazziTalking->idleTime%kBacciIdleTime==0&&this->bazziTalking->isRunningIdleAnimation==false)
                {
                        this->bazziTalking->runBacciIdleAnimation();
                }
        }
}

#pragma mark -initialiseSound
void BBMazeGameScene::initialiseSound()
{
    bazziTalking = new BacciTalking();
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(65,110));  //65
    }
    else
    {
        bazziTalking->initialize(this,CCPoint(60,78)); //35,38
    }
    
    
    //play bgMusic
    if (SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
    {
        SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/maze_oldmac.mp3",true);
    }
    
    if(BBMazeDataManager::sharedManager()->canPlayWelcomeSound)
    {
        
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::playWelcomeSound)),CCDelayTime::create(3.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::initialDogAdviceFunc)),NULL);
        this->runAction(Seq);
    }
    
    if(BBMazeDataManager::sharedManager()->canPlayReplaySound)
    {
        
     //   soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtoplayagain.mp3",false);
       CCSequence *Seq = CCSequence::create(CCDelayTime::create(16), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::replaySound)),NULL);
        this->runAction(Seq);
        
    }
    
    if(BBMazeDataManager::sharedManager()->canPlayAdviceSound)
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(11), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::findBestPath)),NULL);
        this->runAction(Seq);
    }
    if(BBMazeDataManager::sharedManager()->canPlaySecondAdviceSound)
    {
        
     //   CCSequence *Seq = CCSequence::create(CCDelayTime::create(18), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::lookForObstacles)),NULL);
      //  this->runAction(Seq);
        
    }
}


#pragma mark - Initialize
void BBMazeGameScene::initializeVariables()
{
    this->obstacleTouchCount = 0;
    
    this->obstaclesArr = CCArray::create();
    this->obstaclesArr->retain();
    
    this->setTouchEnabled(true);
    this->isPathFound = false;
    this->isGameFinished=false;
    this->isStartedPlaying=false;
    
    
    
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMazeDataManager::sharedManager()->currentLevel);
    BBMazeDataManager::sharedManager()->mazeName = mazeName;
    CCLOG("%s",mazeName);
    
    
    
    //loading plist
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BBMazeGamePlayDetails.plist");
    
    CCDictionary *allMazesInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    aMazeDict = (CCDictionary*)allMazesInfoDict->valueForKey(BBMazeDataManager::sharedManager()->mazeName);
    
    CCLOG("%d",allMazesInfoDict->count());
    
    //loading Puzzle Skeleton position array from plist
    CCString *aPointStr = (CCString *)aMazeDict->objectForKey("gridSize");
    CCPoint gridSizePos = CCPointFromString(aPointStr->getCString());
    
    float nodeSpace = aMazeDict->valueForKey("nodeSpace")->floatValue();
    
    //initialize variables
    this->gridSize = gridSizePos;
    this->nodeSpace = nodeSpace;
    this->touchPointNode = ccp(0, 0);
    
    this->isTouchedNodeIsNew = false;
    
    //touchArray
    this->touchArray = CCPointArray::create(100);
    this->touchArray->retain();
    
    //startArray
    this->startCordArray = CCArray::create();
    this->startCordArray->retain();
    
    //endArray
    this->endCordArray = CCArray::create();
    this->endCordArray->retain();
    
    //gridArray
    this->gridArray = CCArray::createWithCapacity((int)gridSize.x);
    this->gridArray->retain();
    
    //separate grid node
    this->gridNode = new CCNode();
    gridNode->setPosition(ccp(0, 0));
    this->addChild(gridNode,3);
    
    for(int x = 0; x<gridSize.x; x++) {
        
        this->gridArray->addObject(this->gridArray->createWithCapacity((int)gridSize.y));
    }
    
    //Create AStar nodes and place them in the grid
    for(int x = 0; x<gridSize.x; x++)
    {
        for(int y = 0;y<gridSize.y;y++)
        {
            BBAStarNode* node = new BBAStarNode();
            
            CCPoint pos = ccp(x*nodeSpace+nodeSpace/2, y*nodeSpace+nodeSpace/2);
            node->position = pos;
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
            tempArray->insertObject(node, y);
        }
    }
    //Add neighbour nodes
    for(int x=0; x<gridSize.x; x++)
    {
        for(int y=0; y<gridSize.y; y++)
        {
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
            BBAStarNode *node = (BBAStarNode*)tempArray->objectAtIndex(y);
            node->active = false;
            
            //Add self as neighbor to neighboring nodes
            this->addNeighbourNodeToGridNode(node, x-1, y-1);
            this->addNeighbourNodeToGridNode(node, x-1, y);
            this->addNeighbourNodeToGridNode(node, x-1, y+1);
            this->addNeighbourNodeToGridNode(node, x, y-1);
            
            this->addNeighbourNodeToGridNode(node, x, y+1);
            this->addNeighbourNodeToGridNode(node, x+1, y-1);
            this->addNeighbourNodeToGridNode(node, x+1, y);
            this->addNeighbourNodeToGridNode(node, x+1, y+1);
        }
    }
    
#ifdef kMazeDebug
    this->addGridArt();
#endif
}

#pragma mark - Sounds

void BBMazeGameScene::playWelcomeSound()
{
    bazziTalking->startDogTalking();
    soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizmazes.mp3",false);
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(Seq);
    
}
void BBMazeGameScene::findBestPath()
{
    
    if (this->isPathFound==false&&isStartedPlaying)
    {
        bazziTalking->startDogTalking();
        SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
        BBMazeDataManager::sharedManager()->canPlayAdviceSound=false;
        int rand = arc4random() % 2;
        if (rand == 0)
        {
            soundValue=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/lookfirsttosee_maze.mp3");
        }
        else if (rand == 1)
        {
            soundValue=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/toseebestpath_maze.mp3");
            
        }
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.8), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
        this->runAction(Seq);
        
    }
}

//void BBMazeGameScene::lookForObstacles()
//{
//    if (this->isPathFound==false&&isStartedPlaying)
//        
//    {
//        BBMazeDataManager::sharedManager()->canPlaySecondAdviceSound=false;
//        SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
//        bazziTalking->startDogTalking();
//        int rand = arc4random() % 2;
//        if (rand == 0)
//        {
//            soundValue = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/watchoutobstacles_maze.mp3");
//        }
//        else if (rand == 1)
//        {
//            soundValue = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/goaroundobstacles_maze.mp3");
//        }
//        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
//        this->runAction(Seq);
//        
//        
//    }
//}

void BBMazeGameScene::replaySound()
{
    if(!isPathFound)
    {
        SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
        bazziTalking->startDogTalking();
        soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtoplayagain.mp3",false);
        BBMazeDataManager::sharedManager()->canPlayReplaySound=false;
    }
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(Seq);
    
}

void BBMazeGameScene::convincesound()
{
    
    if(isStartedPlaying)
    {
        
        this->bazziTalking->startDogTalking();
        int rand=arc4random()%3;
        SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
        if(rand==0)
        {
            soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tryagainyoucandoit.mp3",false);
        }
        else if(rand==1)
        {
            soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/onemoretime.mp3",false);
        }
        else
        {
            soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/try again.mp3",false);
        }
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.0), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
        this->runAction(Seq);
    }
}


#pragma mark - UI
void BBMazeGameScene::GameUI() {
    //dog base
    CCSprite *dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        dogBase->setPosition(CCPointMake(60,30));   //117.9 48
    }
    else
    {
        dogBase->setVisible(false);
        //  dogBase->setPosition(CCPointMake(43,22));
    }
    
    this->addChild(dogBase,2);
    
    //    CCSprite *dogSpr = CCSprite::createWithSpriteFrameName("doggy.png");
    //          this->addChild(dogSpr,10);
    
    //Reset Scene
    CCSprite *NormalSpr = CCSprite::createWithSpriteFrameName("repeat.png");
    CCSprite *SelectedSpr = CCSprite::createWithSpriteFrameName("repeat.png");
    
    replayBtnSpr = CCMenuItemSprite::create(NormalSpr, SelectedSpr, this, menu_selector(BBMazeGameScene::replaceScene));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        replayBtnSpr->setPosition(CCPointMake(952.3,690));
    }
    else
    {
        replayBtnSpr->setPosition(CCPointMake(966,692));
    }
        this->replayBtnSpr->setEnabled(false);

    //Back to Main Menu
    CCSprite *controlNormalSpr = CCSprite::createWithSpriteFrameName("control.png");
    CCSprite *controlSelectedSpr = CCSprite::createWithSpriteFrameName("control.png");
    
    controlMenuItem = CCMenuItemSprite::create(controlNormalSpr, controlSelectedSpr, this, menu_selector(BBMazeGameScene::gotoGameSelectionScene));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        controlMenuItem->setPosition(CCPointMake(78,690));
    }
    else
    {
        controlMenuItem->setPosition(CCPointMake(60,690));
    }
    
    //goTo Different Levels
    CCSprite *leftArrowNormalSpr = CCSprite::createWithSpriteFrameName("leftArrow.png");
    CCSprite *leftArrowSelectedSpr = CCSprite::createWithSpriteFrameName("leftArrow.png");
    
    leftArrowMenuItem = CCMenuItemSprite::create(leftArrowNormalSpr, leftArrowSelectedSpr, this, menu_selector(BBMazeGameScene::goToPreviousScene));
    leftArrowMenuItem->setPosition(CCPointMake(57,305));
    leftArrowMenuItem->setVisible(false);
    //goTo Different Levels
    if(BBMazeDataManager::sharedManager()->currentLevel==1)
    {
        leftArrowMenuItem->setVisible(false);
        
    }
    
    CCSprite *rightArrowNormalSpr = CCSprite::createWithSpriteFrameName("rightArrow.png");
    CCSprite *rightArrowSelectedSpr = CCSprite::createWithSpriteFrameName("rightArrow.png");
    rightArrowMenuItem = CCMenuItemSprite::create(rightArrowNormalSpr, rightArrowSelectedSpr, this, menu_selector(BBMazeGameScene::goToNextScene));
    rightArrowMenuItem->setPosition(CCPointMake(962,305));
    rightArrowMenuItem->setVisible(false);
    
    if(BBMazeDataManager::sharedManager()->currentLevel==15)
    {
        rightArrowMenuItem->setVisible(false);
        rightArrowMenuItem->setEnabled(false);
    }
    
    CCMenu *tempMenu = CCMenu::create(replayBtnSpr, controlMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,10);
    
    char mazeName[20];
    sprintf(mazeName, "%d/15", BBMazeDataManager::sharedManager()->currentLevel);
    
    //    CCLabelTTF *pageCount = CCLabelTTF::create(mazeName, "arial", 50);
    //    pageCount->setPosition(ccp(954,41));
    //    pageCount->setColor(ccc3(255,0,0));
    //
    //   //   pageCount->setColor(ccc3(0,162,255));
    //    CCRenderTexture *stroke = createStroke(pageCount,2,ccWHITE);
    //    this->addChild(stroke,10);
    //    this->addChild(pageCount,10);
    CCLabelTTF *pageCountLbl=CCLabelTTF::create(mazeName, "Apple Casual", 45);
    pageCountLbl->setColor(ccc3(0,162,255));
    pageCountLbl->setPosition(ccp(954,41));
    
    CCRenderTexture *stroke =createStroke(pageCountLbl, 3,ccWHITE);
    this-> addChild(stroke,10);
    this->addChild(pageCountLbl,10);
    
    //Add Award-Cup Sprite
    award = CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,5);
    award->setScale(0.7);
    award->setPosition(ccp(512,384));
    award->setVisible(false);
}

void BBMazeGameScene::addBgWithObstacles() {
    
    this->startCordArray = (CCArray*)aMazeDict->valueForKey("startPointArray");
    this->endCordArray = (CCArray*)aMazeDict->valueForKey("endPointArray");
    
    //getting Winsize
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    
    //Green Bg
    CCSprite *backGround = CCSprite::create("Maze/BG/Bg green.png");
    this->addChild(backGround,2);
    backGround->setPosition(ccp(size.width/2, size.height/2));
    
    //Yellow Bg
    CCSprite *yellowSprite = CCSprite::create("Maze/BG/Bg yellow.png");
    this->addChild(yellowSprite,1);
    yellowSprite->setPosition(ccp(size.width/2, size.height/2));
    
    //Yellow Bg
    char spriteName1[150];
    sprintf(spriteName1,"Maze/Objects/%s",aMazeDict->valueForKey("fenceName")->getCString());
    
    CCSprite *fenceSprite = CCSprite::create(spriteName1);
    this->addChild(fenceSprite,3);
    fenceSprite->setPosition(ccp(524, 375));
    //fenceSprite->setVisible(false);
    
    //------------------------Add Black BG images
    char spriteName[150];
    sprintf(spriteName,"Maze/ForegroundBlackImages/%s",aMazeDict->valueForKey("BackgroundSpriteName")->getCString());
    
    this->blackBackgroundSprite = CCSprite::create(spriteName);
    this->blackBackgroundSprite->setPosition(ccp(512, 384));
    //    this->blackBackgroundSprite->setOpacity(0);
    this->addChild(this->blackBackgroundSprite,-1);
    
    //        if (size.width==2048&&size.height==1536)  //ipad-retina
    //        {
    //                this->blackBackgroundSprite ->setScale(2.0);
    //        }
    
    
    //startPoint
    for(int i = 0; i<this->startCordArray->count(); i++)
    {
        CCString *aPointStr  =  (CCString *)this->startCordArray->objectAtIndex(i);
        CCPoint point  =  CCPointFromString(aPointStr->getCString());
        CCSprite *startSprite = CCSprite::create("Maze/Images/start_button.png");
        startSprite->setScale(1);
        startSprite->setVisible(false);
        startSprite->setPosition(ccp(point.x*nodeSpace+nodeSpace/2, point.y*nodeSpace+nodeSpace/2));
        this->gridNode->addChild(startSprite,5);
    }
    
    //endPoint
    for(int i = 0; i<this->endCordArray->count(); i++)
    {
        CCString *aPointStr  =  (CCString *)this->endCordArray->objectAtIndex(i);
        CCPoint point  =  CCPointFromString(aPointStr->getCString());
        CCSprite *endSprite = CCSprite::create("Maze/Images/end_button.png");
        endSprite->setPosition(ccp(point.x*nodeSpace+nodeSpace/2, point.y*nodeSpace+nodeSpace/2));
        this->gridNode->addChild(endSprite,5);
        endSprite->setVisible(false);
        
    }
    
    
    //-------------------StartPoint
    //add Farmer sprite
    this->farmerSprite = CCSprite::create("Maze/Objects/Farmer001.png");
    this->addChild(this->farmerSprite,30);
    this->farmerSprite->setScale(0.5);
    this->farmerSprite->setAnchorPoint(ccp(0.5, 0));
    
    //set Farmer position
    CCString *aPointStr1 = (CCString *)aMazeDict->valueForKey("farmerPos");
    CCPoint point1 = CCPointFromString(aPointStr1->getCString());
    this->farmerSprite->setPosition(point1);
    
    this->previousFarmerPosition = this->farmerSprite->getPosition();
    this->currentFarmerPosition = this->farmerSprite->getPosition();
    
    //-------------------EndPoint
    //add Cow sprite
    this->aCow = CCSprite::create("Maze/Objects/Vaca001.png");
    this->aCow->setScale(0.5);
    this->addChild(this->aCow,5);
    
    //set Cow position
    CCString *aPointStr = (CCString *)aMazeDict->valueForKey("cowPos");
    CCPoint point = CCPointFromString(aPointStr->getCString());
    this->aCow->setPosition(point);
    
    //load Objects for MazeGame from plist
    CCArray *objectsArr = (CCArray*)aMazeDict->valueForKey("objects");
    
    CCObject *aObj = NULL;
    CCARRAY_FOREACH(objectsArr, aObj)
    {
        CCDictionary *objectDetailsDict = (CCDictionary*)aObj;
        
        //load and set Image Name
        char spriteName[150];
        sprintf(spriteName,"Maze/Objects/%s",objectDetailsDict->valueForKey("imageName")->getCString());
        
        CCSprite *aSpr = CCSprite::create(spriteName);
        
        CCString *aPointStr = (CCString *)objectDetailsDict->valueForKey("imagePos");
        CCPoint point = CCPointFromString(aPointStr->getCString());
        aSpr->setPosition(point);
        this->obstaclesArr->addObject(aSpr);
        this->addChild(aSpr,3);
    }
}

void BBMazeGameScene::addStars()
{
    // int x=276;
    // int y=31;
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        xPos=170;
        yPos=25;  //48
    }
    else
    {
        xPos=170;
        yPos=25; //15
    }
    
    
    for(int i=0; i<BBMazeDataManager::sharedManager()->starCount; i++){
        
        
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starEmptySprite,20);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            xPos=xPos+50; //55
        }
        else
        {
            xPos=xPos+50; //30 //25
        }
    }
    
    for(int i=0; i<15-BBMazeDataManager::sharedManager()->starCount; i++){
        
        CCSprite *starEmptySprite = CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,20);
        starEmptySprite->setPosition(ccp(xPos,yPos));
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            xPos=xPos+50;
        }
        
        else
        {
            xPos=xPos+50;
        }
        
    }
}

//void BBMazeGameScene::addingStarAfterLevelTen()
//{
//        int x=276;
//        int y=31;
//
//        for(int i=0; i<BBMazeDataManager::sharedManager()->starCount; i++){
//
//                CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
//                this->addChild(starEmptySprite,5);
//                starEmptySprite->setPosition(ccp(x, y));
//                x=x+50;
//        }
//
//        for(int i=0; i<5-BBMazeDataManager::sharedManager()->starCount; i++){
//
//                CCSprite *starEmptySprite = CCSprite::createWithSpriteFrameName("star_white.png");
//                this->addChild(starEmptySprite,5);
//                starEmptySprite->setPosition(ccp(x, y));
//                x=x+50;
//        }
//
//}
#pragma mark - starAnimationSound
void BBMazeGameScene::playStarAnimationSound()
{
    bazziTalking->startDogTalking();
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    int rand=arc4random()%2;
    if(rand==0)
    {
        
        soundValue=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/star1.mp3");
        
    }
    else
    {
        soundValue=SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/star2.mp3");
    }
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.3), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(Seq);
    
}

void BBMazeGameScene::addNewStar()
{
    
    BBMazeDataManager::sharedManager()->isAddedStar=true;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    this->playStarAnimationSound();
    
    CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
    starSprite->setPosition(ccp(170+((BBMazeDataManager::sharedManager()->starCount)*50),25));
    this->addChild(starSprite,20);
    
    CCRotateTo *rotate=CCRotateTo::create(.6, 1080);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.1, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.1, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIN = CCFadeIn::create(0.1);
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut,fadeIN,NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut,fadeIN,NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(0.25), seq2, NULL);
    starSprite->runAction(seq3);
    
    //Play Star Sound
    BBMazeDataManager::sharedManager()->starCount++;
    
    if(BBMazeDataManager::sharedManager()->starCount==15)
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::addBanner)),NULL);
        this->runAction(Seq);
        replayBtnSpr->setEnabled(false);
    }
    
    
    //        if(BBMazeDataManager::sharedManager()->starCount==10)
    //        {
    //                BBMazeDataManager::sharedManager()->starCount=0;
    //                award->setVisible(true);
    //                award->setScale(0);
    //                CCScaleTo *scaleSmall = CCScaleTo::create(0.6,0.7);
    //                award->runAction(scaleSmall);
    //
    //                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::replaceScene)),NULL);
    //                this->runAction(Seq);
    //        }
    //        else
    //        {
    //                award->setVisible(false);
    //        }
}


CCRenderTexture* BBMazeGameScene::createStroke(CCLabelTTF* label, int size, ccColor3B color)
{
    CCRenderTexture *rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2,label->getTexture()->getContentSize().height+size * 2);
    
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    
    rt->begin();
    
    for (int i=20; i<360; i+=40)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    
    return rt;
}

#pragma mark - Menu Methods
void BBMazeGameScene::replaceScene()
{
    if( BBMazeDataManager::sharedManager()->isAddedStar)
    {
        BBMazeDataManager::sharedManager()->isAddedStar=true;
    }
    else
    {
        BBMazeDataManager::sharedManager()->isAddedStar=false;
        
    }
    
    
    award->setVisible(false);
    bazziTalking->stopDogTalking();
    BBMazeDataManager::sharedManager()->canTapDog=true;
    //Inorder to replace with the cuurent scene we need to take the currentLevel
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMazeDataManager::sharedManager()->currentLevel);
    BBMazeDataManager::sharedManager()->mazeName = mazeName;
    BBMazeDataManager::sharedManager()->canPlayWelcomeSound=false;
 
        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
}

void BBMazeGameScene::gotoGameSelectionScene()
{
        BBAllGamesFunctionSharedManager::sharedManager()->resetToDefaultValues();
    
    //  BBMazeDataManager::sharedManager()->canPlayWelcomeSound=false;
    //        BBMazeDataManager::sharedManager()->canPlayAdviceSound=true;
    BBMazeDataManager::sharedManager()->isAddedStar=false;
    BBMazeDataManager::sharedManager()->currentLevel=1;
    BBMazeDataManager::sharedManager()->starCount=0;
    BBMazeDataManager::sharedManager()->canTapDog=true;
    BBMazeDataManager::sharedManager()->canPlayReplaySound=true;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    
    BBSharedSoundManager::sharedManager()->playGameButtonSound();
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}

void BBMazeGameScene::goToNextScene(CCMenuItemSprite *sender)

{
    BBMazeDataManager::sharedManager()->isAddedStar=false;
    BBMazeDataManager::sharedManager()->canTapDog=true;
    BBMazeDataManager::sharedManager()->canPlayWelcomeSound=false;
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    bazziTalking->stopDogTalking();
    
    
    //incrementing levelCount
    BBMazeDataManager::sharedManager()->currentLevel++;
    award->setVisible(false);
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMazeDataManager::sharedManager()->currentLevel);
    BBMazeDataManager::sharedManager()->mazeName = mazeName;
    
    if (BBMazeDataManager::sharedManager()->currentLevel > 15) {
        return;
    }
    else {
        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
    }
}

void BBMazeGameScene::goToPreviousScene(CCMenuItemSprite *sender) {
    award->setVisible(false);
    //decrementing levelCount
    BBMazeDataManager::sharedManager()->currentLevel--;
    BBMazeDataManager::sharedManager()->canTapDog=true;
    BBMazeDataManager::sharedManager()->isAddedStar=false;
    char mazeName[20];
    sprintf(mazeName, "Maze%d", BBMazeDataManager::sharedManager()->currentLevel);
    BBMazeDataManager::sharedManager()->mazeName = mazeName;
    
    if (BBMazeDataManager::sharedManager()->currentLevel < 1) {
        return;
    }
    else {
        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
    }
}

#pragma mark - replaceScene
void BBMazeGameScene::gotoNextLevel()
{
        if(BBMazeDataManager::sharedManager()->pageCount<=14)
        {
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::goToNextScene)),NULL);
                this->runAction(Seq);
        }
        
}
#pragma mark - addingCongratulationBanner
void BBMazeGameScene::addBanner()
{
        this->calladdingTrophyFunc();
        
  //  leftArrowMenuItem->setVisible(false);
//    bazziTalking->startDogTalking();
//    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
//    {
//        BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(509,670));
//    }
//    else
//    {
//        BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(500,650));
//    }
//    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calladdingTrophyFunc)),NULL);
//    this->runAction(Seq);
}

#pragma mark - addTrophy
void BBMazeGameScene::calladdingTrophyFunc()
{
    award->setVisible(true);
    
    
    
    CCScaleTo *scaleTo = CCScaleTo::create(.5, 1.5);
    CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
    award->runAction(move_ease_in);
    ///  this->setTouchEnabled(true);
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(4), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::afterFinishingLevelFunc)),NULL);
    this->runAction(Seq);
    
    // SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    // SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    
    // SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playOnGettingTrophy();
    
    bazziTalking->startDogTalking();
    CCSequence *SeqOne = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(SeqOne);
    
    
}
#pragma mark - afterFinishingLevelFunc
void BBMazeGameScene::afterFinishingLevelFunc()
{
    this->isAddedCongratulationPopUp=true;
    
    isGameFinished=true;
    bazziTalking->startDogTalking();
    BBSharedSoundManager::sharedManager()->playGameCompletePopUpSound();
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.7), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
    this->runAction(Seq);
    
    
    CCSize winsize= CCDirector::sharedDirector()->getWinSize();
    award->setVisible(false);
    CCSprite *congragulationSpr = CCSprite::createWithSpriteFrameName("congrats.png");
    congragulationSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(congragulationSpr,10);
    // congragulationSpr->setScale(2);
    
    CCSprite *playAgainNormalSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    CCSprite *playAgainSelectedSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    
    CCMenuItemSprite *playAgainMenuItem = CCMenuItemSprite::create(playAgainNormalSpr, playAgainSelectedSpr, this, menu_selector(BBMazeGameScene::playAgainFunc));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        playAgainMenuItem->setPosition(ccp(120,10));
    }
    else
    {
        playAgainMenuItem->setPosition(ccp(120,10));
    }
    
    CCSprite *gobackNormalSpr = CCSprite::createWithSpriteFrameName("goback.png");
    CCSprite *gobackSelectedSpr = CCSprite::createWithSpriteFrameName("goback.png");
    
    CCMenuItemSprite *gobackMenuItem = CCMenuItemSprite::create(gobackNormalSpr, gobackSelectedSpr, this, menu_selector(BBMazeGameScene::goBackFunc));
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        gobackMenuItem->setPosition(ccp(320, 10));
    }
    else
    {
        gobackMenuItem->setPosition(ccp(320, 10));
    }
    
    CCScaleBy *scaleTo = CCScaleBy::create(1, 1.5);
    CCActionInterval* move_ease_in = CCEaseBackInOut::create((CCActionInterval*)(scaleTo->copy()->autorelease()));
    congragulationSpr->runAction(move_ease_in);
    
    
    CCMenu *tempMenu = CCMenu::create(playAgainMenuItem,gobackMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    congragulationSpr->addChild(tempMenu,10);
    
}

#pragma mark -playAgainFunc
void BBMazeGameScene::playAgainFunc()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playPlayAgainButtonSound();
    bazziTalking->startDogTalking();
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.0), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::playAgainFuncAfterDelay)),NULL);
    this->runAction(Seq);
}

#pragma mark - goBackFunc
void BBMazeGameScene::goBackFunc()
{
    this->gotoGameSelectionScene();
}

void BBMazeGameScene::playAgainFuncAfterDelay()
{
    char mazeName[20];
    BBMazeDataManager::sharedManager()->currentLevel=1;
    BBMazeDataManager::sharedManager()->starCount=0;
    BBMazeDataManager::sharedManager()->canPlayWelcomeSound=false;
    sprintf(mazeName, "Maze%d", BBMazeDataManager::sharedManager()->currentLevel);
    BBMazeDataManager::sharedManager()->mazeName = mazeName;
    bazziTalking->stopDogTalking();
    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
}

#pragma mark -removeLabel
void BBMazeGameScene::removeLoadLabel() {
    this->removeChildByTag(777, true);
}

#pragma mark - Update
void BBMazeGameScene::checkPath(CCTime dt)
{
    //If path found, then return
    if(this->isPathFound)
        return;
    if(isGameFinished)
        
        return;
    
    
    //-----------------------------Start Co-ordinate Array
    CCObject *aStartCordObj = NULL;
    CCARRAY_FOREACH(this->startCordArray, aStartCordObj)
    {
        CCString *aPointStr = (CCString *)aStartCordObj;
        CCPoint point = CCPointFromString(aPointStr->getCString());
        CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex((int)point.x);
        BBAStarNode *startNode = (BBAStarNode*)tempArray->objectAtIndex((int)point.y);
        
        //---------------------------End Co-ordinate Array
        CCObject *aEndCordObj = NULL;
        CCARRAY_FOREACH(this->endCordArray, aEndCordObj)
        {
            //If path found, then return
            if(this->isPathFound)
                return;
            
            CCString *aPointStr = (CCString *)aEndCordObj;
            CCPoint point = CCPointFromString(aPointStr->getCString());
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex((int)point.x);
            BBAStarNode *endNode = (BBAStarNode*)tempArray->objectAtIndex((int)point.y);
            
            //---------------Checking Path
            CCPointArray *tempPathArray = BBAStarPathNode::findPathFromStartToEnd(startNode, endNode);
            
            if(tempPathArray->count() != 0)
            {
                this->isPathFound = true;
                
                //stop all other sounds when farmer reaches to the cow
                // SimpleAudioEngine::sharedEngine()->stopEffect(welcomeSoundInt);
                
                pathFoundlabel = CCLabelTTF::create("Path Found", "Apple Casual", 40);
                pathFoundlabel->setPosition(ccp(512, 700));
                    
                    SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
               // this->addChild(pathFoundlabel,15);
                    bazziTalking->startDogTalking();
                    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
                    {
                            BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(509,685)); //670
                    }
                    else
                    {
                            BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(500,650));
                    }
                    CCSequence *Seq = CCSequence::create(CCDelayTime::create(.7), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),NULL);
                    this->runAction(Seq);
                    
                
                 
                CCPointArray *tempPurePathPoints = BBMazeGameScene::genCatmullRomSplinesWithPoints(tempPathArray, tempPathArray->count(), 2);
                
                CCPointArray *curveArray = CCPointArray::create(1000);
                curveArray->retain();
                curveArray->addControlPoint(ccp(130, 400));
                
                for(int i=tempPurePathPoints->count(); i>=0; i=i-6)
                {
                    CCPoint point = tempPurePathPoints->getControlPointAtIndex(i);
                    int x = point.x;
                    int y = point.y-15;
                    
                    CCPoint tp = ccp(x, y);
                    curveArray->addControlPoint(tp);
                }
                
                CCString *aPointStr = (CCString *)aMazeDict->valueForKey("curvePoint");
                CCPoint point = CCPointFromString(aPointStr->getCString());
                
                curveArray->addControlPoint(point);
                
                int speed = 5;
                float dur = curveArray->count()/speed;
                
                CCCatmullRomTo *action = CCCatmullRomTo::create(dur, curveArray);
                CCFiniteTimeAction *seq = CCSequence::create(action,
                                                             CCCallFunc::create(this,callfunc_selector(BBMazeGameScene::afterReachingDestinationFunc)),
                                                             CCCallFuncN::create(this,callfuncN_selector(BBMazeGameScene::stopAnimation)),
                                                             //   CCCallFunc::create(this,callfunc_selector(BBMazeGameScene::addNewStar)),
                                                             //  CCDelayTime::create(0.1),
                                                             CCCallFunc::create(this,callfunc_selector(BBMazeGameScene::callCowAnimation)),CCDelayTime::create(2),
                                                             CCCallFuncN::create(this,callfuncN_selector(BBMazeGameScene::stopCowAnimation)),   CCCallFuncN::create(this,callfuncN_selector(BBMazeGameScene::gotoNextLevel)),NULL);
                                                            // CCCallFunc::create(this,callfunc_selector(BBMazeGameScene::callVisibileFuncForArrows)),NULL);
                
                this->farmerSprite->runAction(seq);
                
                testArray = curveArray;
                tempPurePathPoints->retain();
            }
            
            CC_SAFE_RELEASE(tempPathArray);
            continue;
        }
        //
        
    }
    
}


void BBMazeGameScene::callVisibileFuncForArrows()
{
    if(BBMazeDataManager::sharedManager()->currentLevel==1)
    {
      leftArrowMenuItem->setVisible(false);
        rightArrowMenuItem->setVisible(true);
    }
    else if( BBMazeDataManager::sharedManager()->currentLevel==15)
    {
        leftArrowMenuItem->setVisible(true);
        rightArrowMenuItem->setVisible(false);
        
    }
    else
    {
        leftArrowMenuItem->setVisible(true);
        rightArrowMenuItem->setVisible(true);
        
    }
    if(BBMazeDataManager::sharedManager()->pageCount<=14)
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::goToNextScene)),NULL);
        this->runAction(Seq);
    }
    
    
}

void BBMazeGameScene::update(CCTime dt) {
    if(this->isPathFound&& isRunningFarmerAnimation){
        
        previousFarmerPosition = currentFarmerPosition;
        currentFarmerPosition = this->farmerSprite->getPosition();
        
        CCPoint ptCurrPos = CCPoint(currentFarmerPosition.x, currentFarmerPosition.y);
        CCPoint ptPrevPos = CCPoint(previousFarmerPosition.x,previousFarmerPosition.y);
        
        int angleBtwnCurrPosAndPrevPos = getAngleBetweenPoints(ptCurrPos, ptPrevPos);
        // CCLOG("%d=angle",angleBtwnCurrPosAndPrevPos);
        //Flip Conditions
        if((currentFarmerPosition.y > previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos > 330 && angleBtwnCurrPosAndPrevPos <= 360)) || (currentFarmerPosition.y > previousFarmerPosition.y &&(angleBtwnCurrPosAndPrevPos > 0 && angleBtwnCurrPosAndPrevPos <= 30))) {
            //            CCLog("UP...");
            if (walkingState != kUp) {
                walkingState = kUp;
                
                //stopping other actions when one action is running
                this->stopAnimation();
                
                //run farmerBack Animation
                this->runAnimation("FarmerBack");
                
                this->farmerSprite->setFlipX(false);
            }
        }
        else if((currentFarmerPosition.y > previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos >= 31 && angleBtwnCurrPosAndPrevPos <= 75 )) && walkingState != kRight) {
            //            CCLog("RIGHT-UP...");
            walkingState = kRight;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(false);
        }
        else if((currentFarmerPosition.x > previousFarmerPosition.x && (angleBtwnCurrPosAndPrevPos >= 76 && angleBtwnCurrPosAndPrevPos <= 110)) && walkingState != kRight) {
            //            CCLog("RIGHT...");
            walkingState = kRight;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(false);
        }
        else if((currentFarmerPosition.y < previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos > 111 && angleBtwnCurrPosAndPrevPos <= 160)) && walkingState != kRight) {
            //            CCLog("RIGHT-DOWN...");
            walkingState = kRight;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(false);
        }
        else if((currentFarmerPosition.y < previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos >= 161 && angleBtwnCurrPosAndPrevPos <= 210))) {
            //            CCLog("DOWN...");
            if (walkingState != kDown) {
                walkingState = kDown;
                
                //stopping other actions when one action is running
                this->stopAnimation();
                
                //run farmerFront Animation
                this->runAnimation("FarmerFront");
                
                this->farmerSprite->setFlipX(false);
            }
        }
        else if((currentFarmerPosition.y < previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos > 211 && angleBtwnCurrPosAndPrevPos < 260)) && walkingState != kLeft) {
            //            CCLog("LEFT-DOWN...");
            walkingState = kLeft;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(true);
        }
        else if((currentFarmerPosition.x < previousFarmerPosition.x && (angleBtwnCurrPosAndPrevPos >= 261 && angleBtwnCurrPosAndPrevPos <= 280)) && walkingState != kLeft) {
            //            CCLog("LEFT...");
            walkingState = kLeft;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(true);
        }
        else if((currentFarmerPosition.y > previousFarmerPosition.y && (angleBtwnCurrPosAndPrevPos >= 281 && angleBtwnCurrPosAndPrevPos <= 330)) && walkingState != kLeft) {
            //            CCLog("LEFT-UP...");
            walkingState = kLeft;
            
            //stopping other actions when one action is running
            this->stopAnimation();
            
            //run farmerWalk Animation
            this->runAnimation("Farmer");
            
            this->farmerSprite->setFlipX(true);
        }
        return;
    }
    if(this->isTouchedNodeIsNew) {
        this->flipNodeWithTouchedNode();
        this->isTouchedNodeIsNew = false;
    }
}


#pragma mark - GetAngleBetween Two Points
float BBMazeGameScene::getAngleBetweenPoints(CCPoint currentPoint, CCPoint toPoint){
    
    float angle;
    CCPoint difference = ccpSub(currentPoint, toPoint);
    angle = -1 * (atan2(difference.y, difference.x) * 180 / M_PI + 90) + 180;
    
    if (angle < 0) {
        angle = 360 + angle;
    }
    return abs(angle);
}


#pragma mark - Animation
void BBMazeGameScene::callCowAnimation() {
    
    //Cow Animation
    CCAnimationCache *animCacheVaca = CCAnimationCache::sharedAnimationCache();
    CCAnimation *animationForVaca = animCacheVaca->animationByName("Vaca");
    animationForVaca->setRestoreOriginalFrame(1);
    CCAnimate *animNVaca = CCAnimate::create(animationForVaca);
    this->aCow->runAction(animNVaca);
}

void BBMazeGameScene::stopCowAnimation() {
    
    //stop actions for Cow and set the default Image
    this->aCow->stopAllActions();
    this->aCow->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Vaca001.png"));
}

void BBMazeGameScene::runAnimation(const char* animName) {
    
    CCAnimationCache *animCacheFarmer = CCAnimationCache::sharedAnimationCache();
    CCAnimation *animationFarmer= animCacheFarmer->animationByName(animName);
    animationFarmer->setRestoreOriginalFrame(1);
    CCAnimate *animNFarmer = CCAnimate::create(animationFarmer);
    CCRepeatForever *repeatAction = CCRepeatForever::create(animNFarmer);
    repeatAction->setTag(4444);
    this->farmerSprite->runAction(repeatAction);
}

void BBMazeGameScene::stopAnimation()
{
    this->farmerSprite->stopActionByTag(4444);
}

void BBMazeGameScene::resetIsRunningAnimation() {
    this->isRunningAnimation = false;
}

void BBMazeGameScene::afterReachingDestinationFunc()
{
    // BBMazeDataManager::sharedManager()->isFarmerReachedDestination=true;
    this->farmerSprite->setDisplayFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("Farmer006.png"));
    this->farmerSprite->setFlipX(false);
    isRunningFarmerAnimation=false;
    if(!BBMazeDataManager::sharedManager()->isAddedStar)
    {
        if(BBMazeDataManager::sharedManager()->currentLevel%2==1)
        {
            bazziTalking->startDogTalking();
            SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
            
          //  int random = arc4random()%2;
          //  if (random==0) {
                soundValue= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/hoorayfoodforcow_maze.mp3");
          //  }
          //  else
           // {
           //     BBAllGamesFunctionSharedManager::sharedManager()->addCongratulationBanner(false, CCPointZero);
          //  }
            
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.8), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),CCDelayTime::create(.8),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::addNewStar)),NULL);
            this->runAction(Seq);
        }
        else
        {
            this->addNewStar();
        }
    }
}

void BBMazeGameScene::setFarmerFlipTrue()
{
    this->farmerSprite->setFlipX(true);
}

#pragma mark - Logic
void BBMazeGameScene::addNeighbourNodeToGridNode(BBAStarNode *node, int x, int y) {
    
    if(x>=0 && y>=0 && x<gridSize.x && y<gridSize.y)
    {
        CCArray *tempArr = (CCArray*)this->gridArray->objectAtIndex(x);
        BBAStarNode *neighbourNode = (BBAStarNode*)tempArr->objectAtIndex(y);
        node->neighbourNodesArray->addObject(neighbourNode);
    }
}

void BBMazeGameScene::addWall() {
    
    CCSize s = CCDirector::sharedDirector()->getWinSize();
    
    CCLabelTTF *loading = CCLabelTTF::create("Loading...", "Apple Casual", 40);
    loading->setColor(ccc3(255, 0, 0));
    loading->setPosition(ccp(s.width/2, s.height/2));
    loading->setTag(777);
    this->addChild(loading,25);
    
    bool isShouldAddWall;
    for(int p=0; p<1024; p=p+6)
    {
        for(int q=0; q<768; q=q+6)
        {
            isShouldAddWall = this->scanForObstacles(ccp(p,q));
            //            this->blackBackgroundSprite->setVisible(false);
            if(isShouldAddWall)
            {
                //                this->blackBackgroundSprite->setVisible(false);
                int m = ((p-gridNode->getPositionX())/nodeSpace);
                int n = ((q-gridNode->getPositionY())/nodeSpace);
                CCPoint tp = ccp(m,n);
                int x = tp.x;
                int y = tp.y;
                
                CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
                BBAStarNode *node = (BBAStarNode*)tempArray->objectAtIndex(y);
                node->isWall = true;
                node->active = false;
                
#ifdef kMazeDebug
                
                //converting the touch position into string
                CCString *aStr = CCString::createWithFormat("%d,%d",x,y);
                
                //here the sprite stored in the spriteDict in addGridArt method is accessed
                CCSprite *aSpr = (CCSprite*)this->spritesDict->objectForKey(aStr->getCString());
                
                //if the node is not a wall(i.e obstacle), then it will set the color for dat particular node so as to make a path from the start to end
                if(node->isWall)
                {
                    aSpr->setColor(ccc3(255, 0, 0));
                }
#endif
            }
        }
    }
#ifdef kMazeDebug
    this->blackBackgroundSprite->setZOrder(10);
    this->blackBackgroundSprite->setOpacity(50);
#else
    this->blackBackgroundSprite->setVisible(false);
    
#endif
    
    CCDelayTime *delayAction = CCDelayTime::create(0.2);
    CCSequence *seq = CCSequence::createWithTwoActions(delayAction, CCCallFuncN::create(this,callfuncN_selector(BBMazeGameScene::removeLoadLabel)));
    this->runAction(seq);
    
    this->isPixelReading = false;
}

CCPointArray* BBMazeGameScene::genCatmullRomSplinesWithPoints(CCPointArray *arrOriginalPoints, int num, int segments) {
    
    //Create Point Array
    CCPointArray *arrPathConverted = CCPointArray::create(1000);
    arrOriginalPoints->retain();
    
    float b[segments][4];
    {
        //Precompute interpolation parameters
        float t = 0.0f;
        float dt = 1.0f/(float)segments;
        
        for (int i=0; i<segments; i++, t+=dt) {
            float tt  = t*t;
            float ttt  = tt * t;
            b[i][0] = 0.5f * (-ttt + 2.0f*tt - t);
            b[i][1] = 0.5f * (3.0f*ttt -5.0f*tt +2.0f);
            b[i][2] = 0.5f * (-3.0f*ttt + 4.0f*tt + t);
            b[i][3] = 0.5f * (ttt - tt);
        }
    }
    
    {   //first control point
        int i=0;
        
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        arrOriginalPoints->addControlPoint(point);
        
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i+1);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+2);
            
            float px = (b[j][0]+b[j][1])*point.x + b[j][2]*pointPlusOne.x + b[j][3]*pointPlusTwo.x;
            float py = (b[j][0]+b[j][1])*point.y + b[j][2]*pointPlusOne.y + b[j][3]*pointPlusTwo.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }
    
    for (int i=1; i<num-2; i++) {
        
        //the first interpolated point is always the original control point
        CCPoint p;
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        p.x = point.x;
        p.y = point.y;
        
        arrPathConverted->addControlPoint(p);
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i-1);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+1);
            CCPoint pointPlusThree = arrOriginalPoints->getControlPointAtIndex(i+2);
            
            float px  =  b[j][0]*point.x + b[j][1]*pointPlusOne.x + b[j][2]*pointPlusTwo.x + b[j][3]*pointPlusThree.x;
            float py  =  b[j][0]*point.y + b[j][1]*pointPlusOne.y + b[j][2]*pointPlusTwo.y + b[j][3]*pointPlusThree.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }
    
    {   //second to last control point
        int i = num-2;
        CCPoint p;
        CCPoint point = arrOriginalPoints->getControlPointAtIndex(i);
        
        p.x = point.x;
        p.y = point.y;
        
        arrPathConverted->addControlPoint(p);
        
        for (int j=1; j<segments; j++)
        {
            CCPoint point = arrOriginalPoints->getControlPointAtIndex(i-1);
            CCPoint pointPlusOne = arrOriginalPoints->getControlPointAtIndex(i);
            CCPoint pointPlusTwo = arrOriginalPoints->getControlPointAtIndex(i+1);
            
            float px = b[j][0]*point.x + b[j][1]*pointPlusOne.x + (b[j][2]+b[j][3])*pointPlusTwo.x;
            float py = b[j][0]*point.y + b[j][1]*pointPlusOne.y + (b[j][2]+b[j][3])*pointPlusTwo.y;
            
            CCPoint p;
            p.x = px;
            p.y = py;
            
            arrPathConverted->addControlPoint(p);
        }
    }
    
    //the very last interpolated point is the last control point
    CCPoint point = arrOriginalPoints->getControlPointAtIndex(num-1);
    arrPathConverted->addControlPoint(point);
    arrPathConverted->autorelease();
    return arrPathConverted;
}

bool BBMazeGameScene::scanForObstacles(CCPoint point) {
    
    CCSize size = CCEGLView::sharedOpenGLView()->getFrameSize();
    float contentFactorX =1.0f;
    float contentFactorY = 1.0f;
    
    if (size.width==2048&&size.height==1536)  //ipad-retina
    {
        contentFactorX = .5f;
        contentFactorY = .5f;
    }
    else if(size.width==480&&size.height==320) //iphone-normal
    {
        contentFactorX = 2.13;
        contentFactorY = 2.4;
    }
    else if(size.width==960&&size.height==640) //iphone-retina
    {
        contentFactorX=1.06;
        contentFactorY=1.2;
    }
    else if(size.width==1136&&size.height==640) //iphone-5
    {
        contentFactorX=0.90;
        contentFactorY=1.2;
    }
    
    glReadPixels(point.x/contentFactorX, point.y/contentFactorY, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, &pixelColors[0]);
    if(pixelColors[0] == 0 && pixelColors[1] == 0 && pixelColors[0] == 0)
    {
        return true;
    }
    return false;
}


void BBMazeGameScene::draw()
{
    
    if(this->isPixelReading)
    {
        this->addWall();
    }
}

#pragma mark - Touches
void BBMazeGameScene::ccTouchesBegan(CCSet *pTouches,CCEvent *pEvent)
{
    this->isStartedPlaying=true;
    this->playSoundWhenTapDog(pTouches,pEvent);
    
    //If path found return
    if(this->isPathFound)
        return;
    
        CCSetIterator it;
    CCTouch* touch;
    
    for(it=pTouches->begin(); it!=pTouches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        sPoint = location;
        
        this->createParticleAtPosition(location);
        
        int x = ((location.x-gridNode->getPositionX())/nodeSpace);
        int y = ((location.y-gridNode->getPositionY())/nodeSpace);
        
        CCPoint tp = ccp(x, y);
        this->isTouchedNodeIsNew = true;
        this->touchPointNode = tp;
        this->touchArray->addControlPoint(this->touchPointNode);
    }
}

void BBMazeGameScene::ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent) {
    //If path found return
    if(this->isPathFound)
        return;
    
    //Grid Scan
    CCTouch *touch1 = (CCTouch*)pTouches->anyObject();
    CCPoint start = touch1->getLocation();
    CCPoint end = touch1->getPreviousLocation();
    
    //set position for particles
    if(addParticleEffectToTexture)
        addParticleEffectToTexture->setPosition(start);

    
    renderTarget->begin();
    float dist = ccpDistance(start, end);
    
    //---------------//
    if(dist>1)
    {
        int d = (int)dist;
        for(int i = 0; i<d; i++)
        {
            float difx = end.x - start.x;
            float dify = end.y - start.y;
            float delta = (float)i/dist;
            
            CCPoint t1 = ccp(start.x + (difx * delta), start.y + (dify * delta));
            int x = ((t1.x-gridNode->getPositionX())/nodeSpace);
            int y = ((t1.y-gridNode->getPositionY())/nodeSpace);
            
            CCPoint tp = ccp(x, y);
            if(tp.x!=this->touchPointNode.x || tp.y!=this->touchPointNode.y)
                this->isTouchedNodeIsNew = true;
            
            this->touchPointNode = tp;
            this->touchArray->addControlPoint(this->touchPointNode);
            
            renderSprite->setPosition(t1);
            renderSprite->setRotation(rand() % 360);
            float r = (float)(rand()%40 / 50.f) + 0.25f;
            renderSprite->setScale(r);
            renderSprite->setColor(ccc3(25,180,200));
            
                       
            renderSprite->visit();
        }
    }
    renderTarget->end();
}

void BBMazeGameScene::ccTouchesEnded(CCSet *pTouches, CCEvent *pEvent)
{
    //stop particle effect when touch stops & start in touchesbegin
    this->removeParticle();
    
    if(this->isPathFound)
        return;
    
    
}


void BBMazeGameScene::ccTouchesCancelled(CCSet *pTouches, CCEvent *pEvent)
{
    this->removeParticle();
    
    if(this->isPathFound)
        return;
  }


//This tick vl be called every seconds to check whether has bad path
void BBMazeGameScene::farmerTouchedObstacle()
{
        if(  this->canPlayHintSound)
        {
                if(checkForBadPath()==1)
                {
                        CCLOG("There was a bad path ");
                        if(hintCount<=3&&!isPathFound)
                        {
                                this->canPlayHintSound=false;
                                hintCount++;
                                SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
                                bazziTalking->startDogTalking();
                                
                                int rand = arc4random() % 2;
                                if(hintCount<=2)
                                {
                                        if (rand == 0)
                                        {
                                                soundValue = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/watchoutobstacles_maze.mp3");
                                        }
                                        else if (rand == 1)
                                        {
                                                soundValue = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/goaroundobstacles_maze.mp3");
                                        }
                                }
                                else
                                {
                                        this->convincesound();
                                }
                                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),CCDelayTime::create(6),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::setcanPlayHintSoundTrue)),NULL);
                                this->runAction(Seq);
                                this->resetBadPath();
                        }
                }
        }
        
}

void BBMazeGameScene::setcanPlayHintSoundTrue()
{
        this->canPlayHintSound=true;
}
#pragma mark - soundAfterTappingDog
void BBMazeGameScene::playSoundWhenTapDog(CCSet *pTouches,CCEvent *pEvent)
{
    CCTouch* touches = (CCTouch*)pTouches->anyObject();
    CCPoint  touchPoint = touches->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    if(bazziTalking->animatedDog->boundingBox().containsPoint(touchPoint))
    {
        if(BBMazeDataManager::sharedManager()->canTapDog)
        {
            BBMazeDataManager::sharedManager()-> dogTapCount++;
            BBMazeDataManager::sharedManager()->canTapDog=false;
            SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
            SimpleAudioEngine::sharedEngine()->stopAllEffects();
            bazziTalking->startDogTalking();
            if(!isGameFinished)
            {
                int rand=arc4random()%4;
                if(rand==0)
                {
                    soundValue=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/lookfirsttosee_maze.mp3");
                }
                else if(rand==1)
                {
                    soundValue=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/toseebestpath_maze.mp3");
                }
                else if(rand==2)
                {
                    soundValue=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/goaroundobstacles_maze.mp3");
                    
                }
                else if(rand==3)
                {
                    soundValue=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/watchoutobstacles_maze.mp3");
                }
            }
            else
            {
                soundValue=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3");
            }
            if(isGameFinished&&isAddedCongratulationPopUp)
            {
                SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
                
                SimpleAudioEngine::sharedEngine()->stopEffect(soundValue);
                BBSharedSoundManager::sharedManager()-> playSoundOnTappingDogAfterPopup();
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.8), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::canTapDog)),NULL);
                this->runAction(Seq);
                
            }
            
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::calstopDogTalkingFunc)),CCCallFunc::create(this, callfunc_selector(BBMazeGameScene::canTapDog)),NULL);
            this->runAction(Seq);
            
        }
        
    }
    
}
#pragma mark - canTapDog
void BBMazeGameScene::canTapDog()
{
    BBMazeDataManager::sharedManager()->canTapDog=true;
}

#pragma mark - flipNodeWithTouchedNode
void BBMazeGameScene::flipNodeWithTouchedNode() {
    
    for(int i=0; i<touchArray->count(); i++)
    {
        CCPoint point1 = this->touchArray->getControlPointAtIndex(i);
        
        int x = point1.x;
        int y = point1.y;
        
        if(x == 0 && y == 0)
            return;
        
        if(x == gridSize.x-1 && y == gridSize.y-1)
            return;
        
        if(x<0 || y<0 || x>gridSize.x-1 || y>gridSize.y-1)
            return;
        
        CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
        touchedNode = (BBAStarNode*)tempArray->objectAtIndex(y);
            
            if(touchedNode->isWall==false)
            {
                    touchedNode->active = true;
            }
            else
            {
                    touchedNode->didUserAttemptedForBadPath = true;
            }
    }
        

        
//        if(!touchedNode->isWall)
//            touchedNode->active = true;
//    }
    
    //Clean the Point Array
    while (touchArray->count() != 0)
        touchArray->removeControlPointAtIndex(0);
}


#pragma mark - Detect Bad Path
//Detect Bad Path
bool BBMazeGameScene::checkForBadPath()
{
        for(int p=0; p<1024; p=p+6)
        {
                for(int q=0; q<768; q=q+6)
                {
                        int m = ((p-gridNode->getPositionX())/nodeSpace);
                        int n = ((q-gridNode->getPositionY())/nodeSpace);
                        CCPoint tp = ccp(m,n);
                        int x = tp.x;
                        int y = tp.y;
                        
                        CCArray *tempArray = NULL;
                        
                        if (x<this->gridArray->count()) {
                                tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
                                
                                
                                BBAStarNode *node = NULL;
                                
                                if (y<tempArray->count())
                                {
                                        node = (BBAStarNode*)tempArray->objectAtIndex(y);
                                        
                                        if (node->didUserAttemptedForBadPath) {
                                                return true;
                                        }
                                }
                        }
                }
        }
        return false;
}

void BBMazeGameScene::resetBadPath()
{
        for(int p=0; p<1024; p=p+6)
        {
                for(int q=0; q<768; q=q+6)
                {
                        int m = ((p-gridNode->getPositionX())/nodeSpace);
                        int n = ((q-gridNode->getPositionY())/nodeSpace);
                        CCPoint tp = ccp(m,n);
                        int x = tp.x;
                        int y = tp.y;
                        
                        CCArray *tempArray = NULL;

                        if (x<this->gridArray->count()) {
                                tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
                                
                                BBAStarNode *node = NULL;
                                
                                if (y<tempArray->count())
                                {
                                        node = (BBAStarNode*)tempArray->objectAtIndex(y);
                                        node->didUserAttemptedForBadPath = false;
                                      
                                }
                        }
                }
        }
}


#pragma mark - Design size

void BBMazeGameScene::setMazeDefaultValues()
{
    CCDirector *pDirector = CCDirector::sharedDirector();
    
    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    CCSize designSize;
    CCSize resourceSize;
    CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
    
    std::vector<std::string> searchPaths;
    
    if (screenSize.height > 768)
    {
        resourceSize = CCSizeMake(2048, 1536);
        searchPaths.push_back("ipad-HD");
    }
    else
    {
        resourceSize = CCSizeMake(1024, 768);
        searchPaths.push_back("ipad-Normal");
    }
    
    designSize = CCSizeMake(1024,768);
    pFileUtils->setSearchPaths(searchPaths);
    
    pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
    CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
}


#pragma mark - Particle
void BBMazeGameScene::createParticleAtPosition(CCPoint inPosition)
{
    //---------------Particle Effect
    this->addParticleEffectToTexture = NULL;
    this->addParticleEffectToTexture = CCParticleSystemQuad::create("BBParticle/mazeTouchDrag.plist");
    this->addParticleEffectToTexture->setAutoRemoveOnFinish(true);
    this->addChild(addParticleEffectToTexture, 1);
}

void BBMazeGameScene::removeParticle()
{
    if(this->addParticleEffectToTexture)
    {
        this->addParticleEffectToTexture->stopSystem();
        this->addParticleEffectToTexture->removeFromParentAndCleanup(true);
        
        this->addParticleEffectToTexture = NULL;

    }
}




#pragma mark - Test
void BBMazeGameScene::addGridArt() {
    
    this->spritesDict = CCDictionary::create();
    this->spritesDict->retain();
    
    for(int x=0; x<gridSize.x; x++)
    {
        for(int y=0; y<gridSize.y; y++)
        {
            CCArray *tempArray = (CCArray*)this->gridArray->objectAtIndex(x);
            
            BBAStarNode *node = (BBAStarNode*)tempArray->objectAtIndex(y);
            CCSprite *sprite;
            
            /*
             if(x==8 && y==27)
             {   //create the start coordinate icon sprite
             sprite=CCSprite::create("Images/Icon.png");
             sprite->setScale(1.5);
             //                sprite->setVisible(false);
             }
             else if(x==56 && y==23)
             {   //create the end coordinate icon sprite
             sprite = CCSprite::create("Images/Icon.png");
             sprite->setScale(1.5);
             //                sprite->setVisible(false);
             }
             else{//create the node sprite
             }
             */
            sprite = CCSprite::create("Maze/MazeResources/Images/gridNode32.png");
            
            node->nodeSprite = sprite;
            sprite->setPosition(node->position);
            
            if(node->active)
            {   //set color for the starting icon sprite
                sprite->setColor(ccc3(200, 200, 200));
            }
            else if(node->isWall && !node->active)
            {   //set color for the end icon sprite
                sprite->setColor(ccc3(200, 200, 200));
            }
            else
            {   //set color for the nodes(all white dots)
                sprite->setColor(ccc3(200, 200, 200));
            }
            
            this->gridNode->addChild(sprite,5);
            
            //storing the sprite's position in the form of string
            CCString *aStr = CCString::createWithFormat("%d,%d",x,y);
            
            //here the sprite is converted into object
            CCObject *tempObj = (CCObject*)sprite;
            
            //here the sprite & it's position is stored in the spriteDict
            //sprite is stored in the form of object
            //position is stored in the form of string
            this->spritesDict->setObject(tempObj, aStr->getCString());
        }
    }
    /*
     //Create start button at the centre of start icon sprite to begin drawing the texture,
     CCSprite *startBtnSpr = CCSprite::create("Images/start_button.png");
     startBtnSpr->setPosition(CCPointMake(startCoord.x*nodeSpace+nodeSpace/2, startCoord.y*nodeSpace+nodeSpace/2));
     this->gridNode->addChild(startBtnSpr,5);
     
     //Create end button at the centre of end icon sprite to end the drawing of texture,
     CCSprite *endBtnSpr = CCSprite::create("Images/end_button.png");
     endBtnSpr->setPosition(CCPointMake(endCoord.x*nodeSpace+nodeSpace/2, endCoord.y*nodeSpace+nodeSpace/2));
     this->gridNode->addChild(endBtnSpr,5);
     */
}
