//
//  BBDatamanager.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#include "cocos2d.h"
#include "CCBReader.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

class BBMazeDataManager: public CCObject
{
    
private:
    
    BBMazeDataManager(void);
    virtual ~BBMazeDataManager(void);
    
public:
    
    
    //Default
    bool init(void);
    static BBMazeDataManager* sharedManager(void);
    
    //Variables
    int type;
    const char *mazeName;
    int currentLevel;

    int pageCount;
    int starCount;
        int wrongPath;

        bool isPressedGamerButton;
        
        bool canPlayWelcomeSound;
        bool canPlayAdviceSound;
        bool canPlaySecondAdviceSound;
        bool canPlayReplaySound;
        bool canTapDog;
        
        
        bool isAddedStar;
        int dogTapCount;

};



