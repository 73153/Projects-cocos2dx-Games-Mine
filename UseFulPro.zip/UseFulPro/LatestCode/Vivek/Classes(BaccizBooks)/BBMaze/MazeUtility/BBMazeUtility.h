//
//  BBUtility.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 31/01/13.
//
//

#ifndef __BaccizBooks__BBUtility__
#define __BaccizBooks__BBUtility__

#include "cocos2d.h"

using namespace cocos2d;

class BBMazeUtility: public cocos2d::CCObject  {
    
private:
    
    BBMazeUtility(void);
    ~BBMazeUtility(void);
    
public:
    static void addGameAnimationsToAnimationCache(const char *pszFileName);
};

#endif
