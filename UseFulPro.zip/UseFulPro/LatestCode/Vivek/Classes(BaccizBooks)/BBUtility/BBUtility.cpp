//
//  BBUtility.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 31/01/13.
//
//

#include "BBUtility.h"
USING_NS_CC;

BBUtility::BBUtility(void) { }

BBUtility::~BBUtility(void) { }



int BBUtility::getRandomNumberBetween(int min, int max) {
    
    int toNumber = max + 1;
    int fromNumber = min;
    
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    
    return randomNumber;
}

CCArray* BBUtility::shuffleArray(CCArray *cardsToShuffle) {
    
    for (int x = 0; x < cardsToShuffle->count(); x++) {
        
        int randInt = (arc4random() % (cardsToShuffle->count() - x)) + x;
        cardsToShuffle->exchangeObjectAtIndex(x, randInt);
    }
    return cardsToShuffle;
}

void BBUtility::addGameAnimationsToAnimationCache(const char *pszFileName) {
        
        CCAssert(pszFileName != NULL, "TextureCache: fileimage MUST not be NULL");
        
        std::string pathKey = pszFileName;
        pathKey = CCFileUtils::sharedFileUtils()->fullPathForFilename(pathKey.c_str());
        
        std::string fullpath = pathKey;
        CCAssert(pszFileName, "Invalid texture file name");
        
        CCDictionary *dictAnimationData = CCDictionary::createWithContentsOfFile(pszFileName);
        CCAssert(dictAnimationData, "CCAnimationCache: File could not be found");
        
        //Looping through the items n adding them into cache...
        CCDictElement* pElement = NULL;
        CCDICT_FOREACH(dictAnimationData, pElement) {
                
                CCDictionary *aAnimationDict = (CCDictionary *)pElement->getObject();
                int numOfFrames = aAnimationDict->valueForKey("no_of_frames")->intValue();
                const char *prefixName = aAnimationDict->valueForKey("prefix")->getCString();
                
                CCArray *animFrames = CCArray::create();
                
                for (int i = 1; i <= numOfFrames; i++) {
                        
                        char name[30];
                        sprintf(name, "%s%d.png",prefixName,i);
                        
                        CCSpriteFrame *frame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name);
                        animFrames->addObject(frame);
                }
                const char *key = aAnimationDict->valueForKey("Key")->getCString();
                float animationDelay = aAnimationDict->valueForKey("delay")->floatValue();
                
                CCAnimation *animation = CCAnimation::createWithSpriteFrames(animFrames,animationDelay);
                animFrames->release();
                CCAnimationCache::sharedAnimationCache()->addAnimation(animation, key);
        }
}
