//
//  BBGameSelection.cpp
//  BaccizBooks
//
//  Created by Vivek on 22/04/13.
//
//

#include "BBGameSelection.h"

#include "BBConfig.h"
#include "BBMainDataManager.h"

#include "SimpleAudioEngine.h"

#include "BBTicToeGamePlay.h"
#include "BBMatchGamePlay.h"
#include "FindMamaGamePlay.h"
#include "TIGameScene.h"
#include "TWGameScene.h"
#include "BBMazeGameScene.h"
#include "BBPuzzleGameSelection.h"

using namespace cocos2d;

#define WIND_PARTICLES 30


CCScene* BBGameSelection::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBGameSelection();
    scene->addChild(layer);
    layer->release();
    
    return scene;
}

#pragma mark - constructor
BBGameSelection::BBGameSelection()
{
    
}

#pragma mark - onEnter
void BBGameSelection::onEnter()
{
    CCLayer::onEnter();
    //loading MainPage plist
CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameSelectionSpriteSheet/BBGameSelection.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");

    this->initializeUI();
    
    this->createWind();

    this->schedule( schedule_selector(BBGameSelection::updateWind) );
    
}

void BBGameSelection::onEnterTransitionDidFinish()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/gamehome_music.mp3", true);
        introSeq =1;
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
    this->runAction(callBack);
}

#pragma mark - iitialiseUI
void BBGameSelection::initializeUI()
{
    CCSize   winsize = CCDirector::sharedDirector()->getWinSize();
    //add bg
    CCSprite *bg = CCSprite::create("BBSharedResources/BackGrounds/BG.png");
    bg->setPosition(CCPointMake(winsize.width/2, winsize.height/2));
    this->addChild(bg);
    
    CCSprite *MGNormalSpr = CCSprite::createWithSpriteFrameName("match.png");
    CCSprite *MGSelectedSpr = CCSprite::createWithSpriteFrameName("match.png");
    
    CCMenuItemSprite *MGMenuItem = CCMenuItemSprite::create(MGNormalSpr, MGSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    MGMenuItem->setTag(1);
    MGMenuItem->setScale(0.80);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
//        MGMenuItem->setPosition(CCPointMake(200,560));
        MGMenuItem->setPosition(CCPointMake(371,635));

    }
    else
    {
        MGMenuItem->setScale(0.80);
        MGMenuItem->setPosition(CCPointMake(160,265));
    }
    
    CCSprite *FMNormalSpr = CCSprite::createWithSpriteFrameName("find-mama.png");
    CCSprite *FMSelectedSpr = CCSprite::createWithSpriteFrameName("find-mama.png");
    
    CCMenuItemSprite *FMMenuItem = CCMenuItemSprite::create(FMNormalSpr, FMSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    FMMenuItem->setTag(2);
    FMMenuItem->setScale(0.80);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
//        FMMenuItem->setPosition(CCPointMake(510,560));
        FMMenuItem->setPosition(CCPointMake(700,125));
    }
    else
    {
        FMMenuItem->setScale(0.80);
        FMMenuItem->setPosition(CCPointMake(325,55));
    }
    
    CCSprite *TTTNormalSpr = CCSprite::createWithSpriteFrameName("tictactoe.png");
    CCSprite *TTTSelectedSpr = CCSprite::createWithSpriteFrameName("tictactoe.png");
    
    CCMenuItemSprite *TTTMenuItem = CCMenuItemSprite::create(TTTNormalSpr, TTTSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TTTMenuItem->setTag(3);
    TTTMenuItem->setScale(0.80);

    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
//        TTTMenuItem->setPosition(CCPointMake(200,200));
          TTTMenuItem->setPosition(CCPointMake(525,370));
    }
    else
    {
        TTTMenuItem->setScale(0.80);
        TTTMenuItem->setPosition(CCPointMake(winsize.width/2,160));
    }
    
    CCSprite *TPNormalSpr = CCSprite::createWithSpriteFrameName("tap-the-picture.png");
    CCSprite *TPSelectedSpr = CCSprite::createWithSpriteFrameName("tap-the-picture.png");
    
    CCMenuItemSprite *TPMenuItem = CCMenuItemSprite::create(TPNormalSpr, TPSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TPMenuItem->setTag(4);
    TPMenuItem->setScale(0.80);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
//        TPMenuItem->setPosition(CCPointMake(830,200));
      TPMenuItem->setPosition(CCPointMake(200,370));
    }
    else
    {
        TPMenuItem->setScale(0.80);
        TPMenuItem->setPosition(CCPointMake(60,160));
    }
    
    CCSprite *TWNormalSpr = CCSprite::createWithSpriteFrameName("tap-the-word.png");
    CCSprite *TWSelectedSpr = CCSprite::createWithSpriteFrameName("tap-the-word.png");
    
    CCMenuItemSprite *TWMenuItem = CCMenuItemSprite::create(TWNormalSpr, TWSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TWMenuItem->setTag(5);
    TWMenuItem->setScale(0.80);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
//        TWMenuItem->setPosition(CCPointMake(830,560));
        TWMenuItem->setPosition(CCPointMake(825,370));
    }
    else
    {
        TWMenuItem->setScale(0.80);
        TWMenuItem->setPosition(CCPointMake(420,160));   //400,80
    }
    
//    CCSprite *BSnormal   = CCSprite::createWithSpriteFrameName("bookshelf-icon1.png");
    CCSprite *BSnormal = CCSprite::create("BBSharedResources/spritesheets/BBGameUISpriteSheet/bookshelf-icon1.png");
    CCSprite *BSselected = CCSprite::create("BBSharedResources/spritesheets/BBGameUISpriteSheet/bookshelf-icon1.png");
    
    CCMenuItemSprite *BSMenuItem = CCMenuItemSprite::create(BSnormal, BSselected, this, menu_selector(BBGameSelection::mainMenuCallBack));
    BSMenuItem->setTag(6);
    BSMenuItem->setScale(0.65);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        BSMenuItem->setPosition(CCPointMake(100,700));
    }
    else
    {
        BSMenuItem->setScale(0.65);
        BSMenuItem->setPosition(CCPointMake(45,280));
    }

    CCSprite *MZnormal   = CCSprite::createWithSpriteFrameName("maze.png");
    CCSprite *MZselected = CCSprite::createWithSpriteFrameName("maze.png");
    
    CCMenuItemSprite *MZMenuItem = CCMenuItemSprite::create(MZnormal, MZselected, this, menu_selector(BBGameSelection::mainMenuCallBack));
    MZMenuItem->setTag(7);
    MZMenuItem->setScale(0.8);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        MZMenuItem->setPosition(CCPointMake(700, 635));
    }
    else
    {
        MZMenuItem->setScale(0.8);
        MZMenuItem->setPosition(CCPointMake(325,265));
    }
    
    CCSprite *PZnormal   = CCSprite::createWithSpriteFrameName("puzzle.png");
    CCSprite *PZselected = CCSprite::createWithSpriteFrameName("puzzle.png");
    
    CCMenuItemSprite *PZMenuItem = CCMenuItemSprite::create(PZnormal, PZselected, this, menu_selector(BBGameSelection::mainMenuCallBack));
    PZMenuItem->setTag(8);
    PZMenuItem->setScale(0.8);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        PZMenuItem->setPosition(CCPointMake(361, 125));
    }
    else
    {
        PZMenuItem->setScale(0.8);
        PZMenuItem->setPosition(CCPointMake(160,55));
    }

    
    CCMenu *selectMenu=CCMenu::create(BSMenuItem, MZMenuItem, PZMenuItem, MGMenuItem,FMMenuItem,TTTMenuItem,TPMenuItem,TWMenuItem,NULL);
    selectMenu->setPosition(CCPointZero);
    this->addChild(selectMenu,6);
    
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        CCSprite *dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
        dogBase->setScale(0.8);
        dogBase->setPosition(CCPointMake(83, 47));
        addChild(dogBase);
    }
  
   
   
    
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        bazziTalking->initialize(this,CCPoint(35,38));
    }
    actionTag = 5000;
    
    
    backgroundWidth = winsize.width;
    backgroundHeight = winsize.height;
    windSpeed = 5.0;
    
}

#pragma MARK - replaceSceneS

void BBGameSelection::mainMenuCallBack(CCObject * pSender)
{
    CCMenuItemSprite *item = (CCMenuItemSprite*)pSender;
    
    int tag = item->getTag();
    
    if(dogTalking)
    {
      CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        this->callStopDogAnimation();
    }
    selectedScene = tag;
    
    switch (tag) {
        case 1:
        {
           
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/matchgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
            
        case 2:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/findmyparents.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 3:
        {
        
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tictactoe_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 4:
        {

            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapthepicture.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 5:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taptheword_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 6:
        {
    
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/bookshelf.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 7:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/maze.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 8:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/puzzles_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
            
        default:
            break;
    }
    
}

void BBGameSelection::playScene()
{
        switch (selectedScene)
        {
                        
                case 1:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
                        break;
                        
                case 2:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(FindMamaGamePlay::scene());
                        break;
                        
                case 3:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(BBTicToeGamePlay::scene());
                        break;
                case 4:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
                        break;
                case 5:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
                        break;
                case 6:
                        //Go back to bookshelf
                        break;
                case 7:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
                        break;
                case 8:
                        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
                        CCDirector::sharedDirector()->replaceScene(BBPuzzleGameSelection::scene());
                        break;
                        
                default:
                        break;
        }
}

void BBGameSelection::goToMGScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
}

void BBGameSelection::goToFMScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(FindMamaGamePlay::scene());
}
void BBGameSelection::goToTicTacToeScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(BBTicToeGamePlay::scene());
}
void BBGameSelection::goToTPScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
}
void BBGameSelection::goToTWScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
}

void BBGameSelection::goToBS()
{
    
}

void BBGameSelection::goToMZScene()
{       

    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
}

void BBGameSelection::goToPZScene()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    CCDirector::sharedDirector()->replaceScene(BBPuzzleGameSelection::scene());
}


#pragma mark - destructor
BBGameSelection::~BBGameSelection()
{
      CC_SAFE_RELEASE_NULL(this->windParticles);
}

#pragma MARK - onExit
void BBGameSelection::onExit()
{
    CCLayer::onExit();
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameSelectionSpriteSheet/BBGameSelection.plist");
    
    
}

#pragma mark - windAnimation
void BBGameSelection::createWind()
{
    
        windParticles = CCArray::create();
        windParticles->retain();

    
	float creationZone_Width =  backgroundWidth;
	float creationZone_Height = backgroundHeight;
	float densityRatio = (backgroundWidth*backgroundHeight)/(512*512);
    
	for (int j=0; j<(WIND_PARTICLES*densityRatio); j++)
    {
        
        
        int subImageType = 1 + arc4random() % 5;
        
        CCString *url = CCString::createWithFormat("BBSharedResources/spritesheets/BBGameUISpriteSheet/l%i.png", subImageType) ;

        
		
        leafSprite* leaf = leafSprite::create(url->getCString());
        CCLOG(url->getCString());
        leaf->setScale(0.5 + (CCRANDOM_0_1() + 0.01) * 0.3);
        leaf->setTag(j);
        
        this->addChild(leaf);
        
		leaf->setPosition(ccp(((CCRANDOM_0_1() + 0.01) * creationZone_Width),((CCRANDOM_0_1() + 0.01) * creationZone_Height)));
		leaf->setSpeed(windSpeed);
		leaf->startMovement();
		
		windParticles->addObject(leaf);
	}

}

void BBGameSelection::updateWind(CCTime *dt)
{
    //remove out of stage objects
	for (int i=0; i<windParticles->count(); i++){
		
        leafSprite* leaf = (leafSprite *)windParticles->objectAtIndex(i);
		
        if (leaf->getPositionX() < 0 || leaf->getPositionX() > backgroundWidth)
        {
            windParticles->removeObjectAtIndex(i);
            leaf->removeLeaf();
		}
	
    }
	
	float densityRatio = (backgroundWidth*backgroundHeight)/(512*512);
	
	//create new objects
	if (windParticles->count() < WIND_PARTICLES*densityRatio) {
		float creationZone_Height = backgroundHeight;
		float creationZone_Width =  (windSpeed < 0)?100.0f:-100.0f;
		
		for (int j=0; j<((WIND_PARTICLES*densityRatio) - windParticles->count()); j++)
        {
            
			float start_point = (windSpeed>0)?0:backgroundWidth;

            int subImageType = 1 + arc4random() % 5;
            CCString *url = CCString::createWithFormat("BBSharedResources/spritesheets/BBGameUISpriteSheet/l%i.png", subImageType) ;

            leafSprite* leaf = leafSprite::create(url->getCString());
            leaf->setScale(0.5 + (CCRANDOM_0_1() + 0.01) * 0.3);
            leaf->setTag(j);

            this->addChild(leaf);

            leaf->setPosition(ccp(start_point + ((CCRANDOM_0_1() + 0.01) * creationZone_Width),((CCRANDOM_0_1() + 0.01) * creationZone_Height)));
            leaf->setSpeed(windSpeed);
            leaf->startMovement();

            windParticles->addObject(leaf);
		}
	}
}

# pragma mark - godAnimation

void BBGameSelection::callStopDogAnimation()
{
    bazziTalking->stopDogTalking();
    isDogTalking = false;
    this->setTouchEnabled(true);
}

void BBGameSelection::playIntro()
{
    switch (introSeq)
    {
        case 1:
            this->playWelcome();
            break;
            
        case 2:
        {
            this->callStopDogAnimation();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
            this->runAction(callBack);
        }
            break;
            
        case 3:
        {
            this->playIntructions();
        }
            break;
        default:
            break;
    }
    
    introSeq++;
}

//play the intro animation of the dog Talking.
void BBGameSelection::playWelcome()
{
            this->setTouchEnabled(false);
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizplayground.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
            this->runAction(callBack);
            isDogTalking = true;
}

void BBGameSelection::playIntructions()
{
    this->setTouchEnabled(false);
    bazziTalking->startDogTalking();
    
    int i = arc4random() % 2;
    
    switch (i)
    {
        case 0:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/Letsplay.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
        break;
            
        case 1:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/findgameyouwantoplay_game.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
        break;
            
        case 2:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/selectgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
        break;
            
        default:
            break;
    }
    
    isDogTalking = true;
}


