//
//  leafSprite.h
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/4/13.
//
//

#ifndef BaccizBooks_leafSprite_h
#define BaccizBooks_leafSprite_h

#include "cocos2d.h"

using namespace cocos2d;

class leafSprite : public CCSprite
{
    
public:
    
    leafSprite(void);
    ~leafSprite(void);
    
    static leafSprite* spriteWithFile(const char *pszFileName);
    static leafSprite* spriteWithFrame(const char *pszFileName);
    static leafSprite* create(const char *pszFileName);
    static leafSprite* create(CCSpriteFrame *pSpriteFrame);
    static leafSprite* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static leafSprite* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    
    void setSpeed(float speed);
    void startMovement();
    void createVerticalMotion();
    void setImage();
    void removeLeaf();
    
    float   velocityX;
    float   velocityY;
    
    /*
     -(void) setSpeed: (float)speed;
     -(void) startMovement;
     -(void) createVerticalMotion;
     -(void) setImage;
     */

};


#endif
