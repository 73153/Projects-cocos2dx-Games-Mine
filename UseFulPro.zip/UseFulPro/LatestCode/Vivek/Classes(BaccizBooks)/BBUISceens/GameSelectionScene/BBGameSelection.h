//
//  BBGameSelection.h
//  BaccizBooks
//
//  Created by Vivek on 22/04/13.
//
//

#ifndef BaccizBooks_BBGameSelection_h
#define BaccizBooks_BBGameSelection_h


#include"cocos2d.h"
#include "CCScrollView.h"
#include "cocos-ext.h"
#include "leafSprite.h"
#include "BacciTalking.h"

USING_NS_CC_EXT;

using namespace cocos2d;

class BBGameSelection : public cocos2d::CCLayer
{
private: CCScrollView *scrollView;
        
public:
        //Default
        BBGameSelection();
        ~BBGameSelection();
        
        
        static CCScene* scene();
        
        virtual void onEnter();
        virtual void onExit();
        virtual void onEnterTransitionDidFinish();
        
        void initializeUI();
        void goToMGScene();
        void goToTicTacToeScene();
        void goToTWScene();
        void goToTPScene();
        void goToFMScene();
        void goToMZScene();
        void goToBS();
        void goToPZScene();
    
        void playScene();
        void mainMenuCallBack(CCObject * pSender);
    
    
       float backgroundWidth;
	   float backgroundHeight;
       float windSpeed;
    
       CCArray* windParticles;
    
       void createWind();
       void updateWind(CCTime *dt);
    
    
    BacciTalking *bazziTalking;
    void callStopDogAnimation();
    void playIntro();
    void playWelcome();
    void playIntructions();
    void playAgain();
    
    bool isDogTalking;
    int dogTalking;
    int introSeq;
    int actionTag;
    int selectedScene;

};



#endif
