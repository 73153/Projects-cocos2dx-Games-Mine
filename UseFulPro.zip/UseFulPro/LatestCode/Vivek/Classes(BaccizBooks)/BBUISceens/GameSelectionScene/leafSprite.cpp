//
//  leafSprite.cpp
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/4/13.
//
//

#include "leafSprite.h"

leafSprite::leafSprite(void)
{
 this->velocityX  = 2.0f;
}

leafSprite::~leafSprite(void)
{
    
}

// To create separate sprite from file...
leafSprite* leafSprite::spriteWithFile(const char *pszFileName)
{
    leafSprite *pobSprite = new leafSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        //pobSprite->scheduleUpdate();
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
	return NULL;
}

// To create sprite from sprite sheet!
leafSprite* leafSprite::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    leafSprite *tempSpr = leafSprite::create(pFrame);
    return tempSpr;
}


leafSprite* leafSprite::create(const char *pszFileName)
{
    leafSprite *pobSprite = new leafSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

leafSprite* leafSprite::create(CCSpriteFrame *pSpriteFrame)
{
    leafSprite *pobSprite = new leafSprite();
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

leafSprite* leafSprite::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "This is Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

leafSprite* leafSprite::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    leafSprite *pobSprite = new leafSprite();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

#pragma mark - leafAnimation

void leafSprite::startMovement()
{
//    this->setImage();
    this->createVerticalMotion();
}

void leafSprite::createVerticalMotion()
{
    float multiplierX = 150.0f;
	float multiplierY = 30.0f;
	
	float variantY = 3.0f;
	
	float dura1 = ((CCRANDOM_0_1() + 0.01) * 3)+1;
	float dura2 = ((CCRANDOM_0_1() + 0.01) * 3)+1;
	
	
	float xPos1 = this->getPositionX() + ((CCRANDOM_0_1() + 0.01) * velocityX * multiplierX);
	float xPos2 = xPos1 + ((CCRANDOM_0_1() + 0.01) * velocityX * multiplierX);
	
	float yPos1 = this->getPositionY() + ((CCRANDOM_0_1() + 0.01) * variantY * multiplierY);
	float yPos2 = this->getPositionY() + ((CCRANDOM_0_1() + 0.01) * -variantY * multiplierY);
	
	CCMoveTo *m1 = CCMoveTo::create(dura1, ccp(xPos1, yPos1));//[CCMoveTo actionWithDuration: dura1 position:ccp(xPos1,yPos1)];
	CCMoveTo *m2 = CCMoveTo::create(dura2, ccp(xPos2, yPos2));//id actionVariateDown = [CCMoveTo actionWithDuration:dura2 position:ccp(xPos2,yPos2)];
    
	CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.8),CCCallFunc::create(this,callfunc_selector(leafSprite::createVerticalMotion)),NULL);//id callFunction = [CCCallFunc actionWithTarget:self selector:@selector(createVerticalMotion)];
    
	CCFiniteTimeAction *sequence = CCSequence::create(m1, m2, callBack, NULL);//id sequence = [CCSequence actions: actionVariateUp,actionVariateDown,callFunction,nil];
    
	
//	[self runAction:[CCRepeat actionWithAction:sequence times:1]];
    
    this->runAction(CCRepeat::create(sequence, 1));
    
    
//	[self runAction:[CCRepeat actionWithAction:[CCRotateBy actionWithDuration:((CCRANDOM_0_1() + 0.01) * 3)+1 angle:((CCRANDOM_0_1() + 0.01) * 360)+1] times:2]];
    
    this->runAction(CCRepeat::create(CCRotateBy::create( ((CCRANDOM_0_1() + 0.01) * 3)+1, (CCRANDOM_0_1()+0.01)*360+1 ), 2));

}

void leafSprite::setImage()
{
    int subImageType = 1 + arc4random() % 5;
    CCString *url = CCString::createWithFormat("BBSharedResources/spritesheets/BBGameUISpriteSheet/Leaf%i.png", subImageType) ;//[NSString stringWithFormat:@"Leaf%i.png",subImageType];
    
	//CCSprite* img = CCSprite::create(url->getCString());//[CCSprite spriteWithFile:url];
	
    CCSprite *img = CCSprite::createWithSpriteFrameName("maze.png");
    
    img->setScale(0.5 + (CCRANDOM_0_1() + 0.01) * 0.3);//img.scale = 0.5+ (CCRANDOM_0_1() + 0.01) * 0.3;
	this->addChild(img,0,1);//[self addChild:img z:0 tag:1];
}

void leafSprite::setSpeed(float speed)
{
    velocityX = speed; 
}

void leafSprite::removeLeaf()
{
    if (this->getParent()) {
		this->getParent()->removeChild(this, true);//[parent_ removeChild:self cleanup:YES];
	}
}








