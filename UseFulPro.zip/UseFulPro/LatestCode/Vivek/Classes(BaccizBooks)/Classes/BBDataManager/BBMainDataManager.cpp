//
//  BBDatamanager.cpp
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

//un comentario

#include "BBMainDataManager.h"
#include "cocos2d.h"
using namespace cocos2d::extension;

static BBMainDataManager *gSharedManager = NULL;

BBMainDataManager::BBMainDataManager(void){
    
}

BBMainDataManager::~BBMainDataManager(void){}

BBMainDataManager* BBMainDataManager::sharedManager(void) {
    
	BBMainDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBMainDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBMainDataManager::init(void) {
	return true;
}

void BBMainDataManager::postNitification(bool sw)
{
    CCBool *s = CCBool::create(sw);
   CCNotificationCenter::sharedNotificationCenter()->postNotification("HideBuyFullVersionView", s);
}

