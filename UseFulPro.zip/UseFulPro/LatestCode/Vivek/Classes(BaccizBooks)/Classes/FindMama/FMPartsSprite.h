//
//  FMPartsSprite.h
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#ifndef FindMama_FMPartsSprite_h
#define FindMama_FMPartsSprite_h

#include "cocos2d.h"
#include "FMPartsSprite.h"

using namespace cocos2d;

class FMPartsSprite : public CCSprite
{
    
public:
    
    FMPartsSprite(void);
    ~FMPartsSprite(void);
    
    // Creation of a tile...
    static FMPartsSprite* spriteWithFile(const char *pszFileName);
    static FMPartsSprite* spriteWithFrame(const char *pszFileName);
    static FMPartsSprite* create(const char *pszFileName);
    static FMPartsSprite* create(CCSpriteFrame *pSpriteFrame);
    static FMPartsSprite* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static FMPartsSprite* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    
    // variables
    int matchId;
    float setScale;
    bool isSolved;
    const char *name;
    const char *animalName;
    const char *sound;
};


#endif
