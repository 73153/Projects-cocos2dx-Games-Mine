//
//  FindMamaGamePlayScene.cpp
//  FindMamaGamePlay
//
//  Created by Vivek on 28/05/13.
//
//

#include "FindMamaGamePlay.h"
#include "cocos2d.h"
#include "FMPartsSprite.h"
#include "FMDataManager.h"
#include "SimpleAudioEngine.h"
#include "BBGameSelection.h"
#include "BBMainDataManager.h"
#include "BacciTalking.h"
#include "BBSharedSoundManager.h"
#include "SimpleAudioEngine.h"
#include "BBConfig.h"
#include "BBAllGamesFunctionSharedManager.h"


using namespace CocosDenshion;
using namespace cocos2d;
using namespace extension;

USING_NS_CC_EXT;

#pragma mark default
CCScene* FindMamaGamePlay::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    FindMamaGamePlay *layer = new FindMamaGamePlay();
    
    // add layer as a Parent to scene
    scene->addChild(layer);
    
    CC_SAFE_RELEASE(layer);
    // return the scene
    return scene;
}


FindMamaGamePlay::FindMamaGamePlay()
{
    this->selectedAnimal=NULL;
    this->motherArr = CCArray::create();
    this->motherArr->retain();
    
    this->childArr = CCArray::create();
    this->childArr->retain();
    
    this->randNumberarrayForMother= CCArray::create();
    this->randNumberarrayForMother->retain();
    
    this->lineSprarray= CCArray::create();
    this->lineSprarray->retain();
    
    this->starArray= CCArray::create();
    this->starArray->retain();
    
    this->fatherArr= CCArray::create();
    this->fatherArr->retain();
    
    this->isLoked = BBAllGamesFunctionSharedManager::sharedManager()->isLocked(1);
    //HideBuyFullVersionView
    CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(FindMamaGamePlay::reSet), "HideBuyFullVersionView", NULL);
    

    
}

FindMamaGamePlay::~FindMamaGamePlay()
{
    CCNotificationCenter::sharedNotificationCenter()->removeObserver(this, "HideBuyFullVersionView");
    //Delete Dog from memory
    delete bazziTalking;
    bazziTalking = NULL;

    
    this->clearTexture();
    
    CC_SAFE_RELEASE_NULL(this->motherArr);
    CC_SAFE_RELEASE_NULL(this->childArr);
    CC_SAFE_RELEASE_NULL(this->randNumberarrayForMother);
    CC_SAFE_RELEASE_NULL(this->lineSprarray);
    CC_SAFE_RELEASE_NULL(this->starArray);
    CC_SAFE_RELEASE_NULL(this->fatherArr);
    CC_SAFE_RELEASE_NULL(this->randNumberarrayForFather);
    
}

void FindMamaGamePlay::onEnter()
{
    CCLayer::onEnter();
    
    //load plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("FindMama/BBFMImages.plist");
    
    //Initialising variables
    this->initialiseVariables();
    
    //Initialising Game UI
    this->initialiseGameUI();
    
    //Initialising Game
    this->initialiseGame();
    
    // Idle dog animaton according to scheduling
    this->scheduleIdleTickAfterSounds();
    
}


void FindMamaGamePlay::onExit()
{
    CCLayer::onExit();
    
    this->removeParticle();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("FindMama/BBFMImages.plist");
}

#pragma mark - initialise
void FindMamaGamePlay::initialiseVariables(){
    
    winSize = CCDirector::sharedDirector()->getWinSize();
    
    levelNumber = FMDataManager::sharedManager()->currentLevel;
    
    this->movedChildCount=0;
    this->gameCount=0;
    this->dogAnimationCount=1;
    this->idleTime=0;
    
    this->canStopDogTalking=true;
    this->isFatherPresent=false;
    this->canRenderTexture=false;
    this->setTouchEnabled(true);
    this->canTapChildAnimal=true;
    this->isGameRestarted=true;
    this->isGameCompleted=false;
    this->canDrawTargetTexture=true;
    this->isWrongMathedAnimalMoreThanThree=true;
    
    this->addParticleEffectToTexture = NULL;
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
}

void FindMamaGamePlay::initialiseGameUI()
{
    //Adding White stars
    this->addStars();
    
    //BackGround Music
    if(SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
        SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/mama_music.mp3",true);
    
    CCSprite *goBackToGameSelectionNormalSprite = CCSprite::createWithSpriteFrameName("control.png");
    CCSprite *goBackToGameSelectionSelectedSprite = CCSprite::createWithSpriteFrameName("control.png");
    
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(goBackToGameSelectionNormalSprite, goBackToGameSelectionSelectedSprite, this, menu_selector(FindMamaGamePlay::homeButton));
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        backMenuItem->setPosition(CCPointMake(86,677));
    }
    else
    {
        backMenuItem->setPosition(CCPointMake(35,286));
    }
    
    //Restart button
    CCSprite *normalSprite = CCSprite::createWithSpriteFrameName("repeat.png");
    CCSprite *selectedSprite = CCSprite::createWithSpriteFrameName("repeat.png");
    restartMenuItem = CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(FindMamaGamePlay::restartButtonPressed));
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        restartMenuItem->setPosition(ccp(952,677));
    }
    else
    {
        restartMenuItem->setPosition(ccp(446,288));
    }
    
    CCMenu *tempMenu = CCMenu::create(restartMenuItem, backMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,3);
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        animalLabel = CCLabelTTF::create("", "Apple Casual", 45);
    }
    else
    {
        animalLabel = CCLabelTTF::create("", "Apple Casual", 23);
    }
    
    this-> addChild(animalLabel,3);
    animalLabel->setColor(ccc3(255, 0, 0));
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        CCSprite *dogBaseSpr = CCSprite::createWithSpriteFrameName("dog_base.png");
        this->addChild(dogBaseSpr,4);
        dogBaseSpr->setPosition(ccp(85, 50));
    }
    
    //Award Sprite
    award = CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,6);
    award->setScale(0.7);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        award->setPosition(ccp(522,190));
    }
    else
    {
        award->setPosition(ccp(230,80));
        
    }
    award->setVisible(false);
    
    //bacci
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        this->bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        this->bazziTalking->initialize(this,CCPoint(35,38));
    }
}

void FindMamaGamePlay::initialiseGame()
{
    //Creting New Layer and Adding UI Sprites on it.
    this->animalLayer=CCLayer::create();
    this->addChild(this->animalLayer,1);
    this->animalLayer->setPosition(ccp(0,0));
    
    //Add drawing texture
    this->addTexture();
    
    if(levelNumber==1 && this->isGameRestarted)
    {
        this->setTouchEnabled(false);
        //Welcome Sounds
        CCSequence *sequenceAction = CCSequence::create(CCDelayTime::create(1.0f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::welcomeSound)),NULL);
        this->runAction(sequenceAction);
    }
    
    this->isChildMotherGameSolved=false;
    this->movedChildCount=0;
    this->gameCount=0;
    
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("FMSprites.plist");
    
    CCDictionary  *allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    CCDictionary *animalGroupInfoDict = (CCDictionary*)allCardInfoDict->objectForKey("AnimalGroup");
    
    CCDictionary *levelsInfoDict = (CCDictionary*)allCardInfoDict->objectForKey("Levels");
    linesInfoArr = (CCArray*)allCardInfoDict->objectForKey("Lines");
    
        
    //Taking all the property for the sprite from plist
    char levelName[40]={};
    sprintf(levelName,"Page%d",levelNumber);
    
    levelNameDict = (CCDictionary*)levelsInfoDict->objectForKey(levelName);
    int noOfChildren = levelNameDict->valueForKey("noOfChildAnimals")->intValue();
    int noOfParents = levelNameDict->valueForKey("noOfParentAnimals")->intValue();
    
    this->isFatherPresent = levelNameDict->valueForKey("isFatherPresent")->boolValue();
    
    this->isNextLevelFree = levelNameDict->valueForKey("isNextLevelFree")->boolValue();
    
    CCLog("Valor isNextLevelFree = %s",(isNextLevelFree)?"true":"false");

    
    CCString *bgName = (CCString*)levelNameDict->valueForKey("background");
    
    char BGName[80];
    sprintf(BGName,"BBSharedResources/BackGrounds/%s",bgName->getCString());
    backgroundforSpr = CCSprite::create(BGName);
    backgroundforSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->animalLayer->addChild(backgroundforSpr);
    
    //Setting the Lable For Difficulties
    sprintf(BGName,"%d/12",levelNumber);
    CCLabelTTF *levelLbl = NULL;
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        levelLbl=CCLabelTTF::create(BGName, "Apple Casual", 45);
        
    }
    else
    {
        levelLbl=CCLabelTTF::create(BGName, "Apple Casual", 25);
    }
    this->animalLayer->addChild(levelLbl,1);
    levelLbl->setColor(ccc3(0,162,255));
    levelLbl->setPosition(CCPointMake(950, 80));
    
    //Creating Stroke For the Level Number
    CCRenderTexture *stroke =createStrokeForLable(levelLbl, 2,ccWHITE, 100);
    this->animalLayer-> addChild(stroke);
    
    // remove the line color
    if( levelNumber==4|| levelNumber==10){
        // remove blue and yellow line from array
        linesInfoArr->removeObjectAtIndex(0,true);
        //linesInfoArr->removeObjectAtIndex(6,true);
    }
    
    if(levelNumber==1|| levelNumber==8||levelNumber==9||levelNumber==13|| levelNumber==14 || levelNumber==15 || levelNumber==16|| levelNumber==5|| levelNumber==6||levelNumber==10||levelNumber==11){
        // remove green line from array
        linesInfoArr->removeObjectAtIndex(5);
    }
    if(levelNumber==3|| levelNumber==7)
    {
        // remove yellow line from array
        linesInfoArr->removeObjectAtIndex(6);
    }
    
    CCString *AnimalGroupString = (CCString*)levelNameDict->valueForKey("AnimalGroup");
    arrayOfAnimalsAccordingToGroupName=(CCArray*)animalGroupInfoDict->objectForKey(AnimalGroupString->getCString());
    
    //store unique no's into array
    int no_to_randomize[10];
    for (int i = 0 ; i <arrayOfAnimalsAccordingToGroupName->count(); i++){
        no_to_randomize[i] = i;
    }
    
    if(!(levelNumber==3 || levelNumber ==7))
    {
        //store indexes into an integer Array from randomize method
        store_randomArray = this->randomizeInt(no_to_randomize);
        
    }
    else
    {
        //checking for seal and Manatee not to appear in same Screen
        int j=6;
        int k=0;
        int checkCount=0;
        //mother
        for(int i=0; i<noOfParents; i++)
        {
            int randNum = store_randomArray[i];
            
            if(randNum==j ||randNum==k)
            {
                checkCount++;
                
            }
        }
        
        //store unique no's into array
        int no_to_randomize[7];
        for (int i = 0 ; i < 7; i++){
            no_to_randomize[i] = i;
        }
        
        if(checkCount==2){
            
            store_randomArray=this->rand_num(no_to_randomize);
        }
    }
    
    //Adding The Animals
    this->addMothers(noOfParents);
    this->addChilds(noOfChildren);
    
    //Storing the game over count into gamecount variable
    this->gameCount=this->childArr->count();
    
    //checking whether father present
    if(this->isFatherPresent) {
        this->addFathers(noOfChildren);
        this->gameCount=this->childArr->count() + this->fatherArr->count();
    }
}


void FindMamaGamePlay::reSet(CCBool *sw)
{
    CCLog("Valor sw = %s",(sw->getValue())?"true":"false");

    if (!sw->getValue())
    {
        FMDataManager::sharedManager()->starCount = 0;
        FMDataManager::sharedManager()->currentLevel = 1;
        this->levelNumber = 1;
//        this->isGameRestarted = true;
        FMDataManager::sharedManager()->mistakeCountToImplementStar=0;
//        CCDirector::sharedDirector()->replaceScene(FindMamaGamePlay::scene());

        CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
    }
    else
    {
        this->isLoked = BBAllGamesFunctionSharedManager::sharedManager()->isLocked(1);
        this->levelCleared();
    }
    
    

}



#pragma mark - createStroke
//creating the stroke for the levelcount variable, to know the difficulty level
CCRenderTexture*  FindMamaGamePlay::createStrokeForLable(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity)
{
    
    CCRenderTexture* rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2,
                                                  label->getTexture()->getContentSize().height+size * 2);
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    // label->setAnchorPoint(ccp(0,0.5));
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    label->setZOrder(6);
    
    rt->begin();
    
    for (int i=0; i<360; i+=50)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    
    return rt;
}

//creating the stroke for the selected Animal
CCRenderTexture* FindMamaGamePlay::createStroke(CCSprite* sparite, int size, ccColor3B color, GLubyte opacity)
{
    CCRenderTexture* rt = CCRenderTexture::create(sparite->getTexture()->getContentSize().width * size, sparite->getTexture()->getContentSize().height*size);
    
    CCPoint originalPos = sparite->getPosition();
    
    ccColor3B originalColor = sparite->getColor();
    
    GLubyte originalOpacity = sparite->getOpacity();
    
    bool originalVisibility = sparite->isVisible();
    
    sparite->setColor(color);
    
    sparite->setOpacity(opacity);
    
    sparite->setVisible(true);
    
    ccBlendFunc originalBlend = sparite->getBlendFunc();
    
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    
    sparite->setBlendFunc(bf);
    
    CCPoint bottomLeft = ccp(sparite->getTexture()->getContentSize().width * sparite->getAnchorPoint().x + size, sparite->getTexture()->getContentSize().height * sparite->getAnchorPoint().y + size);
    
    
    rt->begin();
    
    for (int i=0; i<360; i+= 15)
    {
        sparite->setPosition(
                             ccp(bottomLeft.x + sin(CC_DEGREES_TO_RADIANS(i))*size, bottomLeft.y + cos(CC_DEGREES_TO_RADIANS(i))*size));
        sparite->visit();
    }
    
    rt->end();
    
    sparite->setPosition(originalPos);
    sparite->setColor(originalColor);
    sparite->setBlendFunc(originalBlend);
    sparite->setVisible(originalVisibility);
    sparite->setOpacity(originalOpacity);
    
    rt->setPosition(originalPos);
    
    return rt;
    
}

#pragma mark - Add animals
void FindMamaGamePlay::addMothers(int noOfParents)
{
    this->randNumberarrayForFather = CCArray::create();
    this->randNumberarrayForFather->retain();
    
    //mother
    for(int i=0; i<noOfParents; i++)
    {
        int randNum = store_randomArray[i];
        CCString *rand_No_string = CCString::createWithFormat("%d",randNum);
        
        this->randNumberarrayForMother->addObject(rand_No_string);
        this->randNumberarrayForFather->addObject(CCInteger::create(randNum));
        
        CCDictionary *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(randNum);
        
        
        animalName = (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        
        std::string mamaAnimalName = this->motherAnimalName(animalName);
        
        
        FMPartsSprite *motherSpr = motherSpr->createWithSpriteFrameName(mamaAnimalName.c_str());
        motherSpr->sound = selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(motherSpr,3);
        //position
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPositionIpad");
            CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos=CCPointFromString(posSting->getCString());
            motherSpr->setPosition(CCPoint(firstParentPos));
        }
        else{
            CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPositionIphone");
            CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos=CCPointFromString(posSting->getCString());
            motherSpr->setPosition(CCPoint(firstParentPos));
        }
        
        motherSpr->matchId = randNum;
        motherSpr->animalName = animalName;
        this->motherArr->addObject(motherSpr);
    }
}

std::string FindMamaGamePlay::motherAnimalName(const char *motherName)
{
    char Name[30]={};
    if(std::string("Chicken")==animalName)
    {
        if(levelNumber==1 || levelNumber==2)
        {
            sprintf(Name,"%s-A0.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-A.png",animalName);
        }
    }
    
    if(std::string("Cow")==animalName){
        
        cow_Rand_Num=arc4random()%2;
        if(!(levelNumber==10||levelNumber==11||levelNumber==12))
        {
            if(levelNumber==1)
            {
                sprintf(Name,"%s-A1.png",animalName);
            }
            else if (levelNumber==2)
            {
                sprintf(Name,"%s-A0.png",animalName);
            }
            else
            {
                sprintf(Name,"%s-A%d.png",animalName,cow_Rand_Num);
            }
        }
        else
        {
            sprintf(Name,"%s-A1.png",animalName);
            
        }
    }
    else if(std::string("Bird")==animalName){
        
        if(levelNumber==2)
        {
            sprintf(Name,"%s-A1.png",animalName);
        }
        else if (levelNumber==3 || levelNumber==7)
        {
            sprintf(Name,"%s-A2.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-A0.png",animalName);
        }
    }
    
    else if(std::string("Cat")==animalName){
        
        cat_Rand_Num=arc4random()%2;
        if(cat_Rand_Num==0)
        {
            sprintf(Name,"%s-A0.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-A1.png",animalName);
        }
    }
    
    else if(std::string("Parrot")==animalName){
        
        if(levelNumber==1  || levelNumber==5   )
        {
            sprintf(Name,"%s-A1.png",animalName);
        }
        else if (levelNumber==4|| levelNumber==8 || levelNumber==9 ||levelNumber==2)
        {
            sprintf(Name,"%s-A0.png",animalName);
        }
    }
    
    else
    {
        sprintf(Name,"%s-A.png",animalName);
        
    }
    std::string mamaName=Name;
    return mamaName;
}

void FindMamaGamePlay::addFathers( int noOfFather)
{
    //fathers
    for(int i=0; i<noOfFather; i++)
    {
        int randNo = arc4random()% this->randNumberarrayForFather->count();
        
        CCInteger *rand_Number_string = (CCInteger*)this->randNumberarrayForFather->objectAtIndex(randNo);
        int rand = rand_Number_string->getValue();
        this->randNumberarrayForFather->removeObject(rand_Number_string);
        
        CCDictionary   *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(rand);
        char Name[30]={};
        const char *animalName= (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        
        sprintf(Name,"%s-C.png",animalName);
        
        FMPartsSprite *fatherSpr  = fatherSpr->createWithSpriteFrameName(Name);
        fatherSpr->sound=selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(fatherSpr,3);
        
        //position
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPositionIpad");
            CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos=CCPointFromString(posSting->getCString());
            fatherSpr->setPosition(CCPoint(firstParentPos));
            
            if(levelNumber==19){
                fatherSpr->setPosition(CCPoint(firstParentPos.x+80,-100));
            }
            else
            {
                fatherSpr->setPosition(CCPoint(firstParentPos.x,-100));
            }
        }
        else
        {
            CCArray *arrayOfParentPos=(CCArray*)levelNameDict->objectForKey("parentAnimalPositionIphone");
            CCString *posSting=(CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos=CCPointFromString(posSting->getCString());
            fatherSpr->setPosition(CCPoint(firstParentPos));
            
            if(levelNumber==19)
            {
                fatherSpr->setPosition(CCPoint(firstParentPos.x+40,-50));
            }
            else
            {
                fatherSpr->setPosition(CCPoint(firstParentPos.x,-50));
            }
        }
        fatherSpr->matchId = rand;
        fatherSpr->animalName = animalName;
        this->fatherArr->addObject(fatherSpr);
    }
}

void FindMamaGamePlay::addChilds(int noOfChildren)
{
    //Child
    if(levelNumber>=11){
        
        this->randNumberarrayForFather->removeAllObjects();
    }
    for(int i=0; i<noOfChildren; i++)
    {
        int randNo = arc4random() % this->randNumberarrayForMother->count();
        
        CCString *rand_Number_string = (CCString*)this->randNumberarrayForMother->objectAtIndex(randNo);
        int rand = rand_Number_string->intValue();
        if(levelNumber>=11){
            
            this->randNumberarrayForFather->addObject(CCInteger::create(rand));
        }
        this->randNumberarrayForMother->removeObject(rand_Number_string);
        
        CCDictionary   *selectAnimal =(CCDictionary*)arrayOfAnimalsAccordingToGroupName->objectAtIndex(rand);
        
        animalName= (const char *)selectAnimal->valueForKey("AnimalName")->getCString();
        std::string childAnimalName = this->childAnimalName(animalName);
        
        FMPartsSprite *childSpr  = childSpr->createWithSpriteFrameName(childAnimalName.c_str());
        childSpr->sound=selectAnimal->valueForKey("Sound")->getCString();
        
        this->animalLayer->addChild(childSpr,3);
        //position
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            CCArray *arrayOfParentPos = (CCArray*)levelNameDict->objectForKey("childAnimalPositionIpad");
            CCString *posSting = (CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos = CCPointFromString(posSting->getCString());
            childSpr->setPosition(CCPoint(firstParentPos));
        }
        else
        {
            CCArray *arrayOfParentPos = (CCArray*)levelNameDict->objectForKey("childAnimalPositionIphone");
            CCString *posSting = (CCString*)arrayOfParentPos->objectAtIndex(i);
            CCPoint firstParentPos = CCPointFromString(posSting->getCString());
            childSpr->setPosition(CCPoint(firstParentPos));
        }
        childSpr->matchId = rand;
        childSpr->animalName = animalName;
        this->childArr->addObject(childSpr);
    }
}

std::string FindMamaGamePlay::childAnimalName(const char *childName)
{
    char Name[30]={};
    if(std::string("Cow")==animalName){
        
        if(!(levelNumber==10||levelNumber==11||levelNumber==12))
        {
            if(levelNumber==1)
            {
                sprintf(Name,"%s-B1.png",animalName);
            }
            else if (levelNumber==2)
            {
                sprintf(Name,"%s-B0.png",animalName);
            }
            else
            {
                
                sprintf(Name,"%s-B%d.png",animalName,cow_Rand_Num);
            }
        }
        else
        {
            sprintf(Name,"%s-B1.png",animalName);
            
        }
    }
    else if(std::string("Cat")==animalName){
        
        if(cat_Rand_Num==0)
        {
            sprintf(Name,"%s-B0.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-B1.png",animalName);
        }
    }
    else if(std::string("Bird")==animalName){
        
        if(levelNumber==2)
        {
            sprintf(Name,"%s-B1.png",animalName);
        }
        else if (levelNumber==3 || levelNumber==7)
        {
            sprintf(Name,"%s-B2.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-B0.png",animalName);
        }
    }
    else if(std::string("Parrot")==animalName){
        
        if(levelNumber==1  ||  levelNumber==5   )
        {
            sprintf(Name,"%s-B1.png",animalName);
        }
        else if (levelNumber==4|| levelNumber==8 || levelNumber==9 ||levelNumber==2)
        {
            sprintf(Name,"%s-B0.png",animalName);
        }
    }
    
    else if(std::string("Chicken")==animalName){
        
        if(levelNumber==6 || levelNumber==1 || levelNumber==10)
        {
            sprintf(Name,"%s-B0.png",animalName);
        }
        else if (levelNumber==2 || levelNumber==5)
        {
            sprintf(Name,"%s-B1.png",animalName);
        }
        else
        {
            sprintf(Name,"%s-B.png",animalName);
            
        }
    }
    else
    {
        sprintf(Name,"%s-B.png",animalName);
        
    }
    std::string childAnimalName=Name;
    return childAnimalName;
    
}


#pragma mark - Animal Sound
//Animal sound On Tapping
void FindMamaGamePlay::animalSound(FMPartsSprite *selectedSpr)
{
    char soundName[100]={};
    sprintf(soundName, "%s",selectedSpr->sound);
    
    bazziTalking->startDogTalking();
    SimpleAudioEngine::sharedEngine()->playEffect(soundName);
    CCSequence *Seq=CCSequence::create(CCDelayTime::create(0.1),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
    this->runAction(Seq);
}

#pragma mark - touches methods
void FindMamaGamePlay::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)touches->anyObject();
    CCPoint  touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    //Create Particle Effect
    this->createParticleAtPosition(touchPoint);
    
    if(bazziTalking->animatedDog->boundingBox().containsPoint(touchPoint) && FMDataManager::sharedManager()->canDogStartTalking)
    {
        FMDataManager::sharedManager()->canDogStartTalking=false;
        
        SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
        bazziTalking->startDogTalking();
        CCCallFunc *actionCallFunc = NULL;
        
        if(levelNumber==12)
        {
            actionCallFunc = CCCallFunc::create(this, callfunc_selector(FindMamaGamePlay::playRandomSoundOnTappingDogOnLevelTwelve));
        }
        else
        {
            actionCallFunc = CCCallFunc::create(this, callfunc_selector(FindMamaGamePlay::playRandomSoundOnTappingDog));
        }
        
        CCSequence *Seq = CCSequence::create(actionCallFunc,CCDelayTime::create(3.0f), CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
        this->runAction(Seq);
        
    }
    
    if(canTapChildAnimal)
    {
        CCObject* ChildSpriteObj = NULL;
        if(isChildMotherGameSolved)
        {
            // father
            CCARRAY_FOREACH(this->fatherArr, ChildSpriteObj){
                
                FMPartsSprite *aFatherSpr = (FMPartsSprite *)ChildSpriteObj;
                
                if (aFatherSpr->isSolved){
                    
                    continue;
                }
                
                if (aFatherSpr->boundingBox().containsPoint(touchPoint))
                {
                    this->canRenderTexture=true;
                    
                    selectedAnimal = aFatherSpr;
                    
                    this->setAnimalLabelName(aFatherSpr->animalName);
                    
                    //Play selected Animal Sound
                    this->animalSound(selectedAnimal);
                    
                    CCSequence *sequenceAction = CCSequence::create(
                                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::canTapChildAnimalMakingFalse)), CCDelayTime::create(0.5),
                                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::canTapChildAnimalMakingTrue)),NULL);
                    this->runAction(sequenceAction);
                    
                    
                }
                
            }
        }
    }
    
    if(canTapChildAnimal)
    {
        CCObject* ChildSpriteObj = NULL;
        
        CCARRAY_FOREACH(this->childArr, ChildSpriteObj)
        {
            //child
            FMPartsSprite *aChildSpr = (FMPartsSprite *)ChildSpriteObj;
            
            if (aChildSpr->isSolved){
                continue;
            }
            
            if (aChildSpr->boundingBox().containsPoint(touchPoint))
            {
                this->canRenderTexture=true;
                
                if(this->selectedAnimal!=NULL)
                {
                    if(this->selectedAnimal->matchId!=aChildSpr->matchId )
                    {
                        //remove the stroke for animal
                        this->animalLayer->removeChild(targetTexture, true);
                        targetTexture=NULL;
                        this->canDrawTargetTexture=true;
                    }
                }
                
                this->selectedAnimal = aChildSpr;
                this->setAnimalLabelName(aChildSpr->animalName);
                
                this->animalSound(selectedAnimal );
                CCSequence *sequenceAction = CCSequence::create(CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::canTapChildAnimalMakingFalse)), CCDelayTime::create(0.5), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::canTapChildAnimalMakingTrue)),NULL);
                this->runAction(sequenceAction);
                
                if(canDrawTargetTexture)
                {
                    canDrawTargetTexture=false;
                    targetTexture = this->createStroke(aChildSpr, 1, ccc3(0, 255, 0), 100 );
                    targetTexture->setTag(500);
                    this->animalLayer->addChild(targetTexture, aChildSpr->getZOrder() - 1);
                    CCActionInterval*  actionTo1 = CCScaleTo::create(0.5f, 0.9f);
                    CCActionInterval*  actionTo2 = CCScaleTo::create(0.5f, 1.2f);
                    
                    //Scaling the Stroke repeatedly For the Target Sprite Selected
                    CCSequence *seq = CCSequence::create(actionTo1, actionTo2,NULL);
                    CCRepeatForever *repeat = CCRepeatForever::create(seq);
                    targetTexture->runAction(repeat);
                    
                    break;
                    
                }
            }
        }
    }
    
}


void FindMamaGamePlay::canTapChildAnimalMakingTrue()
{
    canTapChildAnimal=true;
}

void FindMamaGamePlay::canTapChildAnimalMakingFalse()
{
    canTapChildAnimal=false;
    
}


void FindMamaGamePlay::ccTouchesMoved(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    this->moveParticleToTouchedPos(touchPoint);
    
    if(canRenderTexture==false) {
        return;
    }
    
    CCPoint start = touch->getLocation();
    CCPoint end = touch->getPreviousLocation();
    // begin drawing to the render texture
    m_pTarget->begin();
    
    float distance = ccpDistance(start, end);
    if (distance > 1)
    {
        int d = (int)distance;
        for (int i = 0; i < d; i++)
        {
            float difx = end.x - start.x;
            float dify = end.y - start.y;
            float delta = (float)i / distance;
            
            m_pBrush->setPosition(ccp(start.x + (difx * delta), start.y + (dify * delta)));
            m_pBrush->setRotation(rand() % 360);
            m_pBrush->setColor(ccc3(255,0,0));
            // Call visit to draw the brush, don't call draw..
            m_pBrush->visit();
        }
    }
    // finish drawing and return context back to the screen
    m_pTarget->end();
}


void FindMamaGamePlay::ccTouchesEnded(CCSet *touches,CCEvent *event)
{
    this->removeParticle();
    this->canRenderTexture=false;
    
    m_pTarget->clear(0,0,0,0);
    
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    
    if(this->selectedAnimal==NULL) {
        return;
    }
    
    if(this->selectedAnimal->isSolved){
        return;
    }
    
    CCObject* ChildSpriteObj = NULL;
    CCARRAY_FOREACH(this->motherArr, ChildSpriteObj) {
        
        FMPartsSprite *aMotherSpr = (FMPartsSprite *)ChildSpriteObj;
        
        int distance=ccpDistance(aMotherSpr->getPosition(), touchPoint);
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            if(distance<100)
            {
                this->checkWhetherCorectParentSelected(aMotherSpr, touchPoint);
            }
        }
        else
        {
            if(distance<50)
            {
                this->checkWhetherCorectParentSelected(aMotherSpr, touchPoint);
            }
        }
    }
    
}

void FindMamaGamePlay::checkWhetherCorectParentSelected(FMPartsSprite *aMotherSpr, cocos2d::CCPoint touchPoint)
{
    this->setAnimalLabelName(aMotherSpr->animalName);
    this->setTouchEnabled(false);
    
    this->isCorrectParentSelected(this->getOriginalChild(),aMotherSpr, touchPoint);
    
    CCSequence *sequenceAction = CCSequence::create(CCDelayTime::create(0.7), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),NULL);
    this->runAction(sequenceAction);
}

void FindMamaGamePlay::ccTouchesCancelled(CCSet *touches,CCEvent *event){
    
    this->removeParticle();
    
}
void FindMamaGamePlay::clearTexture()
{
    if(m_pTarget)
    {
        //clearing the Drawn Texture
        m_pTarget->clear(0,0,0,0);
        m_pTarget->release();
        m_pBrush->release();
        
        m_pTarget=NULL;
        m_pBrush=NULL;
    }
    
    
}

#pragma mark - Getting the correct sprite selected
FMPartsSprite* FindMamaGamePlay::getOriginalChild() {
    
    CCObject *obj;
    
    if(this->isChildMotherGameSolved){
        
        CCARRAY_FOREACH_REVERSE(this->fatherArr, obj){
            
            FMPartsSprite *aChild=(FMPartsSprite*)obj;
            if(this->selectedAnimal==aChild){
                return aChild;
            }
        }
    }
    else
    {
        CCARRAY_FOREACH_REVERSE(this->childArr, obj){
            FMPartsSprite *aChild=(FMPartsSprite*)obj;
            
            if(this->selectedAnimal==aChild){
                return aChild;
            }
        }
    }
    return NULL;
}

void FindMamaGamePlay::isCorrectParentSelected(FMPartsSprite *child, FMPartsSprite *mother,CCPoint touchPoint){
    
    if(child==NULL) {
        return;
    }
    
    if(child->isSolved){
        return;
    }
    
    if(child->matchId==mother->matchId) {
        
        this->setTouchEnabled(false);
        
        if(this->selectedAnimal!=NULL)
        {
            //remove the stroke for animal
            this->animalLayer->removeChild(targetTexture, true);
            targetTexture=NULL;
        }
        
        //...........Creating Stroke for mama
        targetTexture = this->createStroke(mother, 1, ccc3(0, 255, 0), 100 );
        targetTexture->setTag(500);
        
        this->animalLayer->addChild(targetTexture, mother->getZOrder() - 1);
        CCActionInterval*  actionTo1 = CCScaleTo::create(0.5f, 0.9f);
        CCActionInterval*  actionTo2 = CCScaleTo::create(0.5f, 1.2f);
        
        //Scaling the Stroke repeatedly For the Target Sprite Selected
        CCSequence *seq = CCSequence::create(actionTo1, actionTo2,actionTo1,actionTo2,actionTo1,CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::removeStrokeFromMamaAfterTwoSeconds)),NULL);
        
        targetTexture->runAction(seq);
        
        
        child->isSolved=true;
        
        
        //Play Correct Sound on Proper Match
        int rand=arc4random()%2;
        float delay;
        if(rand==0)
        {
            delay=1.0;
            BBSharedSoundManager::sharedManager()->playShortSoundOnClickOfCorrecAns();
            if(BBSharedSoundManager::sharedManager()->correctRandomSound==3||BBSharedSoundManager::sharedManager()->correctRandomSound==5)
            {
                bazziTalking->stopDogTalking();
            }
            else
            {
                bazziTalking->startDogTalking();
                
            }
        }
        else
        {
            delay=3;
            BBSharedSoundManager::sharedManager()->playLongSoundOnClickOfCorrectAns();
            
        }
        CCSequence *sequenceAction = NULL;
        
        sequenceAction = CCSequence::create(CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::playCheersSound)),CCDelayTime::create(delay),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
        
        
        this->gameCount--;
        
        if(this->gameCount==0)
        {
            if( FMDataManager::sharedManager()->mistakeCountToImplementStar<1)
            {
                if(levelNumber==1 || levelNumber==4 || levelNumber==7 || levelNumber==10 ||levelNumber==12)
                {
                    CCSequence *sequenceActions = CCSequence::create(
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::addNewStar)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::playSoundOnStarAnim)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::levelCleared)),NULL);
                    this->runAction(CCSequence::createWithTwoActions(sequenceAction,sequenceActions));
                }
                else
                {
                    CCSequence *sequenceActions = CCSequence::create(
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::addNewStar)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),
                                                                     CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::levelCleared)),NULL);
                    this->runAction(CCSequence::createWithTwoActions(sequenceAction,sequenceActions));
                }
            }
            else
            {
                CCSequence *sequenceActions = CCSequence::create(
                                                                 CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),
                                                                 CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::levelCleared)),NULL);
                this->runAction(CCSequence::createWithTwoActions(sequenceAction,sequenceActions));
                
            }
            
        }
        else
        {
            if(levelNumber==10)
            {
                this->runAction(sequenceAction);
            }
            else
            {
                this->runAction(CCSequence::createWithTwoActions(sequenceAction,CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch))));
            }
            
        }
        
        
        int randLineN0 = arc4random()%linesInfoArr->count();
        CCString *lineName = (CCString*)linesInfoArr->objectAtIndex(randLineN0);
        CCSprite *line = CCSprite::createWithSpriteFrameName(lineName->getCString());
        this->animalLayer->addChild(line,0,100);
        
        //calculate the ContentSize and Pos of the targetPosition and the selectedSprite Position
        CCPoint ChildPos = child->getPosition();
        CCPoint motherPos = mother->getPosition();
        float angle = this->getAngleBetweenPoint(ChildPos,motherPos);
        line->setScale(.2);
        line->setRotation(angle);
        line->setPosition(ChildPos);
        line->setAnchorPoint(CCPoint(0.5,0.95));
        
        float distance = ccpDistance(ChildPos,motherPos);
        
        //scale line
        CCActionInterval *action = CCScaleTo::create(0.4, 0.6, distance/(line->getContentSize().height));
        CCSequence *Seq = CCSequence::create(action,CCDelayTime::create(.2), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::clearLines)), NULL);
        line->runAction(Seq);
        
        FindMamaGamePlayParameterObject *object = new FindMamaGamePlayParameterObject();
        object->child=child;
        object->parent=mother;
        
        CCCallFuncND *Callback=CCCallFuncND::create(this, callfuncND_selector(FindMamaGamePlay::moveSelectedAnimalToMatchedAnimalPos), object);
        CCSequence *Seq1=CCSequence::create(CCDelayTime::create(.5), Callback, NULL);
        
        this->runAction(Seq1);
        
    }
    else
    {
        if(FMDataManager::sharedManager()->missedCount>3)
        {
            if( isWrongMathedAnimalMoreThanThree)
            {
                isWrongMathedAnimalMoreThanThree=false;
                
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.3f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::playOnClickOfMoreThanThreeWrongAnswer)),CCDelayTime::create(2), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
                this->runAction(Seq);
            }
        }
        else
        {
            
            CCSequence *sequenceAction = CCSequence::create(CCDelayTime::create(0.6f), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::playOhhSound)), CCDelayTime::create(0.5), CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),NULL);
            this->runAction(sequenceAction);
        }
        
        
    }
}
void FindMamaGamePlay::removeStrokeFromMamaAfterTwoSeconds()
{
    //remove the stroke for animal
    this->animalLayer->removeChild(targetTexture, true);
    targetTexture=NULL;
    
}

#pragma mark - generating RandomNumbers
int* FindMamaGamePlay::randomizeInt(int noOfAnimalSprites[15]) {
    
    //variables used for swapping
    int swap;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i < arrayOfAnimalsAccordingToGroupName->count(); i++){
        
        rand_no = arc4random() %  arrayOfAnimalsAccordingToGroupName->count();
        
        swap = noOfAnimalSprites[rand_no];
        noOfAnimalSprites[rand_no]= noOfAnimalSprites[i];
        noOfAnimalSprites[i] = swap;
    }
    return noOfAnimalSprites;
}

int* FindMamaGamePlay::rand_num(int noOfAnimal[7])
{
    //variables used for swapping
    int swap;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i < arrayOfAnimalsAccordingToGroupName->count(); i++){
        
        rand_no = arc4random() % 6;
        
        swap = noOfAnimal[rand_no];
        noOfAnimal[rand_no]= noOfAnimal[i];
        noOfAnimal[i] = swap;
    }
    return noOfAnimal;
}


#pragma mark - addTexture
void FindMamaGamePlay::addTexture(){
    
    m_pTarget = CCRenderTexture::create(winSize.width,winSize.height, 	kCCTexture2DPixelFormat_RGBA8888);
    m_pTarget->retain();
    m_pTarget->setPosition(ccp(winSize.width / 2, winSize.height / 2));
    this->animalLayer->addChild(m_pTarget,4);
    
    m_pBrush = CCSprite::create("FindMama/fire.png");
    m_pBrush->retain();
    m_pBrush->setColor(ccORANGE);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        m_pBrush->setScale(0.4);
    }
    else
    {
        m_pBrush->setScale(0.2);
    }
}


#pragma mark - Moving sprite to there respective Pos
void FindMamaGamePlay::moveSelectedAnimalToMatchedAnimalPos(CCObject *Sender, void* data) {
    
    FindMamaGamePlayParameterObject *object=(FindMamaGamePlayParameterObject*)data;
    
    int widthForMotherFactor = 30;
    int heightForMotherFactor = 25;
    int childAdjustFactor = 70;
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        widthForMotherFactor = 60;
        heightForMotherFactor = 50;
        childAdjustFactor = 150;
    }
    
    CCPoint  originalMotherLocation = ccp(object->parent-> getPositionX()+widthForMotherFactor,object->parent-> getPositionY()-heightForMotherFactor);
    
    if(this->isChildMotherGameSolved){
        
        originalMotherLocation = ccp(object->parent-> getPositionX(),object->parent-> getPositionY()-childAdjustFactor);
        CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(originalMotherLocation));
        object->child->runAction(selectedSpritePos);
    }
    else
    {
        if(this->isFatherPresent)
        {
            char childName[30];
            if(std::string("Cow")==object->child->animalName){
                
                if(!(levelNumber==10||levelNumber==11||levelNumber==12))
                {
                    sprintf(childName,"%s-B0.png",object->child->animalName);
                }
                else
                {
                    sprintf(childName,"%s-B1.png",object->child->animalName);
                    
                }
            }
            else if(std::string("Cat")==object->child->animalName){
                
                if(cat_Rand_Num==0)
                {
                    sprintf(childName,"%s-B0.png",object->child->animalName);
                }
                else
                {
                    sprintf(childName,"%s-B1.png",object->child->animalName);
                }
            }
            else
            {
                sprintf(childName, "%s-B.png",object->child->animalName);
            }
            
            FMPartsSprite *childSprite=childSprite->createWithSpriteFrameName(childName);
            object->parent->addChild(childSprite);
            childSprite->setPosition(object->parent->convertToNodeSpace(object->child->getPosition()));
            this->animalLayer->removeChild(object->child);
            this->childArr->removeObject(object->child);
            
            
            CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(object->parent->convertToNodeSpace(originalMotherLocation)));
            childSprite->runAction(selectedSpritePos);
        }
        else
        {
            CCMoveTo *selectedSpritePos = CCMoveTo::create(0.6,CCPoint(originalMotherLocation));
            object->child->runAction(selectedSpritePos);
        }
    }
    
    this->movedChildCount++;
    if(this->isFatherPresent && this->movedChildCount==this->fatherArr->count() ){
        this->isChildMotherGameSolved=true;
        CCSequence *Seq=CCSequence::createWithTwoActions(CCDelayTime::create(0.8f),
                                                         CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::moveAllFatherToChildPos)));
        this->runAction(Seq);
    }
}


void FindMamaGamePlay::moveAllFatherToChildPos(){
    
    CCObject *obj;
    CCMoveTo *moveAction;
    
    CCARRAY_FOREACH(this->fatherArr, obj){
        FMPartsSprite *fatherSpr=(FMPartsSprite*)obj;
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            if(levelNumber==11)
            {
                moveAction=CCMoveTo::create(.5, ccp(fatherSpr->getPosition().x + 150, 230));
            }
            else
            {
                moveAction=CCMoveTo::create(.5, ccp(fatherSpr->getPosition().x , 230));
                
            }
        }
        else
        {
            if(levelNumber==11)
            {
                moveAction=CCMoveTo::create(.5, ccp(fatherSpr->getPosition().x + 70, 80));
            }
            else
            {
                moveAction=CCMoveTo::create(.5, ccp(fatherSpr->getPosition().x , 80));
                
            }
            
        }
        fatherSpr->runAction(moveAction);
    }
    
    if(levelNumber==10)
    {
        this->setTouchEnabled(false);
        CCSequence *Seq=CCSequence::create(CCDelayTime::create(1.3f),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.5),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::helpPapa_mama)),CCDelayTime::create(3.2f),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(1.0f),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::letGetFamilySound)),CCDelayTime::create(1.7f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),
                                           CCDelayTime::create(0.7f),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::drawlinepapatomama)),CCDelayTime::create(2.2f),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::enablingTouch)),NULL);
        this->runAction(Seq);
    }
    
}

void FindMamaGamePlay::stopTheDogAnim()
{
    this->stopDogTalkingAnimation();
}


#pragma mark - LevelCleared
void FindMamaGamePlay::levelCleared()
{
    
    if(levelNumber==9)
    {
        this->setTouchEnabled(false);
        CCSequence *Sequence = CCSequence ::create(
                                                   CCCallFuncN::create(this,callfuncN_selector     (FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.5),
                                                   
                                                   CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                                   
                                                   CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::youFoundAllMamaSound)),CCDelayTime::create(1.8),NULL);
        
                                                   CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.5f);
        
        CCSequence *Seq=CCSequence::create(
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::readyForNextLevelSound)),CCDelayTime::create(0.8f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.5f),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::greatSound)),CCDelayTime::create(0.5),
                                           CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),
                                           CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::enablingTouch)),NULL);
        this->runAction(CCSequence::createWithTwoActions(Sequence,Seq));
    }
    
    if(levelNumber==12)
    {
        CCSequence *Sequence = CCSequence::create(CCDelayTime::create(2.0),
                                                  CCCallFunc::create(this, callfunc_selector(FindMamaGamePlay::youGetTrophySound)),CCDelayTime::create(2.9),
                                                  CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::gameOver)),NULL);
        this->runAction(Sequence);
        
    }
    
    
    if(isNextLevelFree)
    {
    if(levelNumber>=1 && levelNumber<12)
    {
        if(levelNumber==9)
        {
            CCSequence *Seq=CCSequence::create(CCDelayTime::create(5.2f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
            this->runAction(Seq);
        }
        else if (levelNumber==2 || levelNumber==3 || levelNumber==5 || levelNumber==6 ||levelNumber==8 || levelNumber==10 ||levelNumber==11 )
        {
            CCSequence *Seq=CCSequence::create(CCDelayTime::create(1.5f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
            this->runAction(Seq);
            
        }
        else
        {
            CCSequence *Seq=CCSequence::create(CCDelayTime::create(2.0f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
            this->runAction(Seq);
        }
    }
    
    }
    else
    {
        if (!isLoked)
        {
            if(levelNumber==9)
            {
                CCSequence *Seq=CCSequence::create(CCDelayTime::create(5.2f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
                this->runAction(Seq);
            }
            else if (levelNumber==2 || levelNumber==3 || levelNumber==5 || levelNumber==6 ||levelNumber==8 || levelNumber==10 ||levelNumber==11 )
            {
                CCSequence *Seq=CCSequence::create(CCDelayTime::create(1.5f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
                this->runAction(Seq);
                
            }
            else
            {
                CCSequence *Seq=CCSequence::create(CCDelayTime::create(2.0f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::goToNextLevel)),NULL);
                this->runAction(Seq);
            }
            
        }
        else
        {
            WrapperHelper::postByNotificationWithGameIndex(1);
        }

    }
}

void FindMamaGamePlay::gameOver()
{
    restartMenuItem->setEnabled(false);
    bazziTalking->startDogTalking();
    BBSharedSoundManager::sharedManager()->playGameCompletePopUpSound();
    this->canStopDogTalking=true;
    
    this->isGameCompleted=true;
    
    CCSequence *seq = CCSequence::create(CCDelayTime::create(3.2),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
    this->runAction(seq);
    
    CCSprite *congragulationSpr = CCSprite::createWithSpriteFrameName("congrats.png");
    congragulationSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->animalLayer->addChild(congragulationSpr,10);
    
    CCSprite *playAgainNormalSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    CCSprite *playAgainSelectedSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    
    CCMenuItemSprite *playAgainMenuItem = CCMenuItemSprite::create(playAgainNormalSpr, playAgainSelectedSpr, this, menu_selector(FindMamaGamePlay::restartButtonPressed));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        playAgainMenuItem->setPosition(ccp(120,10));
    }
    else
    {
        playAgainMenuItem->setPosition(ccp(60,10));
    }
    
    CCSprite *gobackNormalSpr = CCSprite::createWithSpriteFrameName("goback.png");
    CCSprite *gobackSelectedSpr = CCSprite::createWithSpriteFrameName("goback.png");
    
    CCMenuItemSprite *gobackMenuItem = CCMenuItemSprite::create(gobackNormalSpr, gobackSelectedSpr, this, menu_selector(FindMamaGamePlay::homeButton));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        gobackMenuItem->setPosition(ccp(320, 10));
    }
    else
    {
        gobackMenuItem->setPosition(ccp(160, 10));
    }
    
    CCScaleBy *scaleTo = CCScaleBy::create(1, 1.5);
    CCActionInterval* move_ease_in = CCEaseBackInOut::create((CCActionInterval*)(scaleTo->copy()->autorelease()));
    congragulationSpr->runAction(move_ease_in);
    
    
    CCMenu *tempMenu = CCMenu::create(playAgainMenuItem,gobackMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    congragulationSpr->addChild(tempMenu,10);
}


#pragma mark - add stars
void FindMamaGamePlay::addStars(){
    
    int xPos;
    int yPos;
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        xPos=230;
        yPos=35;
    }
    else
    {
        xPos=100;
        yPos=25;
    }
    
    for(int i=0;i<FMDataManager::sharedManager()->starCount;i++){
        CCSprite *starFullSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starFullSprite,4);
        
        starFullSprite->setTag(i);
        starFullSprite->setPosition(ccp(xPos, yPos));
        this->starArray->addObject(starFullSprite);
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
    for(int i=0;i<12-FMDataManager::sharedManager()->starCount;i++){
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,3);
        starEmptySprite->setTag(i);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
}


void FindMamaGamePlay::addNewStar()
{
    
    CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        starSprite->setPosition(ccp(230+((FMDataManager::sharedManager()->starCount)*50),35));
    }
    else
    {
        starSprite->setPosition(ccp(100+((FMDataManager::sharedManager()->starCount)*25),25));
    }
    this->addChild(starSprite,10);
    this->starArray->addObject(starSprite);
    
    CCRotateTo *rotate=CCRotateTo::create(.5, 720);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.16, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.16, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIN = CCFadeIn::create(0.1);
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut,fadeIN,NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut,fadeIN,NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.25),  seq2,NULL);
    starSprite->runAction(seq3);
    
    FMDataManager::sharedManager()->starCount++;
    
    if(FMDataManager::sharedManager()->starCount<12)    {
        award->setVisible(false);
    }
    
    if(FMDataManager::sharedManager()->starCount==12)
    {
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0f),
                                                        CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::deletingStarsOnCountTwelve)),NULL);
        this->runAction(callBack);
    }
    
    
}

void FindMamaGamePlay::deletingStarsOnCountTwelve()
{
    FMDataManager::sharedManager()->starCount=0;
    
    for (int i=0; i<this->starArray->count(); i++)
    {
        CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
        this->removeChild(star, true);
    }
    this->starArray->removeAllObjects();
    
}

#pragma mark - Enable
void FindMamaGamePlay::enablingTouch()
{
    this->setTouchEnabled(true);
}

#pragma mark - IdleTickAfterSounds
void FindMamaGamePlay::scheduleIdleTickAfterSounds(){
    
    this->schedule(schedule_selector(FindMamaGamePlay::idleCheckTick), 1);
}


void FindMamaGamePlay::idleCheckTick()
{
    if(this->bazziTalking->isBacciTalking==false)
    {
        this->bazziTalking->idleTime ++;
        if(levelNumber==1)
        {
            if(this->bazziTalking->idleTime%6==0&&this->bazziTalking->isRunningIdleAnimation==false)
            {
                this->bazziTalking->runBacciIdleAnimation();
            }
        }
        else{
            if(this->bazziTalking->idleTime%kBacciIdleTime==0&&this->bazziTalking->isRunningIdleAnimation==false)
            {
                this->bazziTalking->runBacciIdleAnimation();
            }
        }
    }
}

#pragma mark - Stopping And Starting Dog Animations
void FindMamaGamePlay::stopDogTalkingAnimation()
{
    FMDataManager::sharedManager()->canDogStartTalking=true;
    this->bazziTalking->stopDogTalking();
}

#pragma mark - play Sounds According to the Conditions Required
void FindMamaGamePlay::drawlinepapatomama()
{
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/drawlinepapato_mama.mp3");
}


void FindMamaGamePlay::startDogTalking()
{
    bazziTalking->startDogTalking();
}

void FindMamaGamePlay::playGameWonRandomSound()
{
    int rand= arc4random()%2;
    if(rand==0)
    {
        dogAnimationCount = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/thatwasfun.mp3", false);
    }
    else if(rand==1)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/great.mp3", false);
        
    }
    
}
void FindMamaGamePlay::welcomeSound()
{
    this->setTouchEnabled(false);
    
    this->bazziTalking->startDogTalking();
    
    
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizwheresmama.mp3");
    
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),
                                                    CCDelayTime::create(1.0f),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                                    CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::helpBabies_MamasSound)),CCDelayTime::create(2.8f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(1.0f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                                    CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::greatSound)),CCDelayTime::create(0.6f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(1.0f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::startDogTalking)),
                                                    CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::drawaLineFromMamaSound)),CCDelayTime::create(3.0f),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.8),
                                                    CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::enablingTouch)),NULL);
    
    this->runAction(callBack);
    
}

void FindMamaGamePlay::greatSound()
{
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/great.mp3");
    
}

void FindMamaGamePlay::playRandomSoundOnTappingDogOnLevelTwelve()
{
    int rand= arc4random()%3;
    if(rand==0)
    {
        dogAnimationCount = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3", false);
    }
    else if(rand==1)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/play_again_orgoback.mp3", false);
        
    }
    else if(rand==2)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/playagainorgoback.mp3", false);
        
    }
}

void FindMamaGamePlay::playRandomSoundOnTappingDog()
{
    int rand= arc4random()%5;
    
    if(rand==0)
    {
        dogAnimationCount = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/helpbabies_mamas.mp3", false);
    }
    else if(rand==1)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3", false);
        
        
    }
    else if(rand==2)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/letsgetfamily_mama.mp3", false);
        
    }
    else if(rand==3)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtoplayagain.mp3", false);
        
    }
    else if(rand==4)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/drawalinefrom_mama.mp3", false);
    }
    
}
void FindMamaGamePlay::helpPapa_mama()
{
    if(levelNumber==10)
    {
        bazziTalking->startDogTalking();
        this->removeParticle();
    }
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/helppapa_mama.mp3");
    
}

void FindMamaGamePlay::playSoundOnStarAnim()
{
    bazziTalking->startDogTalking();
    BBSharedSoundManager::sharedManager()->playOnStarAnimation();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8f),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
    this->runAction(callBack);
}



void FindMamaGamePlay::playOnClickOfMoreThanThreeWrongAnswer()
{
    isWrongMathedAnimalMoreThanThree=true;
    int rand= arc4random()%3;
    if(rand==0)
    {
        dogAnimationCount= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/dontthinktheyarerelated_mama.mp3", false);
    }
    else if(rand==1)
    {
        dogAnimationCount= SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/areyoupullingmyleg.mp3", false);
        
    }
    else if(rand==2)
    {
        
        dogAnimationCount=  SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/yourejokingright.mp3",false);
        
    }
}


void FindMamaGamePlay::letGetFamilySound()
{
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/letsgetfamily_mama.mp3");
}


void FindMamaGamePlay::youGetTrophySound()
{
    restartMenuItem->setEnabled(false);
    bazziTalking->startDogTalking();
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/yougetatrophy.mp3")
    ;
    CCFiniteTimeAction *callBack = CCSequence::createWithTwoActions(CCDelayTime::create(0.3),CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::stopDogTalkingAnimation)));
    this->runAction(callBack);
    this->award->setVisible(true);
}


void FindMamaGamePlay::youFoundAllMamaSound()
{
    this->removeParticle();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/youfoundallthemamas.mp3");
}


void FindMamaGamePlay::helpBabies_MamasSound()
{
    //    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/helpbabies_mamas.mp3");
    
}


void FindMamaGamePlay::drawaLineFromMamaSound()
{
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/drawalinefrom_mama.mp3");
}


void FindMamaGamePlay::readyForNextLevelSound(){
    
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/readyfornextlevel.mp3");
}


void FindMamaGamePlay::playCheersSound()
{
    this->setAnimalLabelName("Matched");
    FMDataManager::sharedManager()->missedCount=0;
    /* bazziTalking->startDogTalking();
     BBSharedSoundManager::sharedManager()->playShortSoundOnClickOfCorrecAns();
     CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.2),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
     this->runAction(callBack);*/
    
}

void FindMamaGamePlay::playOhhSound()
{
    this->setAnimalLabelName("Not Matched");
    
    FMDataManager::sharedManager()->mistakeCountToImplementStar++;
    FMDataManager::sharedManager()->missedCount++;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    BBSharedSoundManager::sharedManager()->playOnClickOfWrongAnswer();
    bazziTalking->startDogTalking();
    
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.2),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),NULL);
    this->runAction(callBack);
    
}


#pragma mark - lables to display
void FindMamaGamePlay::setAnimalLabelName(const char*name){
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        animalLabel->setPosition(ccp(500, 670));
    }
    else
    {
        animalLabel->setPosition(ccp(230, 282));
    }
    animalLabel->setString(name);
    CCScaleTo *scaleBig = CCScaleTo::create(0.6,1);
    CCScaleTo *scaleSmall = CCScaleTo::create(0.6,0);
    CCAction *sequenceAction  = CCSequence::create(scaleBig,scaleSmall,NULL);
    animalLabel->runAction(sequenceAction);
}


#pragma mark - GetAngleBetween Two Points
float FindMamaGamePlay::getAngleBetweenPoint(CCPoint currentPoint, CCPoint toPoint) {
    
    float angle;
    CCPoint difference = ccpSub(currentPoint,toPoint);
    angle = -1 * (atan2(difference.y, difference.x) * 180 / M_PI + 90) + 180;
    
    if (angle < 0) {
        angle = 360 + angle;
    }
    return abs(angle);
}

#pragma mark - Menu Items Actions
void FindMamaGamePlay::restartButtonPressed()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->stopDogTalkingAnimation();
    this->isGameRestarted=false;
    
    //remove the stroke for animal
    this->animalLayer->removeChild(targetTexture, true);
    targetTexture=NULL;
    
    this->canDrawTargetTexture=false;
    
    restartMenuItem->setEnabled(false);
    
    if(levelNumber==12)
    {
        if(isGameCompleted)
        {
            //Game completion Sounds along with dog Animations
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8f),
                                                            CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::startDogTalking)),
                                                            CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::playGameWonRandomSound)),CCDelayTime::create(0.9f),
                                                            CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::stopDogTalkingAnimation)),CCDelayTime::create(0.8f),
                                                            CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::playAgain)),NULL);
            this->runAction(callBack);
        }
        else
        {
            
            this->stopDogTalkingAnimation();
            CCFiniteTimeAction *callBack=CCSequence::createWithTwoActions(CCDelayTime::create(0.8f),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::playAgain)));
            this->runAction(callBack);
        }
    }
    else
    {
        //Restart the game
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8f),CCCallFunc::create(this,callfunc_selector(FindMamaGamePlay::playAgain)),NULL);
        this->runAction(callBack);
    }
}

void FindMamaGamePlay::playAgain()
{
    this->setTouchEnabled(true);
    this->canTapChildAnimal=true;
    this->stopDogTalkingAnimation();
    
    //remove the texture
    this->clearTexture();
    
    if(levelNumber==12 && isGameCompleted)
    {
        levelNumber=1;
        
        FMDataManager::sharedManager()->starCount=0;
        
        for (int i=0; i<this->starArray->count(); i++)
        {
            CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
            this->removeChild(star, true);
        }
        
    }
    
    restartMenuItem->setEnabled(true);
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    FMDataManager::sharedManager()->isGameBegin=true;
    
    award->setVisible(false);
    
    this->stopAllActions();
    this->clear();
    
    this->initialiseGame();
}

void FindMamaGamePlay::homeButton(CCMenuItemImage *sender)
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    
    BBSharedSoundManager::sharedManager()->playGameButtonSound();
    
    FMDataManager::sharedManager()->mistakeCountToImplementStar=0;
    
    FMDataManager::sharedManager()->isGameBegin=true;
    isGameCompleted=false;
    
    this->removeAllChildrenWithCleanup(true);
    this->stopAllActions();
    FMDataManager::sharedManager()->starCount=0;
    
    for (int i=0; i<this->starArray->count(); i++)
    {
        
        CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
        this->removeChild(star, true);
    }
    this->starArray->removeAllObjects();
    
    levelNumber = 1;
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}

void FindMamaGamePlay::goToNextLevel(CCMenuItemSprite *sender)
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    bazziTalking->stopDogTalking();
    
    
    //remove the texture
    this->clearTexture();
    
    //remove the stroke for animal
    this->animalLayer->removeChild(targetTexture, true);
    targetTexture=NULL;
    
    if(levelNumber==12)
    {
        isGameCompleted=true;
    }
    else
    {
        isGameCompleted=false;
    }
    
    
    FMDataManager::sharedManager()->mistakeCountToImplementStar=0;
    
    if(levelNumber>1)
    {
        this->setTouchEnabled(true);
        FMDataManager::sharedManager()->canDogStartTalking=true;
    }
    
    if(levelNumber==1 || levelNumber==9 || levelNumber==10 || levelNumber==11)
    {
        this->stopDogTalkingAnimation();
    }
    
    if(FMDataManager::sharedManager()->starCount==12)
    {
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0f),
                                                        CCCallFuncN::create(this, callfuncN_selector(FindMamaGamePlay::deletingStarsOnCountTwelve)),NULL);
        this->runAction(callBack);
    }
    
    if(levelNumber==12)
    {
        levelNumber=1;
        FMDataManager::sharedManager()->isGameBegin=true;
        
        FMDataManager::sharedManager()->starCount=0;
        for (int i=0; i<this->starArray->count(); i++){
            
            CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
            this->removeChild(star, true);
        }
        this->starArray->removeAllObjects();
    }
    else
    {
        levelNumber++;
    }
    
    FMDataManager::sharedManager()->isGameBegin=false;
    
    this->stopAllActions();
    this->clear();
    award->setVisible(false);
    this->initialiseGame();
}


#pragma mark - Particle
void FindMamaGamePlay::createParticleAtPosition(CCPoint inPosition)
{
    //Create Particle Effect
    this->addParticleEffectToTexture = NULL;
    
    this->addParticleEffectToTexture = CCParticleSystemQuad::create("BBParticle/prinkal.plist");
    this->addParticleEffectToTexture->setPosition(inPosition);
    this->animalLayer->addChild(addParticleEffectToTexture,4);
    
}

void FindMamaGamePlay::moveParticleToTouchedPos(CCPoint tochesLocation)
{
    if(this->addParticleEffectToTexture)
        this->addParticleEffectToTexture->setPosition(tochesLocation);
}

void FindMamaGamePlay::removeParticle()
{
    if(this->addParticleEffectToTexture)
    {
        this->addParticleEffectToTexture->stopSystem();
        this->animalLayer->removeChild(this->addParticleEffectToTexture,true);
        this->addParticleEffectToTexture = NULL;
        
    }
}



#pragma mark - Clear
void FindMamaGamePlay::clearLines(CCObject *Sender ){
    CCSprite *lineSprite=(CCSprite*)Sender;
    this->animalLayer->removeChild(lineSprite,true);
}

void FindMamaGamePlay::clear(){
    
    //Remove particle if present
    this->removeParticle();
    canDrawTargetTexture=true;
    FMDataManager::sharedManager()->missedCount=0;
    this->award->setVisible(false);
    
    this->fatherArr->removeAllObjects();
    this->childArr->removeAllObjects();
    this->motherArr->removeAllObjects();
    this->randNumberarrayForMother->removeAllObjects();
    this->lineSprarray->removeAllObjects();
    
    this->animalLayer->removeAllChildrenWithCleanup(true);
    this->removeChild(this->animalLayer,true);
    
}

// FindMamaGamePlay parameter object
#pragma mark - FindMamaGamePlay parameter object
FindMamaGamePlayParameterObject ::FindMamaGamePlayParameterObject(){
    
}

FindMamaGamePlayParameterObject ::~FindMamaGamePlayParameterObject(){
    
}



