//
//  FMDataManager.cpp
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#include "FMDataManager.h"
#include "cocos2d.h"

static FMDataManager *gSharedManager = NULL;

FMDataManager::FMDataManager(void){
    this->currentLevel=1;
    this->starCount=0;
    this->movedCount=0;
    this->missedCount=0;
    this->mistakeCountToImplementStar=0;
    this->mistakeCountToImplementStar=0;
    this->canDogStartTalking=true;
    this->isGameBegin=true;
    this->canPlayIdleDogAnimation=false;
}

FMDataManager::~FMDataManager(void){}

FMDataManager* FMDataManager::sharedManager(void) {
    
	FMDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new FMDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool FMDataManager::init(void) {
	return true;
}

