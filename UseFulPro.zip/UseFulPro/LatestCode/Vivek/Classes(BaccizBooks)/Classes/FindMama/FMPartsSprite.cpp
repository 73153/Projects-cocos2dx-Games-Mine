//
//  FMPartsSprite.cpp
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#include "FMPartsSprite.h"
#include "FMPartsSprite.h"

FMPartsSprite::FMPartsSprite(void)
{
    this->isSolved=false;
    this->name=NULL;
    this->animalName=NULL;
}

FMPartsSprite::~FMPartsSprite(void)
{
}

// To create separate sprite from file...
FMPartsSprite* FMPartsSprite::spriteWithFile(const char *pszFileName)
{
    FMPartsSprite *pobSprite = new FMPartsSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        //pobSprite->scheduleUpdate();
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
	return NULL;
}

// To create sprite from sprite sheet!
FMPartsSprite* FMPartsSprite::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    FMPartsSprite *tempSpr = FMPartsSprite::create(pFrame);
    return tempSpr;
}


FMPartsSprite* FMPartsSprite::create(const char *pszFileName)
{
    FMPartsSprite *pobSprite = new FMPartsSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

FMPartsSprite* FMPartsSprite::create(CCSpriteFrame *pSpriteFrame)
{
    FMPartsSprite *pobSprite = new FMPartsSprite();
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

FMPartsSprite* FMPartsSprite::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "This is Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

FMPartsSprite* FMPartsSprite::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    FMPartsSprite *pobSprite = new FMPartsSprite();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}