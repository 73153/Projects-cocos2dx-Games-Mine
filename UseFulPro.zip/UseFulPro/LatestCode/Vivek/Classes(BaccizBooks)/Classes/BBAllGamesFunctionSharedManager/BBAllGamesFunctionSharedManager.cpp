//
//  BBSharedManager.cpp
//  BaccizBooks
//
//  Created by Deepthi on 03/06/13.
//
//
//Hola

#ifndef BaccizBooks_BBSharedManager_cpp
#define BaccizBooks_BBSharedManager_cpp

#include "SimpleAudioEngine.h"
#include "BBAllGamesFunctionSharedManager.h"
#include "BBMainDataManager.h"
#include "WrapperHelper.h"

using namespace cocos2d;
using namespace CocosDenshion;


static BBAllGamesFunctionSharedManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

BBAllGamesFunctionSharedManager::BBAllGamesFunctionSharedManager(void)
{
        
}

BBAllGamesFunctionSharedManager::~BBAllGamesFunctionSharedManager(void)
{
        
}


BBAllGamesFunctionSharedManager* BBAllGamesFunctionSharedManager::sharedManager(void) {
        
	BBAllGamesFunctionSharedManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBAllGamesFunctionSharedManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBAllGamesFunctionSharedManager::init(void)
{
	return true;
}
void BBAllGamesFunctionSharedManager::addCongratulationBanner(bool bannerStatus,CCPoint pos)
{
        std::string soundName;
        std::string imageName;

        
        int rand = arc4random()%25;
        soundName="Sounds/CongragulationSounds/";
        imageName="BBSharedResources/CongratulationBanner/";

        if(rand==0)
        {
                soundName=soundName+ "amazing.mp3";
                imageName=imageName+"Amazing!.png";
        }
        else if(rand==1)
        {
                soundName=soundName+ "awesome.mp3";
                imageName=imageName+"Awesome!.png";

             //   spr = CCSprite::create("BBSharedResources/CongratulationBanner/Awesome!.png");
              // SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/awesome.mp3", false);
        }
        else if(rand==1)
        {
                soundName=soundName+"bigstep.mp3";
                imageName=imageName+"Big-step.png";
                
        }
        else if(rand==2)
        {
                soundName=soundName+"bravo.mp3";
                imageName=imageName+"Bravo!.png";
          
        }
        else if(rand==3)
        {
                soundName=soundName+"brilliant.mp3";
                imageName=imageName+"Brilliant!.png";

        }
        else if(rand==4)
        {
                soundName=soundName+"congratulations.mp3";
                imageName=imageName+"Congratulations!.png";
              
        }
        else if(rand==5)
        {
                soundName=soundName+"excellent.mp3";
                imageName=imageName+"Excellent!.png";
        }
        else if(rand==6)
        {
                soundName=soundName+"fantastic.mp3";
                imageName=imageName+"Fantastic!.png";

        }
        else if(rand==7)
        {
                soundName=soundName+"goodjob.mp3";
                imageName=imageName+"Good-Job!.png";

        }
        else if(rand==8)
        {
                soundName=soundName+"great_effort.mp3";
                imageName=imageName+"Great-effort!.png";
        }
        else if(rand==9)
        {
                soundName=soundName+"great-job.mp3";
                imageName=imageName+"Great-Job!.png";

                 }
        else if(rand==10)
        {
                soundName=soundName+"great.mp3";
                imageName=imageName+"Great!.png";
            
        }
     

        else if(rand==11)
        {
                soundName=soundName+"incredible.mp3";
                imageName=imageName+"Incredible!.png";
               
        }
        else if(rand==12)
        {
                soundName=soundName+"nicework.mp3";
                imageName=imageName+"Nice-work!.png";
}
        else if(rand==13)
        {
                soundName=soundName+"original.mp3";
                imageName=imageName+"Original!.png";
                
                        }
        else if(rand==14)
        {
                soundName=soundName+"outstanding.mp3";
                imageName=imageName+"Outstanding!.png";
                
             
        }
        else if(rand==15)
        {
                soundName=soundName+"perfect.mp3";
                imageName=imageName+"Perfect!.png";
        }
        
        else if(rand==16)
        {
                soundName=soundName+"Super_happy!.mp3";
                imageName=imageName+"Super_happy!.png";

        }
        else if(rand==17)
        {
                soundName=soundName+"super.mp3";
                imageName=imageName+"Super!.png";

        }
        else if(rand==18)
        {
                soundName=soundName+"terrific.mp3";
                imageName=imageName+"Terrific.png";

                    }
        else if(rand==19)
        {
                soundName=soundName+"thatsgreat.mp3";
                imageName=imageName+"That’s-Great!.png";
                      }
        else if(rand==20)
        {
                soundName=soundName+"thatsgreat.mp3";
                imageName=imageName+"That’s-Great!.png";
        }
        else if(rand==21)
        {
                soundName=soundName+"unique.mp3";
                imageName=imageName+"Unique!.png";
        }
        else if(rand==22)
        {
                soundName=soundName+"very_nice.mp3";
                imageName=imageName+"Very_nice!.png";
        }
        else if(rand==23)
        {
                soundName=soundName+"welldone.mp3";
                imageName=imageName+"Well-done!.png";
}
        else if(rand==24)
        {
                soundName=soundName+"wonderful.mp3";
                imageName=imageName+"Wonderful!.png";
                
        }
        else if(rand==25)
        {
                soundName=soundName+"wonderful.mp3";
                imageName=imageName+"Wow!.png";

        }
        if(bannerStatus)
        {
                CCSprite *spr = CCSprite::create(imageName.c_str());
                spr->setPosition(pos);
                CCDirector::sharedDirector()->getRunningScene()->addChild(spr,20);
               congratulationId= SimpleAudioEngine::sharedEngine()->playEffect(soundName.c_str(), false);
        }
        else
        {
              congratulationId=  SimpleAudioEngine::sharedEngine()->playEffect(soundName.c_str(), false);
        }
}

void  BBAllGamesFunctionSharedManager::resetToDefaultValues()
{
        // initialize director
        CCDirector *pDirector = CCDirector::sharedDirector();
        
        CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
        
        CCSize designSize;
        CCSize resourceSize;
        CCFileUtils* pFileUtils = CCFileUtils::sharedFileUtils();
        
        std::vector<std::string> searchPaths;
        
        if (BBMainDataManager::sharedManager()->target == kTargetIphone)
        {
                if (screenSize.height > 320) //iPhone Retina
                {
                        resourceSize = CCSizeMake(960, 640);
                        searchPaths.push_back("ipad-Normal");
                }
                else
                {
                        resourceSize = CCSizeMake(480, 320);
                }
                designSize = CCSizeMake(480,320);
        }
        else if (BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
                if(screenSize.height > 768) //ipadRetina
                {
                        resourceSize = CCSizeMake(2048, 1536);
                        searchPaths.push_back("ipad-HD");
                }
                else{
                        resourceSize = CCSizeMake(1024, 768);
                        searchPaths.push_back("ipad-Normal");
                }
                designSize = CCSizeMake(1024,768);
        }
        pFileUtils->setSearchPaths(searchPaths);
        
        pDirector->setContentScaleFactor(resourceSize.height/designSize.height);
        CCEGLView::sharedOpenGLView()->setDesignResolutionSize(designSize.width, designSize.height, kResolutionExactFit);
}

bool BBAllGamesFunctionSharedManager::isLocked(int productId)
{
    bool sw = true;
    
    //There was some error so i have commented Please change as required //Krithik 
    //if(WrapperHelper::itsFull())
    {
        return false;
    }
  
    if (WrapperHelper::itsLite() && WrapperHelper::wasProductBoughtWithIndex(0))
    {
        return false;
    }
    
    
    if (WrapperHelper::itsLite() && WrapperHelper::wasProductBoughtWithIndex(productId))
    {
        return false;
    }
    
    
    
    
    return sw;
}



#endif
