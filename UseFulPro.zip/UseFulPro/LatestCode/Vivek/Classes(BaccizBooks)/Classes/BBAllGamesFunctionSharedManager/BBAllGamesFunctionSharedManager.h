//
//  BBSharedManager.h
//  BaccizBooks
//
//  Created by Deepthi on 03/06/13.
//
//

#ifndef BaccizBooks_BBAllGamesFunctionSharedManager_h
#define BaccizBooks_BBAllGamesFunctionSharedManager_h

#include "cocos2d.h"
USING_NS_CC;


class BBAllGamesFunctionSharedManager: public cocos2d::CCObject
{
public:
        
        //Basic Vars & Methods of Shared Manager
        static BBAllGamesFunctionSharedManager* sharedManager(void);
        bool init(void);
        BBAllGamesFunctionSharedManager();
        ~BBAllGamesFunctionSharedManager();
        
        int congratulationId;
        void addCongratulationBanner(bool bannerStatus,CCPoint pos);
        void resetToDefaultValues();
        bool isLocked(int productId);
    
        
     
};


#endif
