//
//  BBGameSelection.cpp
//  BaccizBooks
//
//  Created by Vivek on 22/04/13.
//
//

#include "BBGameSelection.h"

#include "BBConfig.h"
#include "BBMainDataManager.h"

#include "SimpleAudioEngine.h"

#include "BBTicToeGamePlay.h"
#include "BBMatchGamePlay.h"
#include "FindMamaGamePlay.h"
#include "TIGameScene.h"
#include "TWGameScene.h"
#include "BBMazeGameScene.h"
#include "BBPuzzleGameSelection.h"



using namespace cocos2d;

#define WIND_PARTICLES 30


CCScene* BBGameSelection::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // add layer as a child to scene
    CCLayer* layer = new BBGameSelection();
    scene->addChild(layer);
    layer->release();
    
    return scene;
}

#pragma mark - constructor
BBGameSelection::BBGameSelection()
{
    
}

#pragma mark - onEnter
void BBGameSelection::onEnter()
{
    CCLayer::onEnter();
    
    //loading MainPage plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameSelectionSpriteSheet/BBGameSelection.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    this->initializeUI();
    
    this->createWind();
    
    this->schedule( schedule_selector(BBGameSelection::updateWind) );
    
    WrapperHelper::logEventWitnName("GameHome", true);
    
}

void BBGameSelection::onEnterTransitionDidFinish()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/gamehome_music.mp3", true);
    if(BBMainDataManager::sharedManager()->introGameHomePlayed == false)
    {        introSeq =1;
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
        this->runAction(callBack);
    }
    else
    {
        this->scheduleIdleTickAfterSounds();
    }
    this->idleTime = 0;
    
    WrapperHelper::showButton();
    
}

#pragma mark - iitialiseUI
void BBGameSelection::initializeUI()
{
    CCSize   winsize = CCDirector::sharedDirector()->getWinSize();
    //add bg
    CCSprite *bg = CCSprite::create("BBSharedResources/BackGrounds/BG.jpg");
    bg->setPosition(CCPointMake(winsize.width/2, winsize.height/2));
    this->addChild(bg);
    
    CCSprite *MGNormalSpr = CCSprite::createWithSpriteFrameName("match.png");
    CCSprite *MGSelectedSpr = CCSprite::createWithSpriteFrameName("match.png");
    
    CCMenuItemSprite *MGMenuItem = CCMenuItemSprite::create(MGNormalSpr, MGSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    MGMenuItem->setTag(1);
    MGMenuItem->setScale(0.70);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //        MGMenuItem->setPosition(CCPointMake(200,560));
        MGMenuItem->setPosition(CCPointMake(321,585));
        
    }
    else
    {
        
        MGMenuItem->setPosition(CCPointMake(160,265));
    }
    
    CCSprite *FMNormalSpr = CCSprite::createWithSpriteFrameName("find-mama.png");
    CCSprite *FMSelectedSpr = CCSprite::createWithSpriteFrameName("find-mama.png");
    
    CCMenuItemSprite *FMMenuItem = CCMenuItemSprite::create(FMNormalSpr, FMSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    FMMenuItem->setTag(2);
    FMMenuItem->setScale(0.70);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //        FMMenuItem->setPosition(CCPointMake(510,560));
        FMMenuItem->setPosition(CCPointMake(650,175));
    }
    else
    {
        FMMenuItem->setPosition(CCPointMake(325,55));
    }
    
    CCSprite *TTTNormalSpr = CCSprite::createWithSpriteFrameName("tictactoe.png");
    CCSprite *TTTSelectedSpr = CCSprite::createWithSpriteFrameName("tictactoe.png");
    
    CCMenuItemSprite *TTTMenuItem = CCMenuItemSprite::create(TTTNormalSpr, TTTSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TTTMenuItem->setTag(3);
    TTTMenuItem->setScale(0.70);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //        TTTMenuItem->setPosition(CCPointMake(200,200));
        TTTMenuItem->setPosition(CCPointMake(500,370));
    }
    else
    {
        TTTMenuItem->setPosition(CCPointMake(winsize.width/2,160));
    }
    
    CCSprite *TPNormalSpr = CCSprite::createWithSpriteFrameName("tap-the-picture.png");
    CCSprite *TPSelectedSpr = CCSprite::createWithSpriteFrameName("tap-the-picture.png");
    
    CCMenuItemSprite *TPMenuItem = CCMenuItemSprite::create(TPNormalSpr, TPSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TPMenuItem->setTag(4);
    TPMenuItem->setScale(0.70);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //        TPMenuItem->setPosition(CCPointMake(830,200));
        TPMenuItem->setPosition(CCPointMake(200,370));
    }
    else
    {
        TPMenuItem->setPosition(CCPointMake(60,160));
    }
    
    CCSprite *TWNormalSpr = CCSprite::createWithSpriteFrameName("tap-the-word.png");
    CCSprite *TWSelectedSpr = CCSprite::createWithSpriteFrameName("tap-the-word.png");
    
    CCMenuItemSprite *TWMenuItem = CCMenuItemSprite::create(TWNormalSpr, TWSelectedSpr, this, menu_selector(BBGameSelection::mainMenuCallBack));
    TWMenuItem->setTag(5);
    TWMenuItem->setScale(0.70);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //        TWMenuItem->setPosition(CCPointMake(830,560));
        TWMenuItem->setPosition(CCPointMake(825,370));
    }
    else
    {
        TWMenuItem->setPosition(CCPointMake(420,160));   //400,80
    }
    
    
    
    CCSprite *MZnormal   = CCSprite::createWithSpriteFrameName("maze.png");
    CCSprite *MZselected = CCSprite::createWithSpriteFrameName("maze.png");
    
    CCMenuItemSprite *MZMenuItem = CCMenuItemSprite::create(MZnormal, MZselected, this, menu_selector(BBGameSelection::mainMenuCallBack));
    MZMenuItem->setTag(7);
    MZMenuItem->setScale(0.7);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        MZMenuItem->setPosition(CCPointMake(650, 585));
    }
    else
    {
        MZMenuItem->setPosition(CCPointMake(325,265));
    }
    
    CCSprite *PZnormal   = CCSprite::createWithSpriteFrameName("puzzle.png");
    CCSprite *PZselected = CCSprite::createWithSpriteFrameName("puzzle.png");
    
    CCMenuItemSprite *PZMenuItem = CCMenuItemSprite::create(PZnormal, PZselected, this, menu_selector(BBGameSelection::mainMenuCallBack));
    PZMenuItem->setTag(8);
    PZMenuItem->setScale(0.7);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        PZMenuItem->setPosition(CCPointMake(321, 175));
    }
    else
    {
        PZMenuItem->setPosition(CCPointMake(160,55));
    }
    
    
    CCMenu *selectMenu=CCMenu::create(MZMenuItem, PZMenuItem, MGMenuItem,FMMenuItem,TTTMenuItem,TPMenuItem,TWMenuItem,NULL);
    selectMenu->setPosition(CCPointZero);
    this->addChild(selectMenu,6);
    
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        CCSprite *dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
        dogBase->setScale(0.7);
        dogBase->setPosition(CCPointMake(83, 47));
        addChild(dogBase);
    }
    
    
    
    
    this->bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        this->bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        this->bazziTalking->initialize(this,CCPoint(35,38));
    }
    actionTag = 5000;
    
    
    backgroundWidth = winsize.width;
    backgroundHeight = winsize.height;
    windSpeed = 5.0;
    
}

#pragma MARK - replaceSceneS

void BBGameSelection::mainMenuCallBack(CCObject * pSender)
{
    CCMenuItemSprite *item = (CCMenuItemSprite*)pSender;
    
    int tag = item->getTag();
    
    if(dogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        this->callStopDogAnimation();
    }
    selectedScene = tag;
    
    switch (tag) {
        case 1:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/matchgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
            
        case 2:
        {
            int i = arc4random() %15;
            
            if((i%2) == 0)
            {
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/findmyparents.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
                this->runAction(callBack);
            }
            else
            {
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/findmama.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
                this->runAction(callBack);
            }
            
            
            
        }
            
            break;
        case 3:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tictactoe_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 4:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapthepicture.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 5:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taptheword_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 6:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/bookshelf.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 7:
        {
            
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/maze.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
        case 8:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/puzzles_games.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playScene)),NULL);
            this->runAction(callBack);
        }
            
            break;
            
        default:
            break;
    }
    
}

void BBGameSelection::playScene()
{
    this->unschedule(schedule_selector(BBGameSelection::updateWind) );
    switch (selectedScene)
    {
            
        case 1:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
            break;
            
        case 2:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(FindMamaGamePlay::scene());
            break;
            
        case 3:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(BBTicToeGamePlay::scene());
            break;
        case 4:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
            break;
        case 5:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
            break;
        case 6:
            //Go back to bookshelf
            break;
        case 7:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
            break;
        case 8:
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
            CCDirector::sharedDirector()->replaceScene(BBPuzzleGameSelection::scene());
            break;
            
        default:
            break;
    }
}

//void BBGameSelection::goToMGScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
//}
//
//void BBGameSelection::goToFMScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(FindMamaGamePlay::scene());
//}
//void BBGameSelection::goToTicTacToeScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(BBTicToeGamePlay::scene());
//}
//void BBGameSelection::goToTPScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(TIGameScene::scene());
//}
//void BBGameSelection::goToTWScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
//}
//
//void BBGameSelection::goToBS()
//{
//
//}
//
//void BBGameSelection::goToMZScene()
//{
//
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(BBMazeGameScene::scene());
//}
//
//void BBGameSelection::goToPZScene()
//{
//    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
//    CCDirector::sharedDirector()->replaceScene(BBPuzzleGameSelection::scene());
//}


#pragma mark - destructor
BBGameSelection::~BBGameSelection()
{
    CCLOG("out from BBGameSelection...");

    if(bazziTalking)
    {
    }
  
    
}

#pragma MARK - onExit
void BBGameSelection::onExit()
{
    CCLayer::onExit();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameSelectionSpriteSheet/BBGameSelection.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    WrapperHelper::hideButton();
    WrapperHelper::endTimedEventWithName("GameHome");
    
    delete bazziTalking;
    bazziTalking = NULL;
    
    CC_SAFE_RELEASE_NULL(this->windParticles);

    
}

#pragma mark - Touches End
void BBGameSelection::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
    //If disable touch return
    //    if (this->canTouch == false){
    //        return;
    //    }
    
    CCSetIterator it;
    CCTouch* touch;
    
    for(it = touches->begin(); it != touches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        
        
        
        CCRect bBox = bazziTalking->animatedDog->boundingBox();
        
        if(bBox.containsPoint(this->convertTouchToNodeSpace(touch)))
        {
            this->playIntructions();
        }
        
        
    }
}



#pragma mark - windAnimation
void BBGameSelection::createWind()
{
    
    windParticles = CCArray::create();
    windParticles->retain();
    
    
	float creationZone_Width =  backgroundWidth;
	float creationZone_Height = backgroundHeight;
	float densityRatio = (backgroundWidth*backgroundHeight)/(512*512);
    
	for (int j=0; j<(WIND_PARTICLES*densityRatio); j++)
    {
        
        
        int subImageType = 1 + arc4random() % 5;
        
        CCString *img = CCString::createWithFormat("l%i.png",subImageType);
        leafSprite *leaf = leafSprite::createWithSpriteFrameName(img->getCString());
        
        CCLOG(url->getCString());
        leaf->setScale(0.5 + (CCRANDOM_0_1() + 0.01) * 0.3);
        leaf->setTag(j);
        
        this->addChild(leaf);
        
		leaf->setPosition(ccp(((CCRANDOM_0_1() + 0.01) * creationZone_Width),((CCRANDOM_0_1() + 0.01) * creationZone_Height)));
		leaf->setSpeed(windSpeed);
		leaf->startMovement();
		
		windParticles->addObject(leaf);
	}
    
}

void BBGameSelection::updateWind(CCTime *dt)
{
    //remove out of stage objects
	for (int i=0; i<windParticles->count(); i++){
		
        leafSprite* leaf = (leafSprite *)windParticles->objectAtIndex(i);
		
        if (leaf->getPositionX() < 0 || leaf->getPositionX() > backgroundWidth)
        {
            windParticles->removeObjectAtIndex(i);
            leaf->removeLeaf();
		}
        
    }
	
	float densityRatio = (backgroundWidth*backgroundHeight)/(512*512);
	
	//create new objects
	if (windParticles->count() < WIND_PARTICLES*densityRatio) {
		float creationZone_Height = backgroundHeight;
		float creationZone_Width =  (windSpeed < 0)?100.0f:-100.0f;
		
		for (int j=0; j<((WIND_PARTICLES*densityRatio) - windParticles->count()); j++)
        {
            
			float start_point = (windSpeed>0)?0:backgroundWidth;
            
            int subImageType = 1 + arc4random() % 5;
            CCString *img = CCString::createWithFormat("l%i.png",subImageType);
            leafSprite *leaf = leafSprite::createWithSpriteFrameName(img->getCString());
            
            leaf->setScale(0.5 + (CCRANDOM_0_1() + 0.01) * 0.3);
            leaf->setTag(j);
            
            this->addChild(leaf);
            
            leaf->setPosition(ccp(start_point + ((CCRANDOM_0_1() + 0.01) * creationZone_Width),((CCRANDOM_0_1() + 0.01) * creationZone_Height)));
            leaf->setSpeed(windSpeed);
            leaf->startMovement();
            
            windParticles->addObject(leaf);
		}
	}
}

# pragma mark - godAnimation

void BBGameSelection::callStopDogAnimation()
{
    bazziTalking->stopDogTalking();
    isDogTalking = false;
    this->setTouchEnabled(true);
    this->scheduleIdleTickAfterSounds();
}

void BBGameSelection::scheduleIdleTickAfterSounds(){
    
    this->schedule(schedule_selector(BBGameSelection::idleCheckTick), 1);
}

void BBGameSelection::idleCheckTick()
{
    if(this->isDogTalking==false)
    {
        this->idleTime ++;
        
        if(this->idleTime%3==0 && bazziTalking->isRunningIdleAnimation==false)
        {
            idleTime = 0;
            bazziTalking->runBacciIdleAnimation();
        }
    }
}


void BBGameSelection::playIntro()
{
    BBMainDataManager::sharedManager()->introGameHomePlayed = true;
    switch (introSeq)
    {
        case 1:
            this->playWelcome();
            break;
            
        case 2:
        {
            this->callStopDogAnimation();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
            
            this->runAction(callBack);
        }
            break;
            
        case 3:
        {
            this->playIntructions();
        }
            break;
        default:
            break;
    }
    
    introSeq++;
}

//play the intro animation of the dog Talking.
void BBGameSelection::playWelcome()
{
    this->setTouchEnabled(false);
    
    
    bazziTalking->startDogTalking();
    int i = arc4random() % 2;
    
    if(i == 0)
    {
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizplayground.mp3");
        
        //                    welcometobaccizhome_books_games.mp3
        
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
        this->runAction(callBack);
        
    }
    
    if(i == 1)
    {
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizhome_books_games.mp3");
        
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::playIntro)),NULL);
        this->runAction(callBack);
        
    }
    isDogTalking = true;
}

void BBGameSelection::playIntructions()
{
    this->setTouchEnabled(false);
    bazziTalking->startDogTalking();
    
    int i = arc4random() % 3;
    
    switch (i)
    {
        case 0:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/Letsplay.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
            break;
            
        case 1:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/findgameyouwantoplay_game.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
            break;
            
        case 2:
        {
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/selectgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBGameSelection::callStopDogAnimation)),NULL);
            this->runAction(callBack);
        }
            break;
            
        default:
            break;
    }
    
    isDogTalking = true;
}


