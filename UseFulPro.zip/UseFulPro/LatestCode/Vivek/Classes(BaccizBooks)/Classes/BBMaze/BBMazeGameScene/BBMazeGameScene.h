//
//  BBMazeGameScene.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 13/02/13.
//
//

#ifndef __BaccizBooks__BBMazeGameScene__
#define __BaccizBooks__BBMazeGameScene__

#include "cocos2d.h"
#include "cocos-ext.h"
#include "BBAStarNode.h"
#include "BBAStarPathNode.h"
#include "BacciTalking.h"



USING_NS_CC;
USING_NS_CC_EXT;

enum state {
    kLeft = 1,
    kRight = 2,
    kUp = 3,
    kDown = 4
};

class BBMazeGameScene:public CCLayer
{
private:
    //Default
    virtual void onEnter();
    virtual void onExit();
    
    BBMazeGameScene();
    ~BBMazeGameScene();
    
public:
    static CCScene* scene();
    
    //------------- VARIABLES
    CCNode *gridNode; //Where we draw everything
    GLubyte pixelColors[4];
    
    BBAStarNode *touchedNode;
    
    CCDictionary *aMazeDict;
    
    CCArray *obstaclesArr;
    CCArray *gridArray;
    CCArray *startCordArray;
    CCArray *endCordArray;
    
    CCPointArray *touchArray;
    CCPointArray *testArray;
    
    CCPoint sPoint;// start point

    CCPoint gridSize;
    CCPoint touchPointNode;
    
    CCPoint previousFarmerPosition;
    CCPoint currentFarmerPosition;
    
    CCSprite *farmerSprite;
    CCSprite *aCow;
    CCSprite *award;
    
    float nodeSpace;//The space between each node
         
    bool isTouchedNodeIsNew;//Where we touched
    bool isPathFound;
    bool isPixelReading;
    bool isRunningAnimation;
    bool isRunningFarmerAnimation;
    
    //Texture
    CCSprite *blackBackgroundSprite;
    CCSprite *renderSprite;
    CCRenderTexture *renderTarget;
    
    //Particles
    CCParticleSystem *addParticleEffectToTexture;
   //Initialize variables
    void initializeVariables();
    
    //------------UI
    void GameUI();
    void addStars();
    void addNewStar();
    void addBgWithObstacles();
    CCRenderTexture* createStroke(CCLabelTTF *label,int size,ccColor3B color); // Stroke
    void callVisibileFuncForArrows();
  //  void addingStarAfterLevelTen();
    
    //-----------SOUNDS
    
    int obstacleTouchCount;
        void findWayToCow();
        void findBestPath();
        void lookForObstacles();
        void tryMore();
        void gameOver();
        void playPlayAgainSound();
        
        //position
        int xPos;
        int yPos;
        
        //bacciTaking
        BacciTalking *bazziTalking;
      
        
        unsigned int welcomeSoundInt;
    
    //--------FUNCTIONALITY
    void addWall();
    void findPath();
    void removeLoadLabel();
    void flipNodeWithTouchedNode();
    void addNeighbourNodeToGridNode(BBAStarNode *node,int x,int y);
    bool scanForObstacles(CCPoint point);
    
    //---------ANIMATION
    state walkingState; //Enum Object
    
   // void setFarmerFlipFalse();
    void  afterReachingDestinationFunc();
    void setFarmerFlipTrue();
    float getAngleBetweenPoints(CCPoint currentPoint, CCPoint toPoint);
    
    void callCowAnimation();
    void stopCowAnimation();
        
    void runAnimation(const char* animName);
    void stopAnimation();
    void resetIsRunningAnimation();
        
  //global declaration
    CCMenuItemSprite *replayBtnSpr;
    CCMenuItemSprite *controlMenuItem;
        
   //sound
        bool canPlaySound();
        void playSoundAfterDelay();
        void checkTheConditionsToPlayInitialSound();
        void checkTheConditionsToPlaySecondSound();
        void checkTheConditionsToPlayThirdSound();
        void initialDogAdviceFunc();
        void calstopDogTalkingFunc();
        void initialiseSound();
        int soundValue;
        void playStarAnimationSound();
        void replaySound();
        void convincesound();
        
        //game play
        void replaceSceneAfterDelay();
        void addBanner();
        void calladdingTrophyFunc();
        void afterFinishingLevelFunc();
        void playAgainFunc();
        void goBackFunc();
        void playAgainFuncAfterDelay();
        bool isGameFinished;
        bool isAddedCongratulationPopUp;
        void canTapDog();
     //   bool isPressedReplayButton;
        void playSoundWhenTapDog(CCSet *pTouches, CCEvent *pEvent);
        CCLabelTTF *pathFoundlabel ;
        bool canAddStar;
        void playWelcomeSound();
        bool isStartedPlaying;
        
        void gotoNextLevel();
    

    //Menu Variables & Methods
    CCMenuItemSprite *leftArrowMenuItem;
    CCMenuItemSprite *rightArrowMenuItem;
    
    void replaceScene();
    void gotoGameSelectionScene();
    void goToNextScene(CCMenuItemSprite *sender); // NextScene
    void goToPreviousScene(CCMenuItemSprite *sender); // PreviouScene
    
    static CCPointArray* genCatmullRomSplinesWithPoints(CCPointArray *arrOriginalPoints,int num,int segments);
        
    //Update
    void update(CCTime dt);
    void checkPath(CCTime dt);
   
        //Game Idle
        void idleCheckTick();
    //draw
    void draw();
    
    //TEST
    CCDictionary *spritesDict;
    CCPoint startCoord;
    CCPoint endCoord;
    void addGridArt();
    
    //touches
    void ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesMoved(CCSet *pTouches, CCEvent *pEvent);
    void ccTouchesEnded(CCSet *pTouches, CCEvent *pEvent);
        void ccTouchesCancelled(CCSet *pTouches, CCEvent *pEvent);
        
        //Design size
        void setMazeDefaultValues();
   
    
    //Particle
    void createParticleAtPosition(CCPoint inPosition);
    void removeParticle();
        
        //Detect Bad Path
        bool checkForBadPath();
        void resetBadPath();
     
        //hint
        void farmerTouchedObstacle();
        bool canPlayHintSound;
         int hintCount;
        void setcanPlayHintSoundTrue();
        
        void secondTick();

     bool isLoked;
    void reSet(CCBool *sw);
};

#endif /* defined(__BaccizBooks__BBMazeGameScene__) */
