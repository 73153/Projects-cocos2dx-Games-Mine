//
//  FMDataManager.cpp
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#include "TIDataManager.h"
#include "cocos2d.h"

static TIDataManager *gSharedManager = NULL;

TIDataManager::TIDataManager(void){
        this->currentLevel=1;
        this->pageCount=1;
        this->starCount=0;
        this->isNewGame=true;
        this->canPlaySound=true;
        this->canTapDog=true;
        this->canAddAnimals=true;
        this->canPlayAdviceSound=true;
         this->previousAnimalTag = 0;
}

TIDataManager* TIDataManager::sharedManager(void) {
    
	TIDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new TIDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool TIDataManager::init(void) {
	return true;
}

