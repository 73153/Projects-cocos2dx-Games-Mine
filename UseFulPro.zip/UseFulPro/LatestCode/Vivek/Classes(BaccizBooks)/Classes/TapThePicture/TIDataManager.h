//
//  FMDataManager.h
//  FindMama
//
//  Created by Vivek on 11/03/13.
//
//

#ifndef FindMama_FMDataManager_h
#define FindMama_FMDataManager_h

#include "cocos2d.h"
#include "CCBReader.h"
#include "TIDataManager.h"

USING_NS_CC;
USING_NS_CC_EXT;


class TIDataManager: public cocos2d::CCObject  {
    
private:
    
    TIDataManager(void);
  //  virtual TIDataManager(void);
    
public:

    bool init(void);
    static TIDataManager* sharedManager(void);
    
    const char *gameLevelName;
    int currentLevel;
    int pageCount;
    int starCount;
    bool isNewGame;
    bool canPlaySound;
    bool canTapDog;
    bool canAddAnimals;
    bool canPlayAdviceSound;
    
    int previousAnimalTag; //This is used so the animals wont repeat again i.e. dog is the random animal , next again we should nt choose dog 

    TargetPlatform target;
};


#endif
