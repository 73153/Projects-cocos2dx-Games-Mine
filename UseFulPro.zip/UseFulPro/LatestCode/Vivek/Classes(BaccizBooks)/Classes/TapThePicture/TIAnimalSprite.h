//
//  TICustomSprite.h
//  TapThePicture
//
//  Created by Deepthi on 28/03/13.
//
//

#ifndef TapThePicture_TICustomSprite_h
#define TapThePicture_TICustomSprite_h
#include "cocos2d.h"
using namespace cocos2d;

class TIAnimalSprite: public CCSprite
{
        
public:
        
         TIAnimalSprite();
       ~ TIAnimalSprite();
        
        static TIAnimalSprite* createWithSpriteFrameName(const char *pszSpriteFrameName);
         static TIAnimalSprite* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
       
        const char *sound;
        const char  *itemName;
        int animalTag;
        bool canTapAnimal;
        
        

};

#endif
