//
//  TICustomSprite.cpp
//  TapThePicture
//
//  Created by Deepthi on 28/03/13.
//
//

#include "TIAnimalSprite.h"
#include "cocos2d.h"

TIAnimalSprite::TIAnimalSprite()
{
        canTapAnimal=true;
}
TIAnimalSprite::~TIAnimalSprite()
{
        
}
TIAnimalSprite* TIAnimalSprite::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
        
#if COCOS2D_DEBUG > 0
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s", pszSpriteFrameName);
        CCAssert(pFrame != NULL, msg);
#endif
        
        return createWithSpriteFrame(pFrame);
}
TIAnimalSprite* TIAnimalSprite::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
        TIAnimalSprite
        *pobSprite = new TIAnimalSprite();
        if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}