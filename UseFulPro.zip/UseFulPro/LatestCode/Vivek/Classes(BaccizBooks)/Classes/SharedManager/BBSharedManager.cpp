//
//  BBSharedManager.cpp
//  BaccizBooks
//
//  Created by Deepthi on 03/06/13.
//
//

#ifndef BaccizBooks_BBSharedManager_cpp
#define BaccizBooks_BBSharedManager_cpp

#include "SimpleAudioEngine.h"
#include "BBSharedManager.h"

using namespace cocos2d;
using namespace CocosDenshion;


static BBSharedManager *gSharedManager = NULL;

#pragma mark - Basic Methods of Shared Manager

BBSharedManager::BBSharedManager(void)
{
        
}

BBSharedManager::~BBSharedManager(void)
{
        
}


BBSharedManager* BBSharedManager::sharedManager(void) {
        
	BBSharedManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBSharedManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBSharedManager::init(void)
{
	return true;
}
void BBSharedManager::addCongratulationBanner(CCLayer *parentLayer,CCPoint pos)
{
        
        int rand = arc4random()%10;
        
        if(rand==0)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Amazing!.png");
                
              
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/amazing.mp3", false);
        }
        else if(rand==1)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Awesome!.png");
               SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/awesome.mp3", false);   
        }
        else if(rand==1)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Big-step.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/bigstep.mp3", false);
        }
        else if(rand==2)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Bravo!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/bravo.mp3", false);
        }
        else if(rand==3)
        {
              spr = CCSprite::create("BBSharedResources/CongratulationBanner/Brilliant!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/brilliant.mp3", false);
        }
        else if(rand==4)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Congratulations!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/congratulations.mp3", false);
        }
        else if(rand==5)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Excellent!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/excellent.mp3", false);
        }
        else if(rand==6)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Fantastic!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/fantastic.mp3", false);
        }
        else if(rand==7)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Good-Job!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/goodjob.mp3", false);
        }
        else if(rand==8)
        {
            spr = CCSprite::create("BBSharedResources/CongratulationBanner/Great-effort!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/great_effort.mp3", false);
        }
        else if(rand==9)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Great-Job!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/great-job.mp3", false);
        }
        else if(rand==10)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Great!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/great.mp3", false);
        }
        else if(rand==11)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Incredible!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/incredible.mp3", false);
        }
        else if(rand==12)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Nice-work!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/nicework.mp3", false);
        }
        else if(rand==13)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Original!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/original.mp3", false);
        }
        else if(rand==14)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Outstanding!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/outstanding.mp3", false);
        }
        else if(rand==15)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Perfect!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/perfect.mp3", false);
        }
        else if(rand==16)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Perfect!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/perfect.mp3", false);
        }
        else if(rand==17)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Super_happy!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/super_happy.mp3", false);
        }
        else if(rand==18)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Super!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/super.mp3", false);
        }
        else if(rand==19)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Terrific.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/terrific.mp3", false);
        }
        else if(rand==20)
        {
              spr = CCSprite::create("BBSharedResources/CongratulationBanner/That’s-Great!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/thatsgreat.mp3", false);
        }
        else if(rand==21)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Unique!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/unique.mp3", false);
        }
        else if(rand==22)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Very_nice!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/very_nice.mp3", false);
        }
        else if(rand==23)
        {
               spr = CCSprite::create("BBSharedResources/CongratulationBanner/Well-done!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/welldone.mp3", false);
        }
        else if(rand==24)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Wonderful!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/wonderful.mp3", false);
        }
        else if(rand==25)
        {
                spr = CCSprite::create("BBSharedResources/CongratulationBanner/Wow!.png");
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/CongragulationSounds/wow3.mp3", false);
        }
        spr ->setPosition(pos);
        parentLayer->addChild(spr,20);
        

}


#endif
