//
//  BBSharedManager.h
//  BaccizBooks
//
//  Created by Deepthi on 03/06/13.
//
//

#ifndef BaccizBooks_BBSharedManager_h
#define BaccizBooks_BBSharedManager_h

#include "cocos2d.h"
USING_NS_CC;


class BBSharedManager: public cocos2d::CCObject
{
public:
        
        //Basic Vars & Methods of Shared Manager
        static BBSharedManager* sharedManager(void);
        bool init(void);
        BBSharedManager();
        ~BBSharedManager();
          CCSprite *spr ;
        
        void addCongratulationBanner(CCLayer *parentLayer,CCPoint pos);
        
     
};


#endif
