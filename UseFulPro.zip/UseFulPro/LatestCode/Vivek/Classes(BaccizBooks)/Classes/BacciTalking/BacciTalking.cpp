//
//  BacciTalking.cpp
//  BaccizBooks
//
//  Created by Deepthi on 25/05/13.
//
//

#include "BacciTalking.h"
#include "BBMainDataManager.h"
BacciTalking::BacciTalking()
{
    
    this->isRunningIdleAnimation = false;
    this->isBacciTalking = false;
    this->idleTime = 0;
}


BacciTalking::~BacciTalking()
{
    CCLog("Dealloc in ~BaccizAnimation");

    
    //Remove the animations from the memory
    std::string anAnimFileFullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BacciTalking/talking.sam");
    UnloadAnimFileExt(anAnimFileFullPath);
    
    std::string anIdleAnimFileFullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BacciTalking/Idle/Waiting.sam");
    UnloadAnimFileExt(anIdleAnimFileFullPath);
    
    this->animatedDog = NULL;
    this->idleAnimatedDog = NULL;
}


#pragma mark - Initialise

void BacciTalking :: initialize(CCLayer *parentLayer,CCPoint pos)
{
    //Dog Talking
    std::string anAnimFileFullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BacciTalking/talking.sam");
    
    this->animatedDog = SuperAnimNode::create(anAnimFileFullPath,0, this);
    this->animatedDog->setPosition(CCPoint(pos));
    
    //Dog Idle
    
    std::string anIdleAnimFileFullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BacciTalking/Idle/Waiting.sam");

    this->idleAnimatedDog = SuperAnimNode::create(anIdleAnimFileFullPath,0, this);
    this->idleAnimatedDog->setPosition(CCPoint(pos));
    this->idleAnimatedDog->setScale(1.2);
    this->idleAnimatedDog->setPositionY(idleAnimatedDog->getPositionY()+4);
       
    //Check whether the App in running in Retina Device
    if(CCDirector::sharedDirector()->getContentScaleFactor()==2)
    {
        this->animatedDog->setScale(0.5);
        this->idleAnimatedDog->setScale(0.5);
        if (BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            this->animatedDog->setAnchorPoint(CCPoint(0.0, 0.0));
            this->animatedDog->setPosition(CCPoint(pos.x-animatedDog->getContentSize().width/2, pos.y-animatedDog->getContentSize().height/2));

           
            this->idleAnimatedDog->setAnchorPoint(CCPoint(0.0, 0.0));
            this->idleAnimatedDog->setPosition(CCPoint(pos.x-this->animatedDog->getContentSize().width/2-50, pos.y-this->animatedDog->getContentSize().height/2-8));
                this->idleAnimatedDog->setScale(0.6);

        }
       
        else if(BBMainDataManager::sharedManager()->target == kTargetIphone){
            
            this->idleAnimatedDog->setScale(.6);
            this->idleAnimatedDog->setPosition(ccp(this->idleAnimatedDog->getPositionX()-10, this->idleAnimatedDog->getPositionY()-5));

        }
    }
    
    else if(BBMainDataManager::sharedManager()->target == kTargetIphone){
        this->idleAnimatedDog->setPositionY(this->idleAnimatedDog->getPositionY()-2);
    }
    
    parentLayer->addChild(this->animatedDog,10);
    parentLayer->addChild(this->idleAnimatedDog,10);
    
    this->animatedDog->PlaySection("talking");
    this->animatedDog->Pause();
    
    this->idleAnimatedDog->PlaySection("Waiting");
    this->idleAnimatedDog->setVisible(false);
    

    this->shouldDogTalk = false;
}

//void BacciTalking::runDogAnimation()
//{
//        animatedDog->PlaySection("talking");
//}

void BacciTalking::startDogTalking()
{
    if(this->isRunningIdleAnimation)
    {
        this->stopBacciIdleAnimation();
    }
    
    this->animatedDog->PlaySection("talking");
    
    this->shouldDogTalk = true;
    this->isBacciTalking = true;
}


void BacciTalking::stopDogTalking()
{
    this->shouldDogTalk = false;
    this->isBacciTalking = false;
}

#pragma mark - Idle Animation
void BacciTalking::runBacciIdleAnimation()
{
   
    this->isRunningIdleAnimation = true;
    this->animatedDog->setVisible(false);
    
    this->idleAnimatedDog->setVisible(true);
    this->idleAnimatedDog->PlaySection("Waiting");
    
    this->idleTime = 0;

}

void BacciTalking::stopBacciIdleAnimation()
{
    this->idleTime = 0;

    this->isRunningIdleAnimation = false;
    
    this->animatedDog->setVisible(true);
    
    this->idleAnimatedDog->setVisible(false);
    this->idleAnimatedDog->Pause();
    
    this->stopDogTalking();
   
}

#pragma mark - Dog Point Right & Up
void BacciTalking::createDogPointingRight() {
    
    //Hide the current Animated Dog
    this->animatedDog->setVisible(false);
    
    //Bacci Pointing Right
    CCSprite *bacciPointingRight = CCSprite::create("BacciTalking/BacciTalkingRight/point_right0012.png");
    CCDirector::sharedDirector()->getRunningScene()->addChild(bacciPointingRight);
    bacciPointingRight->setTag(kDogPointingRightTag);
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        bacciPointingRight->setPosition(CCPoint(85, 128));
    }
    else
    {
        bacciPointingRight->setPosition(CCPoint(35, 38));
    }
    
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(1), CCCallFunc::create(CCDirector::sharedDirector()->getRunningScene(),callfunc_selector(BacciTalking::removeDogPointingRight)),NULL);
    CCDirector::sharedDirector()->getRunningScene()->runAction(seq);
}

void BacciTalking::removeDogPointingRight() {
    
    //    this->animatedDog->setVisible(true);
    CCDirector::sharedDirector()->getRunningScene()->removeChildByTag(kDogPointingRightTag);
}

void BacciTalking::createDogPointingUp() {
    
    //Hide the current Animated Dog
    this->animatedDog->setVisible(false);
    
    //Bacci Pointing Up
    CCSprite *bacciPointingUp = CCSprite::create("BacciTalking/BacciTalkingUp/point_up0012.png");
    CCDirector::sharedDirector()->getRunningScene()->addChild(bacciPointingUp);
    bacciPointingUp->setTag(kDogPointingUpTag);
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        bacciPointingUp->setPosition(CCPoint(85, 128));
    }
    else
    {
        bacciPointingUp->setPosition(CCPoint(35, 38));
    }
    
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(1), CCCallFunc::create(CCDirector::sharedDirector()->getRunningScene(), callfunc_selector(BacciTalking::removeDogPointingUp)), NULL);
    CCDirector::sharedDirector()->getRunningScene()->runAction(seq);
}

void BacciTalking::removeDogPointingUp() {
    
    CCDirector::sharedDirector()->getRunningScene()->removeChildByTag(kDogPointingUpTag);
}


#pragma mark - Hammer Animation
void BacciTalking::runHammerAnimation()
{
    this->animatedDog->setVisible(false);
    
    CCSprite *tempDogSpr;
    tempDogSpr = CCSprite::createWithSpriteFrameName("Hammer001.png");

    if (BBMainDataManager::sharedManager()->target==kTargetIpad) {
        tempDogSpr->setPosition(CCPoint(105,108));
    }
    else {
        
        tempDogSpr->setPosition(CCPoint(40, 40));
        tempDogSpr->setScale(0.8);
    }
    tempDogSpr->setTag(kHammerAnimTag);
    CCDirector::sharedDirector()->getRunningScene()->addChild(tempDogSpr,5);

    
    CCAnimationCache *animCacheFarmer = CCAnimationCache::sharedAnimationCache();
    CCAnimation *animationFarmer = animCacheFarmer->animationByName("Hammer");
    animationFarmer->setRestoreOriginalFrame(1);
    CCAnimate *animNFarmer = CCAnimate::create(animationFarmer);
    animNFarmer->setTag(kHammerAnimTag);
    tempDogSpr->runAction(animNFarmer);
}

void BacciTalking::removeHammerAnimation()
{
    this->animatedDog->setVisible(true);
    CCDirector::sharedDirector()->getRunningScene()->removeChildByTag(kHammerAnimTag);
}

#pragma mark - 

void BacciTalking::setDogTalkingVisibility(){
    
    this->animatedDog->setVisible(true);
}

void BacciTalking::setDogVisibleFalse()
{
    this->animatedDog->setVisible(false);

}



#pragma mark - Animations

void BacciTalking::OnAnimSectionEnd(int theId, std::string theLabelName){
    
    if(this->shouldDogTalk)
    {
        if(theLabelName=="talking")
        {
            this->animatedDog->PlaySection("talking");
            
        }
    }
    
    if (theLabelName == "Waiting")
    {
        this->isRunningIdleAnimation = false;
    }
}

