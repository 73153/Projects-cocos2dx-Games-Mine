//
//  BacciTalking.h
//  BaccizBooks
//
//  Created by Deepthi on 25/05/13.
//
//

#ifndef BaccizBooks_BacciTalking_h
#define BaccizBooks_BacciTalking_h

#include "cocos2d.h"
#include "SuperAnimNodeV2.h"
using namespace SuperAnim;
USING_NS_CC;

#define kHammerAnimTag 1111
#define kDogPointingRightTag 2222
#define kDogPointingUpTag 3333

class  BacciTalking:public SuperAnimNodeListener
{
public:
    
    BacciTalking();
    ~BacciTalking();
 
    bool shouldDogTalk;
    
    SuperAnimNode *animatedDog;
    SuperAnimNode *idleAnimatedDog;
    
    void initialize(CCLayer *parentLayer,CCPoint pos);
    
    bool isBacciTalking;
    void startDogTalking();
    void stopDogTalking();
    
    int idleTime;
    bool isRunningIdleAnimation;
    void runBacciIdleAnimation();
    void stopBacciIdleAnimation();
    
    //Dog Point Right
    void createDogPointingRight();
    void removeDogPointingRight();
    
    void createDogPointingUp();
    void removeDogPointingUp();
    
    void setDogTalkingVisibility();
    void setDogVisibleFalse();
    
    //Hammer Animation
    void runHammerAnimation();
    void removeHammerAnimation();

    
    void OnAnimSectionEnd(int theId, std::string theLabelName);
    
};


#endif
