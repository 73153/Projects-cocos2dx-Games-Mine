//
//  BBMatchGamePlay.h
//  BaccizBooks
//
//  Created by Anshul on 22/01/13.
//
//

#ifndef __BaccizBooks__BBMatchGamePlay__
#define __BaccizBooks__BBMatchGamePlay__

#include "BBGameManager.h"
#include "BBMGSprite.h"
#include "cocos2d.h"
#include "cocos-ext.h"
#include "BacciTalking.h"
#include "BBMatchDataManager.h"
#include "BBSharedSoundManager.h"

USING_NS_CC;
USING_NS_CC_EXT;


using namespace cocos2d;

class BBMatchGamePlay:public cocos2d::CCLayer {
    
private:
    CCBAnimationManager *mAnimationManager;
    
public:
    
    // Default
    virtual void onEnter();
    virtual void onExit();
    virtual void onEnterTransitionDidFinish();
    
    BBMatchGamePlay();
    virtual ~BBMatchGamePlay();
    static cocos2d::CCScene* scene();
    
    CREATE_FUNC(BBMatchGamePlay);
    
    //Game Bg
    CCSprite *gameBackground;
    //    CCSprite *dogAnim;
    
    // Initialize
    void initializeGame(const char *type);
    void initializeGameUI();
    void initializeVariables();
    
    //Functions
    void addBlinkActionForRefreshButton(float dt);
    void loadLevel(int tag);
    int* randomizeInt(int GameCards[15]);
    void cardsNotMatch(CCSprite *senderSpr);
    
    //shineAnimation
    void shineAnimation(BBMGSprite *selectedSprite);
    void stopShineAnimationEffect();
    
    //Restart
    CCMenuItemSprite *restartMenuItem;
    
    //CardsArray
    CCArray *cardsArr;
    CCArray* cardsToBeShuffleArr;
    
    //CardsDictionary
    CCDictionary *aCardLevelDict;
    
    CCLabelTTF* pLabel;
    
    //CustomSprites
    BBMGSprite* firstSelectedCard;
    BBMGSprite* secondSelectedCard;
    BBMGSprite* remainingCards;
    
    int selectedCardCount;
    int correctMatches;
    int wrongMatches;
    
    //Particles
    CCParticleSystem *shine;
    
    void openCard(BBMGSprite *fgSpr);
    void flipCards(BBMGSprite *topCard);
    void changeImageOfTopCard(BBMGSprite *matchCard);
    void matchCardsShineAnimation(BBMGSprite *Cards);
    
    void checkCards();
    void removeCards();
    void gameOver();
    
    void addStars();
    void addNewStar();
    
    //Touch
    bool canTouch;
    void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    
    //Button Actions
    // Level Selection
    void gotoLevel(cocos2d::CCMenuItemImage* sender);
    
    //Utility
    CCArray* shuffleArray(CCArray *cardsToShuffle);
    
    BacciTalking *bazziTalking;
    void callStopDogAnimation();
    void scheduleIdleTickAfterSounds();
    void idleCheckTick();
    void sayHint();
    void playIntro();
    void tryAgain();
    void playAgain();
    void playGetTrophy();
    void playGoodBye();
    void playGoodBye2();
    void gotoGameHome();
    
    
    bool isDogTalking;
    int dogTalking;
    int introSeq;
    int actionTag;
    int idleTime;
    
    int xPos;
    int yPos;

    CCSprite *starEmptySprite;
    CCSprite *award;
    
    bool isLoked;
    
    void reSet(CCBool *sw);
    
};


#endif /* defined(__BaccizBooks__BBMatchGamePlay__) */
