//
//  BBMatchGamePlay.cpp
//  BaccizBooks
//
//  Created by Anshul on 22/01/13.
//
//

#include "BBMatchGamePlay.h"
#include "BBMainDataManager.h"
#include "BBGameSelection.h"
#include "BBUtility.h"
#include "CCBReader.h"
#include "CCBSequence.h"
#include "BBAllGamesFunctionSharedManager.h"

#include "cocos2d.h"
using namespace cocos2d;
using namespace cocos2d::extension;

#include "SimpleAudioEngine.h"
using CocosDenshion::SimpleAudioEngine;

USING_NS_CC;
USING_NS_CC_EXT;

CCScene* BBMatchGamePlay::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CCLayer *layer = new BBMatchGamePlay();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    layer->release();
    return scene;
}


BBMatchGamePlay::BBMatchGamePlay() {
    
    this->setTouchEnabled(true);
    //Creating Cards Array
    this->isLoked = BBAllGamesFunctionSharedManager::sharedManager()->isLocked(2);
    this->cardsArr = CCArray::create();
    this->cardsArr->retain();
    
    this->cardsToBeShuffleArr = CCArray::create();
    this->cardsToBeShuffleArr->retain();
    
    //HideBuyFullVersionView
    CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(BBMatchGamePlay::reSet), "HideBuyFullVersionView", NULL);
    
}


#pragma mark - initialize
void BBMatchGamePlay::onEnter() {
    
    CCLayer::onEnter();
    
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
    
    //loading plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("MatchGame/BBMGImages.plist");
    
    //Background
    this->gameBackground = CCSprite::create("BBSharedResources/BackGrounds/BGmatchV.png");
    this->gameBackground->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(this->gameBackground,2,1);
    
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        bazziTalking->initialize(this,CCPoint(35,38));
        this->gameBackground->setPosition(ccp(winsize.width/2, winsize.height/2 + 10));
        
    }
    actionTag = 5000;
    
    
    //call to initialize variables
    this->initializeVariables();
    
    //Add Game UI
    this->initializeGameUI();
    
    //call to last gameLevel played
    int lastLevelPlayed = CCUserDefault::sharedUserDefault()->getIntegerForKey("lastLevelPlayed");
    this->loadLevel(lastLevelPlayed);
    
    WrapperHelper::logEventWitnName("memoryMatch", true);
}

void BBMatchGamePlay::onEnterTransitionDidFinish()
{
    CocosDenshion::SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/memory_match_music.mp3", true);
    
    if(BBMatchDataManager::sharedManager()->isNewGame)
    {
      BBMatchDataManager::sharedManager()->isNewGame = false;
      introSeq =1;
//      this->playIntro();
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playIntro)),NULL);
        this->runAction(callBack);
    }
    idleTime = 0;
}


void BBMatchGamePlay::initializeVariables() {
    
    
    //touch enable for next sprite to get opened
    this->canTouch = true;
    
    //set Count
    this->selectedCardCount = 0;
    this->correctMatches = 0;
    this->wrongMatches = 0;
    
}


void BBMatchGamePlay::initializeGame(const char *type) {
    
    //stop all the previous actions
    this->stopAllActions();
    
    //set default action for restart button
    this->restartMenuItem->unselected();
    
    //Remove all previous cards if present
    this->removeCards();
    
    //loading plist
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("BBColorCards.plist");
    CCDictionary *allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    
    aCardLevelDict = (CCDictionary *)allCardInfoDict->valueForKey(type);
    
    CCArray *aLevelGameCards = (CCArray *)allCardInfoDict->valueForKey("GameCards");
    
    //set the default card Index
    int cardIndex = 1;
    
    //loading split and skip Index
    int skipIndex = aCardLevelDict->valueForKey("SkipIndex")->intValue();
    int splitIndex = aCardLevelDict->valueForKey("splitIndex")->intValue();
    
    //scale cards
    float scaleCard = aCardLevelDict->valueForKey("scaleCard")->floatValue();
    
    //loading X and Y position
    //loading X and Y position
    int xPos;
    int yPos;
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        xPos = aCardLevelDict->valueForKey("cardStartingPosXIpad")->intValue();
        yPos = aCardLevelDict->valueForKey("cardStartingPosYIpad")->intValue();
    }
    else
    {
        xPos = aCardLevelDict->valueForKey("cardStartingPosXIphone")->intValue();
        yPos = aCardLevelDict->valueForKey("cardStartingPosYIphone")->intValue();
    }
    
    //difference of height and width between the cards
    int diffX;
    int diffY;
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        diffX = aCardLevelDict->valueForKey("diffXIpad")->intValue();
        diffY = aCardLevelDict->valueForKey("diffYIpad")->intValue();
    }
    else
    {
        diffX = aCardLevelDict->valueForKey("diffXIphone")->intValue();
        diffY = aCardLevelDict->valueForKey("diffYIphone")->intValue();
    }
    
    //loading uniqueCardsCount
    int uniqueCardsCount = aCardLevelDict->valueForKey("uniqueCards")->intValue();
    
    //store unique no's into array
    int no_to_randomize[15];
    for (int i = 0 ; i <= 14; i++) {
        
        no_to_randomize[i] = i;
    }
    
    //store indexes into an integer Array from randomize method
    int* store_randomArray;
    store_randomArray = this->randomizeInt(no_to_randomize);
    
    //remove all previous cards if present
    this->cardsToBeShuffleArr->removeAllObjects();
    
    //randomize the indexes
    for (int i = 0; i < uniqueCardsCount; i++) {
        
        int randomIndex = store_randomArray[i];
        
        CCDictionary *aLevelDictCards = (CCDictionary*)aLevelGameCards->objectAtIndex(randomIndex);
        
        //adding items twice into the Array
        this->cardsToBeShuffleArr->addObject(aLevelDictCards);
        this->cardsToBeShuffleArr->addObject(aLevelDictCards);
    }
    
    //call to shuffleCards method
    CCArray *shuffledCardsArr = this->shuffleArray(cardsToBeShuffleArr);
    
    CCObject *aCardObj = NULL;
    CCARRAY_FOREACH(shuffledCardsArr, aCardObj)
    {
        //Skip the position if we get Skip Index
        if(cardIndex == skipIndex)
        {
            xPos = xPos + diffX + 100;
            cardIndex++;
        }
        
        CCDictionary *aCardDict = (CCDictionary *)aCardObj;
        
        //Add top Card to Hide Match Card
        BBMGSprite * atopCard = BBMGSprite::createWithSpriteFrameName(aCardLevelDict->valueForKey("topCard")->getCString());
        
        this->gameBackground->addChild(atopCard,10);
        atopCard->setPosition(ccp(xPos,yPos));
        this->cardsArr->addObject(atopCard);
        
        atopCard->matchID = aCardDict->valueForKey("matchID")->intValue();
        atopCard->bottomCardTag = aCardDict->valueForKey("bottomCardTag")->intValue();
        atopCard->bottomImageName =  aCardDict->valueForKey("imageName")->getCString();
        atopCard->soundName = aCardDict->valueForKey("soundName")->getCString();
        atopCard->matchSoundName = aCardDict->valueForKey("matchSound")->getCString();
        atopCard->setScale(scaleCard);
        atopCard->isFlipped = false;
        
        //Increase X
        xPos = xPos + diffX + 100;
        
        //Go to Next Row
        if (cardIndex % splitIndex == 0)
        {
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                xPos = aCardLevelDict->valueForKey("cardStartingPosXIpad")->intValue();
            }
            else
            {
                xPos = aCardLevelDict->valueForKey("cardStartingPosXIphone")->intValue();
            }
            yPos = yPos - diffY - 60;
        }
        cardIndex++;
    }
    
     this->addStars();
    
}

void BBMatchGamePlay::reSet(CCBool *sw)
{
    CCLog("Valor sw = %s",(sw->getValue())?"true":"false");
    
    CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
    
    //play Restart Sound
    SimpleAudioEngine::sharedEngine()->playEffect("restart_match.mp3");
}


#pragma mark - Game UI
void BBMatchGamePlay::initializeGameUI() {
    
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
    CCSprite *bg=CCSprite::create("BBSharedResources/BackGrounds/BG.jpg");
    bg->setPosition(CCPointMake(winsize.width/2, winsize.height/2));
    this->addChild(bg);
    
    CCSprite *twoByTwo = CCSprite::createWithSpriteFrameName("2x2_menu.png");
    
    CCMenuItemSprite *twoByTwoMenu = CCMenuItemSprite::create(twoByTwo, twoByTwo, this, menu_selector(BBMatchGamePlay::gotoLevel));
    twoByTwoMenu->setTag(1);
    twoByTwoMenu->setScale(0.98);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        twoByTwoMenu->setPosition(ccp(winsize.width/2 + 400, winsize.height/2 + 200));
    }
    else
    {
        twoByTwoMenu->setPosition(ccp(424, 270));
    }
    
    CCSprite *twoByThree = CCSprite::createWithSpriteFrameName("2x3_menu.png");
    
    CCMenuItemSprite *twoByThreeMenu = CCMenuItemSprite::create(twoByThree, twoByThree, this, menu_selector(BBMatchGamePlay::gotoLevel));
    twoByThreeMenu->setTag(2);
    twoByThreeMenu->setScale(0.98);
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        twoByThreeMenu->setPosition(ccp(winsize.width/2 + 400, winsize.height/2 + 70));
    }
    else
    {
        twoByThreeMenu->setPosition(ccp(424,200));
    }
    
    CCSprite *threeByThree = CCSprite::createWithSpriteFrameName("3x3_menu.png");
    
   
        if (isLoked)
        {
            CCSprite *lockSprite = CCSprite::createWithSpriteFrameName("lock1.png");
            lockSprite->setPosition(ccp(threeByThree->getContentSize().width/2, threeByThree->getContentSize().height/2));
            lockSprite->setScale(0.5);
            threeByThree->addChild(lockSprite);
        }

    
    
    CCMenuItemSprite *threeByThreeMenu = CCMenuItemSprite::create(threeByThree, threeByThree, this, menu_selector(BBMatchGamePlay::gotoLevel));
    threeByThreeMenu->setTag(3);
    threeByThreeMenu->setScale(0.98);
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        threeByThreeMenu->setPosition(ccp(winsize.width/2 + 400, winsize.height/2 - 70));
    }
    else
    {
        threeByThreeMenu->setPosition(ccp(424, 130));
    }
    
    CCSprite *threeByFour = CCSprite::createWithSpriteFrameName("3x4_menu.png");
    
    
        if (isLoked)
        {
            CCSprite *lockSprite = CCSprite::createWithSpriteFrameName("lock1.png");
            lockSprite->setPosition(ccp(threeByFour->getContentSize().width/2, threeByFour->getContentSize().height/2));
            lockSprite->setScale(0.5);
            threeByFour->addChild(lockSprite);
        }
    
    
    CCMenuItemSprite *threeByFourMenu = CCMenuItemSprite::create(threeByFour, threeByFour, this, menu_selector(BBMatchGamePlay::gotoLevel));
    threeByFourMenu->setTag(4);
    threeByFourMenu->setScale(0.98);
    
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        threeByFourMenu->setPosition(ccp(winsize.width/2 + 400, winsize.height/2 - 200));
    }
    else
    {
        threeByFourMenu->setPosition(ccp(424, 60));
        
    }
    
    
    CCMenu *selectMenu = CCMenu::create(twoByTwoMenu,twoByThreeMenu,threeByThreeMenu,threeByFourMenu,NULL);
    selectMenu->setPosition(CCPointZero);
    selectMenu->setScale(0.98);
    this->addChild(selectMenu,2);
    
    //Add restart button
    CCSprite *normalSprite = CCSprite::createWithSpriteFrameName("PlayAgain_restart.png");
    CCSprite *selectedSprite = CCSprite::createWithSpriteFrameName("PlayAgain_restart_off.png");
    
    restartMenuItem = CCMenuItemSprite::create(normalSprite, selectedSprite, this, menu_selector(BBMatchGamePlay::gotoLevel));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        restartMenuItem->setPosition(ccp(winsize.width/2 - 400, winsize.height/2 + 80));
    }
    else
    {
        restartMenuItem->setPosition(ccp(winsize.width/2 - 200, winsize.height/2 + 40));
        
    }
    restartMenuItem->setTag(5);
    
    CCMenu *tempMenu = CCMenu::create(restartMenuItem,NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,2);
    
    
    //add back button
    normalSprite = CCSprite::createWithSpriteFrameName("control.png");
    
    CCMenuItemSprite *backMenuItem = CCMenuItemSprite::create(normalSprite, normalSprite, this, menu_selector(BBMatchGamePlay::gotoLevel));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        backMenuItem->setPosition(CCPointMake(winsize.width/2 - 400, winsize.height/2 + 290));
    }
    else
    {
        backMenuItem->setPosition(CCPointMake(45, 290));
        
    }
    backMenuItem->setTag(999);
    
    CCMenu *gamesButtonMenu = CCMenu::create(backMenuItem,NULL);
    gamesButtonMenu->setPosition(CCPointZero);
    this->addChild(gamesButtonMenu,2);
    
    award=CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,5);
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        award->setPosition(ccp(512,384));
    }
    else
    {
        award->setPosition(ccp(240,160));
    }
    award->setVisible(false);
    
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        CCSprite *dogBase=CCSprite::createWithSpriteFrameName("dog_base.png");
        dogBase->setPosition(CCPointMake(80,48));   //117.9 48
        this->addChild(dogBase);
    }
}

#pragma mark - Game Logic
void BBMatchGamePlay::openCard(BBMGSprite *fgSpr) {
    
    this->selectedCardCount++;
    
    if(this->selectedCardCount == 1) {
        
        this->firstSelectedCard = fgSpr;
        //call to flip cards method
        this->flipCards(this->firstSelectedCard);
        
        //sound-Effect for particular cards
        SimpleAudioEngine::sharedEngine()->playEffect(this->firstSelectedCard->soundName);
    }
    else if(this->selectedCardCount == 2) {
        
        this->secondSelectedCard = fgSpr;
        
        //call to flip cards method
        this->flipCards(this->secondSelectedCard);
        
        //sound-Effect for particular cards
        SimpleAudioEngine::sharedEngine()->playEffect(this->secondSelectedCard->soundName);
    }
    
    //We touched 2 Cards //So check the cards
    if(this->selectedCardCount == 2) {
        
        this->canTouch = false;
        
        CCCallFuncN* checkCardsObj = CCCallFuncN::create(this, callfuncN_selector(BBMatchGamePlay::checkCards));
        this->runAction(checkCardsObj);
    }
}


void BBMatchGamePlay::checkCards() {
    
    CCLOG("Path: %s",this->firstSelectedCard->matchSoundName);
    
    if(this->firstSelectedCard->matchID == this->secondSelectedCard->matchID)
    {
        this->wrongMatches = 0;
        //matchCards ShineAnimation
        this->shineAnimation(this->firstSelectedCard);
        this->shineAnimation(this->secondSelectedCard);
        
        //play ShineAnimation Sound
        SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/shine_match.mp3");
        
        //play Sound for the match Cards
        SimpleAudioEngine::sharedEngine()->playEffect(this->firstSelectedCard->matchSoundName);
        
        //incrementing matched cards count
        correctMatches++;
        
        
        //remove top Card images from the layer
        this->removeChild(firstSelectedCard,true);
        this->removeChild(secondSelectedCard,true);
        
        //remove top Card images from the array
        this->cardsArr->removeObject(firstSelectedCard,true);
        this->cardsArr->removeObject(secondSelectedCard,true);
        
        //once the cards are matched & top card is removed then only you can touch other cards
        this->canTouch = true;
        
        //check if gameOver
        if(this->cardsArr->count() <= 0) {
            
            
            this->gameOver();
            
            
        }
        
    }
    
    else
    { //if card not matches then hide the match Card
        
        CCCallFuncN* changeMatchCardImageFunc1 = CCCallFuncN::create(this,callfuncN_selector(BBMatchGamePlay::flipCards));//call to flipCards method for firstSelectedCard
        CCFiniteTimeAction *flipSequence1 = CCSequence::create(CCDelayTime::create(0.8),changeMatchCardImageFunc1,NULL);
        
        this->firstSelectedCard->runAction(flipSequence1);
        
        CCCallFuncN* changeMatchCardImageFunc2 = CCCallFuncN::create(this,callfuncN_selector(BBMatchGamePlay::flipCards));//call to flipCards method for secondSelectedCard
        CCFiniteTimeAction *flipSequence2 = CCSequence::create(CCDelayTime::create(0.8),changeMatchCardImageFunc2,NULL);
        
        this->secondSelectedCard->runAction(flipSequence2);
        
        //incrementing unmatched cards count
        this->wrongMatches++;
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.65),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::tryAgain)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        
    }
    
    //reset the count
    this->selectedCardCount = 0;
    //this->canTouch = true;
}


void BBMatchGamePlay::flipCards(BBMGSprite *topCard) {
    
    if (topCard->isFlipped) {
        
        topCard->isFlipped = false;
    }
    
    else {
        
        topCard->isFlipped = true;
    }
    float d = 0.25f;
    
    CCOrbitCamera *firstHalfFlip = CCOrbitCamera::create(d/2, 1, 0, 0, 90, 0, 0);
    CCOrbitCamera *secondHalfFlip = CCOrbitCamera::create(d/2, 1, 0, 270, 90, 0, 0);
    
    CCCallFuncN* changeMatchCardImageFunc = CCCallFuncN::create(this,callfuncN_selector(BBMatchGamePlay::changeImageOfTopCard));
    
    CCFiniteTimeAction *flipSequence = CCSequence::create(firstHalfFlip, changeMatchCardImageFunc,secondHalfFlip, NULL);
    topCard->runAction(flipSequence);
    
    //once flip is over you can open the other cards
    this->canTouch = true;
}


void BBMatchGamePlay::changeImageOfTopCard(BBMGSprite *matchCard) {
    
    if(matchCard->isFlipped)
    {
        //Change the image of Top Card to bottom Card
        CCSpriteFrame *newImage = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(matchCard->bottomImageName);
        matchCard->setDisplayFrame(newImage);
        matchCard->setScale(aCardLevelDict->valueForKey("scaleBottomCard")->floatValue());
    }
    else
    {
        //Change the image of bottom Card to Top Card
        CCSpriteFrame *newImage = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(aCardLevelDict->valueForKey("topCard")->getCString());
        matchCard->setDisplayFrame(newImage);
        matchCard->setScale(aCardLevelDict->valueForKey("scaleCard")->floatValue());
    }
}

#pragma mark - Animation
void BBMatchGamePlay::shineAnimation(BBMGSprite *selectedSpr) {
    
    shine = CCParticleSystemQuad::create("BBParticle/sprinkle.plist");
    this->gameBackground->addChild(shine,11);
    shine->setPosition(ccp(selectedSpr->getPositionX(), selectedSpr->getPositionY()));
    
    CCSequence *Seq=CCSequence::create(CCDelayTime::create(0.2),CCCallFuncN::create(this, callfuncN_selector(BBMatchGamePlay::stopShineAnimationEffect)),NULL);
    this->runAction(Seq);
}


void BBMatchGamePlay::stopShineAnimationEffect()
{
    shine->stopSystem();
}

void BBMatchGamePlay::addBlinkActionForRefreshButton(float dt) {
    
    if(this->restartMenuItem->isSelected()) {
        
        this->restartMenuItem->unselected();
    }
    else {
        this->restartMenuItem->selected();
    }
}


#pragma mark - Game Over
void BBMatchGamePlay::gameOver() {
    
    //gameWon label
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        pLabel = CCLabelTTF::create("You Won", "Noteworthy-Bold",65);
        pLabel->setPosition(ccp(320,638));
    }
    else
    {
        pLabel = CCLabelTTF::create("You Won", "Noteworthy-Bold",40);
        pLabel->setPosition(ccp(140,160));
    }
    pLabel->setColor(ccc3(255, 255, 255));
    
    this->gameBackground->addChild(pLabel,2);
    
    //dogClapping Sound
//    SimpleAudioEngine::sharedEngine()->playEffect("clapping.mp3");
    
    //matchGameWin Sound
//    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/matchgame_win.mp3");
    
    //unschedule blinkAction for Refresh Button
    this->schedule(schedule_selector(BBMatchGamePlay::addBlinkActionForRefreshButton), 0.5);
    
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.5),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::addNewStar)),NULL);
    callBack->setTag(actionTag);
    this->runAction(callBack);
    
    
    
    if(BBMatchDataManager::sharedManager()->starCount == 10)
    {
        CCSequence *Seq=CCSequence::create(CCDelayTime::create(3.0),CCCallFuncN::create(this, callfuncN_selector(BBMatchGamePlay::playGetTrophy)),NULL);
        this->runAction(Seq);
//     this->playGetTrophy();
    }
    else
    {
        CCSequence *Seq=CCSequence::create(CCDelayTime::create(3.0),CCCallFuncN::create(this, callfuncN_selector(BBMatchGamePlay::playAgain)),NULL);
        this->runAction(Seq);
    }
    

}


#pragma mark - Touches End
void BBMatchGamePlay::ccTouchesEnded(CCSet* touches, CCEvent* event) {
    
    //If disable touch return
    if (this->canTouch == false){
        return;
    }
    
    CCSetIterator it;
    CCTouch* touch;
    
    for(it = touches->begin(); it != touches->end(); it++)
    {
        touch = (CCTouch*)(*it);
        
        if(!touch)
            break;
        
        CCPoint location = touch->getLocationInView();
        location = CCDirector::sharedDirector()->convertToGL(location);
        
        CCObject *fgCards = NULL;
        
        CCARRAY_FOREACH(this->cardsArr, fgCards) {
            
            BBMGSprite *fgSpr = (BBMGSprite *)fgCards;
            
            if (fgSpr->isFlipped) {
                continue;
            }
            
            if(fgSpr->boundingBox().containsPoint(this->gameBackground->convertTouchToNodeSpace(touch)))
            {
                this->openCard(fgSpr);
            }
        }
        
        CCRect bBox = bazziTalking->animatedDog->boundingBox();
        
        if(bBox.containsPoint(this->convertTouchToNodeSpace(touch)))
        {
            this->sayHint();
        }
        
        
    }
}


#pragma mark - level Selection
void BBMatchGamePlay::gotoLevel(CCMenuItemImage *sender) {
    
    if (this->canTouch == false) {
        return;
    }
    
    int tag = sender->getTag();
    
//    if(tag != 5 && tag != 999){
//        
//        CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
//    }
    
    switch (tag)
    {
            award->setVisible(false);
        case 1:
        {
            this->initializeGame("2x2"); // Menu to select 2x2 level
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/4tiles.mp3");
            bazziTalking->startDogTalking();
            isDogTalking = true;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            this->runAction(callBack);
            CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
        }
            break;
            
        case 2:
        {
            this->initializeGame("2x3"); // Menu to select 2x3 level
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/6tiles.mp3");
            bazziTalking->startDogTalking();
            isDogTalking = true;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            this->runAction(callBack);
            CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
        }
            break;
            
        case 3:
        {
            if(!isLoked)
            {
            this->initializeGame("3x3"); // Menu to select 3x3 level
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/8tiles.mp3");
            bazziTalking->startDogTalking();
            isDogTalking = true;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            this->runAction(callBack);
                CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
            }
            else
            {
                WrapperHelper::postByNotificationWithGameIndex(2);
            }
        }
            break;
            
        case 4:
        {
            if(!isLoked)
        {
            this->initializeGame("3x4"); // Menu to select 3x4 level
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/MiscSounds/12tiles.mp3");
            bazziTalking->startDogTalking();
            isDogTalking = true;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            this->runAction(callBack);
            CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
        }
            else
            {
                WrapperHelper::postByNotificationWithGameIndex(2);
            }

        }
            break;
            
        case 5: //Restart Scene
            CCDirector::sharedDirector()->replaceScene(BBMatchGamePlay::scene());
            
            //play Restart Sound
            SimpleAudioEngine::sharedEngine()->playEffect("restart_match.mp3");
            break;
            
        case 999:
            
        {
            if(isDogTalking)
            {
                CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
                this->stopActionByTag(actionTag);
            }
            
            bazziTalking->startDogTalking();
            this->playGoodBye();
//            BBSharedSoundManager::sharedManager()->playGameButtonSound();
            
//            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(3.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::gotoGameHome)),NULL);
//            callBack->setTag(actionTag);
//            this->runAction(callBack);

        }
            
            break;
            
        default: break;
    }
}


void BBMatchGamePlay::loadLevel(int tag) {
    
    CCUserDefault::sharedUserDefault()->setIntegerForKey("lastLevelPlayed", tag);
    
    if (tag == 1 || tag == 0) {
        
        this->initializeGame("2x2");
    }
    else if (tag == 2) {
        
        this->initializeGame("2x3");
    }
    else if (tag == 3) {
        
        this->initializeGame("3x3");
    }
    else if (tag == 4) {
        
        this->initializeGame("3x4");
    }
}

void BBMatchGamePlay::gotoGameHome()
{
    bazziTalking->stopDogTalking();
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopBackgroundMusic();
    BBMatchDataManager::sharedManager()->isNewGame = true;
    BBMatchDataManager::sharedManager()->starCount = 0;
    //GameButton
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}


#pragma mark - Remove Card
void BBMatchGamePlay::removeCards() {
    
    //Remove all the cards from the gameBackground & Array
    this->gameBackground->removeAllChildrenWithCleanup(true);
    this->cardsArr->removeAllObjects();
    
    //unSchedule the blinking of refresh button
    this->unschedule(schedule_selector(BBMatchGamePlay::addBlinkActionForRefreshButton));
    
    //Reset the selectedCards count
    this->selectedCardCount = 0;
    this->correctMatches = 0;
    this->wrongMatches = 0;
    
    //set the Card touch
    this->canTouch = true;
    this->removeChild(pLabel, true);
}


#pragma mark - Utility
CCArray* BBMatchGamePlay::shuffleArray(CCArray *cardsToShuffle) {
    
    for (int x = 0; x < cardsToShuffle->count(); x++) {
        
        int randInt = (arc4random() % (cardsToShuffle->count() - x)) + x;
        cardsToShuffle->exchangeObjectAtIndex(x, randInt);
    }
    return cardsToShuffle;
    
    //Reset the Cards count
    this->selectedCardCount = 0;
}

int* BBMatchGamePlay::randomizeInt(int GameCards[15]) {
    
    //variables used for swapping
    int swap;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i <= 14; i++){
        
        rand_no = arc4random() % 15;
        
        swap = GameCards[rand_no];
        GameCards[rand_no]= GameCards[i];
        GameCards[i] = swap;
    }
    return GameCards;
}


#pragma mark - Dealloc
void BBMatchGamePlay::onExit() {
    
    CCLayer::onExit();
    
    //Remove spritesheets of matchGame
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("MatchGame/BBMGImages.plist");
    
    WrapperHelper::endTimedEventWithName("memoryMatch");
}


BBMatchGamePlay::~BBMatchGamePlay() {
    
    CCNotificationCenter::sharedNotificationCenter()->removeObserver(this, "HideBuyFullVersionView");
    
    //Delete Dog from memory
    delete bazziTalking;
    bazziTalking = NULL;

    
    CC_SAFE_RELEASE_NULL(this->cardsArr);
    CC_SAFE_RELEASE_NULL(this->cardsToBeShuffleArr);
}

#pragma mark - Dog Animation Methods

void BBMatchGamePlay::callStopDogAnimation()
{
    bazziTalking->stopDogTalking();
    isDogTalking = false;
    this->setTouchEnabled(true);
    this->scheduleIdleTickAfterSounds();
}

void BBMatchGamePlay::scheduleIdleTickAfterSounds(){
    
    this->schedule(schedule_selector(BBMatchGamePlay::idleCheckTick), 1);
}

void BBMatchGamePlay::idleCheckTick()
{
    if(this->isDogTalking==false)
    {
        this->idleTime ++;
        
        if(this->idleTime%3==0 && bazziTalking->isRunningIdleAnimation==false)
        {
            idleTime = 0;
            bazziTalking->runBacciIdleAnimation();
        }
    }
}


//play the intro animation of the dog Talking.
void BBMatchGamePlay::playIntro()
{
    switch (introSeq)
    {
        case 1:
        {
            this->setTouchEnabled(false);
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobaccizmatchgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playIntro)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
        case 2:
        {
            bazziTalking->stopDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playIntro)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
        }
            break;
            
        case 3:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/Letsplay.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playIntro)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
        }
            break;
            
        case 4:
        {
            bazziTalking->stopDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playIntro)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
        }   //
            break;
            
            case 5:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/toplaymatchgame.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(3.5),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
        }
            break;
    }
    
    introSeq++;
}

//play the animation of the dog when its touched.
void BBMatchGamePlay::sayHint()
{
    int i = arc4random() % 3;
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }
    
    
    if (i == 0)
    {
        bazziTalking->startDogTalking();
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/trytoremember_match.mp3");
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(5.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        isDogTalking = true;
    }
    
    if(i == 1)
    {
        bazziTalking->startDogTalking();
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tryturningnewtile.mp3");
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(3.5),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        isDogTalking = true;
    }
    
    if(i == 2)
    {
        bazziTalking->startDogTalking();
        dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/alwaysstartwithnewtile_match.mp3");
        CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
        callBack->setTag(actionTag);
        this->runAction(callBack);
        isDogTalking = true;
    }
    
}

//play the tryAgain dog animation
void BBMatchGamePlay::tryAgain()
{
    if(wrongMatches == 2 || (wrongMatches%3) == 0)
    {
        int i = arc4random() % 3;
        if(isDogTalking)
        {
            CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
            bazziTalking->stopDogTalking();
            this->stopActionByTag(actionTag);
        }
        
        
        switch (i) {
            case 0:
            {
                bazziTalking->startDogTalking();
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/try again.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
                callBack->setTag(actionTag);
                this->runAction(callBack);
                isDogTalking = true;
            }
                break;
                
            case 1:
            {
                bazziTalking->startDogTalking();
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tryagainyoucandoit.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
                callBack->setTag(actionTag);
                this->runAction(callBack);
                isDogTalking = true;
            }
                break;
                
            case 2:
            {
                bazziTalking->startDogTalking();
                dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/youcandoit.mp3");
                CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
                callBack->setTag(actionTag);
                this->runAction(callBack);
                isDogTalking = true;
            }
                break;
                
        }
        
    }
}

void BBMatchGamePlay::playAgain()
{
    int i = arc4random() % 1;
   
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }
    
    switch (i)
    {
        case 0:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtoplayagain.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
        break;
            
        case 1:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtorestart.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
    }
    
}

void BBMatchGamePlay::playGetTrophy()
{
    
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }
    
    
    award->setVisible(true);
    CCScaleTo *scaleTo = CCScaleTo::create(.5, 1.2);
    CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
    award->runAction(move_ease_in);
    
    this->setTouchEnabled(true);
    
    BBSharedSoundManager::sharedManager()->playOnGettingTrophy();
    bazziTalking->startDogTalking();
//    dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taparrowtoplayagain.mp3");
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.3),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
    callBack->setTag(actionTag);
    this->runAction(callBack);
    isDogTalking = true;
    
    
    CCSequence *Seq=CCSequence::create(CCDelayTime::create(3.0),CCCallFuncN::create(this, callfuncN_selector(BBMatchGamePlay::playAgain)),NULL);
    this->runAction(Seq);
    BBMatchDataManager::sharedManager()->starCount = 0;

}

void BBMatchGamePlay::playGoodBye()
{
    int i = arc4random() % 4;
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }
    
    switch (i)
    {
        case 0:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thankyouforcoming.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.0),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::gotoGameHome)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
        case 1:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/comebacksoon.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.15),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::gotoGameHome)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;

            
        case 2:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/lets_play_again_soon.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.3),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::gotoGameHome)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
            
        case 3:
        {
            this->introSeq = 1;
            this->playGoodBye2();
        }
            break;

    
    }
   
}

void BBMatchGamePlay::playGoodBye2()
{
    if(isDogTalking)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
        this->stopActionByTag(actionTag);
    }

    switch (this->introSeq)
    {
        case 1:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thankyouforplaying.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.25),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playGoodBye2)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
        case 2:
        {

            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.5),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::playGoodBye2)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;
            
        case 3:
        {
            bazziTalking->startDogTalking();
            dogTalking = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/comebacksoon.mp3");
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1.15),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::gotoGameHome)),NULL);
            callBack->setTag(actionTag);
            this->runAction(callBack);
            isDogTalking = true;
        }
            break;

    }
    
    this->introSeq++;
}

# pragma mark - stars
void BBMatchGamePlay::addStars()
{
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        xPos=300;
        yPos=35;
    }
    else
    {
        xPos=125;
        yPos=10; //25
    }
    
    
    for(int i=0;i<BBMatchDataManager::sharedManager()->starCount;i++)
    {
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        //   starEmptySprite->setAnchorPoint(ccp(.5,.5));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
    for(int i=0;i<10-BBMatchDataManager::sharedManager()->starCount;i++)
    {
        starEmptySprite=CCSprite::createWithSpriteFrameName("star_white.png");
        //       starEmptySprite->setAnchorPoint(ccp(.5,.5));
        this->addChild(starEmptySprite);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            xPos=xPos+50;
        }
        else
        {
            xPos=xPos+25;
        }
    }
    
}

void BBMatchGamePlay::addNewStar()
{
    BBSharedSoundManager::sharedManager()->playOnStarAnimation();

    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.8),CCCallFunc::create(this,callfunc_selector(BBMatchGamePlay::callStopDogAnimation)),NULL);
    this->runAction(callBack);
    
    CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
     {
            starSprite->setPosition(ccp(300+((BBMatchDataManager::sharedManager()->starCount)*50),35));
     }
    else
     {
            starSprite->setPosition(ccp(125+((BBMatchDataManager::sharedManager()->starCount)*25),10/*25*/));
     }
            this->addChild(starSprite,20);

    CCRotateBy *rotate = CCRotateBy::create(.8, 430);

    CCScaleTo *scaleStarTo = CCScaleTo::create(0.2, 3.2);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.1, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    //
    //
    CCFadeOut *fadeout = CCFadeOut::create(0.2);
    CCFadeIn *fadeIN = CCFadeIn::create(0.1);
    //        //              //  if(starSprite)
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
    CCSequence *seq1 = CCSequence::create(fadeout,fadeIN,NULL);
    CCSequence *seq2 = CCSequence::create(fadeout,fadeIN,NULL);
    //
    CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.2),  seq2,NULL);
    starSprite->runAction(seq3);
    BBMatchDataManager::sharedManager()->starCount++;

}


