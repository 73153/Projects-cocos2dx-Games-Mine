//
//  TWGameScene.cpp
//  TapTheWords
//
//  Created by Deepthi on 28/03/13.
//
//

#include "TWGameScene.h"

#include "SimpleAudioEngine.h"
#include "time.h"
#include "stdlib.h"
#include "cocos2d.h"

#include "TWDataManager.h"
#include "TWWords.h"
#include "BBConfig.h"

#include "BBGameSelection.h"

#include "BacciTalking.h"

#include "BBMainDataManager.h"
#include "BBSharedSoundManager.h"
#include "BBAllGamesFunctionSharedManager.h"

USING_NS_CC_EXT;
USING_NS_CC;
using namespace cocos2d;
using namespace CocosDenshion;

#pragma  mark - TWGameScene
CCScene* TWGameScene::scene()
{
    //'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    //'layer' is an autorelease object
    TWGameScene *layer = TWGameScene::create();
    
    //add layer as a child to scene
    scene->addChild(layer);
    
    //return the scene
    return scene;
}

TWGameScene::TWGameScene()
{
    CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(TWGameScene::reSet), "HideBuyFullVersionView", NULL);
    this->isLoked = BBAllGamesFunctionSharedManager::sharedManager()->isLocked(4);
    
    CCSize screenSize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    
    this->tapCount=0;
    this->wrongTapCount=0;
    
    isCorrect=false;
    isGameFinished=false;
    numberArray=CCArray::create();
    numberArray->retain();
    
    animalNameArray=CCArray::create();
    animalNameArray->retain();
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        std::string pszPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("AnimalDetailsIpad.plist");
        gameDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPath.c_str());
    }
    else
    {
        std::string pszPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("AnimalDetailsIphone.plist");
        gameDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPath.c_str());
        
    }
    
    
    char levelName[20]={};
    sprintf(levelName,"level_%d",TWDataManager::sharedManager()->currentLevel);
    levelSelection = (CCDictionary*)gameDict->valueForKey(levelName);
    AnimalPositionArray = (CCArray*)levelSelection->valueForKey("animalNamePosition");
    
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        bazziTalking->initialize(this,CCPoint(85,128));
    }
    else
    {
        //bazziTalking->initialize(this,CCPoint(35,30)); //35,38
        bazziTalking->initialize(this,CCPoint(35,38));
    }
    
    
    
    isDogTalking=false;
    canTap=false;
    this->isReplayButtonPressed=false;
    this->isAddedCongratulationPopUp=false;
    
    if(SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
        SimpleAudioEngine::sharedEngine()->playBackgroundMusic("Sounds/Narration/tap_the_word_music2.mp3",true);
    this->schedule(schedule_selector(TWGameScene::idleCheckTick), 1);
    
    this->freeLevels = gameDict->valueForKey("freeLevels")->intValue();
    CCLog("freeLevels %i", this->freeLevels);
}

void TWGameScene::reSet(cocos2d::CCBool *sw)
{
    CCLog("Valor sw = %s",(sw->getValue())?"true":"false");
    
    if (!sw->getValue())
    {
//        playAgainFuncAfterDelay();
//        TWDataManager::sharedManager()->starCount =0;
//        TWDataManager::sharedManager()->currentLevel = 1;
//        CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
        this->goBackToGameSelectionScene();
    }
    else
    {
        this->isLoked = BBAllGamesFunctionSharedManager::sharedManager()->isLocked(4);
        this->replaceScene();
    }
}

#pragma MARK -  ~TWGameScene
TWGameScene::~TWGameScene()
{
    CCNotificationCenter::sharedNotificationCenter()->removeObserver(this, "HideBuyFullVersionView");
    delete bazziTalking;
    bazziTalking = NULL;
    
    CC_SAFE_RELEASE_NULL(animalNameArray);
    CC_SAFE_RELEASE_NULL(numberArray);
}

#pragma MARK - onEnter,onExit
void TWGameScene::onEnter()
{
    this->setTouchEnabled(true);
    this->wrongTapCount=0;
    CCLayer::onEnter();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("TapTheWord/BBTWImages.plist");
    
    bazziTalking->startDogTalking();
    this->intialiseGameUI();
    this->addStars();
    
    
    if(TWDataManager::sharedManager()->canPlayWelcomeSound)
    {
        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/welcometobacciztaptheword.mp3");
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.4),CCCallFunc ::create(this, callfunc_selector(TWGameScene::playTheSound)),CCCallFunc::create(this, callfunc_selector(TWGameScene::initialDogAdviceFunc)),NULL);
        this->runAction(Seq);
        TWDataManager::sharedManager()->canTapDog=false;
        
        //  CCDelayTime::create(1.8)
        
    }
    else
    {
        this->initialiseSounds();
    }
    
     WrapperHelper::logEventWitnName("tapTheWord", true);
}

void TWGameScene::playTheSound()
{
    //   dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/letsplaytaptheword.mp3");
}

void TWGameScene::onExit()
{
    CCLayer::onExit();
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBAnimalsSpriteSheet/BBAnimals.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("TapTheWord/BBTWImages.plist");
    WrapperHelper::endTimedEventWithName("tapTheWord");
}


void TWGameScene::initialDogAdviceFunc()
{
    this->setTouchEnabled(true);
    TWDataManager::sharedManager()->canPlayWelcomeSound=false;
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    int rand=arc4random()%2;
    if(rand==0)
    {
        
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/illsayaword.mp3");
    }
    else if(rand==1)
    {
        
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapwordiask.mp3");
    }
    else
    {
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapwordthatmatches.mp3");
        
    }
    if(TWDataManager::sharedManager()->canAddAnimals)
    {
        TWDataManager::sharedManager()->canAddAnimals=false;
        this->generateRandomNoArray();
        tapSpr->setVisible(true);
        
    }
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::initialiseSounds)),NULL);
    this->runAction(Seq);
    
    
}

#pragma MARK - generateRandomNoArray
void TWGameScene::generateRandomNoArray()
{
    int no_to_randomize[30];
    for (int i = 0 ; i <= 21; i++)
    {
        no_to_randomize[i] = i;
    }
    
    this-> store_randomArray = this->shuffleArray(no_to_randomize);
    this->addAnimalNames();
    this->chooseAnimal();
}

#pragma mark - placeBackGroundImages
void TWGameScene::intialiseGameUI()
{
    CCSize screensize = CCEGLView::sharedOpenGLView()->getFrameSize();
    
    //Bg
    CCSize winsize = CCDirector::sharedDirector()->getWinSize();
    CCSprite *scenarySpr = CCSprite::create("BBSharedResources/BackGrounds/jungle.jpg");
    scenarySpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(scenarySpr);
    
    char a[20]={};
    sprintf(a, "%d/12",TWDataManager::sharedManager()->pageCount);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        
        pageCount=CCLabelTTF::create(a, "Apple Casual" , 50);
        pageCount->setPosition(ccp(930,60));
    }
    else
    {
        pageCount=CCLabelTTF::create(a, "Apple Casual" , 25);
        pageCount->setPosition(ccp(435,25));
        
    }
    pageCount->setColor(ccc3(0,162,255));
    
    CCRenderTexture *stroke =createStroke(pageCount,2,ccWHITE);
    this->addChild(stroke);
    this->addChild(pageCount);
    
    //dog base
    CCSprite *dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        dogBase->setPosition(CCPointMake(80,48));
    }
    else
    {
        //  dogBase->setPosition(CCPointMake(43,22));
        dogBase->setVisible(false);
        
    }
    this->addChild(dogBase);
    
    CCSprite *NormalSpr = CCSprite::createWithSpriteFrameName("repaly_sound.png");
    CCSprite *SelectedSpr = CCSprite::createWithSpriteFrameName("repaly_sound.png");
    
    replaySoundBtn = CCMenuItemSprite::create(NormalSpr, SelectedSpr, this, menu_selector(TWGameScene::repeatSound));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        replaySoundBtn->setPosition(CCPointMake(952,705));
    }
    else
    {
        replaySoundBtn->setPosition(CCPointMake(446,289));
        
    }
    
    
    tapSpr = CCSprite::createWithSpriteFrameName("TAP-THE-WORD!.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        tapSpr->setPosition(CCPointMake(509,690));
    }
    else
    {
        tapSpr->setPosition(CCPointMake(247,295));
    }
    this->addChild(tapSpr);
    tapSpr->setVisible(false);
    
    CCSprite *controlNormalSpr = CCSprite::createWithSpriteFrameName("control.png");
    CCSprite *controlSelectedSpr = CCSprite::createWithSpriteFrameName("control.png");
    
    
    CCMenuItemSprite *controlMenuItem = CCMenuItemSprite::create(controlNormalSpr, controlSelectedSpr, this, menu_selector(TWGameScene::goBackToGameSelectionScene));
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        controlMenuItem->setPosition(CCPointMake(77,702));
    }
    else
    {
        controlMenuItem->setPosition(CCPointMake(35,285));
        
    }
    
    CCMenu *tempMenu = CCMenu::create(replaySoundBtn,controlMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,1);
    
    //award sprite
    award=CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,20);
    award->setScale(0.7);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        award->setPosition(ccp(500,384));
    }
    else
    {
        award->setPosition(ccp(230,170));
    }
    award->setVisible(false);
    
    //ballon Sprite
    booble=CCSprite::createWithSpriteFrameName("booble.png");
    this->addChild(booble,3);
    booble->setScale(0.5);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        booble->setPosition(ccp(225,210));
    }
    else
    {
        booble->setPosition(ccp(99,96));
    }
    booble->setVisible(false);
}

#pragma mark - shuffleArray
int* TWGameScene ::shuffleArray(int num[30]) {
    
    //variables used for swapping
    int temp;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i <= 21; i++)
    {
        
        rand_no = arc4random() % 21;
        temp = num[rand_no];
        num[rand_no]= num[i];
        num[i] = temp;
    }
    return num;
}

#pragma MARK - sound
void TWGameScene::repeatSound()
{
    if(canTap)
    {
        isReplayButtonPressed=true;
        canTap=false;
        isDogTalking=false;
        this->initialiseSounds();
        TWDataManager::sharedManager()->canTapDog=false;
        this->bazziTalking->startDogTalking();
        
        // CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("",false);
        //                CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this, callfunc_selector(TWGameScene::setDelay)),NULL);
        //                this->runAction(callBack);
        // dogSpr->setEnabled(false);
        //   replaySoundBtn->setEnabled(false);
    }
    
}

void TWGameScene::setDelay()
{
 
    replaySoundBtn->setEnabled(true);
    this->setTouchEnabled(true);
    bazziTalking->startDogTalking();
    selectedAnimalName = (CCDictionary*)selectItems->objectAtIndex(touchSprLabel->getTag()-1);
    this->animalSound();
    //  this->playWrongAnimalSound();
   

}

void TWGameScene::playWrongAnimalSound()
{
    const char *soundNam= (const char *)selectedAnimalName->valueForKey("sound")->getCString();
    char soundName[300]={};
    sprintf(soundName, "%s",soundNam);
    
    dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(soundName,false);
    // dogSpr->setEnabled(true);
    replaySoundBtn->setEnabled(true);
    canTap=true;
    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.7),CCCallFunc::create(this,callfunc_selector(TWGameScene::callStopDogAnimation)),CCDelayTime::create(.5),CCCallFunc::create(this,callfunc_selector(TWGameScene::canTapDog)),NULL);
    this->runAction(callBack);

}

void TWGameScene::initialiseSounds()
{
    // dogSpr->setEnabled(false);
    replaySoundBtn->setEnabled(false);
    //   bazziTalking->startDogTalking();
    if(TWDataManager::sharedManager()->canAddAnimals)
    {
        TWDataManager::sharedManager()->canAddAnimals=false;
        this->generateRandomNoArray();
        tapSpr->setVisible(true);
    }
    
    this->setTouchEnabled(false);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    //  SimpleAudioEngine::sharedEngine()->stopAllEffects();
    dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taptheword1.mp3",false);
    if(!isReplayButtonPressed)
    {
        CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TWGameScene::animalSound)),NULL);
        this->runAction(callBack);
    }
    else
    {
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TWGameScene::selectedAnimalSound)),NULL);
    this->runAction(callBack);
    }
}

void TWGameScene::selectedAnimalSound()
{
    selectedAnimalName = (CCDictionary*)selectItems->objectAtIndex(selectedSpr->getTag()-1);
    const char *soundNam= (const char *)selectedAnimalName->valueForKey("sound")->getCString();
    char soundName[300]={};
    sprintf(soundName, "%s",soundNam);
    
    dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(soundName,false);
    // dogSpr->setEnabled(true);
    replaySoundBtn->setEnabled(true);
    canTap=true;
    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.7),CCCallFunc::create(this,callfunc_selector(TWGameScene::callStopDogAnimation)),CCDelayTime::create(.5),CCCallFunc::create(this,callfunc_selector(TWGameScene::canTapDog)),NULL);
    this->runAction(callBack);

    
}
void TWGameScene::animalSound()
{
    
    const char *soundNam= (const char *)selectedAnimalName->valueForKey("sound")->getCString();
    char soundName[300]={};
    sprintf(soundName, "%s",soundNam);
    
    dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect(soundName,false);
    // dogSpr->setEnabled(true);
    replaySoundBtn->setEnabled(true);
    canTap=true;
    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.7),CCCallFunc::create(this,callfunc_selector(TWGameScene::callStopDogAnimation)),CCDelayTime::create(.5),CCCallFunc::create(this,callfunc_selector(TWGameScene::canTapDog)),NULL);
    this->runAction(callBack);
}

#pragma MARK - addING LABELS
void TWGameScene::addAnimalNames()
{
    selectItems = (CCArray*)gameDict->valueForKey("items");
    int noOfAnimalNames = TWDataManager::sharedManager()->currentLevel*2;
    
    char ballon[30]={};
    sprintf(ballon, "baloon%d.png",noOfAnimalNames);
    CCSprite *balonspr =CCSprite::createWithSpriteFrameName(ballon);
    this->addChild(balonspr,1);
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        
        balonspr->setPosition(ccp(680, 360));
    }
    else
    {
        balonspr->setPosition(ccp(302, 148));
    }
    
    
    for(int i=0; i<noOfAnimalNames; i++)
    {
        int randomIndex = this->store_randomArray[i];
        
        CCDictionary *selectedAnimalName = (CCDictionary*)selectItems->objectAtIndex(randomIndex);
        
        CCString *randNoStr = CCString::createWithFormat("%d",randomIndex);
        numberArray->addObject(randNoStr);
        
        const char *animalName = (const char *)selectedAnimalName->valueForKey("label")->getCString();
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            title = CCLabelTTF::create(animalName,"Apple Casual",40);
        }
        else
        {
            title = CCLabelTTF::create(animalName,"Apple Casual",20);
        }
        title->setColor(ccc3(arc4random()%225,arc4random()%100,arc4random()%200));
        this->addChild(title,2);
        title->setTag(selectedAnimalName->valueForKey("tag")->intValue());
        
        animalNameArray->addObject(title);
    }
    
    int positionIndex=0;
    CCObject *obj = NULL;
    CCARRAY_FOREACH(animalNameArray, obj)
    {
        CCLabelTTF *label =(CCLabelTTF*)obj;
        CCString *animalSpritePos = (CCString *)AnimalPositionArray->objectAtIndex(positionIndex);
        CCPoint AnimalPositions = CCPointFromString(animalSpritePos->getCString());
        label->setPosition(CCPoint(AnimalPositions));
        positionIndex++;
    }
}
#pragma mark - Idle

void TWGameScene::idleCheckTick()
{
    if(this->bazziTalking->isBacciTalking==false)
    {
        this->bazziTalking->idleTime ++;
        
        if(this->bazziTalking->idleTime%kBacciIdleTime==0&&this->bazziTalking->isRunningIdleAnimation==false)
        {
            this->bazziTalking->runBacciIdleAnimation();
        }
    }
}

#pragma  MARK - SELECTION OF ANIMAL
void TWGameScene::chooseAnimal()
{
    count = numberArray->count();
    int randNoFromArray=arc4random()%count;
    CCString *randval =(CCString*)numberArray->objectAtIndex(randNoFromArray);
    int rand =randval->intValue();
    
    
    selectedAnimalName= (CCDictionary*)selectItems->objectAtIndex(rand);
    const char *animalName= (const char *)selectedAnimalName->valueForKey("imageName")->getCString();
    CCLOG("%s",animalName);
    selectedSpr =CCSprite::createWithSpriteFrameName(animalName);
    selectedSpr->setTag(selectedAnimalName->valueForKey("tag")->intValue());
    
    
    //To avoid getting same animal again & again
    while (TWDataManager::sharedManager()->previousAnimalTag==selectedSpr->getTag())
    {
        
        randNoFromArray=arc4random()%count;
        CCString *randval =(CCString*)numberArray->objectAtIndex(randNoFromArray);
        int rand =randval->intValue();
        
        selectedAnimalName= (CCDictionary*)selectItems->objectAtIndex(rand);
        const char *animalName= (const char *)selectedAnimalName->valueForKey("imageName")->getCString();
        
        
        selectedSpr =CCSprite::createWithSpriteFrameName(animalName);
        selectedSpr->setTag(selectedAnimalName->valueForKey("tag")->intValue());
    }
    
    TWDataManager::sharedManager()->previousAnimalTag = selectedSpr->getTag();
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        selectedSpr->setPosition(ccp(310,380));
    }
    else
    {
        selectedSpr->setPosition(ccp(110,147));
        
    }
    selectedSpr->setScale(1.3);
    this->addChild(selectedSpr,1);
    selectedSpr->setTag(selectedAnimalName->valueForKey("tag")->intValue());
}

#pragma mark - Touches
void TWGameScene::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)touches->anyObject();
    CCPoint  touchPoint = touch->getLocationInView();
    touchPoint = CCDirector::sharedDirector()->convertToGL(touchPoint);
    if(bazziTalking->animatedDog->boundingBox().containsPoint(touchPoint))
    {
        if(TWDataManager::sharedManager()->canTapDog)
        {
            TWDataManager::sharedManager()-> dogTapCount++;
            isDogTalking=true;
            TWDataManager::sharedManager()->canTapDog=false;
            SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
            SimpleAudioEngine::sharedEngine()->stopAllEffects();
            bazziTalking->startDogTalking();
            
            if(TWDataManager::sharedManager()->dogTapCount<=2)
            {
                if(!isGameFinished)
                {
                    dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/illsayaword.mp3");
                }
                else
                {
                    dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3");
                }
                    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(TWGameScene::callStopDogAnimation)),CCDelayTime::create(1),CCCallFunc::create(this, callfunc_selector(TWGameScene::canTapDog)),NULL);
                    this->runAction(Seq);
            }
            else if(TWDataManager::sharedManager()->dogTapCount>=1)
            {
                if(isGameFinished&&isAddedCongratulationPopUp)
                {
                    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
                    
                    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
                    int rand =arc4random()%2;
                    if(rand==0)
                    {
                        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapcontroller.mp3");
                    }
                    else if(rand==1)
                    {
                        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/play_again_orgoback.mp3");
                    }
                    else
                    {
                        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/playagainorgoback.mp3");
                    }
                    this->setTouchEnabled(false);
                    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.8), CCCallFunc::create(this, callfunc_selector(TWGameScene::callStopDogAnimation)),CCCallFunc::create(this, callfunc_selector(TWGameScene::canTapDog)),NULL);
                    this->runAction(Seq);
                    
                }
                else
                {
                    int rand =arc4random()%2;
                        bazziTalking->startDogTalking();

                    if(rand==0)
                    {
                        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapwordthatmatches.mp3");
                    }
                    else
                    {
                        dogTalking=CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapwordiask.mp3");
                        
                    }
                }
                    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2), CCCallFunc::create(this, callfunc_selector(TWGameScene::callStopDogAnimation)),CCDelayTime::create(1),CCCallFunc::create(this, callfunc_selector(TWGameScene::canTapDog)),NULL);
                    this->runAction(Seq);

                }
                
            
            
        }
            
        
        
    }
     CCObject *obj = NULL;
    CCARRAY_FOREACH(animalNameArray, obj)
    {
        
        CCLabelTTF *tempLabel = (CCLabelTTF *)obj;
        if(canTap)
        {
            if (tempLabel->boundingBox().containsPoint(touchPoint))
            {
                this-> touchSprLabel=tempLabel;
                if(touchSprLabel->getTag()==selectedSpr->getTag())
                {
                    if(isGameFinished)
                    {
                        return;
                    }
                    
                    
                    this->correctFuncAction();
                }
                else
                {
                    if(!isCorrect)
                    {
                        if(isGameFinished)
                        {
                            return;
                        }
                        CCLOG("%d",touchSprLabel->getTag());

                        this->wrongFuncAction();
                    
                        tapCount++;
                    }
                }
                this->scaleAnimalName(touchSprLabel);
                //    this->playWrongTappedAnimalSound(touchSprLabel);
                
            }
        }
    }
}

void TWGameScene::scaleAnimalName(CCLabelTTF *animName)
{
    if(!isGameFinished)
    {
        CCScaleTo *scaleOne = CCScaleTo::create(1, 1.6);
        CCScaleTo *scaleBack = CCScaleTo::create(1, 1.0);
        
        CCSequence *sequenceScale = CCSequence::createWithTwoActions(scaleOne, scaleBack);
        CCRepeat *actionRepeat = CCRepeat::create(sequenceScale, 1);
        touchSprLabel->runAction(actionRepeat);
        touchSprLabel->runAction((CCActionInterval*)actionRepeat->copy()->autorelease());
    }
    
    
    
}

void TWGameScene::canTapDog()
{
        TWDataManager::sharedManager()->canTapDog=true;
        
}
void TWGameScene::onTappingDog()
{
    if(isDogTalking)
    {
        
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
        
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/taptheword1.mp3",false);
        replaySoundBtn->setEnabled(false);
        CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(TWGameScene::animalSound)),NULL);
        this->runAction(callBack);
        
    }
    
}


#pragma MARK - correctFuncAction,wrongFuncAction
void TWGameScene::correctFuncAction()
{
    if(isDogTalking)
    {
        isDogTalking=false;
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
    }
    
    
    isCorrect=true;
    this->wrongTapCount=0;
    CCSprite *smileySpr =CCSprite::createWithSpriteFrameName("smiley_right.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        smileySpr->setPosition(ccp(touchSprLabel->getPositionX()-smileySpr->getContentSize().width/2-90,touchSprLabel->getPositionY()));
    }
    else
    {
        smileySpr->setPosition(ccp(touchSprLabel->getPositionX()-smileySpr->getContentSize().width/2-45,touchSprLabel->getPositionY()));
    }
    this->addChild(smileySpr,5);
    smileySpr->setScale(0.43);
    CCObject *obj;
    CCARRAY_FOREACH(animalNameArray, obj)
    {
        
        CCLabelTTF    *animalLable = (CCLabelTTF *)obj;
        if(animalLable->getTag()==22||animalLable->getTag()==15)
        {
            smileySpr->setScale(0.43);
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                smileySpr->setPosition(ccp(touchSprLabel->getPositionX()-smileySpr->getContentSize().width/2-90,touchSprLabel->getPositionY()));
            }
            else
            {
                smileySpr->setPosition(ccp(touchSprLabel->getPositionX()-smileySpr->getContentSize().width/2-45,touchSprLabel->getPositionY()));
                
            }
            
        }
    }
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        
        int rand=arc4random()%2;
        float delay;
        if(rand==0)
        {
                delay=1.0;
                BBSharedSoundManager::sharedManager()->playShortSoundOnClickOfCorrecAns();
                if(BBSharedSoundManager::sharedManager()->correctRandomSound==3||BBSharedSoundManager::sharedManager()->correctRandomSound==5)
                {
                        bazziTalking->stopDogTalking();
                }
                else
                {
                        bazziTalking->startDogTalking();
                        
                }
                
        }
        else
        {
                delay=3;
                bazziTalking->stopDogTalking();
                BBSharedSoundManager::sharedManager()->playLongSoundOnClickOfCorrectAns();
                
        }

 
    this->setTouchEnabled(false);
    // dogSpr->setEnabled(false);
    replaySoundBtn->setEnabled(false);
    
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(delay),CCCallFunc::create(this, callfunc_selector(TWGameScene::addNewStar)),NULL);
    smileySpr->runAction(callBack);
}

void TWGameScene::wrongFuncAction()
{
  //  bazziTalking->startDogTalking();
    if(isDogTalking)
    {
        isDogTalking=false;
        SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
        bazziTalking->stopDogTalking();
    }
    
    isCorrect=false;
    this->wrongTapCount++;
    
   
    CCSprite *sadSpr =CCSprite::createWithSpriteFrameName("smiley_sad_wrong.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        sadSpr->setPosition(ccp(touchSprLabel->getPositionX()-sadSpr->getContentSize().width/2-90,touchSprLabel->getPositionY()));
    }
    else
    {
        sadSpr->setPosition(ccp(touchSprLabel->getPositionX()-sadSpr->getContentSize().width/2-45,touchSprLabel->getPositionY()));
        
    }
    sadSpr->setScale(0.43);
    
    CCObject *obj;
    CCARRAY_FOREACH(animalNameArray, obj)
    {
        CCLabelTTF    *animalLable = (CCLabelTTF *)obj;
        if(animalLable->getTag()==22||animalLable->getTag()==15)
        {
            sadSpr->setScale(0.43);
            if(BBMainDataManager::sharedManager()->target==kTargetIpad)
            {
                sadSpr->setPosition(ccp(touchSprLabel->getPositionX()-sadSpr->getContentSize().width/2-90,touchSprLabel->getPositionY()));
            }
            else
            {
                sadSpr->setPosition(ccp(touchSprLabel->getPositionX()-sadSpr->getContentSize().width/2-45,touchSprLabel->getPositionY()));
            }
            
        }
    }
    
    this->addChild(sadSpr,5);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    BBSharedSoundManager::sharedManager()->playOnClickOfWrongAnswer();
    //  CCLOG("%d",BBSharedSoundManager::sharedManager()->failedRandomSound);
        if(BBSharedSoundManager::sharedManager()->failedRandomSound==2)
        {
                bazziTalking->startDogTalking();
        }
    this->setTouchEnabled(false);
    CCFiniteTimeAction *callBack = CCSequence::create(CCDelayTime::create(.7),CCCallFunc::create(this, callfunc_selector(TWGameScene::setDelay)),NULL);
    this->runAction(callBack);
    
    if(   TWDataManager::sharedManager()-> canPlayAdviceSound)
    {
        if(wrongTapCount==2)
        {
            TWDataManager::sharedManager()-> canPlayAdviceSound=false;
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(1),CCCallFunc::create(this,callfunc_selector(TWGameScene::twoTimeWrongMatchedSound)),CCDelayTime::create(2),NULL);
            this->runAction(callBack);
            
            
        }
    }
}

void TWGameScene::twoTimeWrongMatchedSound()
{
    
    int rand=arc4random()%1;
    if(rand==0)
    {
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/whatstherightword_word.mp3");
    }
    else
    {
        dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/tapwordiask.mp3");
    }
    bazziTalking->startDogTalking();
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(2.3),CCCallFunc::create(this,callfunc_selector(TWGameScene::callStopDogAnimation)),NULL);
    this->runAction(callBack);
    
}
void TWGameScene::calStopDogAnimationAfterStarAnimation()
{
    bazziTalking->stopDogTalking();
    TWDataManager::sharedManager()->canTapDog=true;
}

void TWGameScene::callStopDogAnimation()
{
    bazziTalking->stopDogTalking();
    this->setTouchEnabled(true);
    isReplayButtonPressed=false;
    
}


#pragma mark - removeFunc
void TWGameScene::remove(CCObject *sender )
{
    CCSprite *spr =(CCSprite*)sender;
    this->removeChild(spr);
    this->setTouchEnabled(true);
}


#pragma mark - ReplaceScene
void TWGameScene::goBackToGameSelectionScene()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    TWDataManager::sharedManager()->pageCount=1;
    booble->setVisible(false);
    award->setVisible(false);
    TWDataManager::sharedManager()->starCount=0;
    TWDataManager::sharedManager()->currentLevel=1;
    TWDataManager::sharedManager()->canPlayWelcomeSound=true;
    TWDataManager::sharedManager()->canAddAnimals=true;
    TWDataManager::sharedManager()-> canPlayAdviceSound=true;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playGameButtonSound();
    
    //  dogTalking= CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/thankyouforcoming.mp3",false);
    
    CCDirector::sharedDirector()->replaceScene(BBGameSelection::scene());
}
void TWGameScene::calladdingTrophyFunc()
{
    isGameFinished=true;
    award->setVisible(true);
    
    
    
    CCScaleTo *scaleTo = CCScaleTo::create(.5, 1.5);
    CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
    award->runAction(move_ease_in);
    this->setTouchEnabled(true);
    booble->setVisible(true);
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(4), CCCallFunc::create(this, callfunc_selector(TWGameScene::afterFinishingLevelFunc)),NULL);
    this->runAction(Seq);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playOnGettingTrophy();
    
    bazziTalking->startDogTalking();
    CCSequence *SeqOne = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::callStopDogAnimation)),NULL);
    this->runAction(SeqOne);
    
    
}
void TWGameScene::replaceScene()
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    TWDataManager::sharedManager()->pageCount++;
   
    if(TWDataManager::sharedManager()->pageCount <= this->freeLevels)
    {
        if( TWDataManager::sharedManager()->pageCount>=5&&TWDataManager::sharedManager()->pageCount<=8)
        {
            TWDataManager::sharedManager()->currentLevel=2;
            TWDataManager::sharedManager()->canAddAnimals=true;
            CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
            
        }
        else if( TWDataManager::sharedManager()->pageCount>=9&&TWDataManager::sharedManager()->pageCount<=12)
        {
            TWDataManager::sharedManager()->currentLevel=3;
            TWDataManager::sharedManager()->canAddAnimals=true;
            CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
            
        }
        
        else if(TWDataManager::sharedManager()->pageCount>=13)
        {
            this->addCongratulationBnner();
            bazziTalking->startDogTalking();
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::calladdingTrophyFunc)),NULL);
            this->runAction(Seq);
        }
        else
        {
            TWDataManager::sharedManager()->canAddAnimals=true;
            CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
            booble->setVisible(false);
            award->setVisible(false);
        }
        

    }
    else
    {
        if (this->isLoked)
        {
            WrapperHelper::postByNotificationWithGameIndex(4);
        }
        else
        {
            if( TWDataManager::sharedManager()->pageCount>=5&&TWDataManager::sharedManager()->pageCount<=8)
            {
                TWDataManager::sharedManager()->currentLevel=2;
                TWDataManager::sharedManager()->canAddAnimals=true;
                CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
                
            }
            else if( TWDataManager::sharedManager()->pageCount>=9&&TWDataManager::sharedManager()->pageCount<=12)
            {
                TWDataManager::sharedManager()->currentLevel=3;
                TWDataManager::sharedManager()->canAddAnimals=true;
                CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
                
            }
            
            else if(TWDataManager::sharedManager()->pageCount>=13)
            {
                this->addCongratulationBnner();
                bazziTalking->startDogTalking();
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::calladdingTrophyFunc)),NULL);
                this->runAction(Seq);
            }
            else
            {
                TWDataManager::sharedManager()->canAddAnimals=true;
                CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
                booble->setVisible(false);
                award->setVisible(false);
            }
        }
    }
    
    
}
void TWGameScene::addCongratulationBnner()
{
    tapSpr->setVisible(false);
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(509,670));
    }
    else
    {
        BBAllGamesFunctionSharedManager:: sharedManager()->addCongratulationBanner(true,CCPoint(247,275));
    }
    
}

void TWGameScene::playAgainFunc()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    BBSharedSoundManager::sharedManager()->playPlayAgainButtonSound();
    bazziTalking->startDogTalking();
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.0), CCCallFunc::create(this, callfunc_selector(TWGameScene::playAgainFuncAfterDelay)),NULL);
    this->runAction(Seq);
    
}

void TWGameScene::playAgainFuncAfterDelay()
{
    bazziTalking->stopDogTalking();
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    TWDataManager::sharedManager()->pageCount=1;
    TWDataManager::sharedManager()->starCount=0;
    TWDataManager::sharedManager()->currentLevel=1;
    TWDataManager::sharedManager()->canPlayWelcomeSound=false;
    TWDataManager::sharedManager()->canAddAnimals=true;
    TWDataManager::sharedManager()-> canPlayAdviceSound=true;
    CCDirector::sharedDirector()->replaceScene(TWGameScene::scene());
}

void TWGameScene::goBackFunc()
{
    this->goBackToGameSelectionScene();
}

void TWGameScene::afterFinishingLevelFunc()
{
    
    this->isAddedCongratulationPopUp=true;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
    SimpleAudioEngine::sharedEngine()->stopEffect(dogTalking);
    bazziTalking->startDogTalking();
    BBSharedSoundManager::sharedManager()->playGameCompletePopUpSound();
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.4), CCCallFunc::create(this, callfunc_selector(TWGameScene::callStopDogAnimation)),NULL);
    this->runAction(Seq);
    
    
    TWDataManager::sharedManager()->canAddAnimals=true;
    CCSize winsize= CCDirector::sharedDirector()->getWinSize();
    award->setVisible(false);
    CCSprite *congragulationSpr = CCSprite::createWithSpriteFrameName("congrats.png");
    congragulationSpr->setPosition(ccp(winsize.width/2,winsize.height/2));
    this->addChild(congragulationSpr,10);
    // congragulationSpr->setScale(2);
    
    CCSprite *playAgainNormalSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    CCSprite *playAgainSelectedSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    
    CCMenuItemSprite *playAgainMenuItem = CCMenuItemSprite::create(playAgainNormalSpr, playAgainSelectedSpr, this, menu_selector(TWGameScene::playAgainFunc));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        playAgainMenuItem->setPosition(ccp(120,10));
    }
    else
    {
        playAgainMenuItem->setPosition(ccp(60,10));
    }
    
    CCSprite *gobackNormalSpr = CCSprite::createWithSpriteFrameName("goback.png");
    CCSprite *gobackSelectedSpr = CCSprite::createWithSpriteFrameName("goback.png");
    
    CCMenuItemSprite *gobackMenuItem = CCMenuItemSprite::create(gobackNormalSpr, gobackSelectedSpr, this, menu_selector(TWGameScene::goBackFunc));
    if(BBMainDataManager::sharedManager()->target == kTargetIpad)
    {
        gobackMenuItem->setPosition(ccp(320, 10));
    }
    else
    {
        gobackMenuItem->setPosition(ccp(160, 10));
    }
    
    CCScaleBy *scaleTo = CCScaleBy::create(1, 1.5);
    CCActionInterval* move_ease_in = CCEaseBackInOut::create((CCActionInterval*)(scaleTo->copy()->autorelease()));
    congragulationSpr->runAction(move_ease_in);
    
    
    CCMenu *tempMenu = CCMenu::create(playAgainMenuItem,gobackMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    congragulationSpr->addChild(tempMenu,10);
    
}

#pragma mark -addingStars
void TWGameScene::addStars()
{
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        xPos=230;
        yPos=35;  //48
    }
    else
    {
        xPos=100;
        yPos=25; //15
    }
    
    for(int i=0;i<TWDataManager::sharedManager()->starCount;i++){
        
        CCSprite *starEmptySprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starEmptySprite,1);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            xPos=xPos+50; //55
        }
        else
        {
            xPos=xPos+25; //30
        }
    }
    
    for(int i=0; i<12-TWDataManager::sharedManager()->starCount; i++){
        
        CCSprite *starEmptySprite = CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,1);
        starEmptySprite->setPosition(ccp(xPos,yPos));
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            xPos=xPos+50;
        }
        
        else
        {
            xPos=xPos+25;
        }
        
    }
}

void TWGameScene::addNewStar()
{
    bazziTalking->stopDogTalking();
    if(!this->tapCount>=1)
    {
        CCSprite *starSprite=CCSprite::createWithSpriteFrameName("star_yellow.png");
        if(BBMainDataManager::sharedManager()->target == kTargetIpad)
        {
            starSprite->setPosition(ccp(230+((TWDataManager::sharedManager()->starCount)*50),35));
        }
        else
        {
            starSprite->setPosition(ccp(100+((TWDataManager::sharedManager()->starCount)*25),25));
        }
        this->addChild(starSprite,20);
        
        if(TWDataManager::sharedManager()->pageCount<=11)
        {
            SimpleAudioEngine::sharedEngine()->stopEffect(BBSharedSoundManager::sharedManager()->sound);
            BBSharedSoundManager::sharedManager()->playOnStarAnimation();
            
            bazziTalking->startDogTalking();
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(.8),CCCallFunc::create(this,callfunc_selector(TWGameScene::calStopDogAnimationAfterStarAnimation)),NULL);
            this->runAction(callBack);
        }
        
        
        
        CCRotateBy *rotate = CCRotateBy::create(.8, 430);
        
        CCScaleTo *scaleStarTo = CCScaleTo::create(0.3, 3.2);
        CCScaleTo *scaleStarBack = CCScaleTo::create(0.3, 1);
        CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
        
        CCFadeOut *fadeout = CCFadeOut::create(0.2);
        CCFadeIn *fadeIN = CCFadeIn::create(0.1);
        
        CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq,NULL);
        CCSequence *seq1 = CCSequence::create(fadeout,fadeIN,NULL);
        CCSequence *seq2 = CCSequence::create(fadeout,fadeIN,NULL);
        
        CCSequence *seq3 = CCSequence::create(spawnStarSpr,seq1, CCDelayTime::create(.35),  seq2,NULL);
        starSprite->runAction(seq3);
        
        TWDataManager::sharedManager()->starCount++;
        
        if(TWDataManager::sharedManager()->pageCount==12)
        {
            this->addCongratulationBnner();
            bazziTalking->startDogTalking();
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::calladdingTrophyFunc)),NULL);
            this->runAction(Seq);
            
        }
        
        else
        {
            CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(TWGameScene::replaceScene)),NULL);
            this->runAction(Seq);
        }
        
    }
    else
    {
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(0.3), CCCallFunc::create(this, callfunc_selector(TWGameScene::replaceScene)),NULL);
        this->runAction(Seq);
    }
    
}

#pragma mark - creatING stroke
CCRenderTexture*  TWGameScene:: createStroke(CCLabelTTF* label, int size, ccColor3B color)
{
    
    CCRenderTexture* rt = CCRenderTexture::create(
                                                  label->getTexture()->getContentSize().width + size * 2,
                                                  label->getTexture()->getContentSize().height+size * 2
                                                  );
    
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    // label->setAnchorPoint(ccp(0,0.5));
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    
    rt->begin();
    
    for (int i=0; i<360; i+=50)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    
    return rt;
}


