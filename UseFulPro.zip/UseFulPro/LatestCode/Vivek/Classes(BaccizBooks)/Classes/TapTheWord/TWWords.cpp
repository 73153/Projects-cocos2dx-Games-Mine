//
//  TWWords.cpp
//  TapTheWords
//
//  Created by Deepthi on 28/03/13.
//
//

#include "TWWords.h"
#include "cocos2d.h"

TWWords::TWWords()
{
        
}
TWWords::~TWWords()
{
        
}
TWWords* TWWords::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
        CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
        
#if COCOS2D_DEBUG > 0
        char msg[256] = {0};
        sprintf(msg, "Invalid spriteFrameName: %s", pszSpriteFrameName);
        CCAssert(pFrame != NULL, msg);
#endif
        
        return createWithSpriteFrame(pFrame);
}
TWWords* TWWords::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
        TWWords
        *pobSprite = new TWWords();
        if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
        {
                pobSprite->autorelease();
                return pobSprite;
        }
        CC_SAFE_DELETE(pobSprite);
        return NULL;
}