//
//  TWWords.h
//  TapTheWords
//
//  Created by Deepthi on 28/03/13.
//
//

#ifndef TapTheWords_TWWords_h
#define TapTheWords_TWWords_h
#include "cocos2d.h"
using namespace cocos2d;

class TWWords: public CCSprite
{
        
public:
        
        TWWords();
        ~ TWWords();
        
        static TWWords* createWithSpriteFrameName(const char *pszSpriteFrameName);
        static TWWords* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
        
        const char *sound;
        const char  *itemName;
        int animalTag;
        
};



#endif
