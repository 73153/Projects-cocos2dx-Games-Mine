//
//  TWDataManager.h
//  TapTheWords
//
//  Created by Deepthi on 29/03/13.
//
//

#ifndef TapTheWords_TWDataManager_h
#define TapTheWords_TWDataManager_h

#include "cocos2d.h"
#include "CCBReader.h"


USING_NS_CC;
USING_NS_CC_EXT;


class TWDataManager: public cocos2d::CCObject  {
        
private:
        
        TWDataManager(void);
        //  virtual TIDataManager(void);
        
public:
        
        bool init(void);
        static TWDataManager* sharedManager(void);
        
        const char *gameLevelName;
        int currentLevel;
        int pageCount;
        int starCount;
        TargetPlatform target;
        bool canPlayWelcomeSound;
        bool canTapDog;
        bool canAddAnimals;
        bool canPlayAdviceSound;
        int dogTapCount;
        int previousAnimalTag;
        
       std::string previousanimalName;

};


#endif
