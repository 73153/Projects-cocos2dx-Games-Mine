//
//  TWDataManager.cpp
//  TapTheWords
//
//  Created by Deepthi on 29/03/13.
//
//

#include "TWDataManager.h"
#include "cocos2d.h"

static TWDataManager *gSharedManager = NULL;

TWDataManager::TWDataManager(void){
        this->currentLevel=1;
        this->pageCount=1;
        this->starCount=0;
        this->canPlayWelcomeSound=true;
        this->canTapDog=true;
        this->canAddAnimals=true;
        this->canPlayAdviceSound=true;
        this->dogTapCount=0;
        
        this->previousAnimalTag=0;
       
      
}



TWDataManager* TWDataManager::sharedManager(void) {
        
	TWDataManager *pRet = gSharedManager;
        
	if (! gSharedManager)
	{
		pRet = gSharedManager = new TWDataManager();
                
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool TWDataManager::init(void) {
	return true;
}
