//
//  BBPlaneSprite.cpp
//  BaccizBooks
//
//  Created by Anshul on 12/02/13.
//
//

#include "BBPuzzlePartSprite.h"


BBPuzzlePartSprite::BBPuzzlePartSprite(void)
{
    this->isPuzzlePartSolved=false;
}

BBPuzzlePartSprite::~BBPuzzlePartSprite(void)
{
    
}

// To create separate sprite from file...
BBPuzzlePartSprite* BBPuzzlePartSprite::spriteWithFile(const char *pszFileName)
{
    BBPuzzlePartSprite *pobSprite = new BBPuzzlePartSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        //pobSprite->scheduleUpdate();
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
	return NULL;
}

// To create sprite from sprite sheet!
BBPuzzlePartSprite* BBPuzzlePartSprite::spriteWithFrame(const char *pszFileName) {
    
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszFileName);
    
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszFileName);
    CCAssert(pFrame != NULL, msg);
    
    BBPuzzlePartSprite *tempSpr = BBPuzzlePartSprite::create(pFrame);
    
    return tempSpr;
}


BBPuzzlePartSprite* BBPuzzlePartSprite::create(const char *pszFileName)
{
    BBPuzzlePartSprite *pobSprite = new BBPuzzlePartSprite();
    if (pobSprite && pobSprite->initWithFile(pszFileName))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

BBPuzzlePartSprite* BBPuzzlePartSprite::create(CCSpriteFrame *pSpriteFrame)
{
    BBPuzzlePartSprite *pobSprite = new BBPuzzlePartSprite();
    if (pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}

BBPuzzlePartSprite* BBPuzzlePartSprite::createWithSpriteFrameName(const char *pszSpriteFrameName)
{
    CCSpriteFrame *pFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(pszSpriteFrameName);
    
#if COCOS2D_DEBUG > 0
    char msg[256] = {0};
    sprintf(msg, "Invalid spriteFrameName: %s", pszSpriteFrameName);
    CCAssert(pFrame != NULL, msg);
#endif
    
    return createWithSpriteFrame(pFrame);
}

BBPuzzlePartSprite* BBPuzzlePartSprite::createWithSpriteFrame(CCSpriteFrame *pSpriteFrame)
{
    BBPuzzlePartSprite *pobSprite = new BBPuzzlePartSprite();
    if (pSpriteFrame && pobSprite && pobSprite->initWithSpriteFrame(pSpriteFrame))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}


BBPuzzlePartSprite* BBPuzzlePartSprite::createWithTexture(CCTexture2D *pTexture)
{
    BBPuzzlePartSprite *pobSprite = new BBPuzzlePartSprite();
    if (pobSprite && pobSprite->initWithTexture(pTexture))
    {
        pobSprite->autorelease();
        return pobSprite;
    }
    CC_SAFE_DELETE(pobSprite);
    return NULL;
}
