//
//  BBPlaneSprite.h
//  BaccizBooks
//
//  Created by Anshul on 12/02/13.
//
//

#ifndef BaccizBooks_BBPuzzlePartSprite_h
#define BaccizBooks_BBPuzzlePartSprite_h

#include "cocos2d.h"
#include "BBPuzzlePartSprite.h"

using namespace cocos2d;

class BBPuzzlePartSprite : public CCSprite
{
    
public:
    
    BBPuzzlePartSprite(void);
    ~BBPuzzlePartSprite(void);
    
    // Creation of a tile...
    static BBPuzzlePartSprite* spriteWithFile(const char *pszFileName);
    static BBPuzzlePartSprite* spriteWithFrame(const char *pszFileName);
    static BBPuzzlePartSprite* create(const char *pszFileName);
    static BBPuzzlePartSprite* create(CCSpriteFrame *pSpriteFrame);
    static BBPuzzlePartSprite* createWithSpriteFrameName(const char *pszSpriteFrameName);
    static BBPuzzlePartSprite* createWithSpriteFrame(CCSpriteFrame *pSpriteFrame);
    static BBPuzzlePartSprite* createWithTexture(CCTexture2D *pTexture);
    
    //PUZZLES
    CCPoint targetPosition;
    CCPoint initialPosition;
    
    const char *gameWonSoundName;
    bool isPuzzlePartSolved;
    
    //ALPHABETS
    int matchID;
    std::string alphabetSoundName;
};

#endif
