#include "CustomTableViewCell.h"

USING_NS_CC;

void CustomTableViewCell::draw()
{
	CCTableViewCell::draw();
}
