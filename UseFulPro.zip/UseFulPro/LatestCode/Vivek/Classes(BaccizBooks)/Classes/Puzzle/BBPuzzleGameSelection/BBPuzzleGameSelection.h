//
//  BBPuzzleGameSelection.h
//  BaccizBooks
//
//  Created by Vivek on 13/02/13.
//
//

#ifndef BaccizBooks_BBPuzzleGameSelection_h
#define BaccizBooks_BBPuzzleGameSelection_h

#include"cocos2d.h"
#include "cocos-ext.h"
#include "BBPuzzleGame.h"
#include "BBPuzzleGameSelection.h"
#include "BacciTalking.h"

USING_NS_CC_EXT;
USING_NS_CC;

using namespace cocos2d;

class BBPuzzleGameSelection : public cocos2d::CCLayer, public cocos2d::extension::CCTableViewDataSource, public cocos2d::extension::CCTableViewDelegate {
    
public:
    //Default
    BBPuzzleGameSelection();
    virtual ~BBPuzzleGameSelection();
    
    virtual void onEnter();
    virtual void onExit();
    static CCScene* scene();
    
    //Initialize
    void initializeDifficultyLvl();
    void initializeUI();
    void initializePuzzleList();
    
    //Game Data
    CCSize winSize;
    CCSprite *normalSprLevelSelection;
    
    int puzzleDifficultyLevel;
    CCArray *spriteArray;
    CCArray *allPuzzleListArr;
    
    CCMenuItemSprite *leftArrowMenuItem;
    CCMenuItemSprite *rightArrowMenuItem;
    
    //--------Sounds----------//
    unsigned int stopSoundForLevels;
    unsigned int soundPlayPuzzle;
    unsigned int soundWhichPuzzle;
    unsigned int soundWhenPuzzleSelected;
    unsigned int soundDifficulty;
    
    void stopDogTalking();
    void startDogTalking();

    void welcomeToBaccizPuzzle();
    void playPuzzleSound();
    void selectDifficultySound();
    void chooseWhichPuzzle();
    void puzzlePutTogetherSound();
    
    //Scroll method
    CCTableView *tableView;
    void loadLastPuzzleScrollOffset(float inLastPuzzleScrollOffsetPosX);
    
    //methods for Puzzle Selection Buttons
    void leftArrowPressed(CCObject *sender);
    void rightArrowPressed(CCObject *sender);
    void goToPuzzle(int cellIndex);
    void backButtonSounds(CCMenuItemImage* sender);
    void backToMainScene();
    
    //difficulty Level
    void difficultyLevel(CCObject *sender);
    void difficultyLevelButton();
    void setDifficultyForLevel(int inLevelNo);
    void setPositionForDifficultyLevelIndicator(int inLevel);
    void getDifficultyLevelName(int difficultyLevel);
    
    virtual void scrollViewDidScroll(CCScrollView* view);
    virtual void scrollViewDidZoom(CCScrollView* view) {}
    virtual void tableCellTouched(CCTableView* table,CCTableViewCell* cell);
    virtual CCSize cellSizeForTable(CCTableView *table);
    virtual CCTableViewCell* tableCellAtIndex(CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(CCTableView *table);
    
    bool canDogTalk;
    CCSprite *dogBase;
    BacciTalking *bazziTalking;
    
    void canDogTalkAgain();
    void setDogVisibility();
    
    CCSprite *puzzleWonAward;
    void addStars();
    void addNewStar();
        
    CREATE_FUNC(BBPuzzleGameSelection);
    
    bool isLoked;
    int freeLevels;
    void reSet(CCBool *sw);
    
};
#endif

