//
//  BBPuzzleGame.cpp
//  Puzzles
//
//  Created by Vivek on 22/05/13.
//
//

#include "BBPuzzleGame.h"
#include "SimpleAudioEngine.h"
#include "BBSharedSoundManager.h"
#include "BBMainDataManager.h"
#include "BBPuzzleDataManager.h"
#include "BBPuzzlePartSprite.h"
#include "cocos2d.h"
#include "BBUtility.h"
#include "CCBReader.h"
#include "cocos-ext.h"
#include "CCNodeLoader.h"
#include "CCNodeLoaderLibrary.h"
#include "BBPuzzleGameSelection.h"
#include "BBAllGamesFunctionSharedManager.h"
#include "WrapperHelper.h"

USING_NS_CC;
USING_NS_CC_EXT;

#define kHint_NoHintSoundTag 444
#define kSkeletonSprTag 555
#define kIntroductionSoundTag 666

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* BBPuzzleGame::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    BBPuzzleGame *layer = BBPuzzleGame::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - Default
BBPuzzleGame::BBPuzzleGame()
{
    isDogTalking = false;
//    BBPuzzleDataManager::sharedManager()->canTapDog = false;
}


void BBPuzzleGame::onEnter() {
    
    CCLayer::onEnter();
    
    // ask director the window size
    winsize = CCDirector::sharedDirector()->getWinSize();
    
    //BG
    CCSprite *gameBackgroundSpr = CCSprite::create("Puzzle/puzzle_background.jpg");
    gameBackgroundSpr->setPosition(ccp(winsize.width/2, winsize.height/2));
    this->addChild(gameBackgroundSpr);
    
    
    this->setTouchEnabled(true); //Enabling Touch
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GamePlaySpriteSheets/Parts/Puzzle_Parts.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GamePlaySpriteSheets/BBPuzzleGame/PuzzleGamePlay.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("GamePlaySpriteSheets/BBPuzzleGame/BBHammerAnimation.plist");
    
    //-------- INITIALIZE --------//
    this->initializeDogWithBase(); //Dog & it's base
    
    this->initializeVariables(); // Variables
    
    this->initializeDataPlist(); //Data plist
    
    
    const char *levelName = BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName;
    if(strcmp(levelName,"FivePiece") == 0) {
        this->isFivePieceGame = true;
    }
    else {
        this->isFivePieceGame = false;
    }
    
    WrapperHelper::logEventWitnName(levelName, true);
    
    //puzzleWonAward Sprite
    puzzleWonAward = CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(puzzleWonAward,6);
    puzzleWonAward->setScale(0.7);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        puzzleWonAward->setPosition(ccp(722,390));
    }
    else
    {
        puzzleWonAward->setPosition(ccp(330,180));
        
    }
    puzzleWonAward->setVisible(false);

    
    if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound) {
        
        //-----SOUND----//
        CCSequence *Seq1 = CCSequence::create(CCDelayTime::create(1), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::completePuzzle)), NULL);
        this->runAction(Seq1);
        isDogTalking = true;
    }
    
    if(strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"FivePiece")==0)
    {
        char spriteName[200];
        sprintf(spriteName,"Puzzle/GamePlaySpriteSheets/BBPuzzleGame/%s/%s",BBPuzzleDataManager::sharedManager()->puzzleName,aPuzzleDict->valueForKey("spriteSheetPath")->getCString());
        
        CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(spriteName);
        
        this->initializeRandPosFor5Piece();
        this->addingMinasingSmallRandPosFor5Piece();
    }
    else { // Add skeleton Image for Levels 4,9 & 12
        
        CCDictionary *bgImageDict = (CCDictionary *)aPuzzleAllTypeDict->valueForKey("BgImage");
        puzzleSkeleton = (const char*)bgImageDict->valueForKey("SkeletonImage")->getCString();
        
        puzzleSkeletonSpr = CCSprite::create(puzzleSkeleton);
        if(BBMainDataManager::sharedManager()->target==kTargetIpad){
            
            puzzleSkeletonSpr->setPosition(ccp(244,400));
        }
        else {
            puzzleSkeletonSpr->setPosition(ccp(122,160));
        }
        this->addChild(puzzleSkeletonSpr,1);
        
        //-----SOUND----//
        if (BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound == true) {
            
            BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound = false;
                        
            CCSequence *Seq1 = CCSequence::create(CCDelayTime::create(6),
                                                  CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::easyToStartWithCornerPieces)), NULL);
            this->runAction(Seq1);
        }
        
        this->createGreyColorBG();
        this->settingThePartsRandomPosition(puzzleSkeleton);
    }
    
    //Add Game UI
    this->initializeGameUI();
    
    //call to last gameLevel played
    if (this->isFivePieceGame == false) {
        
        int LastSprSelected = CCUserDefault::sharedUserDefault()->getIntegerForKey("LastSprSelected");
        this->loadLastSprSelected(LastSprSelected);
    }
    
}


#pragma mark ------------------- PUZZLES PARTS-------------------
#pragma mark - Initialize
void BBPuzzleGame::initializeVariables(){
    
    //-------------------PUZZLES-------------------//
    //Creating Arrays
    this->puzzlePartsArr = CCArray::create();
    this->puzzlePartsArr->retain();
    
    this->randPosArray = CCArray::create();
    this->randPosArray->retain();
    
    //--------------------GENERAL-------------------//
    //Boolean Values
    this->isPuzzlePartSelected = false;
    this->isFirstGameOver = false;
    this->isDogTalking = false;
    this->isGameOver = false;
    
    canDogTalk = true;
    this->canTouchAlphabet = true;
    
    this->wrongAttemptsCount = 0;
    
    //------------------ALPHABETS------------------//
    this->alphabetRandPosArr = CCArray::create();
    this->alphabetRandPosArr->retain();
    
    this->alphabetHoleArray = CCArray::create();
    this->alphabetHoleArray->retain();
    
    this->alphabetsColorArray = CCArray::create();
    this->alphabetsColorArray->retain();
}

void BBPuzzleGame::initializeGameUI(){
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        if(!this->isFivePieceGame)
        {
            //Adding Skeleton Selection Menu for setting skeleton Visible
            char visibleBox[150];
            sprintf(visibleBox,"%s_visibleBox.png",BBPuzzleDataManager::sharedManager()->puzzleName);
            
            CCSprite *normalSkeletonBox = CCSprite::createWithSpriteFrameName(visibleBox);
            CCSprite *selectedSkeletonBox = CCSprite::createWithSpriteFrameName(visibleBox);
            
            skeletonFrameVisibleItem = CCMenuItemSprite::create(normalSkeletonBox, selectedSkeletonBox, this, menu_selector(BBPuzzleGame::checkSkeletonFrameBtn));
            skeletonFrameVisibleItem->setTag(1);
            skeletonFrameVisibleItem->setPosition(ccp(winsize.width/2 - 200, winsize.height/2 + 327));
            
            
            //Adding Skeleton Selection Menu for setting skeleton Invisible
            CCSprite *normalSkeletonEmptyBox = CCSprite::createWithSpriteFrameName("SkeletonInvisible.png");
            CCSprite *selectedSkeletonEmptyBox = CCSprite::createWithSpriteFrameName("SkeletonInvisible.png");
            
            skeletonFrameInVisibleItem = CCMenuItemSprite::create(normalSkeletonEmptyBox, selectedSkeletonEmptyBox,this, menu_selector(BBPuzzleGame::checkSkeletonFrameBtn));
            skeletonFrameInVisibleItem->setPosition(ccp(winsize.width/2 - 300, winsize.height/2 + 330));
            skeletonFrameInVisibleItem->setTag(2);
            
            
            CCMenu *skeletonBoxVisibility = CCMenu::create(skeletonFrameVisibleItem,skeletonFrameInVisibleItem, NULL);
            skeletonBoxVisibility->setPosition(CCPointZero);
            this->addChild(skeletonBoxVisibility,3);
            
            
            //image Selection Sprite
            skeletonBtnSelectionMarkSpr = CCSprite::createWithSpriteFrameName("Selection.png");
            
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 300, winsize.height/2 + 330));
            skeletonBtnSelectionMarkSpr->setScale(0.7);
            skeletonBtnSelectionMarkSpr->setVisible(false);
            this->addChild(skeletonBtnSelectionMarkSpr,2);
        }
        
        //Add restart button
        CCSprite *normalRedSpr = CCSprite::createWithSpriteFrameName("replay-red.png");
        CCSprite *selectedRedSpr = CCSprite::createWithSpriteFrameName("replay-red.png");
        
        restartBtn = CCMenuItemSprite::create(normalRedSpr, selectedRedSpr, this, menu_selector(BBPuzzleGame::restartPuzzleGameScene));
        restartBtn->setPosition(ccp(winsize.width/2 + 440, winsize.height/2 + 330));
        
        //Add back button
        CCSprite *backSpr = CCSprite::createWithSpriteFrameName("back.png");
        
        CCMenuItemSprite *backBtn = CCMenuItemSprite::create(backSpr, backSpr, this, menu_selector(BBPuzzleGame::animateBackButton));
        backBtn->setPosition(ccp(winsize.width/2 - 430, winsize.height/2 + 330));
        backBtn->setTag(1000);
        
        inGameLevelMenu = CCMenu::create(restartBtn, backBtn, NULL);
        inGameLevelMenu->setPosition(CCPointZero);
        this->addChild(inGameLevelMenu,2);
    }
    else
    {
        //If isFivePieceGame Don't add Skeleton & Top Btn
        if(!this->isFivePieceGame)
        {
            //Adding Skeleton Selection Menu for setting skeleton Visible
            char visibleBox[150];
            sprintf(visibleBox,"%s_visibleBox.png",BBPuzzleDataManager::sharedManager()->puzzleName);
            
            CCSprite *normalSkeletonBox = CCSprite::createWithSpriteFrameName(visibleBox);
            CCSprite *selectedSkeletonBox = CCSprite::createWithSpriteFrameName(visibleBox);
            
            skeletonFrameVisibleItem = CCMenuItemSprite::create(normalSkeletonBox, selectedSkeletonBox, this, menu_selector(BBPuzzleGame::checkSkeletonFrameBtn));
            skeletonFrameVisibleItem->setTag(1);
            skeletonFrameVisibleItem->setPosition(ccp(winsize.width/2 - 90, winsize.height/2 + 137));
            
            //Adding Skeleton Selection Menu for setting skeleton Invisible
            CCSprite *normalSkeletonEmptyBox = CCSprite::createWithSpriteFrameName("SkeletonInvisible.png");
            CCSprite *selectedSkeletonEmptyBox = CCSprite::createWithSpriteFrameName("SkeletonInvisible.png");
            
            skeletonFrameInVisibleItem = CCMenuItemSprite::create(normalSkeletonEmptyBox, selectedSkeletonEmptyBox,this, menu_selector(BBPuzzleGame::checkSkeletonFrameBtn));
            
            skeletonFrameInVisibleItem->setPosition(ccp(winsize.width/2 - 130, winsize.height/2 + 140));
            skeletonFrameInVisibleItem->setTag(2);
            
            CCMenu *skeletonBoxVisibility = CCMenu::create(skeletonFrameVisibleItem,skeletonFrameInVisibleItem, NULL);
            skeletonBoxVisibility->setPosition(CCPointZero);
            this->addChild(skeletonBoxVisibility,3);
            
            //image Selection Sprite
            skeletonBtnSelectionMarkSpr = CCSprite::createWithSpriteFrameName("Selection.png");
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 75, winsize.height/2 + 90));
            skeletonBtnSelectionMarkSpr->setScale(0.58);
            skeletonBtnSelectionMarkSpr->setVisible(false);
            this->addChild(skeletonBtnSelectionMarkSpr,4);
        }
        
        //Add restart button
        CCSprite *normalRedSpr = CCSprite::createWithSpriteFrameName("replay-red.png");
        CCSprite *selectedRedSpr = CCSprite::createWithSpriteFrameName("replay-red.png");
        
        restartBtn = CCMenuItemSprite::create(normalRedSpr, selectedRedSpr, this, menu_selector(BBPuzzleGame::restartPuzzleGameScene));
        restartBtn->setPosition(ccp(winsize.width/2 + 210, winsize.height/2 + 135));
        
        //Add back button
        CCSprite *backSpr = CCSprite::createWithSpriteFrameName("back.png");
        
        CCMenuItemSprite *backBtn = CCMenuItemSprite::create(backSpr, backSpr, this, menu_selector(BBPuzzleGame::backToPuzzleGameSelection));
        backBtn->setPosition(ccp(winsize.width/2 - 207, winsize.height/2 + 135));
        
        CCMenu *inGameLevelMenu = CCMenu::create(restartBtn, backBtn, NULL);
        inGameLevelMenu->setPosition(CCPointZero);
        this->addChild(inGameLevelMenu,2);
    }
}

void BBPuzzleGame::initializeRandPosFor5Piece() {
    
    CCNode *ccbPuzzleNode;
    
    //CocosBuilder
    CCNodeLoaderLibrary *ccNodeLoaderLibrary = CCNodeLoaderLibrary::sharedCCNodeLoaderLibrary();
    CCBReader *ccbReader = new CCBReader(ccNodeLoaderLibrary);
    
    //Creating a CCBReader object to read the desired values from cocosbuilder
    BBMainDataManager::sharedManager()->cocosBuilderReader = ccbReader;
    ccbReader->autorelease();
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        ccbPuzzleNode = ccbReader->readNodeGraphFromFile(aPuzzleDict->valueForKey("cocosBuilderFileNameForIpad")->getCString());
    }
    else
    {
        ccbPuzzleNode = ccbReader->readNodeGraphFromFile(aPuzzleDict->valueForKey("cocosBuilderFileNameForIphone")->getCString());
    }
    
    CCArray *allNodeChildrenArr = ccbPuzzleNode->getChildren();
    
    CCObject* aPuzzlePartObj = NULL;
    CCARRAY_FOREACH(allNodeChildrenArr,aPuzzlePartObj)
    {
        CCSprite* puzzlePartSpr = (CCSprite*)aPuzzlePartObj;
        
        if (puzzlePartSpr->getTag() == kSkeletonSprTag) {
            continue; //omitting skeleton position inorder to place sprites at desired location
        }
        
        char sprPosChar[50];
        sprintf(sprPosChar,"{%f,%f}",puzzlePartSpr->getPositionX(),puzzlePartSpr->getPositionY());
        
        //Load all the points in array(Note:- Conversion from CCPoint to CCString)
        CCString *aSprPos = CCString::create(sprPosChar);
        randPosArray->addObject(aSprPos);
    }
}

void BBPuzzleGame::initializeDogWithBase() {
    
    //DOG BASE
    dogBase = CCSprite::createWithSpriteFrameName("dog_base.png");
    
    if(BBMainDataManager::sharedManager()->target == kTargetIpad) {
        
        dogBase->setPosition(CCPointMake(80,48));
    }
    else {
        
        dogBase->setVisible(false);
    }
    this->addChild(dogBase,3);
    
    
    //BACCI TALKING
    bazziTalking = new BacciTalking();
    if(BBMainDataManager::sharedManager()->target == kTargetIpad) {
        
        bazziTalking->initialize(this,CCPoint(85, 128));
    }
    else if(CCDirector::sharedDirector()->getContentScaleFactor() == 2) {
        
        bazziTalking->initialize(this,CCPoint(15, 20));
    }
    else {
        
        bazziTalking->initialize(this,CCPoint(15, 38));
    }
}

void BBPuzzleGame::initializeDataPlist() {
    
    //Load Data plist
    std::string fullPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("Puzzle_Game.plist");
    allCardInfoDict = CCDictionary::createWithContentsOfFileThreadSafe(fullPath.c_str());
    
    //loading PuzzleName
    aPuzzleAllTypeDict = (CCDictionary*)allCardInfoDict->valueForKey(BBPuzzleDataManager::sharedManager()->puzzleName);
    
    //loading PuzzleDifficultyType
    levelName = BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName;
    aPuzzleDict = (CCDictionary*)aPuzzleAllTypeDict->valueForKey(levelName);
    
    //loading gameWonSprites Array
    gameWonSprArray = (CCArray*)allCardInfoDict->valueForKey("gameWonSprites");
}

#pragma mark - Puzzle_Parts Logic
BBPuzzlePartSprite* maskedSpriteWithSprite(CCSprite* pTextureSprite, CCSprite* pMaskSprite) {
    
    // store the original positions of both sprites
    CCPoint textureSpriteOrigPosition(pTextureSprite->getPosition().x, pTextureSprite->getPosition().y);
    CCPoint maskSpriteOrigPosition(pMaskSprite->getPosition().x, pMaskSprite->getPosition().y);
    
    // convert the texture sprite position into mask sprite coordinate system
    pTextureSprite->setPosition(ccp(pTextureSprite->getContentSize().width/2 - pMaskSprite->getPosition().x + pMaskSprite->getContentSize().width/2, pTextureSprite->getContentSize().height/2 - pMaskSprite->getPosition().y + pMaskSprite->getContentSize().height/2));
    
    // position the mask sprite so that the bottom left corner lies on the (o,o) coordinates
    pMaskSprite->setPosition(ccp(pMaskSprite->getContentSize().width/2, pMaskSprite->getContentSize().height/2));
    
    CCRenderTexture *rt = CCRenderTexture::create((int)pMaskSprite->getContentSize().width, (int)pMaskSprite->getContentSize().height);
    
    ccBlendFunc bfMask = ccBlendFunc();
    bfMask.src = GL_ONE;
    bfMask.dst = GL_ZERO;
    pMaskSprite->setBlendFunc(bfMask);
    
    // turn off anti-aliasing around the mask sprite
    pMaskSprite->getTexture()->setAliasTexParameters();
    
    ccBlendFunc bfTexture = ccBlendFunc();
    bfTexture.src = GL_DST_ALPHA;
    bfTexture.dst = GL_ZERO;
    pTextureSprite->setBlendFunc(bfTexture);
    
    rt->begin();
    pMaskSprite->visit();
    pTextureSprite->visit();
    rt->end();
    
    // generate the resulting sprite
    //CCSprite *pOutcome = CCSprite::createWithTexture(rt->getSprite()->getTexture());
    BBPuzzlePartSprite *pOutcome = BBPuzzlePartSprite::createWithTexture(rt->getSprite()->getTexture());
    
    pOutcome->setFlipY(true);
    
    // restore the original sprite positions
    pTextureSprite->setPosition(textureSpriteOrigPosition);
    pMaskSprite->setPosition(maskSpriteOrigPosition);
    pOutcome->setPosition(maskSpriteOrigPosition);
    
    return pOutcome;
}

void BBPuzzleGame::settingThePartsRandomPosition(const char *fileName){
    
    const char *difficultyLvl = BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName;
    CCDictionary *aGameLeveleDict = (CCDictionary *)allCardInfoDict->valueForKey(difficultyLvl);
    
    //Load distance b/w selected PuzzlePart and Skeleton based on the difficulty level
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        CCString *distance = (CCString *)aGameLeveleDict->objectForKey("distance");
        distBtwnSelectedSprAndSkeleton = CCPointFromString(distance->getCString());
    }
    else
    {
        distBtwnSelectedSprAndSkeleton = ccp(-35, 35);
    }
    
    //Array to get the Target Position to for Puzzle Parts (both iPhone & iPad)
    CCArray *puzzlePartsArray = (CCArray*)aGameLeveleDict->valueForKey("PuzzleParts");
    
    //store unique no's into Array
    int no_to_randomize[10];
    for (int i = 0 ; i <puzzlePartsArray->count(); i++){
        no_to_randomize[i] = i;
    }
    
    if(this->isFivePieceGame == false) // skip placing Skeleton (if EasyLevel selected)
    {
        //load Puzzle SkeletonFrame
        BBPuzzlePartSprite *puzzleSkeletonFrameSpr = BBPuzzlePartSprite::createWithSpriteFrameName("SkeltonFrame.png");
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad){
            
            puzzleSkeletonFrameSpr->setPosition(ccp(puzzleSkeletonSpr->getPositionX() + 3, puzzleSkeletonSpr->getPositionY() - 5));
            puzzleSkeletonFrameSpr->setScale(1.05);
        }
        else{
            puzzleSkeletonFrameSpr->setPosition(ccp(puzzleSkeletonSpr->getPositionX() ,puzzleSkeletonSpr->getPositionY() - 2));
            puzzleSkeletonFrameSpr->setScale(1.05);
        }
        this->addChild(puzzleSkeletonFrameSpr);
    }
    
    //store indexes into an integer Array from randomize method
    int *store_randomArray = this->intArrToSwapNumber(no_to_randomize);
    int index=0;
    
    CCObject *aPuzzlePartObj = NULL;
    CCARRAY_FOREACH(puzzlePartsArray, aPuzzlePartObj)
    {
        int randNum = store_randomArray[index];
        
        CCDictionary *aPuzzlePartDict = (CCDictionary *)aPuzzlePartObj;
        const char *partImageName = (const char *)aPuzzlePartDict->valueForKey("imageName")->getCString();
        
        CCSprite *puzzlePartSpr = CCSprite::createWithSpriteFrameName(partImageName);
        CCSprite *SkeletonFrame = CCSprite::create(fileName);
        
        CCSize sourceSize = SkeletonFrame->getContentSize();
        CCSize partSize = puzzlePartSpr->getContentSize();
        
        //Set puzzle parts position
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            CCString *puzzlePartsPosStr = (CCString *)aPuzzlePartDict->valueForKey("posOfPartSpr");
            CCPoint puzzlePartsPos = CCPointFromString(puzzlePartsPosStr->getCString());
            puzzlePartSpr->setPosition(puzzlePartsPos);
        }
        else {
            
            CCString *puzzlePartsPosStr = (CCString *)aPuzzlePartDict->valueForKey("targetPositionIphone");
            CCPoint puzzlePartsPos = CCPointFromString(puzzlePartsPosStr->getCString());
            puzzlePartSpr->setPosition(puzzlePartsPos);
        }
        
        //Random position for puzzle Parts
        CCPoint aPuzzlePartPoint;
        if(BBMainDataManager::sharedManager()->target==kTargetIpad) {
            
            CCArray *randPosArr =(CCArray*)aGameLeveleDict->valueForKey("RandomPosIpad");
            CCString *aPointStr = (CCString *)randPosArr->objectAtIndex(randNum);
            aPuzzlePartPoint = CCPointFromString(aPointStr->getCString());
        }
        else {
            
            CCArray *randPosArr =(CCArray*)aGameLeveleDict->valueForKey("RandomPosIphone");
            CCString *aPointStr = (CCString *)randPosArr->objectAtIndex(randNum);
            aPuzzlePartPoint = CCPointFromString(aPointStr->getCString());
        }
        
        BBPuzzlePartSprite *maskedPart = maskedSpriteWithSprite(SkeletonFrame, puzzlePartSpr);
        maskedPart->setPosition(aPuzzlePartPoint);
        maskedPart->initialPosition = aPuzzlePartPoint; // Initial Position for puzzleParts
        
        this->addChild(maskedPart);
        puzzlePartsArr->addObject(maskedPart);
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            //load targetPos
            CCString *targetPoint = (CCString *)aPuzzlePartDict->valueForKey("targetPositionIpad");
            maskedPart->targetPosition = CCPointFromString(targetPoint->getCString());
        }
        else
        {
            //load targetPos
            CCString *targetPoint = (CCString *)aPuzzlePartDict->valueForKey("targetPositionIphone");
            maskedPart->targetPosition = CCPointFromString(targetPoint->getCString());
        }
        index++;
    }
    
    //Create BG for 4, 9  & 12 Piece
    if(strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"FourPiece")==0)
    {
        CCSprite *bg4Piece = CCSprite::create("GamePlaySpriteSheets/Parts/bg4.png");
        bg4Piece->setPosition(ccp(puzzleSkeletonSpr->getContentSize().width/2, puzzleSkeletonSpr->getContentSize().height/2));
        puzzleSkeletonSpr->addChild(bg4Piece,5);
    }
    else if (strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"NinePiece")==0)
    {
        CCSprite *bg9Piece = CCSprite::create("GamePlaySpriteSheets/Parts/bg9.png");
        bg9Piece->setPosition(ccp(puzzleSkeletonSpr->getContentSize().width/2, puzzleSkeletonSpr->getContentSize().height/2));
        puzzleSkeletonSpr->addChild(bg9Piece);
    }
    else {
        
        CCSprite *bg12Piece = CCSprite::create("GamePlaySpriteSheets/Parts/bg12.png");
        bg12Piece->setPosition(ccp(puzzleSkeletonSpr->getContentSize().width/2, puzzleSkeletonSpr->getContentSize().height/2));
        puzzleSkeletonSpr->addChild(bg12Piece);
    }
    
    //getting an array count
    this->partsArrayCount = this->puzzlePartsArr->count();
}

void BBPuzzleGame::createGreyColorBG() {
    
    int colorRampUniformLocation;  //2
    CCTexture2D *colorRampTexture; //3
    
    //create a grey scale backGround.
    CCGLProgram *shaderProgram_ = new CCGLProgram();
    puzzleSkeletonSpr->setShaderProgram(shaderProgram_);
    GLchar * fragSource = (GLchar*) CCString::createWithContentsOfFile(CCFileUtils::sharedFileUtils()->fullPathForFilename("Shaders/CCMonochromeKBFilter.fsh").c_str())->getCString();
    shaderProgram_->initWithVertexShaderByteArray(ccPositionTextureColor_vert, fragSource);
    shaderProgram_->addAttribute(kCCAttributeNamePosition, kCCVertexAttrib_Position);
    shaderProgram_->addAttribute(kCCAttributeNameTexCoord, kCCVertexAttrib_TexCoords);
    shaderProgram_->link();
    shaderProgram_->updateUniforms();
    
    colorRampUniformLocation = glGetUniformLocation(puzzleSkeletonSpr->getShaderProgram()->getProgram(), "u_colorRampTexture");
    glUniform1i(colorRampUniformLocation, 1);
    
    colorRampTexture = CCTextureCache::sharedTextureCache()->addImage(puzzleSkeleton);
    colorRampTexture->setAliasTexParameters();
    
    puzzleSkeletonSpr->getShaderProgram()->use();
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, colorRampTexture->getName());
    glActiveTexture(GL_TEXTURE0);
}

void BBPuzzleGame::addingMinasingSmallRandPosFor5Piece(){
    
    //loading Puzzle Skeleton Images from plist
    const char *PuzzleSkeletonImage = (const char *)aPuzzleDict->valueForKey("PuzzleSkeletonImage")->getCString();
    puzzleSkeletonSpr = CCSprite::createWithSpriteFrameName(PuzzleSkeletonImage);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad){
        
        puzzleSkeletonSpr->setPosition(ccp(244, 400));
    }
    else {
        puzzleSkeletonSpr->setPosition(ccp(112, 160));
    }
    
    this->addChild(puzzleSkeletonSpr);
    puzzleSkeletonSpr->setVisible(true); // By Default Puzzle Skeleton is Visible
    
    //shuffling the Puzzle parts positions & storing in an Array
    randPosArray = BBUtility::shuffleArray(randPosArray);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        //loading distance b/w selectedPuzzlePart and Skeleton
        CCString *distance = (CCString *)aPuzzleDict->objectForKey("distance");
        distBtwnSelectedSprAndSkeleton = CCPointFromString(distance->getCString());
    }
    else
    {
        distBtwnSelectedSprAndSkeleton = ccp(-20, 20);
    }
    
    //Add puzzle parts
    int index = 0;
    CCArray *puzzlePartsArray = (CCArray*)aPuzzleDict->valueForKey("PuzzleParts");
    
    CCObject *aPuzzlePartObj = NULL;
    CCARRAY_FOREACH(puzzlePartsArray, aPuzzlePartObj) {
        
        //converting Puzzle parts Array into Dictionary
        CCDictionary *aPuzzlePartDict = (CCDictionary *)aPuzzlePartObj;
        
        const char *imageName = (const char *)aPuzzlePartDict->valueForKey("imageName")->getCString();
        
        BBPuzzlePartSprite *aPuzzlePart = BBPuzzlePartSprite::createWithSpriteFrameName(imageName);
        
        //Get the random Pos
        CCString *aPointStr = (CCString *)randPosArray->objectAtIndex(index);
        CCPoint aPuzzlePartPoint = CCPointFromString(aPointStr->getCString());
        
        //Get randomPosChangeFactorXPos & randomPosChangeFactorYPos
        CCString *randomPosChangeFactorXStr = (CCString *)aPuzzlePartDict->valueForKey("RandomPosChangeFactorX");
        CCPoint randomPosChangeFactorXPos = CCPointFromString(randomPosChangeFactorXStr->getCString());
        
        CCString *randomPosChangeFactorYStr = (CCString *)aPuzzlePartDict->valueForKey("RandomPosChangeFactorY");
        CCPoint randomPosChangeFactorYPos = CCPointFromString(randomPosChangeFactorYStr->getCString());
        
        //if selectedPuzzlePart pos is {+,-} the randomvalues, then place the parts at random location
        aPuzzlePartPoint = CCPoint(aPuzzlePartPoint.x + BBUtility::getRandomNumberBetween(randomPosChangeFactorXPos.x, randomPosChangeFactorXPos.y), aPuzzlePartPoint.y + BBUtility::getRandomNumberBetween(randomPosChangeFactorYPos.x, randomPosChangeFactorYPos.y));
        
        aPuzzlePart->setPosition(aPuzzlePartPoint);
        aPuzzlePart->initialPosition = aPuzzlePartPoint;
        aPuzzlePart->isPuzzlePartSolved = false;
        this->addChild(aPuzzlePart, 2);
        
        puzzlePartsArr->addObject(aPuzzlePart);
        
        //incrementing index
        index++;
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad)
        {
            //loading targetPostion from plist to place the image inside the plane skeleton
            CCString *targetPoint = (CCString *)aPuzzlePartDict->valueForKey("targetPositionIpad");
            aPuzzlePart->targetPosition = CCPointFromString(targetPoint->getCString());
        }
        else
        {
            //loading targetPostion from plist to place the image inside the plane skeleton
            CCString *targetPoint = (CCString *)aPuzzlePartDict->valueForKey("targetPositionIphone");
            aPuzzlePart->targetPosition = CCPointFromString(targetPoint->getCString());
        }
    }
    
    //getting an array count
    this->partsArrayCount = this->puzzlePartsArr->count();
}

void BBPuzzleGame::setVisibilityForSkeletonFrame(int tag){
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        if (tag == 1) {
            
            this->puzzleSkeletonSpr->setVisible(true);
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 200, winsize.height/2 + 327));
            skeletonBtnSelectionMarkSpr->setVisible(true);
        }
        else if (tag == 2){
            
            this->puzzleSkeletonSpr->setVisible(false);
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 300, winsize.height/2 + 327));
            skeletonBtnSelectionMarkSpr->setVisible(true);
        }
    }
    else {
        
        if (tag == 1) {
            
            this->puzzleSkeletonSpr->setVisible(true);
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 90 , winsize.height/2 + 140 ));
            skeletonBtnSelectionMarkSpr->setVisible(true);
        }
        else if (tag == 2){
            
            this->puzzleSkeletonSpr->setVisible(false);
            skeletonBtnSelectionMarkSpr->setPosition(ccp(winsize.width/2 - 130, winsize.height/2 + 140));
            skeletonBtnSelectionMarkSpr->setVisible(true);
        }
    }
}

void BBPuzzleGame::loadLastSprSelected(int tag) {
    
    CCUserDefault::sharedUserDefault()->setIntegerForKey("LastSprSelected", tag);
    CCUserDefault::sharedUserDefault()->flush(); //to save the LastSprSelected
    
    if (tag == 1 || tag == 0) {
        
        isEmptyBoxSelected = true;
        this->setVisibilityForSkeletonFrame(1);
    }
    else if (tag == 2) {
        
        isEmptyBoxSelected = false;
        this->setVisibilityForSkeletonFrame(2);
    }
}


#pragma mark - Utility
int* BBPuzzleGame::intArrToSwapNumber(int noOfAnimalSprites[15]) {
    
    //variables used for swapping
    int swap;
    int rand_no;
    const char *diffcultyLvl = BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName;
    CCDictionary *aGameLeveleDict = (CCDictionary *)allCardInfoDict->valueForKey(diffcultyLvl);
    CCArray *puzzlePartsArray = (CCArray*)aGameLeveleDict->valueForKey("PuzzleParts");
    
    //randomize the array
    for(int i=0; i<puzzlePartsArray->count(); i++){
        
        rand_no = arc4random() % puzzlePartsArray->count();
        
        swap = noOfAnimalSprites[rand_no];
        noOfAnimalSprites[rand_no]= noOfAnimalSprites[i];
        noOfAnimalSprites[i] = swap;
    }
    return noOfAnimalSprites;
}

void BBPuzzleGame::checkingPartsGotPlaced() {
    
    //location of SelectedPuzzlePart with respect to Puzzle skeleton
    CCPoint locationOfSelectedPuzzlePart = puzzleSkeletonSpr->convertToNodeSpace(this->selectedPuzzlePart->getPosition());
    
    //calculate the distance between the targetPosition and the selectedPuzzlePart Position
    float distance = ccpDistance(this->selectedPuzzlePart->targetPosition,locationOfSelectedPuzzlePart);
    
    if(distance >= distBtwnSelectedSprAndSkeleton.x && distance <= distBtwnSelectedSprAndSkeleton.y) {
        
        CCPoint originalLocation = puzzleSkeletonSpr->convertToWorldSpace(this->selectedPuzzlePart->targetPosition);
        
        this->selectedPuzzlePart->stopAllActions();
        
        //Get the position based on parent
        CCMoveTo *selectedPuzzlePartPos = CCMoveTo::create(0.25,CCPoint(originalLocation));
        this->selectedPuzzlePart->runAction(selectedPuzzlePartPos);
        this->selectedPuzzlePart->setZOrder(2);
        
        //set puzzlePart solved true if part is placed properly
        this->selectedPuzzlePart->isPuzzlePartSolved = true;
        
        //decrementing partsArray Count
        partsArrayCount--;
        
        if(partsArrayCount <= 0) {
            
            this->puzzlePartsGameWon();
        }
    }
    else {
        
        this->selectedPuzzlePart->stopAllActions();
        
        this->wrongAttemptsCount++;
        
        if (this->wrongAttemptsCount%4 == 0) {
            this->playWrongAttemptSound();
        }
        
        SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/wrong_spot.mp3");
        
        //if not placed properly move back sprite to it's initial location
        CCMoveTo *selectedSprInitialPos = CCMoveTo::create(0.5,CCPoint(this->selectedPuzzlePart->initialPosition));
        this->selectedPuzzlePart->runAction(selectedSprInitialPos);
        this->selectedPuzzlePart->setZOrder(2);
    }
    this->isPuzzlePartSelected = false;
}


#pragma mark - PuzzleParts Sounds
void BBPuzzleGame::completePuzzle() {
    
    if (isFirstGameOver) {
        return;
    }
    
    isDogTalking = true;
    bazziTalking->startDogTalking();
    
    int rand_no = arc4random() % 2;
    if (rand_no == 0) {
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_completethe_puzzle.mp3");
    }
    else {
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_usefingertodrag_puzzle.mp3");
    }
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    Seq->setTag(kIntroductionSoundTag);
    this->runAction(Seq);
}

void BBPuzzleGame::easyToStartWithCornerPieces() {
    
    if (isFirstGameOver) {
        return;
    }
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/5_itseasierwhenyoustart_puzzle.mp3");
    
    isDogTalking = false;
}


void BBPuzzleGame::dogTapSounds() {
    
    if (this->isFirstGameOver) {
        return;
    }
    
    bazziTalking->startDogTalking();
    
    int rand_no = arc4random() % 3;
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    if (rand_no == 0) {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_completethe_puzzle.mp3");
    }
    else if (rand_no == 1) {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_usefingertodrag_puzzle.mp3");
    }
    else {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/5_itseasierwhenyoustart_puzzle.mp3");
    }
    
    //stop Dog Talking after the sound is completed
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(4.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), CCCallFunc::create(this,  callfunc_selector(BBPuzzleGame::canDogTalkAgain)), NULL);
    this->runAction(Seq);
    
}

void BBPuzzleGame::dogTapSoundsFor5Pieces() {
    
    if (this->isFirstGameOver) {
        return;
    }
    
    bazziTalking->startDogTalking();
    
    int rand_no = arc4random() % 2;
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    if (rand_no == 0) {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_completethe_puzzle.mp3");
    }
    else {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/4_usefingertodrag_puzzle.mp3");
    }
    
    //stop Dog Talking after the sound is completed
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(4.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::canDogTalkAgain)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGame::canDogTalkAgain() {
    
    canDogTalk = true;
}


#pragma mark - Puzzle Parts Over
void BBPuzzleGame::puzzlePartsGameWon() {
    
    //stop any Sounds if playing
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    //Dog Talking
    bazziTalking->startDogTalking();
    
    //play only sounds
    BBAllGamesFunctionSharedManager::sharedManager()->addCongratulationBanner(false, CCPoint(0, 0));
    
    CCSequence *playPuzzleNameSound = CCSequence::create(CCDelayTime::create(1.5),
                                                         CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::playPuzzleName)),
                                                         CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    this->runAction(playPuzzleNameSound);
    
    
    //set this value true inorder to start game for alphabets
    this->isFirstGameOver = true;
    
    //-------Play Sounds-------//
    CCSequence *Seq2 = CCSequence::create(CCDelayTime::create(5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::anotherChallenge)), NULL);
    this->runAction(Seq2);
    
    CCSequence *Seq3 = CCSequence::create(CCDelayTime::create(6.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::letsDragTheLetters)), NULL);
    this->runAction(Seq3);
    
    
    if(!this->isFivePieceGame) {
        
        //If Easy Level selected,then set touch disabled for skeleton selection buttons
        skeletonFrameVisibleItem->setEnabled(false);
        skeletonFrameInVisibleItem->setEnabled(false);
    }
    
    //Initialize Random Positions for alphabets
    this->initializeRandomPosForAlphabets();
    
    //Initialize Game for alphabets
    const char *imageName = aPuzzleAllTypeDict->valueForKey("alphabetString")->getCString();    
    this->initializeGameForAlphabets(imageName);
}

#pragma mark ------------------- ALPHABETS -------------------
#pragma mark - Initialize
void BBPuzzleGame::initializeRandomPosForAlphabets() {
    
    //Create a Random Position Array
    CCArray *randPosArr;
    
    //Loading Random Positions for Alphabets
    if(BBMainDataManager::sharedManager()->target==kTargetIpad){
        
        randPosArr = (CCArray*)allCardInfoDict->valueForKey("alphabetRandPosArrIpad");
    }
    else if (BBMainDataManager::sharedManager()->target==kTargetIphone){
        
        randPosArr = (CCArray*)allCardInfoDict->valueForKey("alphabetRandPosArrIphone");
    }
    
    int i=0;
    CCObject *alphabetsObj = NULL;
    CCARRAY_FOREACH(randPosArr, alphabetsObj)
    {
        CCString *randPosStr = (CCString *)randPosArr->objectAtIndex(i);
        alphabetRandPosArr->addObject(randPosStr);
        i++;
    }
    
    for (int i=0; i<strName.size(); i++) {
        
        alphabetRandPosArr = BBUtility::shuffleArray(alphabetRandPosArr);
    }
}

void BBPuzzleGame::initializeGameForAlphabets(const char *imageName) {
    
    if (this->isFirstGameOver){
        
        CCDictionary *alphabetsDict = (CCDictionary*)allCardInfoDict->valueForKey("alphabetsDict");
        
        //--------------ALPHABETS-HOLE---------------//
        strName = imageName;
        std::string alphabetHoleSubstr = ""; //for storing imageName
        
        float paddingHole;
        float initialposXHole = 0;
        int totalContentSizeHole = 0;
        
        float scale;
        float yPos;
        
        if (BBMainDataManager::sharedManager()->target==kTargetIpad) {
            
            yPos = 100;
            paddingHole = 10;
            scale = 1;
        }
        else if (BBMainDataManager::sharedManager()->target==kTargetIphone) {
            
            yPos = 25;
            paddingHole = 0;
            scale = 0.7;
        }
        
        for(int i=0; i<strName.size(); i++) {
            
            alphabetHoleSubstr = strName.substr(i,1);
            
            CCDictionary *letterDict = (CCDictionary*)alphabetsDict->valueForKey(alphabetHoleSubstr);
            
            //store Substring into AlphabetHole Substring
            alphabetHoleSubstr = alphabetHoleSubstr+"_hole.png"; //Concatenate
            
            BBPuzzlePartSprite *alphabetHoleSpr = BBPuzzlePartSprite::createWithSpriteFrameName(alphabetHoleSubstr.c_str());
            
            alphabetHoleSpr->matchID = letterDict->valueForKey("matchID")->intValue(); //matchID
            alphabetHoleSpr->setScale(scale); //scaleFactor
            this->addChild(alphabetHoleSpr,2);
            
            alphabetHoleArray->addObject(alphabetHoleSpr); //add sprite into array
            
            if (i==0) {
                initialposXHole = (alphabetHoleSpr->getContentSize().width/2)/2;
            }
            
            initialposXHole = initialposXHole + alphabetHoleSpr->getContentSize().width/2;
            alphabetHoleSpr->setPosition(ccp(initialposXHole, yPos));
            
            initialposXHole = initialposXHole + alphabetHoleSpr->getContentSize().width/2 + paddingHole;
            totalContentSizeHole += alphabetHoleSpr->getContentSize().width + paddingHole;
        }
        
        float diffWidthH = (winsize.width-totalContentSizeHole)/2;
        
        CCObject *holeObj = NULL;
        CCARRAY_FOREACH(alphabetHoleArray, holeObj){
            
            BBPuzzlePartSprite *alphaHoleSpr = (BBPuzzlePartSprite*)holeObj;
            alphaHoleSpr->setPosition(ccp(alphaHoleSpr->getPositionX() + diffWidthH, alphaHoleSpr->getPositionY()));
        }
        
        //-----------------ALPHABETS-COLOR-----------------//
        std::string alphabetColorSubstr = ""; // for storing imageName
        
        for(int i=0; i<strName.size(); i++) {
            
            alphabetColorSubstr = strName.substr(i,1);
            
            CCDictionary *letterDict = (CCDictionary*)alphabetsDict->valueForKey(alphabetColorSubstr);
            
            alphabetColorSubstr = alphabetColorSubstr+"_colorImage.png"; //Concatenate
            
            BBPuzzlePartSprite *alphabetColorSpr = BBPuzzlePartSprite::createWithSpriteFrameName(alphabetColorSubstr.c_str());
            
            alphabetColorSpr->matchID = letterDict->valueForKey("matchID")->intValue();
            alphabetColorSpr->setScale(scale);
            
            char sound[200];
            sprintf(sound,"Sounds/LettersSounds/%s",letterDict->valueForKey("soundName")->getCString());
            alphabetColorSpr->alphabetSoundName = sound; //Sound
            
            CCScaleBy *scale = CCScaleBy::create(1, 1.0);
            CCFadeIn *fadeIn = CCFadeIn::create(1.2);
            CCSpawn *spawnSpr = CCSpawn::createWithTwoActions(scale,fadeIn);
            alphabetColorSpr->runAction(spawnSpr);
            
            this->addChild(alphabetColorSpr,2);
            alphabetsColorArray->addObject(alphabetColorSpr);
            
            //Taking hole Sprites position & place Color sprites on that position
            BBPuzzlePartSprite *holeSpr = (BBPuzzlePartSprite *)alphabetHoleArray->objectAtIndex(i);
            alphabetColorSpr->setPosition(holeSpr->getPosition());
        }
        
        this->canTouchAlphabet = false;
        
        if(!this->isFivePieceGame) {
            //If Easy Level selected,then set touch disabled for skeleton selection buttons
            skeletonFrameVisibleItem->setEnabled(false);
            skeletonFrameInVisibleItem->setEnabled(false);
        }
    }
    
    //getting holeArray count
    this->alphabetsCount = this->alphabetHoleArray->count();
    
    //call to Animation method for dog Hammer Animation
    BBUtility::addGameAnimationsToAnimationCache("BBPuzzleAnimationData.plist");
    
    //call to Dog Animation method
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(2.3f),
                                                 CCCallFunc::create(this,callfunc_selector(BBPuzzleGame::hammerSound)),
                                                 CCDelayTime::create(0.2f),
                                                 CCCallFunc::create(this,callfunc_selector(BBPuzzleGame::hammerAnimation)),
                                                 CCDelayTime::create(1.5f),
                                                 CCCallFunc::create(this,callfunc_selector(BBPuzzleGame::alphabetCallBack)),
                                                  NULL);
    this->runAction(seq);
}


#pragma mark - Alphabets Logic
void BBPuzzleGame::checkIfAlphabetsPlaced(){
    
    bool isAlphabetPartPlaced = false;
    
    CCObject *alphabetHoleObj = NULL;
    CCARRAY_FOREACH(this->alphabetHoleArray, alphabetHoleObj){
        
        BBPuzzlePartSprite *alphabetHoleSpr = (BBPuzzlePartSprite *)alphabetHoleObj;
        
        //calc distance b/w selectedSpr Pos & Hole Pos
        float distance = ccpDistance(selectedPuzzlePart->getPosition(),alphabetHoleSpr->getPosition());
        
        if((distance <= abs(40)) && (alphabetHoleSpr->matchID == selectedPuzzlePart->matchID)){
            
            if(alphabetHoleSpr->isPuzzlePartSolved){
                continue;
            }
            this->selectedPuzzlePart->stopAllActions();
            
            //Move color alphabet to hole position
            CCMoveTo *selectedSpritePos = CCMoveTo::create(0.25, CCPoint(alphabetHoleSpr->getPosition()));
            this->selectedPuzzlePart->runAction(selectedSpritePos);
            this->selectedPuzzlePart->setZOrder(2);
            
            //set colorAlphabet solved true, if part is placed properly
            this->selectedPuzzlePart->isPuzzlePartSolved = true;
            alphabetHoleSpr->isPuzzlePartSolved = true;
            
            //set colorAlphabet part selected false, bcoz v r doin return after every match we need to set this value false although at the end of the method it is set as false
            this->isPuzzlePartSelected = false;
            
            //decrementing the partsArrayCount
            this->alphabetsCount--;
            
            isAlphabetPartPlaced = true;
            
            //Play Alphabet sound once placed correcty
            SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/letters_clickck.mp3");
            
            if(this->alphabetsCount <= 0) {
                
                CCSequence *Seq = CCSequence::create(CCDelayTime::create(0.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::playPuzzleName)), NULL);
                this->runAction(Seq); // After placing the last alphabet give some delay to play puzzleName Sound
            }
            return;
        }
    }
    
    if(isAlphabetPartPlaced == false){
        
        //it will stop all previous actions
        this->selectedPuzzlePart->stopAllActions();
        
        this->wrongAttemptsCount++;
        
        if (this->wrongAttemptsCount%4==0) {
            this->playWrongAttemptSound();
        }
        
        //if not placed properly, move back sprite to it's initial location
        CCMoveTo *selectedSprInitialPos = CCMoveTo::create(0.5,CCPoint(selectedPuzzlePart->initialPosition));
        this->selectedPuzzlePart->runAction(selectedSprInitialPos);
        this->selectedPuzzlePart->setZOrder(2);
    }
    this->isPuzzlePartSelected = false;
}

void BBPuzzleGame::moveAlphabetsAtRandPos(int type) {
    
    this->canTouchAlphabet = false;
    
    CCString *randomPosChangeFactorXStr = (CCString *)aPuzzleAllTypeDict->valueForKey("RandomPosX");
    CCPoint randomPosChangeFactorXPos = CCPointFromString(randomPosChangeFactorXStr->getCString());
    
    CCString *randomPosChangeFactorYStr = (CCString *)aPuzzleAllTypeDict->valueForKey("RandomPosY");
    CCPoint randomPosChangeFactorYPos = CCPointFromString(randomPosChangeFactorYStr->getCString());
    
    float speed = arc4random()%6 * 0.2;
    if (speed == 0.0) {
        speed = 0.2;
    }
    
    //placing color alpabets on the board to be placed into the hole
    int colorAlphabetsIndex = 0;
    CCObject *alphabetColorObj = NULL;
    CCARRAY_FOREACH(this->alphabetsColorArray, alphabetColorObj) {
        
        //converting Puzzle parts Array into Dictionary
        BBPuzzlePartSprite *alphabetColorSpr = (BBPuzzlePartSprite*)alphabetColorObj;
        
        //loading the random Pos
        CCString *aPointStr = (CCString *)alphabetRandPosArr->objectAtIndex(colorAlphabetsIndex);
        CCPoint alphabetColorPoint = CCPointFromString(aPointStr->getCString());
        
        //if selectedSprite pos is {+,-} the randomvalues, then place the parts at random location
        alphabetColorPoint = CCPoint(alphabetColorPoint.x + BBUtility::getRandomNumberBetween(randomPosChangeFactorXPos.x, randomPosChangeFactorXPos.y), alphabetColorPoint.y + BBUtility::getRandomNumberBetween(randomPosChangeFactorYPos.x, randomPosChangeFactorYPos.y));
        
        alphabetColorSpr->initialPosition = alphabetColorPoint;
        
        //Rotate & Move Alphabets to specific location
        CCMoveTo *moveColorSpr = CCMoveTo::create(speed, alphabetColorPoint);
        CCRotateBy *rotateColorSpr = CCRotateBy::create(0.4, 360);
        
        //SCALE
        CCActionInterval *actionTo;
        CCActionInterval *actionBack;
        
        if(BBMainDataManager::sharedManager()->target==kTargetIpad) {
            
            actionTo = CCScaleTo::create(0.9f, 1.3f);
            actionBack = CCScaleTo::create(0.9f, 1.0f);
        }
        else if (BBMainDataManager::sharedManager()->target==kTargetIphone) {
            
            actionTo = CCScaleTo::create(0.9f, 1.3f);
            actionBack = CCScaleTo::create(0.9f, 0.7f);
        }
        
        //EASE BOUNCE
        CCEaseBounceIn *bounceIn = CCEaseBounceIn::create(actionTo);
        CCEaseBounceOut *bounceback = CCEaseBounceOut::create(actionBack);
        
        CCAction *seq = NULL;
        if(type==0) { //Bounce Effect
            
            seq = CCSequence::create(CCSpawn::create(moveColorSpr, rotateColorSpr, NULL), bounceIn, bounceback,CCDelayTime::create(0.8),CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::resetAlphabetsTouch)), NULL);
        }
        else if(type==1) { //Elastic effect
            
            seq = CCSequence::create(CCSpawn::create(moveColorSpr, rotateColorSpr, NULL), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::move)),CCDelayTime::create(0.8),CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::resetAlphabetsTouch)), NULL);
        }
        else if(type==2) { //Rotate effect
            
            seq = CCSequence::create(CCSpawn::create(moveColorSpr, rotateColorSpr, NULL), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::rotate)),CCDelayTime::create(1.8), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::resetAlphabetsTouch)), NULL);
        }
        else if(type==3) { //Jump Effect
            
            seq = CCSequence::create(CCSpawn::create(moveColorSpr, rotateColorSpr, NULL), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::jump)),CCDelayTime::create(1),CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::resetAlphabetsTouch)), NULL);
        }
        else if(type==4) { //Skew Effect
            
            seq = CCSequence::create(CCSpawn::create(moveColorSpr, rotateColorSpr, NULL), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::skew)),CCDelayTime::create(2),CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::resetAlphabetsTouch)), NULL);
        }
        
        alphabetColorSpr->runAction(seq);
        alphabetColorSpr->isPuzzlePartSolved = false;
        
        //incrementing colorAlphabetsIndex
        colorAlphabetsIndex++;
    }
}

void BBPuzzleGame::resetAlphabetsTouch() {
    
    this->canTouchAlphabet = true;
}


#pragma mark - Alphabets Movement Actions
void BBPuzzleGame::move(CCObject *sender) {
    
    BBPuzzlePartSprite *SprMove = (BBPuzzlePartSprite*)sender;
    
    //MOVE
    CCMoveTo *moveTo = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+30, SprMove->getPosition().y+30));
    CCMoveTo *moveBack = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-25, SprMove->getPosition().y-25));
    CCMoveTo *moveTo1 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+22, SprMove->getPosition().y+22));
    CCMoveTo *moveBack1 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-15, SprMove->getPosition().y-15));
    CCMoveTo *moveTo2 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+15, SprMove->getPosition().y+15));
    CCMoveTo *moveBack2 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-5, SprMove->getPosition().y-5));
    
    CCSequence *moveSeq = CCSequence::create(moveTo, moveBack, moveTo1, moveBack1, moveTo2, moveBack2, NULL);
    SprMove->runAction(moveSeq);
}

void BBPuzzleGame::jump(CCObject *sender) {
    
    BBPuzzlePartSprite *SprJump = (BBPuzzlePartSprite*)sender;
    
    //MOVE (used to give same effect as that of jump)
    CCMoveTo *moveUp = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y+30));
    CCMoveTo *moveDown = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y-20));
    CCMoveTo *moveUp1 = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y+20));
    CCMoveTo *moveDown1 = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y-10));
    CCMoveTo *moveUp2 = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y+10));
    CCMoveTo *moveDown2 = CCMoveTo::create(0.2, ccp(SprJump->getPosition().x,SprJump->getPosition().y-5));
    
    CCSequence *moveUpDownSeq = CCSequence::create(moveUp, moveDown, moveUp1, moveDown1, moveUp2, moveDown2,NULL);
    
    SprJump->runAction(moveUpDownSeq);
}

void BBPuzzleGame::rotate(CCObject *sender) {
    
    BBPuzzlePartSprite *SprRotate = (BBPuzzlePartSprite*)sender;
    
    //ROTATE
    CCRotateTo *rotateToLeft = CCRotateTo::create(0.2, 45);
    CCRotateTo *rotateToRight = CCRotateTo::create(0.2, -45);
    CCRotateTo *rotateToLeft1 = CCRotateTo::create(0.2, 28);
    CCRotateTo *rotateToRight1 = CCRotateTo::create(0.2, -28);
    CCRotateTo *rotateToLeft2 = CCRotateTo::create(0.2, 13);
    CCRotateTo *rotateToRight2 = CCRotateTo::create(0.2, -13);
    CCRotateTo *rotateBack = CCRotateTo::create(0.2, 0);
    
    CCSequence *rotateSeq = CCSequence::create(rotateToLeft, rotateToRight, rotateToLeft1, rotateToRight1,rotateToLeft2, rotateToRight2,rotateBack, NULL);
    SprRotate->runAction(rotateSeq);
}

void BBPuzzleGame::skew(CCObject *sender) {
    
    BBPuzzlePartSprite *SprSkew = (BBPuzzlePartSprite*)sender;
    
    //SKEW
    CCSkewBy *skewBy = CCSkewBy::create(0.3f, 20, 0);
    CCSkewBy *skewBy1 = CCSkewBy::create(0.3, -20, 20);
    CCSkewBy *skewBack = CCSkewBy::create(0.3, 0, -20);
    CCTintBy *tintTo = CCTintBy::create(0.5, 255, 0, 0);
    CCSequence *skewSeq = CCSequence::create(skewBy, skewBy1, skewBack, tintTo, NULL);
    SprSkew->runAction(skewSeq);
}


#pragma mark - Bacci Methods
void BBPuzzleGame::hammerAnimation() {
    
    dogBase->setVisible(false);
    
    //Hammer Animation
    bazziTalking->runHammerAnimation();
    
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(CCDelayTime::create(2.0), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::setDogVisibility)));
    this->runAction(seq);
}

void BBPuzzleGame::hammerSound() {
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/hammer1.mp3");
}

void BBPuzzleGame::setDogVisibility() {
    
    bazziTalking->removeHammerAnimation();
    
    //Setting Visibility for Dog & it's base incase of long letters
    const char *imageName = aPuzzleAllTypeDict->valueForKey("alphabetString")->getCString();
    CCLog("imageName %s",imageName);
    
    if(BBMainDataManager::sharedManager()->target==kTargetIpad) {
        
        if (strcmp(imageName, "BUTTERFLY") == 0) {
            
            dogBase->setVisible(false);
            bazziTalking->setDogVisibleFalse();
        }
        else {
            
            dogBase->setVisible(true);
        }
    }
    else {
        
        dogBase->setVisible(false);
        
        if (strcmp(imageName, "BUTTERFLY") == 0) {
            
            bazziTalking->setDogVisibleFalse();
        }
    }
}

void BBPuzzleGame::stopDogTalking(){
    
    bazziTalking->stopDogTalking();
    BBPuzzleDataManager::sharedManager()->canTapDog = true;
    this->setTouchEnabled(true);
    this->isDogTalking = false;
}

#pragma mark - Alphabets Sounds
void BBPuzzleGame::anotherChallenge() {
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/10_anotherchallenge_puzzle.mp3");
    
    this->isDogTalking = true;
    
    bazziTalking->startDogTalking();
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(3), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGame::letsDragTheLetters() {
    
    this->isDogTalking = true;
    
    int rand_no = arc4random() % 4;
    if (rand_no == 0 || rand_no == 1) {
        
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/letsdragtheletters.mp3");
    }
    else if (rand_no == 2) {
        
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/11_cleanupbacciz_puzzle.mp3");
    }
    else if (rand_no == 3 || rand_no == 4) {
        
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/11_learnwhileyoufiz_puzzle_ltrs.mp3");
    }
}

void BBPuzzleGame::playPuzzleName() {
    
    //Dog Talking
    bazziTalking->startDogTalking();
    
    this->isDogTalking = true;
    
    char puzzleSound[150];
    sprintf(puzzleSound,"Sounds/PuzzlesNames/%s.mp3",BBPuzzleDataManager::sharedManager()->puzzleName);
    
    CCLOG("%s",puzzleSound);
    
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect(puzzleSound);
    
    if (this->alphabetsCount <= 0) {
        
        CCSequence *Seq = CCSequence::create(CCDelayTime::create(1), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::puzzleAlphabetsGameWon)), NULL);
        this->runAction(Seq);
    }
}

void BBPuzzleGame::letterSound() {
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect(this->selectedPuzzlePart->alphabetSoundName.c_str()); //Alphabet Sound
    
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(0.1), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    this->runAction(seq);
}

void BBPuzzleGame::enableRestartBtn() {
    
    restartBtn->setEnabled(true);
}

void BBPuzzleGame::playWrongAttemptSound() {
    
    //Bacci Talking
    this->isDogTalking = true;
    bazziTalking->startDogTalking();
    
    CCSequence *playPuzzleNameSound;
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    int rand_No = arc4random()%4;
    if (rand_No == 0 ) {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/onemoretime.mp3");
        playPuzzleNameSound = CCSequence::create(CCDelayTime::create(0.5),
                                                 CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    }
    else if (rand_No == 1) {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/try again.mp3");
        playPuzzleNameSound = CCSequence::create(CCDelayTime::create(0.5),
                                                 CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    }
    else {
        
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/FailedSounds/tryagainyoucandoit.mp3");
        playPuzzleNameSound = CCSequence::create(CCDelayTime::create(2),
                                                 CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    }
    this->runAction(playPuzzleNameSound);
}


#pragma mark - GameWon
void BBPuzzleGame::puzzleAlphabetsGameWon() {
    
    this->isGameOver = true;
    this->isDogTalking = true;
    
    if (BBMainDataManager::sharedManager()->target==kTargetIpad) {
        
        dogBase->setVisible(true);
        bazziTalking->setDogTalkingVisibility();
        
        //play sounds with banner
        BBAllGamesFunctionSharedManager::sharedManager()->addCongratulationBanner(true, CCPoint(510, 638));
    }
    else {
        
        dogBase->setVisible(false);
        bazziTalking->setDogTalkingVisibility();
        
        //play sounds with banner
        BBAllGamesFunctionSharedManager::sharedManager()->addCongratulationBanner(true, CCPoint(255, 260));
    }
    
    //Add a Star
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::addNewStar)), NULL);
    this->runAction(Seq);
}



#pragma mark ----------------- GENERAL METHODS -----------------
#pragma mark - Touches methods
void BBPuzzleGame::ccTouchesBegan(CCSet *pTouches, CCEvent *pEvent)
{
    CCTouch* touch = (CCTouch*)(pTouches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
    
    // Play the Dog Talking Sounds when you tap the Dog
    if(bazziTalking->animatedDog->boundingBox().containsPoint(location)) {
        
        this->stopActionByTag(kIntroductionSoundTag);
        
        if (canDogTalk) {
            
            canDogTalk = false;
            
            if (strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"FivePiece")==0 && this->isFirstGameOver == false) {
                
                this->isDogTalking = true;
                
                this->dogTapSoundsFor5Pieces(); //play Sounds for 5 pieces
            }
            else {
                
                this->isDogTalking = true;
                
                if (this->isFirstGameOver) {
                    return;
                }
                this->dogTapSounds(); //play Sounds for 4,9 & 12 pieces
            }
        }
    }
    else if (bazziTalking->animatedDog->boundingBox().containsPoint(location) && this->isGameOver) {
        
        bazziTalking->stopDogTalking();
    }
    
    
    if(this->isFirstGameOver == false) //PUZZLES
    {
        CCObject *puzzlePartObj = NULL;
        CCARRAY_FOREACH(this->puzzlePartsArr, puzzlePartObj)
        {
            BBPuzzlePartSprite *puzzlePartSpr = (BBPuzzlePartSprite *)puzzlePartObj;
            
            if(puzzlePartSpr->isPuzzlePartSolved)
                continue;
            
            if (puzzlePartSpr->boundingBox().containsPoint(location)) {
                
                this->isPuzzlePartSelected = true;
                this->selectedPuzzlePart = puzzlePartSpr;
                
                SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/drag1_rough.mp3"); //Drag pieces Sound
            }
        }
    }
    else if(this->isFirstGameOver) //Alphabets
    {
        if(!canTouchAlphabet){
            return;
        }
        
        CCObject *alphabetPartObj = NULL;
        CCARRAY_FOREACH(this->alphabetsColorArray, alphabetPartObj)
        {
            BBPuzzlePartSprite *alphabetsColorSpr = (BBPuzzlePartSprite *)alphabetPartObj;
            
            if(alphabetsColorSpr->isPuzzlePartSolved)
                continue;
            
            if (alphabetsColorSpr->boundingBox().containsPoint(location)) {
                
                this->isPuzzlePartSelected = true;
                this->selectedPuzzlePart = alphabetsColorSpr;
                
                //stop other sounds when you are playing alphabet sound
                SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
                
                bazziTalking->startDogTalking();
                
                CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(CCDelayTime::create(0.15), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::letterSound)));
                this->runAction(seq);
            }
        }
    }
    
    if (this->isPuzzlePartSelected) {
        this->selectedPuzzlePart->setZOrder(10);
    }
}

void BBPuzzleGame::ccTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent* event)
{
    if(!this->canTouchAlphabet){
        return;
    }
    
    CCTouch* touch = (CCTouch*)( touches->anyObject());
    CCPoint location = touch->getLocationInView();
    location = CCDirector::sharedDirector()->convertToGL(location);
    
    //PUZZLES
    if (this->isPuzzlePartSelected) {
        this->selectedPuzzlePart->setPosition(location);
    }
    isDogTalking = true;
}

void BBPuzzleGame::ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event)
{
    //checking conditions if Part is placed or not
    if (this->isPuzzlePartSelected){
        
        if (this->isFirstGameOver) //PUZZLE ALPHABETS
        {
            if(!this->canTouchAlphabet){
                return;
            }
            this->checkIfAlphabetsPlaced();
        }
        else {
            this->checkingPartsGotPlaced(); //PUZZLE PARTS
        }
    }
}


#pragma mark - Menu Functions
void BBPuzzleGame::checkSkeletonFrameBtn(CCMenuItemSprite *sender) {
    
    int tag = sender->getTag();
    
    switch (tag)
    {
        case 1: skeletonFrameInVisibleItem->selected();
                skeletonFrameVisibleItem->unselected();
            
                //Dog Talking while playing Hint Sound
                this->stopActionByTag(kHint_NoHintSoundTag);
                bazziTalking->startDogTalking();
        {
                CCSequence *playPuzzleNameSound = CCSequence::create(CCDelayTime::create(0.3),
                                                     CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
            playPuzzleNameSound->setTag(kHint_NoHintSoundTag);
                this->runAction(playPuzzleNameSound);
        }
                SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
                stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/hint.mp3");
                
                this->loadLastSprSelected(tag);
                break;
                
        case 2: skeletonFrameVisibleItem->selected();
                skeletonFrameInVisibleItem->unselected();
            
                //Dog Talking while playing Hint Sound
                this->stopActionByTag(kHint_NoHintSoundTag);
        {
            CCSequence *playPuzzleNameSound = CCSequence::create(CCDelayTime::create(0.3),
                                                                 CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
            playPuzzleNameSound->setTag(kHint_NoHintSoundTag);
            this->runAction(playPuzzleNameSound);
        }
                SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
                stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/nohint.mp3");
                
                this->loadLastSprSelected(tag);
                break;
            
        default:break;
    }
}

void BBPuzzleGame::alphabetCallBack(CCObject *sender) {
    
    int randomActionTag = arc4random() % 5;
    
    //0 Bounce Effect
    //1 Elastic Effect
    //2 Rotate Effect
    //3 Jump Effect
    //4 Skew Effect
    
    this->moveAlphabetsAtRandPos(randomActionTag);
}

void BBPuzzleGame::animateBackButton()
{
    CCMenuItemSprite *bt = (CCMenuItemSprite*)inGameLevelMenu->getChildByTag(1000);
    
    
    CCScaleTo *scaleTo1 = CCScaleTo::create(0.25, 0.5);
    CCScaleTo *scaleTo2 = CCScaleTo::create(0.25, 1.0);
    
//    CCScaleTo *scaleTo = CCScaleTo::create(0.5, 0.8);
//    CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
//    
    CCFiniteTimeAction *seq = CCSequence::create(scaleTo1, scaleTo2, CCCallFunc::create(this,callfunc_selector(BBPuzzleGame::backToPuzzleGameSelection)), NULL);
    
    bt->runAction(seq);
    
    

}

void BBPuzzleGame::backToPuzzleGameSelection() {
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    //Setting bool Value for puzzle Game So as to give the star only when game over
    if (this->isGameOver) {
        
        BBPuzzleDataManager::sharedManager()->isPuzzleGameOver = true;
    }
    else if (!this->isGameOver) {
        
        BBPuzzleDataManager::sharedManager()->isPuzzleGameOver = false;
    }
    
    BBPuzzleDataManager::sharedManager()->canPlayPuzzleGamePlaySound = false;
    BBPuzzleDataManager::sharedManager()->canPlayDifficultySound = false;
    
    CCDirector::sharedDirector()->replaceScene(BBPuzzleGameSelection::scene());
}

void BBPuzzleGame::restartPuzzleGameScene() {

    restartBtn->setEnabled(false),
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/replay.mp3");
    
    //Replacing the Restart Scene
    CCDirector::sharedDirector()->replaceScene(BBPuzzleGame::scene());
    
    CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(2),
                                                 CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::enableRestartBtn)), NULL);
    this->runAction(seq);
}


#pragma mark - Add Stars
void BBPuzzleGame::addNewStar() {
    
    //Sound for Star
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/yougetastar.mp3");
    
    //Add a Star Image on the top
    CCSprite *starSprite = CCSprite::createWithSpriteFrameName("star_yellow.png");
    if(BBMainDataManager::sharedManager()->target==kTargetIpad)
    {
        starSprite->setPosition(ccp(504,735));
    }
    else
    {
        starSprite->setPosition(ccp(240,305));
    }
    this->addChild(starSprite, 10);
    
    
    //Add an Award on the screen
    if(BBPuzzleDataManager::sharedManager()->starCount == 11){
        
        puzzleWonAward->setVisible(true);
        CCScaleTo *scaleTo = CCScaleTo::create(0.5, 1.2);
        CCActionInterval* move_ease_in = CCEaseIn::create((CCActionInterval*)(scaleTo->copy()->autorelease()), 2.5f);
        puzzleWonAward->runAction(move_ease_in);
    }
    else {
        
        puzzleWonAward->setVisible(false);
    }
    
    
    //Apply Effect for Star
    CCRotateTo *rotate = CCRotateTo::create(0.5, 720);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.16, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.16, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIn = CCFadeIn::create(0.1);
    
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq, NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut, fadeIn, NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut, fadeIn, NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr, seq1, CCDelayTime::create(0.25), seq2, NULL);
    starSprite->runAction(seq3);
    
    //If Level Five is Selected, then Skip playing this sound
    if (strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"FivePiece")==0) {
        
        //delay is kept for stop Dog Talking, So that the dog will speak the star sound properly
        CCFiniteTimeAction *Seq = CCSequence::create(CCDelayTime::create(1),
                                             CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
        this->runAction(Seq);
    }
    else {
        
        CCFiniteTimeAction *seq = CCSequence::create(CCDelayTime::create(1.5), CCCallFuncN::create(this, callfuncN_selector(BBPuzzleGame::tapToReplay)),NULL);
        this->runAction(seq);
    }
}


#pragma mark - Game Over Sounds
void BBPuzzleGame::tapToReplay() {
    
    //Implement the sound only 2 times since the entire game launches 
    BBPuzzleDataManager::sharedManager()->gamePlaySoundSessionCount++;
    
    if (BBPuzzleDataManager::sharedManager()->gamePlaySoundSessionCount > 2) {
        
        bazziTalking->stopDogTalking();
        return;
    }
    
    //Bacci Talking
    bazziTalking->startDogTalking();
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/15_taptoreplayit.mp3");
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2.5), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::goBackToChooseOtherPuzzles)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGame::goBackToChooseOtherPuzzles() {
        
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/20_gobacktochooseother_puzzle.mp3");
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(3), CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::chooseHardLvlSound)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGame::chooseHardLvlSound() {
    
    // If empty box is already selected, then don't play this sound
    if (!isEmptyBoxSelected) {
        
        bazziTalking->stopDogTalking();
    }
    else {
        
        SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
        stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/23_youwantitharder_levels.mp3");
        
        CCSequence *Seq2 = CCSequence::create(CCDelayTime::create(2),
                                              CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::applyBlinkAction)),
                                              CCDelayTime::create(0.5),
                                              CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::tapNoHintBoxSound)), NULL);
        this->runAction(Seq2);
    }
}

void BBPuzzleGame::tapNoHintBoxSound() {
    
    SimpleAudioEngine::sharedEngine()->stopEffect(stopSound);
    stopSound = SimpleAudioEngine::sharedEngine()->playEffect("Sounds/Narration/24_tapnohintbox_puzzle.mp3");
    
    CCSequence *Seq = CCSequence::create(CCDelayTime::create(2),
                                         CCCallFunc::create(this, callfunc_selector(BBPuzzleGame::stopDogTalking)), NULL);
    this->runAction(Seq);
}

void BBPuzzleGame::applyBlinkAction() {
    
    CCActionInterval *actionTo = CCScaleTo::create(0.9f, 1.3f);;
    CCActionInterval *actionNormal = CCScaleTo::create(0.9f, 1.0f);
    
    CCEaseIn *easeIn = CCEaseIn::create(actionTo, 2);
    CCEaseIn *easeNormal = CCEaseIn::create(actionNormal, 2);
    
    CCFiniteTimeAction *seq = CCSequence::create(easeIn, easeNormal, NULL);
    CCRepeat *action = CCRepeat::create(seq, 3);
    
    skeletonFrameInVisibleItem->runAction(action);
}


#pragma mark - Dealloc
void BBPuzzleGame::onExit() {
    
    CCLayer::onExit();
    if(strcmp(BBPuzzleDataManager::sharedManager()->puzzleDifficultyTypeName,"FivePiece")==0)
    {
        char spriteName[200];
        sprintf(spriteName,"Puzzle/GamePlaySpriteSheets/BBPuzzleGame/%s/%s",BBPuzzleDataManager::sharedManager()->puzzleName,aPuzzleDict->valueForKey("spriteSheetPath")->getCString());
        CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile(spriteName);
    }
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GamePlaySpriteSheets/Parts/Puzzle_Parts.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("BBSharedResources/spritesheets/BBGameUISpriteSheet/BBGameUI.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GamePlaySpriteSheets/BBPuzzleGame/PuzzleGamePlay.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("GamePlaySpriteSheets/BBPuzzleGame/BBHammerAnimation.plist");
        
    CocosDenshion::SimpleAudioEngine::sharedEngine()->stopAllEffects();
    WrapperHelper::endTimedEventWithName(levelName);
}

BBPuzzleGame::~BBPuzzleGame(){
    
    //Delete Dog from memory
    delete bazziTalking;
    bazziTalking = NULL;

    
    //releasing the PuzzleGame Array's
    CC_SAFE_RELEASE_NULL(this->puzzlePartsArr);
    CC_SAFE_RELEASE_NULL(this->randPosArray);
    CC_SAFE_RELEASE_NULL(allCardInfoDict);
    
    CC_SAFE_RELEASE_NULL(this->alphabetRandPosArr);
    CC_SAFE_RELEASE_NULL(this->alphabetsColorArray);
    CC_SAFE_RELEASE_NULL(this->alphabetHoleArray);
        
    this->puzzlePartsArr = NULL;
    this->randPosArray = NULL;
    
    this->alphabetHoleArray = NULL;
    this->alphabetsColorArray = NULL;
    this->alphabetRandPosArr = NULL;
}
