//
//  BBPuzzleGame.h
//  Puzzles
//
//  Created by Vivek on 27/05/13.
//
//

#ifndef Puzzles_BBPuzzleGame_h
#define Puzzles_BBPuzzleGame_h

#include "cocos2d.h"
#include "BBPuzzlePartSprite.h"
#include "BBPuzzleGameSelection.h"
#include <iostream>
#include "BBGameManager.h"
#include "BBPuzzlePartSprite.h"
#include "BBPuzzleGame.h"
#include "cocos-ext.h"
#include "CCNodeLoader.h"
#include "BBAllGamesFunctionSharedManager.h"
#include "BacciTalking.h"

using namespace cocos2d;
USING_NS_CC;

class BBPuzzleGame : public cocos2d::CCLayer
{
public:

    //Default
    BBPuzzleGame();
    virtual ~BBPuzzleGame();
    static CCScene* scene();
    virtual void onEnter();
    virtual void onExit();
    
    //---------------------PUZZLES---------------------//
    //Initialize
    void initializeGameUI();
    void initializeDataPlist();
    void initializeDogWithBase();
    void initializeVariables();
    void addingMinasingSmallRandPosFor5Piece();
    void initializeRandPosFor5Piece();
    void createGreyColorBG();
    void settingThePartsRandomPosition(const char *fileName);
    
    //Game Bg
    CCSprite *puzzleSkeletonSpr;
    CCSprite *skeletonBtnSelectionMarkSpr;
        
    //Game Data
    CCSize winsize;
    
    CCArray *puzzlePartsArr;
    CCArray *gameWonSprArray;
    CCArray *randPosArray;
    
    CCPoint distBtwnSelectedSprAndSkeleton;
    int partsArrayCount;
    
    bool isFivePieceGame;
    bool isFirstGameOver;
    bool isPuzzlePartSelected;
    
    const char *levelName;
    const char *puzzleSkeleton;
    
    BBPuzzlePartSprite *selectedPuzzlePart;
    BBPuzzlePartSprite *partSpr;
    
    //Utility
    void checkingPartsGotPlaced();
    void puzzlePartsGameWon();
    int* intArrToSwapNumber(int GameCards[10]);
    
    //Menu Items & it's methods
    CCMenuItemSprite *skeletonFrameVisibleItem;
    CCMenuItemSprite *skeletonFrameInVisibleItem;
    CCMenuItemSprite *restartBtn;
    
    void checkSkeletonFrameBtn(CCMenuItemSprite *sender);
    void setVisibilityForSkeletonFrame(int tag);
    void loadLastSprSelected(int tag);
    
    //------------------------- ALPHABETS
    //Variables
    int alphabetsCount;
    int wrongAttemptsCount;
    
    bool canTouchAlphabet;
    std::string strName;
    
    CCArray *alphabetHoleArray;
    CCArray *alphabetsColorArray;
    
    //Initialize
    void initializeGameForAlphabets(const char *imageName);
    void initializeRandomPosForAlphabets();
    
    //Utility
    void checkIfAlphabetsPlaced();
    void resetAlphabetsTouch();
    void moveAlphabetsAtRandPos(int type);
    void hammerAnimation();
    void setDogVisibility();
    void puzzleAlphabetsGameWon();
    
    //Menu Methods
    void alphabetCallBack(CCObject *sender);
    void move(CCObject *sender);
    void jump(CCObject *sender);
    void rotate(CCObject *sender);
    void skew(CCObject *sender);
    
    
    //Methods
    CCArray* shuffleArray(CCArray *cardsToShuffle);
    int* randomizeInt(int GameCards[15]);
    void restartPuzzleGameScene();
    void backToPuzzleGameSelection();
    
    //Sounds
    unsigned int stopSound;
    void completePuzzle();
    void easyToStartWithCornerPieces();
    void anotherChallenge();
    void letsDragTheLetters();
    
    void letterSound();
    void hammerSound();
    void alphabetSound();
    void goBackToChooseHarderLevels();
    void playWrongAttemptSound();
    void playPuzzleName();
    
    void tapToReplay();
    void goBackToChooseOtherPuzzles();
    void chooseHardLvlSound();
    void tapNoHintBoxSound();
    void applyBlinkAction();
    
    //--------GENERAL-------------//
    //Variables
    CCDictionary *allCardInfoDict;
    CCDictionary *aPuzzleDict;
    CCDictionary *aPuzzleAllTypeDict;
    CCArray *alphabetRandPosArr;
    
    //Methods
    CCArray *starArray;
    CCSprite *dogBase;
    bool isDogTalking;
    bool isGameOver;
    bool isEmptyBoxSelected;
    
    BacciTalking *bazziTalking;
    
    CCSprite *puzzleWonAward;
    void addNewStar();
    
    void dogTapSounds();
    void dogTapSoundsFor5Pieces();
    bool canDogTalk;
    void canDogTalkAgain();
    void stopDogTalking();
    void enableRestartBtn();
    
    //-------------------------TOUCH
    virtual void ccTouchesEnded(CCSet* touches, CCEvent* event);
    virtual void ccTouchesBegan(CCSet* touches, CCEvent* event);
    virtual void ccTouchesMoved(CCSet* touches, CCEvent* event);
    
    CCMenu *inGameLevelMenu;
    void animateBackButton();
    
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(BBPuzzleGame);
};

#endif
