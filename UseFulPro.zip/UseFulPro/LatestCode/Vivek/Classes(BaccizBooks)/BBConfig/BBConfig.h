//
//  BBConfig.h
//  BaccizBooks
//
//  Created by Manjunatha Reddy on 21/01/13.
//
//

#ifndef BaccizBooks_BBConfig_h
#define BaccizBooks_BBConfig_h

enum GamePlaySelection{
    kTicToeGamePlay=1,
    kMatchGamePlay=2,
};


#define kBacciIdleTime 4

#endif
