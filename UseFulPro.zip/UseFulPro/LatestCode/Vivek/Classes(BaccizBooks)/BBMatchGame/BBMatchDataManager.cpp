//
//  BBMatchDataManager.cpp
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/3/13.
//
//

#include "BBMatchDataManager.h"
#include "cocos2d.h"

static BBMatchDataManager *gSharedManager = NULL;

BBMatchDataManager::BBMatchDataManager(void)
{
    this->currentLevel=1;
    
    this->starCount=0;
    this->isNewGame=true;
}

BBMatchDataManager* BBMatchDataManager::sharedManager(void) {
    
	BBMatchDataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new BBMatchDataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool BBMatchDataManager::init(void) {
	return true;
}

