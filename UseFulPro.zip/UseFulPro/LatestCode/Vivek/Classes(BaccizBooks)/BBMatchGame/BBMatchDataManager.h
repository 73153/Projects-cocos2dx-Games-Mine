//
//  BBMatchDataManager.h
//  BaccizBooks
//
//  Created by Manuel Escalante on 6/3/13.
//
//

#ifndef BaccizBooks_BBMatchDataManager_h
#define BaccizBooks_BBMatchDataManager_h

#include "cocos2d.h"


USING_NS_CC;


class BBMatchDataManager: public cocos2d::CCObject  {
    
private:
    
    BBMatchDataManager(void);
    
public:
    
    bool init(void);
    static BBMatchDataManager* sharedManager(void);
    
    const char *gameLevelName;
    int currentLevel;
    
    int starCount;
    bool isNewGame;

    TargetPlatform target;
};


#endif
