//
//  LMGameManager.cpp
//  LostMonster
//
//  Created by Krithik B on 8/28/12.
//  Copyright (c) 2012 iCRG Labs. All rights reserved.
//

#include <iostream>
#include "BBGameManager.h"

BBGameManager::BBGameManager() {
    
    printf("Game Manager initiating");
}

BBGameManager::~BBGameManager() {
    
    //delete this->currentGame;
    printf("destructor Game Manager");
}

