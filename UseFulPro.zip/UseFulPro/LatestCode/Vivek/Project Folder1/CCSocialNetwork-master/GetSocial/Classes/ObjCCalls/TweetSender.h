//
//  TweetSender.h
//  GetSocial
//
//  Created by Mikel Eizagirre on 14/09/12.
//
//

@interface TweetSender : UIViewController 

+ (void) trySendATweet;

@end
