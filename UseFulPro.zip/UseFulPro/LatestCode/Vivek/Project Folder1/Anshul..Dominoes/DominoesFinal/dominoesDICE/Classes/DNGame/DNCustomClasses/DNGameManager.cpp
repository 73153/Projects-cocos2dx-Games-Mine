//
//  DNGameManager.cpp
//  Dominoes
//
//  Created by ICRG LABS on 10/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "DNGameManager.h"

DNGameManager::DNGameManager(void) {
    
    printf("Game Manager initiating");
}

DNGameManager::~DNGameManager(void) {
    
    printf("destructor Game Manager");
}

