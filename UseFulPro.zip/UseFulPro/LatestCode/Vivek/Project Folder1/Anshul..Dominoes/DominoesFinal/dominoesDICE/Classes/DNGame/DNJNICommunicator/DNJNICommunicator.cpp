//
//  DNJNICommunicator.cpp
//  Dominoes
//
//  Created by ICRG LABS on 07/09/12.
//
//

#include "DNJNICommunicator.h"

DNJNICommunicator::DNJNICommunicator(void) { }

DNJNICommunicator::~DNJNICommunicator(void) { }

void DNJNICommunicator::getArray(CCArray *array) {
    
    
}