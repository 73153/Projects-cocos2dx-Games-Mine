# MultiTablesView

Multi-Levels Table View used to stack table views horizontally.
This project adds a notion of levels to the actual UITableView logic.