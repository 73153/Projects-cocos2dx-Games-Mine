//
//  dominoesDICEAppController.h
//  dominoesDICE
//
//  Created by Vivek on 28/12/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
