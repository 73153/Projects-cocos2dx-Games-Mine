//
//  CTAGameScene.h
//  CountTheAnimals
//
//  Created by Vivek on 26/06/13.
//
//

#ifndef __CTAGameScene_SCENE_H__
#define __CTAGameScene_SCENE_H__

#include "cocos2d.h"
#include "CTASprite.h"
#include "BacciTalking.h"

USING_NS_CC;

class CTAGameScene : public cocos2d::CCLayer
{
public:
    
    CTAGameScene();
    ~CTAGameScene();
    
    virtual void onEnter();
    virtual void onExit();
    
    static cocos2d::CCScene* scene();
    
    //Initiliase
    void initialiseVariables();
    void initialiseGame();
    void initialiseSounds();
    void intialiseGameUI();
    
    //Variables
    CCSize winSize;
    
    CCDictionary *gameDict;
    CCDictionary *languageDict;
    CCDictionary *languageNameDict;
    
    int starCount;
    int levelNumber;
    int tapcount;
    int finalAnimalCount;
    int dogAnimationCount;
    
    CCArray *animalsArr;
    CCArray *numberOfAnimalToCreateArr;
    CCArray *animalScaleArr;
    
    CCMenuItemSprite *playAgainMenuItem;
    CCMenuItemSprite *gobackMenuItem;
    CCMenuItemSprite *restartMenuItem;
    CCSprite *award;
    
    bool isGameRestarted;
    bool canTapAnimalSpr;
    bool isGameCompleted;
    bool isGameOver;
    
    const char *animalNameForLable;
    const char *animalSound;
    const char *imageName;
    const char *animalSpeakSound;
    
    
    //Lables
    void setLabel(const char *labelName);
    CCLabelTTF *animalLable;
    CCLabelTTF *animalLableWithCount;

    //dog Talking Animation
    void startDogTalking();
    void stopDogTalkingAnimation();
    BacciTalking *bazziTalking;
    

    //particle
    CCParticleSystem *addParticleEffectToTexture;
    
    //Stars Addition
    void addStars();
    void addNewStar();
    CCArray *starArray;
    
    //layer
    CCLayer *animalLayer;
    
    //Replace
    void goBackToGameSelectionScene();
    
    //add congratulation Baanner
    void addCongratulationBnner();

    
    //Game win
    void gameWinFunction();
    void checkForGoingToNextLevel();
    void gameOverScene();
    void addBanner();
    void youGetTrophySound();
    void restartFromFirstLevel();
    
    //Animal Sprite
    void addAnimalSprites();
    void scaleNumbers();
    int *store_randomArray;
    int uniqueRandomNumberForAnimalName;
    
    CCArray *noOfAnimalsOnScreenArr;
    CCArray *animalNameArr;
    CCDictionary *animalNamesDict;
    CCArray *uniqueRandomNumberForAnimalArr;
    
    //making touches enable true
    void enableTouch();
    void canTapAnimalMakingFalse();
    void canTaPAnimalMakingTrue();
    
    //Menu Items
    void restartLevel();
    void goToNextLevel();
    
    //Clear the Screen before going to new level
    void removeAllAnimalFromScene();
    
    int getRandomNumberBetween(int min, int max);
    int* randomizeInt(int noOfAnimalSprites[15]);
    
    //Actions
    void randomActionForSprite();
    void move(CCObject *sender);
    void bounceOut(CCObject *sender);
    void cardinal(CCObject *sender);
    void rotate(CCObject *sender);
   
    //floating Action
    void initialAnimation();
    void stayAnimation();
    
    //Sounds
    void playOnStarAnimation();
    void can_you_help_me_count();
    void how_many();
    void lets_count_them_together();
    void playGameWonRandomSound();
    void playAnimalSound();
    void count_the();
    void playGameCompletePopUpSound();
    void playRandomSoundOnTappingDogOnLevelTen();
    void playRandomSoundOnTappingDog();
    void numberOfAnimalCounted();
    void animalActionSound();
    void great();
    void playGameButtonSound();
    void you_countedTheNumbers();
    void animalSpeakPlay();
    void you_counted();
    
    //Dog Idle Animation
    void scheduleForIdleDogAnimation();
    void idleTimeAnimation();
    
    //Touches Method
    void ccTouchesBegan(CCSet* touches, CCEvent* event);
    
    CCRenderTexture*  createStroke(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity);

    int animalAccessIndex;
    
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(CTAGameScene);
};

#endif // __CTAGameScene_SCENE_H__
