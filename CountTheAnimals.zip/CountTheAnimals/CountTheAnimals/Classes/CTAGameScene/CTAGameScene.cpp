#include "CTAGameScene.h"
#include "SimpleAudioEngine.h"
#include "CTADataManager.h"
#include "CTASprite.h"
#include "BacciTalking.h"
#include "CTAHomeScene.h"
#include "CTASharedSoundManager.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* CTAGameScene::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CTAGameScene *layer = CTAGameScene::create();
    
    // add layer as a child to scene
    scene->addChild(layer);
    
    // return the scene
    return scene;
}

#pragma mark - Default
CTAGameScene::CTAGameScene()
{
    animalsArr = CCArray::create();
    animalsArr->retain();
    
    starArray = CCArray::create();
    starArray->retain();
    
    animalScaleArr=CCArray::create();
    animalScaleArr->retain();
    
    uniqueRandomNumberForAnimalArr = CCArray::create();
    uniqueRandomNumberForAnimalArr->retain();
}

CTAGameScene::~CTAGameScene()
{
    CC_SAFE_RELEASE_NULL(this->animalsArr);
    CC_SAFE_RELEASE_NULL(this->starArray);
    CC_SAFE_RELEASE_NULL(this->uniqueRandomNumberForAnimalArr);
    CC_SAFE_RELEASE_NULL(this->animalScaleArr);
}

void CTAGameScene::onEnter()
{
    CCLayer::onEnter();
    
    //load plist
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("spriteSheets/CTAUISpriteSheet.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("spriteSheets/CTAGameSpriteSheet.plist");
    
    //Initialising variables
    this->initialiseVariables();
    
    //Initialising Game UI
    this->intialiseGameUI();
    
    //Initialising Game
    this->initialiseGame();
    
    // Idle dog animaton according to scheduling
    this->scheduleForIdleDogAnimation();
    
    //Adding White stars
    this->addStars();
}

void CTAGameScene::onExit()
{
    CCLayer::onExit();
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("spriteSheets/CTAUISpriteSheet.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFramesFromFile("spriteSheets/CTAGameSpriteSheet.plist");
}

#pragma mark - Initialising Game
void CTAGameScene::initialiseVariables()
{
    winSize = CCDirector::sharedDirector()->getWinSize();
    this->tapcount=0;
    animalAccessIndex = 0;
    starCount=0;
    this->setTouchEnabled(false);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    levelNumber=CTADataManager::sharedManager()->currentLevel;
    this->isGameRestarted=true;
    this->canTapAnimalSpr=true;
    this->isGameCompleted=false;
    this->isGameOver=false;
}

void CTAGameScene::initialiseGame()
{
    //Creting New Layer and Adding UI Sprites on it.
    this->animalLayer=CCLayer::create();
    this->addChild(this->animalLayer,1);
    this->animalLayer->setPosition(ccp(0,0));
    
    //Setting the Lable For Difficulties
    char animalNameChar[30];
    sprintf(animalNameChar,"%d/10",levelNumber);
    
    CCLabelTTF *levelLbl=CCLabelTTF::create(animalNameChar, "Apple Casual" , 50);
    
    this->animalLayer->addChild(levelLbl,5);
    levelLbl->setColor(ccc3(0,162,255));
    levelLbl->setPosition(ccp(935, 50));
    //levelLbl->enableStroke(ccc3(255,255,255),1.4);
    
    //Creating Stroke For the Level Number
    CCRenderTexture *stroke =createStroke(levelLbl,2,ccWHITE, 100);
    this->animalLayer->addChild(stroke);
    
    //storing Animal Name into animalNameArr
    animalNameArr =(CCArray*)gameDict->objectForKey("AnimalName");
    noOfAnimalsOnScreenArr=(CCArray*)gameDict->objectForKey("NumberOfAnimalRandom");
    
    languageNameDict=(CCDictionary*)languageDict->valueForKey("English");
    animalNamesDict=(CCDictionary*)languageNameDict->valueForKey("AnimalName");
    
    CCString *animalsNumberStr;
    CCDictionary *animalsNumberDict=NULL;
    int randomPosForAnimalForSameNumber=0;
    
    // Random Creation to decide number of animal on Screen
    if(levelNumber==1 || levelNumber==2 || levelNumber==3)
    {
        animalsNumberStr=(CCString*)noOfAnimalsOnScreenArr->objectAtIndex(this->getRandomNumberBetween(0,3));
        
    }
    else
    {
        animalsNumberStr=(CCString*)noOfAnimalsOnScreenArr->objectAtIndex(this->getRandomNumberBetween(4, 11));
        
    }
    animalsNumberDict = (CCDictionary*)gameDict->valueForKey(animalsNumberStr->getCString());
    
    numberOfAnimalToCreateArr=NULL;
    
    numberOfAnimalToCreateArr = (CCArray*)animalsNumberDict;
    
    randomPosForAnimalForSameNumber=arc4random()%2;
    numberOfAnimalToCreateArr = (CCArray*)numberOfAnimalToCreateArr->objectAtIndex(randomPosForAnimalForSameNumber);
    
    
    //Call to add Animal Sprite
    this->addAnimalSprites();
    
    if(levelNumber==1 && this->isGameRestarted)
    {
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
        
        this->setTouchEnabled(false);
        //Welcome Sounds
        CCSequence *sequenceAction = CCSequence::createWithTwoActions(CCDelayTime::create(1.0f),CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::initialiseSounds)));
        this->runAction(sequenceAction);
    }
    else
    {
        this->stopDogTalkingAnimation();
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
        CCSequence *sequence = CCSequence::create(
                                                  CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::startDogTalking)),
                                                  CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::count_the)),CCDelayTime::create(0.2),
                                                  CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::stopDogTalkingAnimation)),CCDelayTime::create(1),
                                                  CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::playAnimalSound)),NULL);
        this->runAction(sequence);
    }
}

void CTAGameScene::intialiseGameUI()
{
    //store unique no's into array
    int no_to_randomize[10];
    for (int i = 0 ; i <8; i++){
        no_to_randomize[i] = i;
    }
    //store indexes into an integer Array from randomize method
    store_randomArray = this->randomizeInt(no_to_randomize);
    
    //uniqueRandomNumberForAnimalName
    for (int i=0; i<8; i++)
    {
        uniqueRandomNumberForAnimalName = store_randomArray[i];
        
        CCString *rand_No_string = CCString::createWithFormat("%d",uniqueRandomNumberForAnimalName);
        
        this->uniqueRandomNumberForAnimalArr->addObject(rand_No_string);
    }
    
    std::string pszPath = CCFileUtils::sharedFileUtils()->fullPathForFilename("CountAnimals.plist");
    gameDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPath.c_str());
    
    std::string pszPathForLanguage = CCFileUtils::sharedFileUtils()->fullPathForFilename("CTALanguages.plist");
    languageDict= CCDictionary::createWithContentsOfFileThreadSafe(pszPathForLanguage.c_str());
    
    //BackGround Music
    if(SimpleAudioEngine::sharedEngine()->isBackgroundMusicPlaying()==false)
        SimpleAudioEngine::sharedEngine()->playBackgroundMusic("CTASounds/counting_music.mp3",true);
    
    CCSprite *backgroundSpr = CCSprite::create("spriteSheets/BG/CountTheNumbersBG.png");
    backgroundSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->addChild(backgroundSpr);
    
    CCSprite *goBackToGameSelectionNormalSprite = CCSprite::createWithSpriteFrameName("Home_Button.png");
    CCSprite *goBackToGameSelectionSelectedSprite = CCSprite::createWithSpriteFrameName("Home_Button.png");
    
    CCMenuItemSprite *homeMenuItem = CCMenuItemSprite::create(goBackToGameSelectionNormalSprite, goBackToGameSelectionSelectedSprite, this, menu_selector(CTAGameScene::goBackToGameSelectionScene));
    
    homeMenuItem->setPosition(CCPointMake(86,677));
    
    //Restart button
    CCSprite *restartnormalSprite = CCSprite::createWithSpriteFrameName("restart_Button.png");
    CCSprite *restartselectedSprite = CCSprite::createWithSpriteFrameName("restart_Button.png");
    restartMenuItem = CCMenuItemSprite::create(restartnormalSprite, restartselectedSprite, this, menu_selector(CTAGameScene::restartFromFirstLevel));
    
    restartMenuItem->setPosition(ccp(952,677));
    
    CCMenu *tempMenu = CCMenu::create(restartMenuItem, homeMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    this->addChild(tempMenu,3);
    
    CCSprite *dogBaseSpr = CCSprite::createWithSpriteFrameName("dog_base.png");
    this->addChild(dogBaseSpr,4);
    dogBaseSpr->setPosition(ccp(85, 48));
    
    award = CCSprite::createWithSpriteFrameName("award.png");
    this->addChild(award,6);
    award->setScale(0.7);
    award->setPosition(ccp(522,570));
    award->setVisible(false);
    
    //bacci
    bazziTalking = new BacciTalking();
    this->bazziTalking->initialize(this,CCPoint(85,128));
    
}

void CTAGameScene::initialiseSounds()
{
    this->setTouchEnabled(false);
    restartMenuItem->setEnabled(false);
    
    bazziTalking->startDogTalking();
    
    CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
    CCSequence *seq = CCSequence::createWithTwoActions(callbackForstopDogTalkingAnimation,CCDelayTime::create(1.0f));
    CCCallFuncN  *callbackForstartDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::startDogTalking));
    
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/letscount.mp3");
    CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.7f),
                                                    seq
                                                    ,callbackForstartDogTalkingAnimation,
                                                    CCCallFunc::create(this,callfunc_selector(CTAGameScene::can_you_help_me_count)),CCDelayTime::create(2.0f),
                                                    seq,
                                                    callbackForstartDogTalkingAnimation,
                                                    CCCallFunc::create(this,callfunc_selector(CTAGameScene::how_many)),CCDelayTime::create(1.8f),
                                                    seq,
                                                    callbackForstartDogTalkingAnimation,
                                                    CCCallFunc::create(this,callfunc_selector(CTAGameScene::lets_count_them_together)),CCDelayTime::create(0.8f),
                                                    callbackForstopDogTalkingAnimation,CCDelayTime::create(1.3f)
                                                    ,NULL);
    
    
    CCSequence *sequence = CCSequence::create(
                                              CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::startDogTalking)),
                                              CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::count_the)),CCDelayTime::create(0.2),seq,
                                              CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::playAnimalSound)),CCDelayTime::create(1.0f),
                                              CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::enableTouch)),NULL);
    this->runAction(CCSequence::createWithTwoActions(callBack,sequence));
    
}

void CTAGameScene::enableTouch()
{
    if(levelNumber==1)
    {
        restartMenuItem->setEnabled(true);
        
    }
    this->setTouchEnabled(true);
}

#pragma mark - createStroke
CCRenderTexture*  CTAGameScene:: createStroke(CCLabelTTF* label, int size, ccColor3B color, GLubyte opacity)
{
    
    CCRenderTexture* rt = CCRenderTexture::create(label->getTexture()->getContentSize().width + size * 2,label->getTexture()->getContentSize().height+size * 2);
    
    CCPoint originalPos = label->getPosition();
    ccColor3B originalColor = label->getColor();
    label->setColor(color);
    
    ccBlendFunc originalBlend = label->getBlendFunc();
    ccBlendFunc bf = {GL_SRC_ALPHA, GL_ONE};
    label->setBlendFunc(bf);
    CCPoint center = CCPoint(label->getTexture()->getContentSize().width/2+size,label->getTexture()->getContentSize().height/2+size);
    
    rt->begin();
    
    for (int i=0; i<360; i+=50)
    {
        label->setPosition(CCPoint(center.x+sin(CC_DEGREES_TO_RADIANS(i))*size,center.y+cos(CC_DEGREES_TO_RADIANS(i))*size));
        label->visit();
    }
    rt->end();
    
    label->setPosition(originalPos);
    label->setColor(originalColor);
    label->setBlendFunc(originalBlend);
    rt->setPosition(originalPos);
    return rt;
}

#pragma mark - generating RandomNumbers
int* CTAGameScene::randomizeInt(int noOfAnimalSprites[15])
{
    //variables used for swapping
    int swap;
    int rand_no;
    
    //randomize the array
    for(int i = 0; i < 8; i++){
        
        rand_no = arc4random() %8;
        
        swap = noOfAnimalSprites[rand_no];
        noOfAnimalSprites[rand_no]= noOfAnimalSprites[i];
        noOfAnimalSprites[i] = swap;
    }
    return noOfAnimalSprites;
}

int CTAGameScene::getRandomNumberBetween(int min, int max) {
    
    int toNumber = max + 1;
    int fromNumber = min;
    
    int randomNumber = (arc4random()%(toNumber-fromNumber))+fromNumber;
    
    return randomNumber;
}

#pragma mark - Add Animals Sprites
void CTAGameScene::addAnimalSprites()
{
    CCString *animalInitialPositionStr;
    CCString *animalFinalPositionStr;
    
    //for getting the Random Name
    int maxNumberOfAnimalsToCreate = numberOfAnimalToCreateArr->count();
    
    CCString *rand_Number_string = (CCString*)this->uniqueRandomNumberForAnimalArr->objectAtIndex(CTADataManager::sharedManager()->indexForAnimalName);
    CTADataManager::sharedManager()->indexForAnimalName++;
    
    int rand = rand_Number_string->intValue();
    
    finalAnimalCount=maxNumberOfAnimalsToCreate;
    CCDictionary *animalNameDict=NULL;
    CCDictionary *animalPosDict= NULL;
    
    CCPoint animalPosInitial;
    CCPoint animalPosFinal;
    for (int i=0; i<maxNumberOfAnimalsToCreate; i++)
    {
        animalPosDict=(CCDictionary*)numberOfAnimalToCreateArr->objectAtIndex(i);
        animalInitialPositionStr=(CCString*)animalPosDict->valueForKey("InitialPosition");
        animalFinalPositionStr=(CCString*)animalPosDict->valueForKey("FinalPosition");
        
        animalPosInitial = CCPointFromString(animalInitialPositionStr->getCString());
        animalNameDict =(CCDictionary*)animalNameArr->objectAtIndex(rand);
        
        animalPosFinal=CCPointFromString(animalFinalPositionStr->getCString());
        animalNameDict =(CCDictionary*)animalNameArr->objectAtIndex(rand);
        
        imageName = (const char *)animalNameDict->valueForKey("ImageName")->getCString();
        
        std::string nameOfAnimalForCreting = imageName;
        
        CTASprite *animalSprites = animalSprites->createWithSpriteFrameName(nameOfAnimalForCreting.c_str());
        
        animalsArr->addObject(animalSprites);
        
        if(levelNumber==1 ||levelNumber==2||levelNumber==3)
        {
            if(maxNumberOfAnimalsToCreate==1)
            {
                animalSprites->setScale(1.5);
            }
            else
            {
                animalSprites->setScale(1.3);
            }
        }
        else
        {
            animalSprites->setScale(1);
        }
        
        animalSprites->setPosition(animalPosInitial);
        
        animalSprites->FinalPosition=animalPosFinal;
        
        this->animalLayer->addChild(animalSprites,7);
    }
    const char *animalName = (const char*)animalNameDict->valueForKey("NameOfAnimal")->getCString();
    
    animalSpeakSound=(const char *)animalNameDict->valueForKey("AnimalSpeakSound")->getCString();
    
    if(numberOfAnimalToCreateArr->count()>1)
    {
        
        std::string animalNameStrToConvert = animalName;
        std::string addingTheS = "S";
        std::string animalNamePlural = animalNameStrToConvert + addingTheS;
        
        CCDictionary *animalNameFromLangDict = (CCDictionary*)animalNamesDict->valueForKey(animalNameStrToConvert.c_str());
        
        animalNameForLable = (const char *)animalNameFromLangDict->valueForKey("AnimalNamePlural")->getCString();
        
        std::string animalNameStr = animalNameForLable;
        
        
        this->setLabel(animalNamePlural.c_str());
        
        animalSound=(const char *)animalNameDict->valueForKey("AnimalSoundPlural")->getCString();
    }
    else
    {
        
        std::string animalNameStrToConvert = animalName;
        
        CCDictionary *animalNameFromLangDict = (CCDictionary*)animalNamesDict->valueForKey(animalNameStrToConvert.c_str());
        
        animalNameForLable = ( const char * )animalNameFromLangDict->valueForKey("AnimalNameSingular")->getCString();
        
        std::string animalNameStr = animalNameForLable;
        
        
        this->setLabel(animalNameStr.c_str());
        
        animalSound=(const char *)animalNameDict->valueForKey("AnimalSoundSingular")->getCString();
    }
    
    this->randomActionForSprite();
}

void CTAGameScene::randomActionForSprite()
{
    //CCCallFuncN *actionSoundcallBack = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::animalActionSound));
    
    if(levelNumber==1 &&isGameRestarted)
    {
        this->setTouchEnabled(true);
        CCObject *obj = NULL;
        CCARRAY_FOREACH(animalsArr, obj)
        {
            CTASprite *animalSpr = (CTASprite*)obj;
            
            animalSpr->initialAnimation();
            /* CCActionInterval *actionTo;
             CCActionInterval *actionBack;
             
             if(levelNumber==1 ||levelNumber==2||levelNumber==3)
             {
             if(animalsArr->count()==1)
             {
             actionTo = CCScaleTo::create(0.5, 1.8);
             actionBack = CCScaleTo::create(0.5, 1.5);
             }
             else{
             actionTo = CCScaleTo::create(0.5, 1.6);
             actionBack = CCScaleTo::create(0.5, 1.3);
             }
             }
             else
             {
             actionTo = CCScaleTo::create(0.5, 1.4);
             actionBack = CCScaleTo::create(0.5, 1);
             }
             
             //EASE BOUNCE
             CCEaseBounceIn *bounceIn = CCEaseBounceIn::create(actionTo);
             CCEaseBounceOut *bounceback = CCEaseBounceOut::create(actionBack);
             
             //Rotate & Move Sprites to specific location
             moveAnimalSpr = CCMoveTo::create(1,animalSpr->FinalPosition);
             
             CCSequence *seq = CCSequence::createWithTwoActions(bounceIn,bounceback);
             
             animalSpr->runAction(CCSequence::createWithTwoActions(moveAnimalSpr,seq));
             
             animalSpr->initialAnimation();
             
             this->animalActionSound();*/
        }
    }
    
    else
    {
        CCObject *obj = NULL;
        //int type =  this->getRandomNumberBetween(0,4);
        
        //CCAction *seq = NULL;
        CCARRAY_FOREACH(animalsArr, obj)
        {
            CTASprite *animalSpr = (CTASprite*)obj;
            
            animalSpr->initialAnimation();
            this->setTouchEnabled(true);
            /* //SCALE
             CCActionInterval *actionTo;
             CCActionInterval *actionBack;
             if(levelNumber==1 ||levelNumber==2||levelNumber==3)
             {
             if(animalsArr->count()==1)
             {
             actionTo = CCScaleTo::create(0.5, 1.8);
             actionBack = CCScaleTo::create(0.5, 1.5);
             }
             else{
             actionTo = CCScaleTo::create(0.5, 1.6);
             actionBack = CCScaleTo::create(0.5, 1.3);
             }
             }
             else
             {
             actionTo = CCScaleTo::create(0.5, 1.4);
             actionBack = CCScaleTo::create(0.5, 1);
             
             }
             
             //EASE BOUNCE
             CCEaseBounceIn *bounceIn = CCEaseBounceIn::create(actionTo);
             CCEaseBounceOut *bounceback = CCEaseBounceOut::create(actionBack);
             
             //Rotate & Move Sprites to specific location
             CCMoveTo *moveAnimalSpr = CCMoveTo::create(2,animalSpr->FinalPosition);
             
             
             CCSequence *sequence = CCSequence::createWithTwoActions(CCDelayTime::create(0.1f),CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::enableTouch)));
             
             std::string horse = "Horse_img.png";
             if(strcmp(imageName, horse.c_str())==0)
             {
             type=5;
             }
             
             if(type==0) { //Bounce Effect
             
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCEaseElasticInOut::create(moveAnimalSpr),actionSoundcallBack, bounceIn, bounceback,sequence, NULL);
             }
             else if(type==1) { //Elastic effect
             
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCEaseBounceOut::create(moveAnimalSpr),sequence, NULL);
             
             }
             else if(type==2) { //Rotate effect
             
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCEaseBounceInOut::create(moveAnimalSpr),actionSoundcallBack, CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::rotate)),sequence, NULL);
             }
             else if(type==3) { //Jump Effect
             
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCEaseExponentialInOut::create(moveAnimalSpr),actionSoundcallBack, CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::bounceOut)),sequence, NULL);
             }
             else if(type==4)
             {
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCSpawn::create(moveAnimalSpr,  NULL),actionSoundcallBack, CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::cardinal)),sequence, NULL);
             }
             else if(type==5)
             {
             this->setTouchEnabled(false);
             seq = CCSequence::create(CCSpawn::create(moveAnimalSpr, NULL),actionSoundcallBack, CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::move)),sequence, NULL);
             }
             animalSpr->runAction(seq);
             this->animalActionSound();*/
        }
    }
}

#pragma mark - animation
void CTASprite::initialAnimation()
{
    CCMoveTo *moveToFinalAnimalPos = CCMoveTo::create(1.5, this->FinalPosition);
    CCFiniteTimeAction* sequence = CCSequence::create(moveToFinalAnimalPos, CCCallFunc::create(this,callfunc_selector(CTASprite::stayAnimation)), NULL);
    
    this->runAction(sequence);
}

void CTASprite::stayAnimation()
{
    float delayTime = 0.75;
    
    if((arc4random()%40) % 2 == 0)
    {
        delayTime = 0.5;
    }
    
    CCPoint contrllingSprPoint1 = CCPoint(0, 15);
    CCPoint contrllingSprPoint2 = CCPoint(0,- 15);
    
    CCMoveBy *moveUp = CCMoveBy::create(delayTime, contrllingSprPoint1);
    CCMoveBy *moveDown = CCMoveBy::create(delayTime, contrllingSprPoint2);
    
    CCActionInterval *sequence = CCSequence::create(moveUp, moveDown, NULL);
    
    CCRepeatForever *repeatSequence = CCRepeatForever::create(sequence);
    this->runAction(repeatSequence);
}

#pragma mark - Sprites Movement Actions
void CTAGameScene::move(CCObject *sender) {
    
    CTASprite *SprMove = (CTASprite*)sender;
    
    //MOVE
    CCMoveTo *moveTo = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+30, SprMove->getPosition().y+30));
    CCMoveTo *moveBack = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-25, SprMove->getPosition().y-25));
    CCMoveTo *moveTo1 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+22, SprMove->getPosition().y+22));
    CCMoveTo *moveBack1 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-15, SprMove->getPosition().y-15));
    CCMoveTo *moveTo2 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x+15, SprMove->getPosition().y+15));
    CCMoveTo *moveBack2 = CCMoveTo::create(.1, ccp(SprMove->getPosition().x-5, SprMove->getPosition().y-5));
    
    CCSequence *moveSeq = CCSequence::create(moveTo, moveBack, moveTo1, moveBack1, moveTo2, moveBack2, NULL);
    SprMove->runAction(moveSeq);
}

void CTAGameScene::bounceOut(CCObject *sender) {
    
    CTASprite *SprJump = (CTASprite*)sender;
    
    //MOVE (used to give same effect as that of jump)
    
    CCPointArray *m_pArray1 = CCPointArray::create(20);
    m_pArray1->addControlPoint(ccp(0, 20));
    m_pArray1->addControlPoint(ccp(0, -20));
    m_pArray1->addControlPoint(ccp(0,40));
    m_pArray1->addControlPoint(ccp(0,-40));
    
    CCCardinalSplineBy *action = CCCardinalSplineBy::create(0.4, m_pArray1,0);
	
    SprJump->runAction(action);
}

void CTAGameScene::rotate(CCObject *sender) {
    
    
    CTASprite *Sprprogress = (CTASprite*)sender;
    
    CCPointArray *m_pArray1 = CCPointArray::create(20);
    m_pArray1->addControlPoint(ccp(20, 20));
    m_pArray1->addControlPoint(ccp(20, 40));
    m_pArray1->addControlPoint(ccp(-20,40));
    m_pArray1->addControlPoint(ccp(0,-40));
    
    CCCardinalSplineBy *action = CCCardinalSplineBy::create(0.4, m_pArray1,0);
    
    Sprprogress->runAction(action);
}

void CTAGameScene::cardinal(cocos2d::CCObject *sender)
{
    CTASprite *SprCardinal = (CTASprite*)sender;
    //MOVE (used to give same effect as that of jump)
    CCPointArray *m_pArray1 = CCPointArray::create(20);
    m_pArray1->addControlPoint(ccp(60,30));
    m_pArray1->addControlPoint(ccp(30, 80));
    
    CCCardinalSplineBy *action = CCCardinalSplineBy::create(0.4, m_pArray1,0);
    
    CCActionInterval *reverse = action->reverse();
	
    CCFiniteTimeAction *seq = CCSequence::create(action, reverse, NULL);
    SprCardinal->runAction(seq);
    
}

#pragma mark - getLabel
void CTAGameScene::setLabel(const char *labelName)
{
    std::string msg=labelName;
    char animalLables[100]={};
    CCString *countTheStr = (CCString*)languageNameDict->valueForKey("TOPHeading");
    
    std::string topHeading = countTheStr->getCString();
    
    sprintf(animalLables,"%s %s",topHeading.c_str(),msg.c_str());
    
    animalLable = CCLabelTTF::create(animalLables,"Anja Eliane accent" ,60);
    this->animalLayer->addChild(animalLable,5);
    animalLable->setColor(ccc3(249,93,168));
    animalLable->setPosition(ccp(510, 700));
    animalLable->enableStroke(ccRED,1.4);
}

#pragma mark - Adding Stars
void CTAGameScene::addStars() {
    
    int xPos=240;
    int yPos=50;
    
    for(int i=0; i<starCount; i++){
        
        CCSprite *starFullSprite = CCSprite::createWithSpriteFrameName("star_yellow.png");
        this->addChild(starFullSprite,4);
        
        starFullSprite->setTag(i);
        starFullSprite->setPosition(ccp(xPos, yPos));
        
        starArray->addObject(starFullSprite);
    }
    
    for(int i=0; i<10-starCount; i++){
        
        CCSprite *starEmptySprite = CCSprite::createWithSpriteFrameName("star_white.png");
        this->addChild(starEmptySprite,3);
        
        starEmptySprite->setTag(i);
        starEmptySprite->setPosition(ccp(xPos, yPos));
        xPos=xPos+60;
    }
}

void CTAGameScene::addNewStar() {
    
    //Play Star Animation Sound
    this->playOnStarAnimation();
    
    CCSprite *starSprite = CCSprite::createWithSpriteFrameName("star_yellow.png");
    starSprite->setPosition(ccp(240+((starCount)*60),50));
    
    this->addChild(starSprite, 10);
    starArray->addObject(starSprite);
    
    CCRotateTo *rotate = CCRotateTo::create(0.5, 720);
    CCScaleTo *scaleStarTo = CCScaleTo::create(0.16, 3);
    CCScaleTo *scaleStarBack = CCScaleTo::create(0.16, 1);
    CCFiniteTimeAction *seq = CCSequence::createWithTwoActions(scaleStarTo, scaleStarBack);
    
    CCFadeOut *fadeOut = CCFadeOut::create(0.1);
    CCFadeIn *fadeIn = CCFadeIn::create(0.1);
    
    CCSpawn *spawnStarSpr = CCSpawn::create(rotate, seq, NULL);
    CCSequence *seq1 = CCSequence::create(fadeOut, fadeIn, NULL);
    CCSequence *seq2 = CCSequence::create(fadeOut, fadeIn, NULL);
    
    CCSequence *seq3 = CCSequence::create(spawnStarSpr, seq1, CCDelayTime::create(.25), seq2, NULL);
    starSprite->runAction(seq3);
    
    if (starCount >= 10) {
        
        for (int i=0; i<starArray->count(); i++)
        {
            CCSprite *star = (CCSprite*)starArray->objectAtIndex(i);
            this->removeChild(star, true);
        }
        starCount=0;
    }
    starCount++;
}


#pragma mark - Touches MenuItems
void CTAGameScene::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
    CCTouch* touch = (CCTouch*)(touches->anyObject());
    CCPoint touchPoint = this->convertTouchToNodeSpace(touch);
    
    if(bazziTalking->animatedDog->boundingBox().containsPoint(touchPoint) && CTADataManager::sharedManager()->canDogStartTalking)
    {
        CTADataManager::sharedManager()->canDogStartTalking=false;
        
        SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
        SimpleAudioEngine::sharedEngine()->stopAllEffects();
        bazziTalking->startDogTalking();
        
        SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
        
        CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
        
        if(levelNumber==10)
        {
            CCSequence *Seq = CCSequence::create(CCCallFunc::create(this, callfunc_selector(CTAGameScene::playRandomSoundOnTappingDogOnLevelTen)),CCDelayTime::create(3.0f),callbackForstopDogTalkingAnimation,NULL);
            this->runAction(Seq);
        }
        else
        {
            CCSequence *Seq = CCSequence::create(CCCallFunc::create(this, callfunc_selector(CTAGameScene::playRandomSoundOnTappingDog)),CCDelayTime::create(3.0f), CCCallFunc::create(this, callfunc_selector(CTAGameScene::stopDogTalkingAnimation)),NULL);
            this->runAction(Seq);
        }
    }
    
    if(canTapAnimalSpr)
    {
        CCObject *obj = NULL;
        CCARRAY_FOREACH(animalsArr, obj)
        {
            CTASprite *animalSpr = (CTASprite*)obj;
            
            if(animalSpr->boundingBox().containsPoint(touchPoint))
            {
                //Create Particle Effect
                this->addParticleEffectToTexture = NULL;
                
                this->addParticleEffectToTexture = CCParticleSystemQuad::create("CTAParticle/CountTheAnimalsParticle.plist");
                addParticleEffectToTexture->setPosition(touchPoint);
                this->animalLayer->addChild(addParticleEffectToTexture,10);
                
                
                if(animalSpr->isSolved==false)
                {
                    animalScaleArr->addObject(animalSpr);
                    this->tapcount++;
                    if(this->tapcount==this->finalAnimalCount)
                    {
                        animalSpr->isSolved=true;
                        isGameOver=true;
                        CCSequence *sequenceAction = CCSequence::createWithTwoActions( CCDelayTime::create(1.0f),CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::gameWinFunction)));
                        this->runAction(sequenceAction);
                        
                    }
                    else
                    {
                        animalSpr->isSolved=true;
                    }
                    
                    char tapCountNumber[40]={};
                    sprintf(tapCountNumber,"%d.png",this->tapcount);
                    CCSprite *numberSpr = CCSprite::createWithSpriteFrameName(tapCountNumber);
                    numberSpr->setPosition(CCPoint(animalSpr->getContentSize().width/2,animalSpr->getContentSize().height/2));
                    animalSpr->addChild(numberSpr,3);
                    bazziTalking->startDogTalking();
                    sprintf(tapCountNumber,"CTASounds/Numbers/%d.mp3",this->tapcount);
                    
                    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
                    dogAnimationCount=SimpleAudioEngine::sharedEngine()->playEffect(tapCountNumber);
                    CCSequence *sequenceAction = CCSequence::create(
                                                                    CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::canTapAnimalMakingFalse)), CCDelayTime::create(0.3f),
                                                                    CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::canTaPAnimalMakingTrue)),NULL);
                    this->runAction(sequenceAction);
                }
            }
        }
    }
}

void CTAGameScene::canTapAnimalMakingFalse()
{
    canTapAnimalSpr=false;
    CTADataManager::sharedManager()->canDogStartTalking=false;
    this->stopDogTalkingAnimation();
}

void CTAGameScene::canTaPAnimalMakingTrue()
{
    canTapAnimalSpr=true;
    CTADataManager::sharedManager()->canDogStartTalking=true;
    
}

#pragma mark - Game Over
void CTAGameScene::gameWinFunction()
{
    if(isGameOver)
    {
        
        CCSequence *seq = CCSequence::create(CCDelayTime::create(0.5),CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::you_countedTheNumbers)),CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::scaleNumbers)),NULL);
        
        this->runAction(seq);
    }
    
}

void CTAGameScene::scaleNumbers()
{
    if (animalAccessIndex < animalsArr->count()) {
        
        CCSprite *spr = (CCSprite*)animalScaleArr->objectAtIndex(animalAccessIndex);
        bazziTalking->startDogTalking();
        
        CCScaleTo *scaleTo;
        CCScaleTo *scaleBack;
        
        if(levelNumber==1 ||levelNumber==2||levelNumber==3)
        {
            if(animalsArr->count()==1)
            {
                scaleTo = CCScaleTo::create(0.2, 1.9);
                scaleBack = CCScaleTo::create(0.2, 1.5);
            }
            else{
                scaleTo = CCScaleTo::create(0.2, 1.7);
                scaleBack = CCScaleTo::create(0.2, 1.3);
            }
        }
        else
        {
            scaleTo = CCScaleTo::create(0.2, 1.5);
            scaleBack = CCScaleTo::create(0.2, 1);
            
        }
        
        CCSequence *action = CCSequence::create(scaleTo,CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::numberOfAnimalCounted)),CCDelayTime::create(0.2),scaleBack, CCDelayTime::create(0.5), CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::scaleNumbers)),NULL);
        spr->runAction(action);
        
        animalAccessIndex++;
    }
    else
    {
        this->checkForGoingToNextLevel();
    }
}

void CTAGameScene::checkForGoingToNextLevel()
{
    CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
    
    CCCallFuncN *callbackForstartDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::startDogTalking));
    
    CCCallFuncN *animalSounds=CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::playAnimalSound));
    CCCallFuncN *youCounted =CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::you_counted));
    
    CCCallFunc *numberOfAnimlasCounted = CCCallFunc::create(this, callfunc_selector(CTAGameScene::numberOfAnimalCounted));
    
    CCCallFunc *callback = CCCallFunc::create(this, callfunc_selector(CTAGameScene::goToNextLevel));
    
    CCSequence *seq=NULL;
    
    CCCallFuncN *animalspeakcall=CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::animalSpeakPlay));
    
    seq =CCSequence::create(callbackForstartDogTalkingAnimation,youCounted,CCDelayTime::create(1.6),callbackForstopDogTalkingAnimation,numberOfAnimlasCounted,CCDelayTime::create(0.5),animalSounds,CCDelayTime::create(1.0f),callbackForstartDogTalkingAnimation,animalspeakcall,CCDelayTime::create(1.2f),callbackForstopDogTalkingAnimation,CCDelayTime::create(0.5),callbackForstartDogTalkingAnimation,CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::addNewStar)),CCDelayTime::create(1.5f),callbackForstopDogTalkingAnimation,NULL);
    
    
    if(levelNumber==10 && isGameOver)
    {
        if(animalAccessIndex == animalsArr->count())
        {
            CCSequence *Sequence = CCSequence::create(
                                                      CCCallFunc::create(this,callfunc_selector(CTAGameScene::addBanner)),CCDelayTime::create(6.0f),
                                                      CCCallFunc::create(this,callfunc_selector(CTAGameScene::gameOverScene)),NULL);
            this->runAction(CCSequence::createWithTwoActions(seq,Sequence));
        }
    }
    else if(levelNumber<10)
    {
        if(animalAccessIndex >= animalsArr->count() && isGameOver )
        {
            CCSequence *action = CCSequence::createWithTwoActions(CCDelayTime::create(1.0f),callback);
            
            this->runAction(CCSequence::createWithTwoActions(seq,action));
            
        }
    }
}

void CTAGameScene::addBanner()
{
    animalLable->setVisible(false);
    animalLableWithCount->setVisible(false);
    
    CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
    
    CCCallFuncN  *callbackForstartDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::startDogTalking));
    
    //Play Correct Sound on Proper Match
    int rand=arc4random()%2;
    float delay;
    if(rand==0)
    {
        delay=1.0;
        CTASharedSoundManager::sharedManager()->playShortSoundOnClickOfCorrecAns();
        if(CTASharedSoundManager::sharedManager()->correctRandomSound==3||CTASharedSoundManager::sharedManager()->correctRandomSound==5)
        {
            bazziTalking->stopDogTalking();
        }
        else
        {
            bazziTalking->startDogTalking();
            
        }
    }
    else
    {
        delay=3;
        CTASharedSoundManager::sharedManager()->playLongSoundOnClickOfCorrectAns();
        
    }
    CCSequence *sequenceAction = NULL;
    
    sequenceAction = CCSequence::create(CCDelayTime::create(delay),
                                        CCCallFunc::create(this,callfunc_selector(CTAGameScene::stopDogTalkingAnimation)),CCDelayTime::create(0.8),callbackForstartDogTalkingAnimation,
                                        CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::addCongratulationBnner)),CCDelayTime::create(1.0),callbackForstopDogTalkingAnimation
                                        ,NULL);
    this->runAction(sequenceAction);
}

void CTAGameScene::gameOverScene()
{
    restartMenuItem->setEnabled(false);
    
    award->setVisible(true);
    this->isGameCompleted=true;
    
    this->setTouchEnabled(false);
    
    CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
    
    CCCallFuncN  *callbackForstartDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::startDogTalking));
    
    bazziTalking->startDogTalking();
    
    
    CCFiniteTimeAction *callBack = CCSequence::create(
                                                      CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::youGetTrophySound)),CCDelayTime::create(0.3),callbackForstopDogTalkingAnimation,CCDelayTime::create(1.2),callbackForstartDogTalkingAnimation,
                                                      CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::playGameCompletePopUpSound)),CCDelayTime::create(3),callbackForstopDogTalkingAnimation, CCCallFuncN::create(this,callfuncN_selector(CTAGameScene::enableTouch)),NULL);
    this->runAction(callBack);
    
    
    this->award->setVisible(true);
    
    CCSprite *congragulationSpr = CCSprite::createWithSpriteFrameName("congrats.png");
    congragulationSpr->setPosition(ccp(winSize.width/2,winSize.height/2));
    this->animalLayer->addChild(congragulationSpr,10);
    
    CCSprite *playAgainNormalSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    CCSprite *playAgainSelectedSpr = CCSprite::createWithSpriteFrameName("playAgain.png");
    
    playAgainMenuItem = CCMenuItemSprite::create(playAgainNormalSpr, playAgainSelectedSpr, this, menu_selector(CTAGameScene::restartFromFirstLevel));
    
    playAgainMenuItem->setPosition(ccp(120,10));
    
    CCSprite *gobackNormalSpr = CCSprite::createWithSpriteFrameName("goback.png");
    CCSprite *gobackSelectedSpr = CCSprite::createWithSpriteFrameName("goback.png");
    
    gobackMenuItem = CCMenuItemSprite::create(gobackNormalSpr, gobackSelectedSpr, this, menu_selector(CTAGameScene::goBackToGameSelectionScene));
    
    gobackMenuItem->setPosition(ccp(320, 10));
    
    CCScaleBy *scaleTo = CCScaleBy::create(1, 1.5);
    CCActionInterval* move_ease_in = CCEaseBackInOut::create((CCActionInterval*)(scaleTo->copy()->autorelease()));
    congragulationSpr->runAction(move_ease_in);
    
    CCMenu *tempMenu = CCMenu::create(playAgainMenuItem,gobackMenuItem, NULL);
    tempMenu->setPosition(CCPointZero);
    congragulationSpr->addChild(tempMenu,10);
}

void CTAGameScene::restartFromFirstLevel()
{
    this->stopAllActions();
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->stopDogTalkingAnimation();
    
    if(levelNumber==10)
    {
        if(isGameCompleted)
        {
            starCount=0;
            for (int i=0; i<starArray->count(); i++)
            {
                CCSprite *star=(CCSprite*)this->starArray->objectAtIndex(i);
                this->removeChild(star, true);
            }
            playAgainMenuItem->setEnabled(false);
            gobackMenuItem->setEnabled(false);
            
            CTASharedSoundManager::sharedManager()->bannerSpr->removeFromParent();
            
            //Game completion Sounds along with dog Animations
            CCFiniteTimeAction *callBack=CCSequence::create(CCDelayTime::create(0.8f),
                                                            CCCallFunc::create(this,callfunc_selector(CTAGameScene::startDogTalking)),
                                                            CCCallFunc::create(this,callfunc_selector(CTAGameScene::playGameWonRandomSound)),CCDelayTime::create(1.0f),
                                                            CCCallFunc::create(this,callfunc_selector(CTAGameScene::stopDogTalkingAnimation)), CCCallFunc::create(this,callfunc_selector(CTAGameScene::goToNextLevel)),NULL);
            this->runAction(callBack);
        }
        else
        {
            CCFiniteTimeAction *callBack=CCSequence::createWithTwoActions(CCDelayTime::create(0.6f),
                                                                          CCCallFunc::create(this,callfunc_selector(CTAGameScene::restartLevel)));
            this->runAction(callBack);
        }
    }
    else
    {
        CCFiniteTimeAction *callBack=CCSequence::createWithTwoActions(CCDelayTime::create(0.6f),
                                                                      CCCallFunc::create(this,callfunc_selector(CTAGameScene::restartLevel)));
        this->runAction(callBack);
    }
}

#pragma MARK - congragulation Banner
void CTAGameScene::addCongratulationBnner()
{
    CTASharedSoundManager::sharedManager()->addCongratulationBanner(true,CCPoint(509,690));
}

#pragma mark - Sound
void CTAGameScene::you_counted()
{
    SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/you_counted.mp3");
}

void CTAGameScene::animalSpeakPlay()
{
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->stopDogTalkingAnimation();
    
    char soundName[100]={};
    sprintf(soundName, "%s",animalSpeakSound);
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect(soundName);
}

void CTAGameScene::you_countedTheNumbers()
{
    std::string msg = animalNameForLable;
    
    CCString *countTheStr = (CCString*)languageNameDict->valueForKey("BottomHeading");
    
    std::string bottomHeading = countTheStr->getCString();
    
    char animalLables[200]={};
    sprintf(animalLables,"%s%d %s",bottomHeading.c_str(),tapcount,msg.c_str());
    
    animalLableWithCount = CCLabelTTF::create(animalLables,"Anja Eliane accent" ,60);
    this->animalLayer->addChild(animalLableWithCount,5);
    animalLableWithCount->setColor(ccc3(249,93,168));
    animalLableWithCount->setPosition(ccp(552, 100));
    animalLableWithCount->enableStroke(ccRED,1.4);
}

void CTAGameScene::playGameButtonSound()
{
    CTASharedSoundManager::sharedManager()->playGameButtonSound();
}

void CTAGameScene::great()
{
    SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/great.mp3", false);
}

void CTAGameScene::animalActionSound()
{
    int rand= arc4random()%6;
    if(rand==0)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/suuck.mp3", false);
    }
    else if(rand==1)
    {
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/Swipe3.mp3", false);
        
    }
    else if(rand==2)
    {
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/swipe2.mp3", false);
    }
    if(rand==3)
    {
        CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/Swipe4.mp3", false);
    }
    else if(rand==4)
    {
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/Swipe5.mp3", false);
        
    }
    else if(rand==5)
    {
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/swish.mp3", false);
    }
    else if(rand==6)
    {
        SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/animalActionSound/swish2.mp3", false);
    }
}

void CTAGameScene::numberOfAnimalCounted()
{
    char tapCountNumber[40]={};
    sprintf(tapCountNumber,"%d.png",this->animalAccessIndex);
    sprintf(tapCountNumber,"CTASounds/Numbers/%d.mp3",this->animalAccessIndex);
    
    this->stopDogTalkingAnimation();
    
    dogAnimationCount=SimpleAudioEngine::sharedEngine()->playEffect(tapCountNumber);
    
}

void CTAGameScene::playRandomSoundOnTappingDog()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    int rand= arc4random()%3;
    if(rand==0)
    {
        dogAnimationCount = CocosDenshion::SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/count_havent_been_counted.mp3", false);
    }
    else if(rand==1)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/tap_the_oneshaventbeencounted.mp3", false);
        
    }
    else if(rand==2)
    {
        dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/tap_on_no_numberontop.mp3", false);
        
    }
}

void CTAGameScene::playRandomSoundOnTappingDogOnLevelTen()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    CTASharedSoundManager::sharedManager()->playSoundOnTappingDogAfterPopup();
}

void CTAGameScene::playGameCompletePopUpSound()
{
    SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/playagainorgoback.mp3");
}

void CTAGameScene::playAnimalSound()
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->stopDogTalkingAnimation();
    
    CCCallFuncN *callbackForstopDogTalkingAnimation = CCCallFuncN::create(this, callfuncN_selector(CTAGameScene::stopDogTalkingAnimation));
    
    char soundName[100]={};
    sprintf(soundName, "%s",animalSound);
    
    bazziTalking->startDogTalking();
    
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect(soundName);
    CCSequence *Seq=CCSequence::createWithTwoActions(CCDelayTime::create(0.1),callbackForstopDogTalkingAnimation);
    this->runAction(Seq);
}

void CTAGameScene::can_you_help_me_count()
{
    SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/can_you_help_me_count.mp3");
    
}

void CTAGameScene::count_the()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/count_the.mp3");
}

void CTAGameScene::playGameWonRandomSound()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    CTASharedSoundManager::sharedManager()->playPlayAgainButtonSound();
}

void CTAGameScene::how_many()
{
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/how_many.mp3");
}

void CTAGameScene::lets_count_them_together()
{
    SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/lets_count_them_together.mp3");
}

void CTAGameScene::youGetTrophySound()
{
    SimpleAudioEngine::sharedEngine()->stopEffect(dogAnimationCount);
    dogAnimationCount = SimpleAudioEngine::sharedEngine()->playEffect("CTASounds/yougetatrophy.mp3");
}

void CTAGameScene::playOnStarAnimation()
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    bazziTalking->startDogTalking();
    
    int rand= arc4random()%3;
    char starSoundChar[50]={};
    
    sprintf(starSoundChar,"CTASounds/StarSound/star%d.mp3",rand);
    SimpleAudioEngine::sharedEngine()->playEffect(starSoundChar, false);
    CCFiniteTimeAction *callBack=CCSequence::createWithTwoActions(CCDelayTime::create(0.8f),CCCallFunc::create(this,callfunc_selector(CTAGameScene::stopDogTalkingAnimation)));
    this->runAction(callBack);
}

#pragma mark - Start And Stop DogTalking Animations
void CTAGameScene::startDogTalking()
{
    bazziTalking->startDogTalking();
}

void CTAGameScene::stopDogTalkingAnimation()
{
    CTADataManager::sharedManager()->canDogStartTalking=true;
    this->bazziTalking->stopDogTalking();
}

#pragma mark - IdleTickAfterSounds
void CTAGameScene::scheduleForIdleDogAnimation(){
    
    this->schedule(schedule_selector(CTAGameScene::idleTimeAnimation), 1);
}

void CTAGameScene::idleTimeAnimation()
{
    if(this->bazziTalking->isBacciTalking==false)
    {
        this->bazziTalking->idleTime ++;
        if(levelNumber==1)
        {
            if(this->bazziTalking->idleTime%6==0&&this->bazziTalking->isRunningIdleAnimation==false && CTADataManager::sharedManager()->canDogStartTalking)
            {
                this->bazziTalking->runBacciIdleAnimation();
            }
        }
        else
        {
            if(this->bazziTalking->idleTime%6==0&&this->bazziTalking->isRunningIdleAnimation==false &&CTADataManager::sharedManager()->canDogStartTalking)
            {
                this->bazziTalking->runBacciIdleAnimation();
            }
        }
    }
}

#pragma mark - MenuItems
void CTAGameScene::goBackToGameSelectionScene()
{
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
    
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    this->playGameButtonSound();
    
    levelNumber = 1;
    CCDirector::sharedDirector()->replaceScene(CTAHomeScene::scene());
}

void CTAGameScene::restartLevel()
{
    award->setVisible(false);
    restartMenuItem->setEnabled(true);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->removeAllAnimalFromScene();
    this->initialiseGame();
    this->tapcount=0;
}

void CTAGameScene::goToNextLevel()
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    
    if(levelNumber==10)
    {
        isGameCompleted=true;
        animalLable->setVisible(false);
        animalLableWithCount->setVisible(true);
    }
    else
    {
        isGameCompleted=false;
    }
    
    if(levelNumber==10 && isGameCompleted)
    {
        levelNumber=1;
    }
    else
    {
        levelNumber++;
    }
    
    if(levelNumber>1)
    {
        this->setTouchEnabled(true);
        CTADataManager::sharedManager()->canDogStartTalking=true;
    }
    
    award->setVisible(false);
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    this->removeAllAnimalFromScene();
    this->initialiseGame();
}

void CTAGameScene::removeAllAnimalFromScene()
{
    SimpleAudioEngine::sharedEngine()->stopAllEffects();
    //Remove particle if present
    animalsArr->removeAllObjects();
    animalScaleArr->removeAllObjects();
    this->removeChild(this->animalLayer,true);
    
    //Since ther ar only eight sprites and ten levels we reindexForAnimals
    if(CTADataManager::sharedManager()->indexForAnimalName==7)
    {
        CTADataManager::sharedManager()->indexForAnimalName=0;
    }
    this->isGameRestarted=false;
    isGameOver=false;
    animalAccessIndex=0;
    this->tapcount=0;
    animalLable=NULL;
}
