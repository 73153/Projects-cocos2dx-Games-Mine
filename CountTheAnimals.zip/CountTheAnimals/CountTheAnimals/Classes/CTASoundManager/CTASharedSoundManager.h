//
//  CTASharedSoundManager.h
//  CountTheAnimals
//
//  Created by Vivek on 03/07/13.
//
//

#ifndef LostMonster_LMSharedSoundManager_h
#define LostMonster_LMSharedSoundManager_h


#include "cocos2d.h"
USING_NS_CC;

//THIS IS SHARED MANAGER FOR PLAYING SOUND FROM ANYWHERE
//ALSO IT HANDLES SOME EXTRA THINGS
//

class CTASharedSoundManager: public cocos2d::CCObject {
    
    
public:
    
    //Basic Vars & Methods of Shared Manager
    static CTASharedSoundManager* sharedManager(void);
    
    CTASharedSoundManager(void);
    ~CTASharedSoundManager(void);
    
    bool init(void);
    
    
    //Sound Manager Implementation
    //  void playOnClickOfCorrectAnswer();
    static void playOnStarAnimation();
    static void playOnGettingTrophy();
    
    void playSoundOnTappingDogAfterPopup();
    
    //Game Complete
    void playGameCompletePopUpSound();
    
    //Home Button Sound
    void playGameButtonSound();
    
    //Play Again Button
    void playPlayAgainButtonSound();
    
    void playLongSoundOnClickOfCorrectAns();
    void playShortSoundOnClickOfCorrecAns();
    
    void addCongratulationBanner(bool bannerStatus,CCPoint pos);
    
    int sound;
    int failedRandomSound;
    int correctRandomSound;
    
    CCSprite *bannerSpr;
    
    
};


#endif
