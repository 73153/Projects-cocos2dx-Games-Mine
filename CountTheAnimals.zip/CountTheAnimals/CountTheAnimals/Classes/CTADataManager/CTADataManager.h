//
//  CTADataManager.h
//  FindMama
//
//  Created by Vivek on 26/06/13.
//
//

#ifndef CountTheAnimals_CTADataManager_h
#define CountTheAnimals_CTADataManager_h

#include "cocos2d.h"
#include "CCBReader.h"
#include "CTADataManager.h"

USING_NS_CC;
USING_NS_CC_EXT;


class CTADataManager: public cocos2d::CCObject  {
    
private:
    
    CTADataManager(void);
    virtual ~CTADataManager(void);
    
public:

    bool init(void);
    static CTADataManager* sharedManager(void);
    
    bool isGameBegin;
    bool canDogStartTalking;
    bool canPlayIdleDogAnimation;
    
    int currentLevel;
    int indexForAnimalName;
    int mistakeCountToImplementStar;
    TargetPlatform target;
};


#endif
