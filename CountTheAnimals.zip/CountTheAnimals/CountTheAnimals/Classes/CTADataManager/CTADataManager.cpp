//
//  CTADataManager.cpp
//  CountTheAnimals
//
//  Created by Vivek on 26/06/13.
//
//

#include "CTADataManager.h"
#include "cocos2d.h"

static CTADataManager *gSharedManager = NULL;

CTADataManager::CTADataManager(void){
    this->currentLevel=1;
    this->mistakeCountToImplementStar=0;
    this->canDogStartTalking=true;
    this->isGameBegin=true;
    this->canPlayIdleDogAnimation=false;
    this->indexForAnimalName=0;
}

CTADataManager::~CTADataManager(void){}

CTADataManager* CTADataManager::sharedManager(void) {
    
	CTADataManager *pRet = gSharedManager;
    
	if (! gSharedManager)
	{
		pRet = gSharedManager = new CTADataManager();
        
		if (! gSharedManager->init())
		{
			delete gSharedManager;
			gSharedManager = NULL;
			pRet = NULL;
		}
	}
	return pRet;
}

bool CTADataManager::init(void) {
	return true;
}

