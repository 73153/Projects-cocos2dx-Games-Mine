//
//  CTAHomeScene.h
//  CountTheAnimals
//
//  Created by Vivek on 03/07/13.
//
//

#ifndef CountTheAnimals_CTAHomeScene_h
#define CountTheAnimals_CTAHomeScene_h


#include "CTAHomeScene.h"
#include "cocos2d.h"
#include "CTASprite.h"
#include "BacciTalking.h"
#include "CTAHomeScene.h"

USING_NS_CC;

class CTAHomeScene : public cocos2d::CCLayer
{
public:
    
    static cocos2d::CCScene* scene();
    CTAHomeScene();
    ~CTAHomeScene();
    //Variables
    CCSize winSize;
    CCMenuItemSprite *gotoGamePlayMenuItem;
    
    void replaceToCTAGameScene();
    // preprocessor macro for "static create()" constructor ( node() deprecated )
    CREATE_FUNC(CTAHomeScene);
};

#endif
