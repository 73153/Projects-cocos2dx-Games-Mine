// For licensing information relating to this distribution please see Third Party Notices file.

#pragma once

typedef enum {
	kCCExceptionNoSupportDX11 = 0,		// no support direct 11
} ccExceptionCode;

