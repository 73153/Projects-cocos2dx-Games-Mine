/*
* cocos2d-x   http://www.cocos2d-x.org
*
* Copyright (c) 2010-2011 - cocos2d-x community
* 
* Portions Copyright (c) Microsoft Open Technologies, Inc.
* All Rights Reserved
* 
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. 
* You may obtain a copy of the License at 
* 
* http://www.apache.org/licenses/LICENSE-2.0 
* 
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an 
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
* See the License for the specific language governing permissions and limitations under the License.
*/

#include "CCAccelerometerDelegate.h"
#ifndef __PLATFORM_WIN32_UIACCELEROMETER_H__
#define __PLATFORM_WIN32_UIACCELEROMETER_H__

namespace   cocos2d {

class CC_DLL CCAccelerometer
{
public:
    CCAccelerometer();
	bool init(void);
    ~CCAccelerometer();

    static CCAccelerometer* sharedAccelerometer();// { return NULL; }
    void setDelegate(CCAccelerometerDelegate* pDelegate);// {CC_UNUSED_PARAM(pDelegate);}
	void update(float x, float y, float z, long sensorTimeStamp);

//private:
	//static Windows::Devices::Sensors::Accelerometer^ m_deviceAccelerometer;
	CCAccelerometerDelegate* m_pAccelDelegate;
	CCAcceleration m_obAccelerationValue;


};

}//namespace   cocos2d 

#endif
