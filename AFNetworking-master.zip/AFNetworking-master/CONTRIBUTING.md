GitHub Issues is for reporting bugs in AFNetworking and discussing features. 
Please check our [Frequently Asked Questions](https://github.com/AFNetworking/AFNetworking/wiki/AFNetworking-FAQ) page and [past issues](https://github.com/AFNetworking/AFNetworking/issues?state=closed) before reporting any bugs.

Please do not post any general usage questions to GitHub Issues, but instead take them to an appropriate forum such as [Stack Overflow](http://stackoverflow.com/questions/tagged/afnetworking).
