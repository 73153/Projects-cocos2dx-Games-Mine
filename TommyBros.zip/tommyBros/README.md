# TommyBros
This is a two player platformer made for the iPad using cocos2D. It supports remote joypads, check out [iJPad](https://github.com/blender/iJPad) to turn you iPhoe/iPod tuch into one of such pads.
