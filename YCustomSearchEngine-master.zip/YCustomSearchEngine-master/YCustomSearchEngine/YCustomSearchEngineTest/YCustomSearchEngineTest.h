#import <SenTestingKit/SenTestingKit.h>
#import "YCustomSearchEngine.h"

@interface YCustomSearchEngineTest : SenTestCase<YCustomSearchEngineDelegate>

@end
