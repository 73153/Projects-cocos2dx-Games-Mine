#import <Foundation/Foundation.h>

@interface NSDictionary (Helpers)

-(NSString*) urlEncodedString;

@end