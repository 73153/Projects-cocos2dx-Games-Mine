#import "GameLayer.h"

@implementation GameLayer

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	GameLayer *layer = [GameLayer node];
	[scene addChild: layer];
	return scene;
}

#pragma mark -
#pragma mark Callback

-(void)checkBoxValue:(NSNumber *)value {   
    BOOL boxChecked = [value boolValue];
    
    if (boxChecked) {
        NSLog(@"box is checked");
    } else {
        NSLog(@"box is unchecked");
    }
}

#pragma mark -
#pragma mark Setup

-(void)setupCheckBox {        
    
    myCheckBox = [BBCheckBox checkBoxWithDelegate:self callback:@selector(checkBoxValue:) uncheckedImage:@"unmarked.png" checkedImage:@"marked.png" isChecked:YES];
    
    myCheckBox.position=ccp(240,160);
    myCheckBox.scale = 0.6;
    [self addChild:myCheckBox];
}

#pragma mark -
#pragma mark Initialization
-(id) init
{
	if( (self=[super initWithColor:ccc4(50, 100, 150, 255)]) ) { 
        
        [self setupCheckBox];
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}
@end
