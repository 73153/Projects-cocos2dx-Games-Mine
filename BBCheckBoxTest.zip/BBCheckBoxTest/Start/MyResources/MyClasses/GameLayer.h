#import "cocos2d.h"
#import "BBCheckBox.h"

@interface GameLayer : CCLayerColor
{
    BBCheckBox *myCheckBox;
}

+(CCScene *) scene;

@end
