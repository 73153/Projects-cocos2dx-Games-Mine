//  AppDelegate.m

#import "cocos2d.h"

#import "AppDelegate.h"
#import "GameConfig.h"
#import "GameLayer.h"
#import "RootViewController.h"

@implementation AppDelegate

@synthesize window;

- (void)tweakSettings
{
	window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
	if( ! [CCDirector setDirectorType:kCCDirectorTypeDisplayLink] )
		[CCDirector setDirectorType:kCCDirectorTypeDefault];
	
	CCDirector *director = [CCDirector sharedDirector];

	viewController = [[RootViewController alloc] initWithNibName:nil bundle:nil];
	viewController.wantsFullScreenLayout = YES;
	
	EAGLView *glView = [EAGLView viewWithFrame:[window bounds]
								   pixelFormat:kEAGLColorFormatRGB565	// kEAGLColorFormatRGBA8
								   depthFormat:0];						// GL_DEPTH_COMPONENT16_OES
						
	[director setOpenGLView:glView];
	[director setDeviceOrientation:kCCDeviceOrientationLandscapeLeft]; //use this if you want landscape and comment out next line.
    //[director setDeviceOrientation:kCCDeviceOrientationPortrait]; //use this if you want portrait and comment out previos line.

	[director setAnimationInterval:1.0/60];
	[director setDisplayFPS:NO];
		
	[viewController setView:glView];
	[window addSubview: viewController.view];
	[window makeKeyAndVisible];
	
	// Default texture format for PNG/BMP/TIFF/JPEG/GIF images
	// It can be RGBA8888, RGBA4444, RGB5_A1, RGB565' You can change anytime.
	[CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA8888];
}

- (void) applicationDidFinishLaunching:(UIApplication*)application
{
    [self tweakSettings];
	[[CCDirector sharedDirector] runWithScene: [GameLayer scene]];
}


- (void)applicationWillResignActive:(UIApplication *)application {
	[[CCDirector sharedDirector] pause];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	[[CCDirector sharedDirector] resume];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
	[[CCDirector sharedDirector] purgeCachedData];
}

-(void) applicationDidEnterBackground:(UIApplication*)application {
	[[CCDirector sharedDirector] stopAnimation];
}

-(void) applicationWillEnterForeground:(UIApplication*)application {
	[[CCDirector sharedDirector] startAnimation];
}

- (void)applicationWillTerminate:(UIApplication *)application {
	CCDirector *director = [CCDirector sharedDirector];	
	[[director openGLView] removeFromSuperview];
	[viewController release];
	[window release];	
	[director end];	
}

- (void)applicationSignificantTimeChange:(UIApplication *)application {
	[[CCDirector sharedDirector] setNextDeltaTimeZero:YES];
}

- (void)dealloc {
	[[CCDirector sharedDirector] release];
	[window release];
	[super dealloc];
}

@end
